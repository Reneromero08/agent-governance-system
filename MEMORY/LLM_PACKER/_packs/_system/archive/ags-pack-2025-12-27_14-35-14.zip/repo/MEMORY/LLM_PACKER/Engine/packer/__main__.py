if __name__ == "__main__":
    from .cli import main
    import sys
    sys.exit(main())
