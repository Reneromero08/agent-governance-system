# Snapshot Entrypoints

Key entrypoints for `AGS`:

- `repo/AGENTS.md`
- `repo/CANON/CONTRACT.md`
- `repo/MAPS/ENTRYPOINTS.md`
- `repo/SKILLS/`
- `repo/CONTRACTS/runner.py`

Notes:
- `FULL/` contains single-file bundles.
- `SPLIT/` contains chunked sections.
