# START HERE

This snapshot is meant to be shared with any LLM to continue work on `CATALYTIC-DPT (MAIN, no LAB)`.

## Read order
1) `repo/CATALYTIC-DPT/AGENTS.md`
2) `repo/CATALYTIC-DPT/README.md`
3) `repo/CATALYTIC-DPT/ROADMAP_V2.1.md`
4) `repo/CATALYTIC-DPT/swarm_config.json`
5) `repo/CATALYTIC-DPT/CHANGELOG.md`
6) `meta/ENTRYPOINTS.md`

## Notes
- Use `FULL/` for single-file output or `SPLIT/` for sectioned reading.
