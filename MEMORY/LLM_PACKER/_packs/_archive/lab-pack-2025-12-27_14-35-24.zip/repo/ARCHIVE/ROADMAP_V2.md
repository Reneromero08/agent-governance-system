# CATALYTIC-DPT ROADMAP v2
Date: 2025-12-24  
Status: Active  
Supersedes: ROADMAP.md (keep as historical intent)

Principle: Prove the thesis before expanding scope. Once proofs exist, treat them as the contract.

---

## What changed from v1
- SPECTRUM-02 and SPECTRUM-03 are now **shipped**, so the roadmap starts from “bundle and chain proofs already exist”.
- Validator identity is now part of integrity (validator semver + deterministic build fingerprint).
- Phase 0 is **partially real**: the schema spec exists, but the actual JSON Schema files are not present yet.

---

## Definitions (use these words consistently)
- **Data Plane**: raw bytes that matter (outputs, artifacts, blobs). Never trust narratives about it.
- **Control Plane**: minimal metadata needed to verify and resume (hashes, manifests, job specs, receipts).
- **Bundle (SPECTRUM-02)**: the minimum set of artifacts required to verify a run without logs or transcripts.
- **Chain (SPECTRUM-03)**: an ordered sequence of bundles whose dependencies are proven only via artifacts.

---

## Already shipped (as of Pack 1.11)
### Integrity and resume (core)
- [x] **SPECTRUM-02 bundle emission** with `OUTPUT_HASHES.json` and bundle verification that fails closed.
- [x] **Adversarial resume fixtures** that prove resume works without history.
- [x] **SPECTRUM-03 chain verification** that verifies a sequence of bundles, rejects invalid references, and does not depend on logs/tmp/transcripts.

### Validator identity and determinism
- [x] Bundle verification binds to:
  - `validator_semver`
  - `validator_build_id` (deterministic build fingerprint, e.g. commit SHA or file hash)
- [x] **Strict mode** can reject bundles if validator identity mismatches.

### Hardening and security properties
- [x] Tamper evidence via hash mismatch.
- [x] Missing output detection.
- [x] Symlink escape protection (path constraints).
- [x] Structured error vectors and tests for common integrity failures.

### Skills and orchestration hygiene (repo usability)
- [x] Skills organized with scripts/assets/references patterns and import fixes.
- [x] MCP stdio server supports skill execution entrypoints.

### Known hygiene issue (fix soon)
- [ ] Changelog date ordering is inconsistent (1.11 dated 2024-12-24 while adjacent versions are 2025-12-24).  
  Treat changelog as an audit artifact and normalize the dates.

---

## Current phase
**Phase 0.5: Make the contract executable.**  
The schema spec exists in `SCHEMAS/README.md`, but the actual schema files referenced there are missing. Phase 1+ cannot be treated as canon until the schemas exist and are tested.

---

# Phase 0: Freeze the Contract (schemas + fixtures)
Goal: Turn the schema spec into real JSON Schemas with fixtures and a self-validation testbench.

Deliverables
- [ ] `SCHEMAS/jobspec.schema.json`
- [ ] `SCHEMAS/validation_error.schema.json`
- [ ] `SCHEMAS/ledger.schema.json`
- [ ] `SCHEMAS/examples/` (small, human-legible example objects)
- [ ] `FIXTURES/phase0/valid/` and `FIXTURES/phase0/invalid/`

Rules
- JSON Schema Draft 7 (or newer if the validator already supports it, but pick one and lock it).
- No ambiguous fields. Every optional field must have a default behavior documented.
- Errors must map into `validation_error.schema.json` with stable codes.

Tests (exit criteria)
- [ ] `tests/test_phase0_schemas.py` (or equivalent) that:
  - validates every valid fixture
  - rejects every invalid fixture
  - validates the schemas themselves (schema-of-schemas check if supported)
- [ ] CI runner executes schema tests as a gating step.

Exit
- Schemas exist, fixtures exist, tests exist, and the validator emits stable error vectors.

---

# Phase 1: CATLAB primitives (PoC that uses the shipped proofs)
Goal: Implement the smallest real catalytic kernel that can produce runs with receipts, roots, and restoration proofs, reusing SPECTRUM-02/03 as the verification substrate.

Workstreams

## 1) Content Addressable Store (CAS)
Deliverables
- [ ] `PRIMITIVES/cas_store.py`
  - `put(bytes) -> hash`
  - `get(hash) -> bytes`
  - deterministic path layout (no timestamps)
- [ ] `PRIMITIVES/path_normalize.py` (posix paths, repo-relative)

Acceptance
- [ ] same bytes always produce same hash
- [ ] store is stable across OS and shells (path normalization)
- [ ] fixtures include adversarial bytes and edge cases (empty file, large file, unicode paths)

## 2) Merkle roots per domain
Deliverables
- [ ] `PRIMITIVES/merkle.py`
  - `leaf = H(path + '\0' + bytes_hash)`
  - deterministic ordering (sorted by normalized path)
  - `root(leaves) -> root_hash`
- [ ] Domain manifest format: `{ path: bytes_hash }`

Acceptance
- [ ] root stable across runs and machines given identical inputs
- [ ] fixtures prove ordering determinism and rejection on collisions/duplicates

## 3) Ledger (append-only receipts)
Deliverables
- [ ] `PRIMITIVES/ledger.py` that emits records matching `ledger.schema.json`
- [ ] Each record includes:
  - job_id, phase, timestamp (optional but if included must be controlled)
  - inputs (hashes), outputs (hashes), domain roots
  - validator identity (semver + build id)

Acceptance
- [ ] ledger is append-only
- [ ] re-running an identical job yields identical receipt fields except fields explicitly allowed to vary

## 4) Restoration proof runner
Deliverables
- [ ] `TOOLS/prove_restore.py`
  - Given a bundle or chain, re-materialize outputs from CAS (or verify existing outputs)
  - Compare against `OUTPUT_HASHES.json`
  - Emit a proof summary that is itself hashable

Acceptance
- [ ] “restore then verify” passes on fixtures
- [ ] tamper and missing-file cases fail closed

Exit (Phase 1)
- A PoC job can:
  1) run a transformation
  2) emit a bundle
  3) verify the bundle
  4) restore or re-verify using only artifacts
  5) pass deterministic fixtures

---

# Phase 2: Swarm parallelism (safe learning, no corruption)
Goal: Run many jobs in parallel, then accept exactly one deterministic update without breaking integrity.

Deliverables
- [ ] Worker protocol: workers run jobs and emit bundles only
- [ ] Reducer protocol: reducer chooses one accepted outcome and writes one append-only ledger update
- [ ] Deterministic tie-break rules (no “best vibe”):
  - stable score function
  - stable ordering
  - stable acceptance threshold

Acceptance
- [ ] Order of worker completion does not change acceptance
- [ ] Re-running the same batch yields identical accepted update
- [ ] Any bundle mismatch rejects the run, even if score is high

Exit
- Parallel evaluation increases throughput without introducing nondeterminism.

---

# Phase 3: Substrate offload adapters (browser, DB, CLI)
Goal: Treat external substrates as deterministic executors with hash I/O and full replay.

Deliverables
- [ ] `ADAPTERS/cli_exec.py`
- [ ] `ADAPTERS/browser_exec.py`
- [ ] `ADAPTERS/db_exec.py`

Contract
- Every adapter must accept inputs by hash and emit outputs by hash.
- Every adapter must record substrate version and execution recipe into the ledger.

Acceptance
- [ ] At least two substrates demonstrate end-to-end:
  inputs (hashes) -> adapter -> outputs (hashes) -> bundle -> verify -> restore proof

---

# Phase 4: Runtime hardening (fail-closed correctness)
Goal: Make “incorrect success” impossible.

Deliverables
- [ ] Forbidden overlap checks both directions:
  - outputs must not overlap inputs
  - inputs must not overlap outputs
  - durable paths must be inside allowed root(s)
- [ ] Stronger path rules:
  - no absolute paths
  - no traversal
  - no symlink escape

Acceptance
- [ ] Fuzz fixtures for path tricks and overlap edge cases
- [ ] Every hard violation stops the run

---

# Phase 5: Catalytic pipelines (multi-step, one proof boundary)
Goal: Multi-step runs where the entire pipeline is verifiable via one chain.

Deliverables
- [ ] Pipeline runner that composes jobs:
  `step_i OUTPUT_HASHES` become `step_{i+1} inputs`
- [ ] Pipeline emits:
  - per-step bundles
  - chain receipt
  - final proof artifact

Acceptance
- [ ] 3-step pipeline demo:
  1) index
  2) transform
  3) validate + emit
- [ ] End-to-end chain verification passes and restoration proof passes

---

# Phase 6: Integrate with AGS proper
Goal: Wrap one real AGS operation in catalytic verification, proving the integration boundary.

Deliverables
- [ ] Convert one high-risk skill run into:
  - JobSpec input
  - deterministic execution
  - bundle emission
  - bundle verification gate
- [ ] Add documentation for how AGS calls catalytic runtime

Acceptance
- [ ] One real operation runs catalytically and can be resumed by bundles only.

---

# Phase 7: Optional upgrades (only if needed)
- [ ] Hierarchical Merkle proofs for incremental verification
- [ ] Semantic validators (typecheckers, dependency graphs) as optional layers, never replacements for byte-level proofs

---

## Non-goals (stay disciplined)
- [ ] No full repo packing of code bodies as “context”
- [ ] No large-model finetuning as a substitute for proofs
- [ ] No sweeping refactors unrelated to integrity contracts
- [ ] No expanding canon without tests

---

## Build order (dependency graph)
1) Phase 0 schemas + fixtures  
2) CAS + path normalization  
3) Merkle + domain roots  
4) Ledger + receipts  
5) Restoration proof runner  
6) Swarm parallelism  
7) Substrate adapters  
8) Hardening  
9) Pipelines  
10) AGS integration

---

## Next actions (smallest high-impact sequence)
- [ ] Write the three schema files under `SCHEMAS/` exactly as referenced in `SCHEMAS/README.md`
- [ ] Add Phase 0 fixtures and tests
- [ ] Add/confirm a single canonical CLI entrypoint for:
  - verify bundle
  - verify chain
  - prove restore
- [ ] Fix changelog date ordering (if changelog is treated as an audit artifact)
