# START HERE (LAB)

This snapshot contains ALL research and experimental code under `CATALYTIC-DPT/LAB`. It is volatile.

## Read order
1) `repo/CATALYTIC-DPT/LAB/ROADMAP_PATCH_SEMIOTIC.md`
2) `repo/CATALYTIC-DPT/LAB/COMMONSENSE/`
3) `repo/CATALYTIC-DPT/LAB/MCP/`

## Notes
- Use `FULL/` for single-file output or `SPLIT/` for sectioned reading.
