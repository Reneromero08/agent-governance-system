# Commit Chunks Plan

All changes need to be committed in chronological order. Each chunk requires a CHANGELOG entry before committing.

---

## Pre-Commit Checklist

Before each commit:
1. Stage the files listed in the chunk
2. Add entry to `CANON/CHANGELOG.md` under appropriate version
3. Update `CANON/VERSIONING.md` to match the version
4. Stage CHANGELOG.md and VERSIONING.md
5. Commit with descriptive message

---

## Chunk 1: MCP Startup Skill

**Version:** 2.9.0
**Date:** 2025-12-26 (~4:30 AM)
**Type:** New skill

### Files to Stage
```
CATALYTIC-DPT/SKILLS/mcp-startup/SKILL.md
CATALYTIC-DPT/SKILLS/mcp-startup/README.md
CATALYTIC-DPT/SKILLS/mcp-startup/INSTALLATION.md
CATALYTIC-DPT/SKILLS/mcp-startup/USAGE.md
CATALYTIC-DPT/SKILLS/mcp-startup/INDEX.md
CATALYTIC-DPT/SKILLS/mcp-startup/CHECKLIST.md
CATALYTIC-DPT/SKILLS/mcp-startup/MODEL-SETUP.md
CATALYTIC-DPT/SKILLS/mcp-startup/QUICKREF.txt
CATALYTIC-DPT/SKILLS/mcp-startup/scripts/startup.ps1
CATALYTIC-DPT/SKILLS/mcp-startup/scripts/startup.py
```

### Git Command
```bash
git add CATALYTIC-DPT/SKILLS/mcp-startup/
```

### Changelog Section
Add under `## [2.9.0] - 2025-12-26` with `### Added`

---

## Chunk 2: LLM Packer Refactor - New Modular Structure

**Version:** 2.10.0
**Date:** 2025-12-26 (~10:00 AM - 6:30 PM)
**Type:** Major refactor

### Files to Stage - New Packer Modules
```
MEMORY/LLM_PACKER/Engine/packer/__init__.py
MEMORY/LLM_PACKER/Engine/packer/__main__.py
MEMORY/LLM_PACKER/Engine/packer/cli.py
MEMORY/LLM_PACKER/Engine/packer/core.py
MEMORY/LLM_PACKER/Engine/packer/archive.py
MEMORY/LLM_PACKER/Engine/packer/lite.py
MEMORY/LLM_PACKER/Engine/packer/split.py
```

### Files to Stage - Migration Tooling
```
MEMORY/LLM_PACKER/Engine/packer_legacy_backup.py
MEMORY/LLM_PACKER/Engine/migrate_phase1.py
MEMORY/LLM_PACKER/Engine/verify_phase1.py
MEMORY/LLM_PACKER/Engine/refactor_packer.py
MEMORY/LLM_PACKER/Engine/scan_old_refs.py
MEMORY/LLM_PACKER/Engine/run_tests.cmd
```

### Files to Stage - New Launchers & Icons
```
MEMORY/LLM_PACKER/1-AGS-PACK.lnk
MEMORY/LLM_PACKER/2-CAT-PACK.lnk
MEMORY/LLM_PACKER/3-LAB-PACK.lnk
MEMORY/LLM_PACKER/Engine/3-LAB-PACK.cmd
MEMORY/LLM_PACKER/Engine/lab.ico
```

### Files to Stage - Updated CMD/PS Scripts
```
MEMORY/LLM_PACKER/Engine/2-CAT-PACK.cmd
MEMORY/LLM_PACKER/Engine/1-AGS-PACK.cmd
MEMORY/LLM_PACKER/Engine/3-LAB-PACK.cmd
MEMORY/LLM_PACKER/Engine/pack.ps1
```

### Files to Stage - Packer Documentation
```
MEMORY/LLM_PACKER/README.md
MEMORY/LLM_PACKER/DETERMINISM.md
MEMORY/LLM_PACKER/CHANGELOG.md
MEMORY/PACKER_ROADMAP.md
```

### Git Command
```bash
git add MEMORY/LLM_PACKER/Engine/packer/
git add MEMORY/LLM_PACKER/Engine/packer_legacy_backup.py
git add MEMORY/LLM_PACKER/Engine/migrate_phase1.py
git add MEMORY/LLM_PACKER/Engine/verify_phase1.py
git add MEMORY/LLM_PACKER/Engine/refactor_packer.py
git add MEMORY/LLM_PACKER/Engine/scan_old_refs.py
git add MEMORY/LLM_PACKER/Engine/run_tests.cmd
git add MEMORY/LLM_PACKER/1-AGS-PACK.lnk
git add MEMORY/LLM_PACKER/2-CAT-PACK.lnk
git add MEMORY/LLM_PACKER/3-LAB-PACK.lnk
git add MEMORY/LLM_PACKER/Engine/3-LAB-PACK.cmd
git add MEMORY/LLM_PACKER/Engine/lab.ico
git add MEMORY/LLM_PACKER/Engine/2-CAT-PACK.cmd
git add MEMORY/LLM_PACKER/Engine/1-AGS-PACK.cmd
git add MEMORY/LLM_PACKER/Engine/pack.ps1
git add MEMORY/LLM_PACKER/README.md
git add MEMORY/LLM_PACKER/DETERMINISM.md
git add MEMORY/LLM_PACKER/CHANGELOG.md
git add MEMORY/PACKER_ROADMAP.md
```

### Changelog Section
Add under `## [2.10.0] - 2025-12-26` with `### Added` for new structure and `### Changed` for updates

---

## Chunk 3: Smoke Test & Skill Updates (Packer References)

**Version:** Part of 2.10.0
**Date:** 2025-12-26 (~6:30 PM)
**Type:** Updated references to new packer

### Files to Stage - Smoke Test Fixtures
```
SKILLS/llm-packer-smoke/SKILL.md
SKILLS/llm-packer-smoke/run.py
SKILLS/llm-packer-smoke/fixtures/basic/input.json
SKILLS/llm-packer-smoke/fixtures/basic/expected.json
SKILLS/llm-packer-smoke/fixtures/catalytic-dpt/input.json
SKILLS/llm-packer-smoke/fixtures/catalytic-dpt/expected.json
SKILLS/llm-packer-smoke/fixtures/catalytic-dpt-split-lite/input.json
SKILLS/llm-packer-smoke/fixtures/catalytic-dpt-split-lite/expected.json
SKILLS/llm-packer-smoke/fixtures/catalytic-dpt-lab-split-lite/input.json
SKILLS/llm-packer-smoke/fixtures/catalytic-dpt-lab-split-lite/expected.json
SKILLS/llm-packer-smoke/fixtures/lite/input.json
SKILLS/llm-packer-smoke/fixtures/lite/expected.json
SKILLS/llm-packer-smoke/fixtures/split-lite/input.json
SKILLS/llm-packer-smoke/fixtures/split-lite/expected.json
```

### Files to Stage - Pack Validate
```
SKILLS/pack-validate/SKILL.md
SKILLS/pack-validate/run.py
```

### Files to Stage - ADR Updates
```
CONTEXT/decisions/ADR-002-llm-packs-under-llm-packer.md
CONTEXT/decisions/ADR-013-llm-packer-lite-split-lite.md
```

### Files to Stage - Guide Updates
```
CONTEXT/guides/SHIPPING.md
```

### Git Command
```bash
git add SKILLS/llm-packer-smoke/
git add SKILLS/pack-validate/
git add CONTEXT/decisions/ADR-002-llm-packs-under-llm-packer.md
git add CONTEXT/decisions/ADR-013-llm-packer-lite-split-lite.md
git add CONTEXT/guides/SHIPPING.md
```

### Changelog Section
Include in 2.10.0 under `### Changed` - Updated smoke test fixtures, ADRs, guides

**NOTE:** Can be combined with Chunk 2 into a single 2.10.0 commit

---

## Chunk 4: Documentation Cleanup

**Version:** 2.11
**Date:** 2025-12-26 to 2025-12-27 (~6:40 PM - 7:00 AM)
**Type:** Documentation updates

### Files to Stage
```
AGS_ROADMAP_MASTER.md
CONTEXT/archive/planning/AGS_3.0_ROADMAP.md
CONTEXT/archive/planning/AGS_MASTER_TODO-2025-12-21.md
CONTEXT/archive/planning/REPO_FIXES_TASKS.md
```

### Git Command
```bash
git add AGS_ROADMAP_MASTER.md
git add CONTEXT/archive/planning/AGS_3.0_ROADMAP.md
git add CONTEXT/archive/planning/AGS_MASTER_TODO-2025-12-21.md
git add CONTEXT/archive/planning/REPO_FIXES_TASKS.md
```

### Changelog Section
Include in 2.11 under `### Changed` - Updated planning docs

**NOTE:** Can be combined with Chunk 2 & 3 into a single 2.10.0 commit

---

## Chunk 5: MAPS Updates

**Version:** 2.11.2
**Date:** 2025-12-27 (~7:00 AM)
**Type:** Map documentation updates for new packer architecture

### Files to Stage
```
MAPS/SYSTEM_MAP.md
MAPS/DATA_FLOW.md
MAPS/FILE_OWNERSHIP.md
MAPS/ENTRYPOINTS.md
```

### Git Command
```bash
git add MAPS/SYSTEM_MAP.md
git add MAPS/DATA_FLOW.md
git add MAPS/FILE_OWNERSHIP.md
git add MAPS/ENTRYPOINTS.md
```

### Changelog Section
Include in 2.11.2 under `### Changed` - Updated MAPS for new architecture

**NOTE:** Can be combined with Chunks 2, 3, 4 into a single 2.10.0 commit

---

## Chunk 6: Bug Reports & Analysis

**Version:** 2.11.5
**Date:** 2025-12-27 (~6:45 AM - 7:15 AM)
**Type:** New research documentation

### Files to Stage
```
CATALYTIC-DPT/LAB/RESEARCH/SWARM_BUG_REPORT.md
CATALYTIC-DPT/LAB/RESEARCH/CANON_COMPRESSION_ANALYSIS.md
CATALYTIC-DPT/LAB/RESEARCH/SKILL and TOOLS BUG_REPORT.md
```

### Git Command
```bash
git add "CATALYTIC-DPT/LAB/RESEARCH/SWARM_BUG_REPORT.md"
git add "CATALYTIC-DPT/LAB/RESEARCH/CANON_COMPRESSION_ANALYSIS.md"
git add "CATALYTIC-DPT/LAB/RESEARCH/SKILL and TOOLS BUG_REPORT.md"
```

### Changelog Section
Add under `## [2.11.5] - 2025-12-27` with `### Added` - Research documentation and bug reports

---

## Chunk 7: Gitignore Update

**Version:** Part of 2.11.5
**Date:** 2025-12-27 (~7:15 AM)
**Type:** Configuration update

### Files to Stage
```
.gitignore
```

### Git Command
```bash
git add .gitignore
```

### Changelog Section
Include in 2.11.5 under `### Changed` - Updated .gitignore to exclude experimental folders

**NOTE:** Can be combined with Chunk 6 into a single 2.11.0 commit

---

## Recommended Commit Strategy

Combine chunks into 3 logical commits:

### Commit A: v2.9.0 - MCP Startup Skill
- Chunk 1

### Commit B: v2.10.0 - LLM Packer Refactor
- Chunk 2 (new packer modules)
- Chunk 3 (skill/fixture updates)
- Chunk 4 (doc cleanup)
- Chunk 5 (MAPS updates)

### Commit C: v2.11.5 - Research & Cleanup
- Chunk 6 (bug reports)
- Chunk 7 (gitignore)

---

## Final Versioning

After all commits:
- `CANON/VERSIONING.md` should show `canon_version: 2.11.5`
- `CANON/CHANGELOG.md` should have entries for 2.9.0, 2.10.0, 2.11, 2.11.2, 2.11.5

---

*Generated: 2025-12-27*
