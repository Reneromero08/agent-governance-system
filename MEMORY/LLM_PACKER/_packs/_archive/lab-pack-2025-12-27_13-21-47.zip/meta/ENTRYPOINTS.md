# Snapshot Entrypoints

Key entrypoints for `CATALYTIC-DPT (LAB)`:

- `repo/CATALYTIC-DPT/LAB/`
- `repo/CATALYTIC-DPT/LAB/ROADMAP_PATCH_SEMIOTIC.md`
- `repo/CATALYTIC-DPT/LAB/COMMONSENSE/`
- `repo/CATALYTIC-DPT/LAB/MCP/`

Notes:
- `FULL/` contains single-file bundles.
- `SPLIT/` contains chunked sections.
