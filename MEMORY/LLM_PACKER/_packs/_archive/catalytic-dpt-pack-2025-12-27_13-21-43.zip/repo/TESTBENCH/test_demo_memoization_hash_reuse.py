from __future__ import annotations

import json
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
DEMO_ROOT = REPO_ROOT / "CONTRACTS" / "_runs" / "_demos" / "memoization_hash_reuse"


def test_phase2_demo_artifacts_are_falsifiable() -> None:
    baseline = DEMO_ROOT / "baseline"
    reuse = DEMO_ROOT / "reuse"

    assert (baseline / "PROOF.json").exists()
    assert (baseline / "LEDGER.jsonl").exists()
    assert (baseline / "DEREF_STATS.json").exists()

    assert (reuse / "PROOF.json").exists()
    assert (reuse / "LEDGER.jsonl").exists()
    assert (reuse / "DEREF_STATS.json").exists()

    # Proof identity: byte-identical.
    assert (baseline / "PROOF.json").read_bytes() == (reuse / "PROOF.json").read_bytes()

    # Memoization hit must be observable.
    assert "memoization:hit" in (reuse / "LEDGER.jsonl").read_text(encoding="utf-8")

    # Hash-first dereference must be measurably smaller (bytes read) in reuse.
    b = json.loads((baseline / "DEREF_STATS.json").read_text(encoding="utf-8"))
    r = json.loads((reuse / "DEREF_STATS.json").read_text(encoding="utf-8"))

    assert b["deref_count"] > r["deref_count"]
    assert b["bytes_read_total"] > r["bytes_read_total"]

