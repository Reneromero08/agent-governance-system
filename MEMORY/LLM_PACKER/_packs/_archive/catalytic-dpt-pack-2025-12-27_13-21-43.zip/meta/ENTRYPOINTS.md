# Snapshot Entrypoints

Key entrypoints for `CATALYTIC-DPT (MAIN, no LAB)`:

- `repo/CATALYTIC-DPT/AGENTS.md`
- `repo/CATALYTIC-DPT/README.md`
- `repo/CATALYTIC-DPT/ROADMAP_V2.1.md`
- `repo/CATALYTIC-DPT/swarm_config.json`
- `repo/CATALYTIC-DPT/TESTBENCH/`

Notes:
- `FULL/` contains single-file bundles.
- `SPLIT/` contains chunked sections.
