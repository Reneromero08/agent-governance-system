#!/usr/bin/env python3

"""
Contract runner for the Agent Governance System.

This script discovers and runs fixtures under the `CONTRACTS/fixtures/` directory
and skill fixtures under `SKILLS/*/fixtures/`. A fixture consists of an input
(`input.json` or other files) and an expected output (`expected.json`).
The runner executes the relevant skill or validation script, then compares
actual output to expected output.

Any fixture that fails will cause the runner to exit with a non-zero exit code.
"""

import subprocess
import sys
from pathlib import Path
from typing import List, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FIXTURES_DIR = Path(__file__).parent / "fixtures"
SKILLS_DIR = PROJECT_ROOT / "SKILLS"
RUNS_DIR = Path(__file__).parent / "_runs"
DEFAULT_VALIDATE = SKILLS_DIR / "_TEMPLATE" / "validate.py"


def run_process(args: List[str]) -> subprocess.CompletedProcess:
    return subprocess.run(args, capture_output=True, text=True)


def run_validation(validate_script: Path, actual_path: Path, expected_path: Path) -> subprocess.CompletedProcess:
    return run_process([
        sys.executable,
        str(validate_script),
        str(actual_path),
        str(expected_path),
    ])


def iter_contract_inputs() -> List[Path]:
    return sorted(FIXTURES_DIR.rglob("input.json"))


def iter_skill_inputs() -> List[Tuple[Path, Path]]:
    fixtures = []
    for skill_dir in sorted(SKILLS_DIR.iterdir()):
        if not skill_dir.is_dir() or skill_dir.name.startswith("_"):
            continue
        fixtures_root = skill_dir / "fixtures"
        if not fixtures_root.exists():
            continue
        for input_path in sorted(fixtures_root.rglob("input.json")):
            fixtures.append((skill_dir, input_path))
    return fixtures


def run_contract_fixture(input_path: Path) -> int:
    fixture_dir = input_path.parent
    expected = fixture_dir / "expected.json"
    if not expected.exists():
        print(f"Skipping {fixture_dir}: no expected.json")
        return 0
    if not DEFAULT_VALIDATE.exists():
        print(f"Missing default validator at {DEFAULT_VALIDATE}")
        return 1
    print(f"Running contract fixture in {fixture_dir}.")
    result = run_validation(DEFAULT_VALIDATE, input_path, expected)
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
    else:
        print(result.stdout)
    return 0 if result.returncode == 0 else 1


def run_skill_fixture(skill_dir: Path, input_path: Path) -> int:
    fixture_dir = input_path.parent
    expected = fixture_dir / "expected.json"
    if not expected.exists():
        print(f"Skipping {fixture_dir}: no expected.json")
        return 0

    run_script = skill_dir / "run.py"
    validate_script = skill_dir / "validate.py"
    if not run_script.exists():
        print(f"Missing run.py for skill {skill_dir.name} at {run_script}")
        return 1
    if not validate_script.exists():
        validate_script = DEFAULT_VALIDATE

    relative_fixture = fixture_dir.relative_to(skill_dir / "fixtures")
    output_dir = RUNS_DIR / "fixtures" / skill_dir.name / relative_fixture
    output_dir.mkdir(parents=True, exist_ok=True)
    actual_path = output_dir / "actual.json"

    print(f"Running skill fixture in {fixture_dir}.")
    result = run_process([
        sys.executable,
        str(run_script),
        str(input_path),
        str(actual_path),
    ])
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
        return 1

    result = run_validation(validate_script, actual_path, expected)
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
        return 1
    print(result.stdout)
    return 0


def run_fixtures() -> int:
    failures = 0
    for input_path in iter_contract_inputs():
        failures += run_contract_fixture(input_path)
    for skill_dir, input_path in iter_skill_inputs():
        failures += run_skill_fixture(skill_dir, input_path)
    return failures


if __name__ == "__main__":
    failures = run_fixtures()
    if failures:
        print(f"{failures} fixture(s) failed")
        sys.exit(1)
    print("All fixtures passed")
    sys.exit(0)
