#!/usr/bin/env python3
"""
Smoke fixture skill for the LLM packer.

Creates a scoped pack with optional FULL/LITE outputs and checks the generated
files mentioned by contracts.
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from MEMORY.LLM_PACKER.Engine.packer import SCOPES, SCOPE_AGS, make_pack
from TOOLS.skill_runtime import ensure_canon_compat

DEFAULT_LOGROOT = PROJECT_ROOT / "CONTRACTS" / "_runs"
DEFAULT_PACK_ROOT = PROJECT_ROOT / "MEMORY" / "LLM_PACKER" / "_packs"

DEFAULT_MAX_BYTES = 50 * 1024 * 1024
DEFAULT_MAX_ENTRY = 2 * 1024 * 1024
DEFAULT_MAX_ENTRIES = 50_000


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def resolve_out_dir(raw: str) -> Path:
    path = Path(raw)
    if path.is_absolute():
        return path
    return (PROJECT_ROOT / path).resolve()


def ensure_under_packs(path: Path) -> None:
    try:
        path.resolve().relative_to(DEFAULT_PACK_ROOT.resolve())
    except ValueError as exc:
        raise ValueError(f"out_dir must be under {DEFAULT_PACK_ROOT}: {path}") from exc


def ensure_runner_writes_under_runs(path: Path) -> None:
    try:
        path.resolve().relative_to(DEFAULT_LOGROOT.resolve())
    except ValueError as exc:
        raise ValueError(f"Runner output must live under CONTRACTS/_runs/: {path}") from exc


def parse_scope(config: Dict[str, Any]) -> str:
    scope_key = str(config.get("scope", SCOPE_AGS.key)).strip()
    if scope_key not in SCOPES:
        raise ValueError(f"Unknown scope: {scope_key}")
    return scope_key


def parse_int(config: Dict[str, Any], key: str, default: int) -> int:
    raw = config.get(key)
    if raw is None:
        return default
    return int(raw)


def build_required_split(scope_key: str) -> List[str]:
    if scope_key == SCOPE_AGS.key:
        chunks = [
            "AGS-00_INDEX.md",
            "AGS-01_CANON.md",
            "AGS-02_ROOT.md",
            "AGS-03_MAPS.md",
            "AGS-04_CONTEXT.md",
            "AGS-05_SKILLS.md",
            "AGS-06_CONTRACTS.md",
            "AGS-07_SYSTEM.md",
        ]
    elif scope_key == "catalytic-dpt":
        chunks = [
            "CATALYTIC-DPT-00_INDEX.md",
            "CATALYTIC-DPT-01_DOCS.md",
            "CATALYTIC-DPT-02_CONFIG.md",
            "CATALYTIC-DPT-03_TESTBENCH.md",
            "CATALYTIC-DPT-04_SYSTEM.md",
        ]
    else:
        chunks = [
            "CATALYTIC-DPT-LAB-00_INDEX.md",
            "CATALYTIC-DPT-LAB-01_DOCS.md",
            "CATALYTIC-DPT-LAB-02_COMMONSENSE.md",
            "CATALYTIC-DPT-LAB-03_MCP.md",
            "CATALYTIC-DPT-LAB-04_RESEARCH.md",
            "CATALYTIC-DPT-LAB-05_ARCHIVE.md",
            "CATALYTIC-DPT-LAB-06_SYSTEM.md",
        ]
    return [f"SPLIT/{chunk}" for chunk in chunks]


def build_full_paths(scope_key: str, stamp: str) -> List[str]:
    prefix = SCOPES[scope_key].file_prefix
    base = [
        f"{prefix}-FULL-{stamp}.md",
        f"{prefix}-FULL-TREEMAP-{stamp}.md",
    ]
    return [f"FULL/{path}" for path in base]


def build_lite_paths(scope_key: str) -> List[str]:
    prefix = SCOPES[scope_key].file_prefix
    return [f"LITE/{prefix}-00_INDEX.md"]


def main(input_path: Path, output_path: Path) -> int:
    if not ensure_canon_compat(Path(__file__).resolve().parent):
        return 1
    try:
        config = load_json(input_path)
    except Exception as exc:
        print(f"Error reading input JSON: {exc}")
        return 1

    out_dir = resolve_out_dir(str(config.get("out_dir", DEFAULT_PACK_ROOT / "_system" / "fixtures" / "fixture-smoke")))
    ensure_under_packs(out_dir)
    ensure_runner_writes_under_runs(output_path)

    scope_key = parse_scope(config)
    scope = SCOPES[scope_key]
    combined = bool(config.get("combined", False))
    split_lite = bool(config.get("split_lite", False))
    zip_enabled = bool(config.get("zip", False))
    mode = str(config.get("mode", "full")).strip().lower()
    profile = str(config.get("profile", "full")).strip().lower()
    stamp = str(config.get("stamp", "fixture-smoke")).strip() or "fixture-smoke"

    allow_dup = None
    if bool(config.get("allow_duplicate_hashes")):
        allow_dup = True
    elif bool(config.get("disallow_duplicate_hashes")):
        allow_dup = False

    pack_dir = make_pack(
        scope_key=scope_key,
        mode=mode,
        profile=profile,
        split_lite=split_lite,
        out_dir=out_dir,
        combined=combined,
        stamp=stamp,
        zip_enabled=zip_enabled,
        max_total_bytes=parse_int(config, "max_total_bytes", DEFAULT_MAX_BYTES),
        max_entry_bytes=parse_int(config, "max_entry_bytes", DEFAULT_MAX_ENTRY),
        max_entries=parse_int(config, "max_entries", DEFAULT_MAX_ENTRIES),
        allow_duplicate_hashes=allow_dup,
    )

    required = [
        "meta/START_HERE.md",
        "meta/ENTRYPOINTS.md",
        "meta/FILE_TREE.txt",
        "meta/FILE_INDEX.json",
        "meta/REPO_OMITTED_BINARIES.json",
        "meta/REPO_STATE.json",
        "meta/PACK_INFO.json",
        "meta/BUILD_TREE.txt",
    ]
    if (pack_dir / "meta" / "CONTEXT.txt").exists():
        required.append("meta/CONTEXT.txt")

    required.extend(build_required_split(scope_key))
    if combined:
        required.extend(build_full_paths(scope_key, stamp))
    if profile == "lite" or split_lite:
        required.extend(build_lite_paths(scope_key))

    missing = [p for p in required if not (pack_dir / p).exists()]
    if missing:
        print("Packer output missing required files:")
        for p in missing:
            print(f"- {p}")
        return 1

    start_here_text = (pack_dir / "meta" / "START_HERE.md").read_text(encoding="utf-8", errors="replace")
    entrypoints_text = (pack_dir / "meta" / "ENTRYPOINTS.md").read_text(encoding="utf-8", errors="replace")

    mention_map = {
        "ags": [
            "`repo/AGENTS.md`",
            "`repo/README.md`",
            "`repo/CONTEXT/archive/planning/INDEX.md`",
        ],
        "catalytic-dpt": [
            "`repo/CATALYTIC-DPT/AGENTS.md`",
            "`repo/CATALYTIC-DPT/README.md`",
            "`repo/CATALYTIC-DPT/ROADMAP_V2.1.md`",
        ],
    }
    required_mentions = mention_map.get(scope_key, ["`repo/CATALYTIC-DPT/LAB/`"])

    for mention in required_mentions:
        if mention not in start_here_text:
            print(f"START_HERE.md missing required mention: {mention}")
            return 1
        if mention not in entrypoints_text:
            print(f"ENTRYPOINTS.md missing required mention: {mention}")
            return 1

    if scope_key == SCOPE_AGS.key:
        maps_text = (pack_dir / "SPLIT" / "AGS-03_MAPS.md").read_text(encoding="utf-8", errors="replace")
        if "## Read order" not in maps_text:
            print("AGS-03_MAPS.md missing read-order section")
            return 1
    elif scope_key == "catalytic-dpt":
        index_text = (
            pack_dir / "SPLIT" / "CATALYTIC-DPT-00_INDEX.md"
        ).read_text(encoding="utf-8", errors="replace")
        if "## Read order" not in index_text:
            print("CATALYTIC-DPT-00_INDEX.md missing read-order section")
            return 1
    else:
        index_text = (
            pack_dir / "SPLIT" / "CATALYTIC-DPT-LAB-00_INDEX.md"
        ).read_text(encoding="utf-8", errors="replace")
        if "## Read order" not in index_text:
            print("CATALYTIC-DPT-LAB-00_INDEX.md missing read-order section")
            return 1

    if profile == "lite":
        tree_text = (pack_dir / "meta" / "FILE_TREE.txt").read_text(encoding="utf-8", errors="replace")
        excluded_markers = [
            "/fixtures/",
            "/_runs/",
            "/_generated/",
            "/CONTEXT/archive/",
            "/CONTEXT/research/",
        ]
        for marker in excluded_markers:
            if f"repo{marker}" in tree_text:
                print(f"LITE pack unexpectedly contains excluded content: repo{marker}")
                return 1
        if ".cmd" in tree_text or ".ps1" in tree_text:
            print("LITE pack unexpectedly contains OS wrapper files (*.cmd/*.ps1)")
            return 1

    output_payload = {
        "pack_dir": pack_dir.relative_to(PROJECT_ROOT).as_posix(),
        "stamp": stamp,
        "verified": required,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output_payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: run.py <input.json> <output.json>")
        raise SystemExit(1)
    raise SystemExit(main(Path(sys.argv[1]), Path(sys.argv[2])))
