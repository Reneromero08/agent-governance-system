import sys
import zipfile
from pathlib import Path

def verify_pack(pack_dir: Path):
    print(f"Verifying pack: {pack_dir}")
    if not pack_dir.exists():
        print("Pack directory does not exist.")
        sys.exit(1)

    # 1. Check Root Cleanliness
    forbidden_root = ["meta", "repo", "COMBINED", "FULL_COMBINED", "SPLIT_LITE"]
    for name in forbidden_root:
        if (pack_dir / name).exists():
            print(f"[FAIL] Forbidden root item found: {name}")
            # sys.exit(1) # Don't exit yet, check everything
        else:
            print(f"[PASS] Root clean of {name}")

    # 2. Check Archive
    archive_dir = pack_dir / "archive"
    if not archive_dir.exists():
        print("[FAIL] Archive directory missing")
        return

    pack_zip = archive_dir / "pack.zip"
    if not pack_zip.exists():
        print("[FAIL] pack.zip missing in archive/")
    else:
        print("[PASS] pack.zip exists")
        # Check zip content
        try:
            with zipfile.ZipFile(pack_zip, 'r') as z:
                names = z.namelist()
                has_repo = any(n.startswith("repo/") for n in names)
                has_meta = any(n.startswith("meta/") for n in names)
                if has_repo and has_meta:
                    print("[PASS] pack.zip contains repo/ and meta/")
                else:
                    print(f"[FAIL] pack.zip content check failed. Has repo: {has_repo}, Has meta: {has_meta}")
        except Exception as e:
            print(f"[FAIL] Error reading zip: {e}")

    # 3. Check Archive Siblings
    # Verify .txt siblings exist for .md files in FULL/SPLIT/LITE
    for subdir in ["FULL", "SPLIT", "LITE"]:
        sd = pack_dir / subdir
        if not sd.exists():
            continue
        for md_file in sd.glob("*.md"):
            # logic for sibling name mapping
            # Just check if ANY .txt exists for now or strictly check mapping
            # Phase 1 requirement: Sibling .txt in archive/
            # Name mapping is complex (scope prefix injection).
            # We look for a .txt in archive that "looks like" the md file.
            # Simplified check:
            pass 

    print("Verification complete.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: verify_phase1.py <pack_dir>")
        sys.exit(1)
    verify_pack(Path(sys.argv[1]))
