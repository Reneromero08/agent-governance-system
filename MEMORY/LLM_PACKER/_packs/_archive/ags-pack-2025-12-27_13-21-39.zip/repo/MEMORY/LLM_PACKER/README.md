# LLM_PACKER

**Version:** 1.3.1

Utility to bundle repo content into a small, shareable snapshot for an LLM.

## Scopes

- `ags` (default): packs the full AGS repo (governance system)
- `catalytic-dpt`: packs `CATALYTIC-DPT/**` excluding `CATALYTIC-DPT/LAB/**` (full snapshot, excluding `__pycache__`, `_runs`, `_generated`, etc.)
- `lab`: packs only `CATALYTIC-DPT/LAB/**`

## What it includes (FULL profile / default)

- Repo sources (text only): `CANON/`, `CONTEXT/`, `MAPS/`, `SKILLS/`, `CONTRACTS/`, `MEMORY/`, `CORTEX/`, `TOOLS/`, `.github/`
- Key root files (text): `AGENTS.md`, `README.md`, `LICENSE`, `.editorconfig`, `.gitattributes`, `.gitignore`
- Planning archive index: `CONTEXT/archive/planning/INDEX.md`
- Chunked docs under `SPLIT/` (read in order: `00` → `...`)
- Optional combined docs under `FULL/` (when `--combined` is enabled)
- Optional discussion-first output under `LITE/` (when `--split-lite` or `--profile lite` is enabled)
- Optional archives under `archive/` (when `--zip` is enabled)
  - `archive/pack.zip` contains **only** `meta/` + `repo/`
  - `archive/*.txt` siblings are plain-text copies of `FULL/*.md`, `SPLIT/*.md`, and `LITE/*.md`

When `--zip` is enabled, the pack is cleaned so the root contains only `FULL/`, `SPLIT/`, `LITE/`, and `archive/` (with `meta/` and `repo/` living inside `archive/pack.zip`). When `--zip` is disabled, `meta/` and `repo/` remain present (useful for debugging and fixtures).

## LITE profile (discussion-first)

The LITE profile produces a smaller, high-signal pack:

- Includes: `AGENTS.md`, `README.md`, `CANON/**`, `MAPS/**`, `CONTRACTS/runner.py`,
  `CORTEX/query.py`, `TOOLS/critic.py`, `SKILLS/**/SKILL.md`, `SKILLS/**/version.json`
- Excludes: fixtures, `_runs`, `_generated`, research/archive, OS wrapper scripts (`*.cmd`, `*.ps1`)
- Adds symbolic indexes in `meta/`:
  - `LITE_ALLOWLIST.json`, `LITE_OMITTED.json`, `LITE_START_HERE.md`
  - `SKILL_INDEX.json`, `FIXTURE_INDEX.json`, `CODEBOOK.md`, `CODE_SYMBOLS.json`

## How to run

### Quick (Windows)

Double-click one of:

- `MEMORY/LLM_PACKER/1-AGS-PACK.lnk`
- `MEMORY/LLM_PACKER/2-CAT-PACK.lnk`
- `MEMORY/LLM_PACKER/3-LAB-PACK.lnk`

Or run in PowerShell:

`powershell -NoProfile -ExecutionPolicy Bypass -File MEMORY/LLM_PACKER/Engine/pack.ps1`

Or run cross-platform:

`python -m MEMORY.LLM_PACKER.Engine.packer --mode full --combined --zip`

Examples:

- AGS: `python -m MEMORY.LLM_PACKER.Engine.packer --scope ags --mode full --combined --zip`
- CAT: `python -m MEMORY.LLM_PACKER.Engine.packer --scope catalytic-dpt --mode full --combined --zip --split-lite`
- LAB: `python -m MEMORY.LLM_PACKER.Engine.packer --scope lab --mode full --combined --zip --split-lite`

Optional arguments:

- `--scope ags`, `--scope catalytic-dpt`, or `--scope catalytic-dpt-lab`
- `-OutDir MEMORY/LLM_PACKER/_packs/<name>` (must be under `MEMORY/LLM_PACKER/_packs/`)
- `-Mode full` or `-Mode delta`
- `-Profile full` or `-Profile lite`
- `PACK_PROFILE=lite` (env var override when `-Profile` is not passed)
- `--stamp <stamp>` (used for timestamped `FULL/` output filenames)
- `--split-lite` (generate `LITE/` outputs)
- `-NoZip` or `-NoCombined`

## Output

Creates a pack folder under:

`MEMORY/LLM_PACKER/_packs/` (default for user runs)

Fixture/smoke outputs should go under:

`MEMORY/LLM_PACKER/_packs/_system/fixtures/`

And optionally produces a `.zip` archived under:

`MEMORY/LLM_PACKER/_packs/_system/archive/`

Baseline state used for delta packs is stored at:

`MEMORY/LLM_PACKER/_packs/_system/_state/baseline.json`

## Token Estimation

Each pack includes `meta/CONTEXT.txt` with:
- Per-file token estimates
- Per-payload counts (SPLIT, LITE, and any FULL outputs if present)
- Warnings if any single payload exceeds common context limits (128K, 200K tokens)

The packer also prints the per-payload token counts to the terminal after each run.

## Changelog

See `MEMORY/LLM_PACKER/CHANGELOG.md`.
