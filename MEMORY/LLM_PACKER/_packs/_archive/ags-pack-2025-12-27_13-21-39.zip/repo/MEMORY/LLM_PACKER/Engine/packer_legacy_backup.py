
"""
Backup script for legacy packer.py (Stub)
"""
import shutil
from pathlib import Path

def backup():
    src = Path("MEMORY/LLM_PACKER/Engine/packer.py")
    dst = Path("MEMORY/LLM_PACKER/Engine/packer_legacy.py.bak")
    if src.exists():
        shutil.copy2(src, dst)
        print(f"Backed up {src} to {dst}")

if __name__ == "__main__":
    backup()
