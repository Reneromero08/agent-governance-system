import zipfile
import sys
from pathlib import Path

def list_zip(path):
    print(f"Listing {path}...")
    try:
        with zipfile.ZipFile(path, 'r') as z:
            for i in z.infolist():
                print(f"{i.filename} ({i.file_size} bytes)")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        list_zip(sys.argv[1])
