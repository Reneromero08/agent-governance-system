import sys
from pathlib import Path

# Paths to scan
PROJECT_ROOT = Path(__file__).resolve().parents[3]
SCAN_DIRS = [
    PROJECT_ROOT / "CATALYTIC-DPT",
    PROJECT_ROOT / "SKILLS",
    PROJECT_ROOT / "CONTRACTS",
    PROJECT_ROOT / "TOOLS",
    PROJECT_ROOT / "MEMORY" / "LLM_PACKER", # Check itself too
]

OLD_PATTERNS = [
    "COMBINED/SPLIT",
    "FULL_COMBINED",
    "SPLIT_LITE",
    "COMBINED/",  # General check
]

def scan_files():
    print(f"Scanning for old packer references in: {[d.name for d in SCAN_DIRS]}")
    found_count = 0
    
    for root_dir in SCAN_DIRS:
        if not root_dir.exists():
            continue
            
        for path in root_dir.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix not in (".md", ".py", ".json", ".js", ".ps1", ".cmd"):
                continue
            if "node_modules" in path.parts or ".git" in path.parts or "_runs" in path.parts:
                continue
            if path.name == "scan_old_refs.py":
                continue

            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
                for pattern in OLD_PATTERNS:
                    if pattern in content:
                        print(f"[FOUND] {pattern} in {path.relative_to(PROJECT_ROOT)}")
                        found_count += 1
            except Exception as e:
                print(f"[ERROR] Reading {path}: {e}")

    print(f"\nScan complete. Found {found_count} potential issues.")

if __name__ == "__main__":
    scan_files()
