$WshShell = New-Object -comObject WScript.Shell

# 1-AGS-PACK.lnk -> Engine\1-AGS-PACK.cmd
$Shortcut = $WshShell.CreateShortcut("$PSScriptRoot\..\1-AGS-PACK.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\1-AGS-PACK.cmd"
$Shortcut.WorkingDirectory = "$PSScriptRoot"
$Shortcut.IconLocation = "$PSScriptRoot\ags_launcher_blue.ico"
$Shortcut.Save()

# 2-CAT-PACK.lnk -> Engine\2-CAT-PACK.cmd
$Shortcut = $WshShell.CreateShortcut("$PSScriptRoot\..\2-CAT-PACK.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\2-CAT-PACK.cmd"
$Shortcut.WorkingDirectory = "$PSScriptRoot"
$Shortcut.IconLocation = "$PSScriptRoot\ags_launcher_blue.ico"
$Shortcut.Save()

# 3-LAB-PACK.lnk -> Engine\3-LAB-PACK.cmd
$Shortcut = $WshShell.CreateShortcut("$PSScriptRoot\..\3-LAB-PACK.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\3-LAB-PACK.cmd"
$Shortcut.WorkingDirectory = "$PSScriptRoot"
$Shortcut.IconLocation = "$PSScriptRoot\lab.ico"
$Shortcut.Save()

Write-Host "Shortcuts updated."
