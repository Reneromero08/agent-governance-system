#!/usr/bin/env python3
"""
CLI entry point for the modular LLM Packer.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional

from .core import SCOPE_AGS, SCOPES, make_pack

def main(args: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="LLM Packer - Prepare repository snapshots for LLM handoff.")
    
    parser.add_argument("--scope", default=SCOPE_AGS.key, choices=list(SCOPES.keys()), help="Scope of the pack.")
    parser.add_argument("--mode", default="full", choices=["full", "delta"], help="Pack mode (full or delta).")
    parser.add_argument("--profile", default="full", choices=["full", "lite"], help="Pack profile.")
    parser.add_argument("--split-lite", action="store_true", help="Generate LITE outputs alongside others.")
    parser.add_argument("--out-dir", type=Path, help="Explicit output directory.")
    parser.add_argument("--combined", action="store_true", help="Generate FULL/ combined outputs.")
    parser.add_argument("--stamp", help="Explicit timestamp or digest for filenames.")
    parser.add_argument("--zip", action="store_true", help="Zip the resulting pack into archive/pack.zip.")
    
    # Overrides/Limits
    parser.add_argument("--max-total-bytes", type=int, default=50 * 1024 * 1024)
    parser.add_argument("--max-entry-bytes", type=int, default=2 * 1024 * 1024)
    parser.add_argument("--max-entries", type=int, default=50_000)
    
    dup_group = parser.add_mutually_exclusive_group()
    dup_group.add_argument("--allow-duplicate-hashes", action="store_true", default=None)
    dup_group.add_argument("--disallow-duplicate-hashes", action="store_false", dest="allow_duplicate_hashes")

    parsed = parser.parse_args(args)

    try:
        pack_dir = make_pack(
            scope_key=parsed.scope,
            mode=parsed.mode,
            profile=parsed.profile,
            split_lite=parsed.split_lite,
            out_dir=parsed.out_dir,
            combined=parsed.combined or (parsed.profile == "full"), # Default true if full
            stamp=parsed.stamp,
            zip_enabled=parsed.zip,
            max_total_bytes=parsed.max_total_bytes,
            max_entry_bytes=parsed.max_entry_bytes,
            max_entries=parsed.max_entries,
            allow_duplicate_hashes=parsed.allow_duplicate_hashes,
        )
        print(f"Packer completed successfully.")
        print(f"Output: {pack_dir.as_posix()}")
        return 0
    except Exception as exc:
        print(f"PACKER_ERROR: {exc}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
