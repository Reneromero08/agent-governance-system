# START HERE

This snapshot is meant to be shared with any LLM to continue work on the Agent Governance System (AGS) repository.

## Read order
1) `repo/AGENTS.md`
2) `repo/README.md`
3) `repo/CANON/CONTRACT.md`
4) `repo/MAPS/ENTRYPOINTS.md`
5) `repo/CONTRACTS/runner.py`
6) `meta/ENTRYPOINTS.md`

## Notes
- `BUILD` contents exclued.
- Use `FULL/` for single-file output or `SPLIT/` for sectioned reading.
