# MEMORY

## `repo/MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_AGENTS.md`

```
<!-- CONTENT_HASH: c99f13b496af73ad0a775cb031fa567a3292db747e5bea466e7bde0e82a39476 -->

# CAT-DPT AGENTS (Scoped)
Scope: CAT-DPT (Catalytic DPT runtime, bundles, chain verification, CAS, Merkle, ledger, restore proof, tooling)

Authority and inheritance
- This file is subordinate to the repo-root AGENTS.md and any CANON/DECISIONS files.
- If any instruction here conflicts with higher authority, higher authority wins.
- This file must not be duplicated elsewhere. Keep exactly one scoped CAT-DPT AGENTS file.

Active roadmap (do not waste tokens)
- The ONLY active execution roadmap for CAT-DPT is: `ROADMAP_V2.3.md`
- Treat these as historical. Do not load unless explicitly asked:
  - `LAB/ARCHIVE/ROADMAP_V2.2.md`
  - `LAB/ARCHIVE/ROADMAP_V2.1.md`
  - `LAB/ARCHIVE/ROADMAP_V2.md`
  - `LAB/ARCHIVE/ROADMAP.md`
- If unsure what to do next, read `ROADMAP_V2.3.md` and execute the smallest unchecked item that advances Phase 0, then Phase 1, etc.

Primary objective
Build a verifiable catalytic runtime where:
- Truth is artifacts, not narration.
- Runs are resumable and verifiable from bundles and chain proofs.
- Token efficiency is achieved via hash-referenced memory and bounded dereference, not by dumping blobs.

Non-goals (hard)
- Do not pack large bodies of repo content into prompts.
- Do not introduce “helpful” refactors unrelated to contracts, proofs, determinism, or security boundaries.
- Do not rely on chat logs/transcripts as state.
- Do not add large-model fine-tuning as a substitute for proofs.

## Contracts are law
Schemas
- Implement and enforce these schemas as canon:
  - `SCHEMAS/jobspec.schema.json`
  - `SCHEMAS/validation_error.schema.json`
  - `SCHEMAS/ledger.schema.json`
- Schema dialect must be explicitly pinned (Draft 7 recommended). Do not change dialect without an explicit decision record and migration plan.

Run artifact set (required)
Every run MUST write artifacts to:
- `CONTRACTS/_runs/<run_id>/`

Minimum required files
- `JOBSPEC.json` (schema-valid)
- `STATUS.json` (state machine: started/failed/succeeded/verified)
- `INPUT_HASHES.json`
- `OUTPUT_HASHES.json`
- `DOMAIN_ROOTS.json`
- `LEDGER.jsonl` (append-only, schema-valid)
- `VALIDATOR_ID.json` (validator_semver, validator_build_id, substrate/toolchain versions)
- `PROOF.json` (hashable restoration proof summary)

Definition of success
- A run is not “successful” unless:
  - all required artifacts exist
  - bundle verification passes in strict mode
  - restoration proof passes
- Missing artifacts or verification failures must fail closed.

Validator identity
- Bundle and chain verification MUST bind to:
  - `validator_semver`
  - `validator_build_id`
- Strict mode is the default for CI and for any acceptance gate.

## Enforcement model (3 layers)
Preflight (before execution)
- Validate JobSpec against schema.
- Enforce path rules:
  - no absolute paths
  - no traversal
  - allowed roots only
- Enforce forbidden overlaps (inputs vs outputs).
- Resolve required hash references or fail.

Runtime guard (during execution)
- Enforce allowed roots and forbid writes elsewhere.
- Record write events (at least path and byte count; include hash when feasible).
- Fail immediately on policy violation.

CI validation (after execution / PR gate)
- Verify bundles and chains in strict mode.
- Verify restoration proof for required fixtures and demos.
- Reject nondeterminism regressions.

## Token efficiency rules (hash-first operations)
Default interaction pattern
- Prefer: hashes + bounded previews + targeted dereference.
- Do not paste large file bodies into prompts.
- Use the expand-by-hash toolbelt once it exists:
  - `catalytic hash read`
  - `catalytic hash grep`
  - `catalytic hash ast`
  - `catalytic hash describe`

Bounded outputs (mandatory)
- Every “read” or “grep” must enforce explicit bounds:
  - max bytes
  - max matches
  - explicit ranges
- Any tool that can dump unbounded content is a violation and must be fixed.

Dereference protocol
- Only dereference by hash when needed for:
  - correctness of an acceptance decision
  - resolving an ambiguity
  - producing final outputs that require exact bytes
- Log dereference events into receipts where feasible (hash requested, byte bounds returned).

## Memoization (never pay twice)
Caching is required once the cache is implemented.
- Cache key MUST include identity and inputs:
  - job_hash
  - input_hash
  - toolchain_hash
  - model_hash (or validator_build_id when model is external)
- Cache hit must still produce verifiable receipts and proofs.
- Cache miss must not bypass verification.

## Determinism discipline
- Do not introduce timestamps or nondeterministic ordering into proofs, roots, manifests, or receipts unless explicitly allowed and documented.
- Normalize paths and sort deterministically before hashing or generating roots.
- When determinism is expected, add a test that runs twice and asserts identical roots and artifacts.

## Work style (how agents should operate)
Implementation workflow
1) Read `ROADMAP_V2.3.md` and pick the next smallest unchecked item.
2) Implement the minimum code to satisfy that item.
3) Add fixtures and tests that prove it.
4) Run tests locally.
5) Update docs only to reflect reality (no aspirational docs).
6) Commit in small, reviewable changes.

Tests are not optional
- Any new contract or enforcement rule requires tests.
- Any bug fix requires a regression test.
- Any security boundary change requires an adversarial fixture.

No silent behavior
- If the system does something, it must be documented.
- If docs claim behavior, tests must verify it.

## Roadmap navigation rules
- Do not “merge phases” unless the roadmap explicitly says so.
- If you discover the roadmap is wrong relative to reality:
  - do not rewrite history
  - propose a new versioned roadmap (v2.2, v2.3) or add a small patch file
  - keep prior versions intact

## Safety rail for edits
- Do not modify repo-root AGENTS.md, CANON, or DECISIONS unless explicitly instructed.
- Prefer adding scoped docs under CAT-DPT directories instead of changing global law.
- If a contradiction is found, report it and propose a minimal reconciliation.

## Architectural Boundaries
Kernel vs. LAB
- The root `CATALYTIC-DPT/` directory contains the **Kernel** (schemas, primitives, verified skills, and core testbenches).
- The `CATALYTIC-DPT/LAB/` directory contains **Experimental Scaffolds** (research, archived roadmaps, and unstable/phased components).
- **Rule**: Kernel code MUST NOT import from `LAB/`.
- **Rule**: `LAB/` code may import from the Kernel.

Test Gating
- Default `pytest` execution excludes the `LAB/` directory to ensure kernel stability and speed.
- To include `LAB` tests, set the environment variable: `CATDPT_LAB=1`.
- Example: `CATDPT_LAB=1 python -m pytest`


End state definition
CAT-DPT is considered “operational” when:
- Phase 0 schemas and fixtures exist and pass
- Phase 1 kernel (CAS, Merkle, ledger, restore proof) passes determinism and adversarial fixtures
- Expand-by-hash toolbelt exists and is bounded and deterministic
- Bundle and chain verification run in strict mode in CI
- At least one end-to-end demo proves:
  - resume without history
  - proof-gated acceptance
  - measurable token reduction at the interface
```

## `repo/MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_CHANGELOG.md`

```
<!-- CONTENT_HASH: e71f7cb0f3b2a4474b306d3c0e2b692d4d3ec5df73c679a6e288ae204fe59d3e -->

# CATALYTIC-DPT Changelog

All notable changes to the Catalytic Computing Department (Isolated R&D) will be documented in this file.

## [1.61.0] - 2025-12-27

### Phase 7.3: Catalytic Swarm Execution Elision

#### Added
- `PIPELINES/swarm_runtime.py`: Swarm-level reuse detection and execution elision.
  - Computes deterministic swarm hash from canonical spec + pipeline intents + capability hashes.
  - Persists swarm receipts in `_swarms/_receipts/` keyed by swarm hash.
  - On identical swarm re-run: skips ALL pipeline/skill/model execution; emits new `SWARM_RECEIPT.json` and `SWARM_CHAIN.json` referencing prior proofs.
  - Fail-closed: if any referenced pipeline receipt is missing or tampered, reuse is rejected.
- `TESTBENCH/test_swarm_reuse.py`: Fixture proving:
  - First run executes normally (`elided: false`).
  - Identical re-run elides execution (`elided: true`).
  - Chain/receipt artifacts re-emitted correctly.
  - Tampered pipeline proof fails reuse verification.

#### Changed
- `ROADMAP_V2.3.md`: Phase 7.3 marked DONE with acceptance criteria.

---

## [1.60.0] - 2025-12-27

### Phase 6.4: MCP Adapter Contracts
- **Added** `SCHEMAS/mcp_adapter.schema.json`: Strict schema for MCP adapter execution (caps, transcript hashing).
- **Added** `SKILLS/mcp-adapter/`: Official skill wrapper for MCP servers.
- **Added** `SKILLS/mcp-adapter/scripts/wrapper.py`: Subprocess executor enforcing strict governance caps.
- **Verified** `TESTBENCH/test_mcp_adapter_schema.py` and `test_ags_phase6_mcp_adapter_e2e.py`: Verified schema and runtime governance.

### Phase 6.5: Skill Registry (Hash-Addressed Capabilities)
- **Added** `SKILLS/registry.json`: Canonical, versioned mapping of Skill IDs to Capability Hashes.
- **Added** `PRIMITIVES/skills.py`: Skill registry loading, resolution, and strict integrity verification.
- **Verified** `TESTBENCH/test_skills_registry.py`: Tests for registry loading, resolution, and integrity checks (fail-closed).
- **Changed** `TOOLS/ags.py`: Integrated `skill_id` resolution into routing logic.

### Phase 6.6: Capability Pinning & Revocation
- **Added** `CAPABILITY_PINS.json`: Explicit allowlist for capability hashes (immutable by default).
- **Added** `CAPABILITY_REVOKES.json`: Explicit denylist for emergency capability revocation.
- **Verified** `TESTBENCH/test_capability_revocation.py`: Adversarial test confirming revocation enforcement fails closed.
- **Verified** `ags.py` enforcement: Precedence rules (Revoke > Pin) verified.

### Phase 6.7: Registry Immutability & Safety
- **Verified** `PRIMITIVES/registry_validators.py` enforces canonical JSON, sorted keys, and no duplicates.
- **Verified** `TESTBENCH/test_registry_validators.py`: Adversarial tests for duplicate hashes, non-canonical encoding, and tamper detection.
- **Enforced** `ags.py`: `route` and `verify` fail closed on any registry violation.

### Phase 6.8: Capability Versioning Semantics (Immutability-by-Content)
- **Enforced** `PRIMITIVES/registry_validators.py`: Capabilities are immutable-by-content.
  - Registry validator computes SHA-256 of adapter spec and verifies it matches capability hash.
  - Any mismatch returns `REGISTRY_TAMPERED`, preventing "in-place upgrades".
- **Verified** `TESTBENCH/test_ags_phase6_registry_immutability.py::test_registry_tamper_detected_fail_closed`:
  - Tampered adapter spec (hash mismatch) fails routing with `CAPABILITY_HASH_MISMATCH`.
- **Principle**: Upgrading a capability requires creating a new hash, not modifying existing entry.
  - Historical pipelines remain verifiable as long as their capability registry entries are present and correct.

### Phase 8: Model Binding (Optional, Replaceable, Never Trusted)
- **Added** Router receipt artifacts in `ags_plan`:
  - `ROUTER.json`: Records router executable, args, hash, exit code, and stderr bytes.
  - `ROUTER_OUTPUT.json`: Canonical JSON plan output for deterministic verification.
  - `ROUTER_TRANSCRIPT_HASH`: SHA-256 hash of raw router stdout bytes.
- **Verified** `TESTBENCH/test_phase8_router_receipts.py`: 5 tests confirming:
  - Router receipts are created and contain correct metadata.
  - Router over-output fails closed (`ROUTER_OUTPUT_TOO_LARGE`).
  - Router stderr fails closed (`ROUTER_STDERR_NOT_EMPTY`).
  - Malformed plans fail schema validation.
  - Capability escalation attempts fail closed (Phase 6.6 enforcement).
- **Principle**: Models are replaceable and untrusted. Governance validates everything they produce.

### Performance
- **Optimized** `PRIMITIVES/cas_store.py`: Eliminated redundant file copy in `put_stream` (100% write IO reduction).

## [1.55.0] - 2025-12-26

### Swarm Activation (Nervous System Online)

#### Changed
- `swarm_config.json`:
  - Assigned `LFM2-2.6B-Exp` (Python Runner) as the canonical Ant Worker.
  - Assigned `Claude` as the President (reverted from Brains).
- `LAB/MCP/mcp_client.py`: Verified functional connectivity (President ↔ Governor ↔ Ledger).
- `LAB/MCP/server.py`: Verified ledger persistence for dispatch task queue.

#### Added
- `SKILLS/ant-worker/scripts/lfm2_runner.py`: Direct Python execution script for LFM2 using Transformers.
- `SKILLS/ant-worker/scripts/ant_agent.py`: MCP-aware agent daemon that polls ledger and invokes LFM2.

#### Fixed
- `SKILLS/swarm-orchestrator/scripts/poll_and_execute.py`: Corrected MCP import path and added JSON error recovery.
- `SKILLS/swarm-orchestrator/scripts/launch_swarm.ps1`: Fixed hardcoded paths and script locations.

#### Verified
- Nervous System: successful dispatch-perform-report loop via MCP ledger (task `TEST-001`).
- Brain (Cortex): successful indexing and search functionality.
## [1.52.0] - 2025-12-26

### LAB Compression (Cortex-Style Merge)

#### Changed
- Merged `ARCHITECTURE/ORCHESTRATION.md` + `ARCHITECTURE/RECURSIVE_SWARM.md` → `ARCHITECTURE/SWARM_ARCHITECTURE.md`
- Merged `RESEARCH/SEMIOTIC_COMPRESSION_LAYER_REPORT.md` + `RESEARCH/SEMIOTIC_COMPRESSION_ROADMAP_PATCH.md` → `RESEARCH/SEMIOTIC_COMPRESSION.md`
- Added Cortex-style document hashes for versioning (`SHA256:SWARM_ARCH_V1`, `SHA256:SCL_SPEC_V1`)

#### Moved
- `RESEARCH/CATALYTIC_STACK_COMPRESSED_MERGED GPT 5.2.md` → `ARCHIVE/` (superseded)

#### Removed
- Duplicate/superseded architecture and research files

---

## [1.51.0] - 2025-12-26

### LAB Reorganization

#### Changed
- Moved architecture docs to `LAB/ARCHITECTURE/`:
  - `ORCHESTRATION_ARCHITECTURE.md` → `ARCHITECTURE/ORCHESTRATION.md`
  - `RECURSIVE_SWARM_ARCHITECTURE.md` → `ARCHITECTURE/RECURSIVE_SWARM.md`
- Moved `ROADMAP_PATCH_SEMIOTIC.md` → `RESEARCH/SEMIOTIC_COMPRESSION_ROADMAP_PATCH.md`

#### Removed
- `ROADMAP_PATCH_SEMIOTIC_TESTBENCH.md` (duplicate of ROADMAP_PATCH_SEMIOTIC.md)

#### Added
- `LAB/README.md`: Index documenting LAB directory structure

---

## [1.50.0] - 2025-12-26

### Phase 6.7: Registry Immutability Backstop

#### Added
- `PRIMITIVES/registry_validators.py`: strict, deterministic validation for `CAPABILITIES.json` and `CAPABILITY_PINS.json` (duplicates/noncanonical/tamper fail closed).
- `TESTBENCH/test_ags_phase6_registry_immutability.py`: adversarial coverage for duplicate hashes, non-canonical JSON, and tamper detection.

#### Changed
- `TOOLS/ags.py`: fail-closed on malformed/non-canonical/tampered registries during routing.
- `PIPELINES/pipeline_verify.py`: fail-closed on malformed/non-canonical/tampered registries during verification.

---

## [1.53.0] - 2025-12-26

### Phase 6.8: Capability Versioning Semantics

#### Changed
- Route/verify surfaces now report `CAPABILITY_HASH_MISMATCH` when a capability hash cannot be re-derived from the registry adapter spec bytes (internal detection remains registry-based).

#### Added
- `TESTBENCH/test_ags_phase6_capability_versioning_semantics.py`: asserts fail-closed behavior and the dedicated boundary error code.

---

## [1.54.0] - 2025-12-26

### Phase 6.9: Capability Revocation Semantics

#### Added
- `CAPABILITY_REVOKES.json`: deterministic revoked capability list.
- `TESTBENCH/test_ags_phase6_capability_revokes.py`: route-time rejection and verify-time semantics preserving historical verification.

#### Changed
- `TOOLS/ags.py`: rejects revoked capabilities at route time (`REVOKED_CAPABILITY`).
- `PIPELINES/pipeline_verify.py`: rejects post-revocation pipelines that use revoked capabilities (`REVOKED_CAPABILITY`), while allowing legacy pipelines without policy snapshots.

---

## [1.55.0] - 2025-12-26

### Phase 7.0: Pipeline DAG Scheduling

#### Added
- `PIPELINES/pipeline_dag.py`: deterministic DAG spec parsing, topological scheduling, resume-safe receipts, and fail-closed verification integration.
- `TESTBENCH/test_pipeline_dag.py`: DAG happy path, resume, tamper rejection, and cycle detection.
- `catalytic pipeline dag run|status|verify`: minimal CLI surface for artifact-only DAG workflows.
- Deterministic topo sort tie-break: lexicographic node order.

---

## [1.56.0] - 2025-12-26

### Phase 7.1: Distributed Execution Receipts

#### Added
- `PIPELINES/pipeline_dag.py`: node receipts (RECEIPT.json), chained via DAG topology, with strict verification.
- `TESTBENCH/test_pipeline_dag.py`: receipt chaining, tamper rejection, and cross-machine portability coverage.

---

## [1.57.0] - 2025-12-26

### Phase 7.2: Multi-node Restore Runner

#### Added
- `PIPELINES/pipeline_dag.py`: receipt-gated DAG restore with deterministic decisions and fail-closed verification.
- `TESTBENCH/test_pipeline_dag.py`: restore no-op, missing artifact rerun, tampered receipt rerun, and portability coverage.

---

## [1.47.0] - 2025-12-26

### Phase 6.4: MCP Adapters as Governed Pipeline Steps

#### Changed
- `PIPELINES/pipeline_verify.py`: re-hashes durable outputs listed in `OUTPUT_HASHES.json` and fails closed on post-run tampering.

#### Added
- `TESTBENCH/test_ags_phase6_mcp_adapter_e2e.py`: end-to-end adapter step execution using `SKILLS/ant-worker` and strict pipeline verification (including tamper rejection).

---

## [1.48.0] - 2025-12-26

### Phase 6.5: Hash-Addressed Capability Registry

#### Added
- `CAPABILITIES.json`: deterministic registry mapping `capability_hash` to adapter spec (hash-addressed).
- `TESTBENCH/test_ags_phase6_capability_registry.py`: fail-closed tests for resolution, unknown capability rejection, and registry tamper detection.

#### Changed
- `TOOLS/ags.py`: supports `steps[].capability_hash` in plans and resolves it strictly via the registry (unknown/mismatch rejects).
- `PIPELINES/pipeline_verify.py`: enforces registry resolution and exact spec matching when capability hashes are used.

---

## [1.49.0] - 2025-12-26

### Phase 6.6: Capability Pinning Enforcement

#### Added
- `CAPABILITY_PINS.json`: deterministic allowlist of permitted `capability_hash` values.
- `TESTBENCH/test_ags_phase6_capability_pins.py`: route-time and verify-time rejection for unpinned capabilities (fail-closed).

#### Changed
- `TOOLS/ags.py`: rejects known-but-unpinned capabilities at route time (`CAPABILITY_NOT_PINNED`).
- `PIPELINES/pipeline_verify.py`: rejects unpinned capabilities even if present in `CAPABILITIES.json` (`CAPABILITY_NOT_PINNED`).

---

## [1.46.0] - 2025-12-26

### Docs: Roadmap Promotion

#### Changed
- `ROADMAP_V2.3.md` is the canonical roadmap.
- `ROADMAP_V2.2.md` restored as a deprecated stub pointer.

---

## [1.41.0] - 2025-12-26

### Phase 6.1: AGS Bridge (Model-Free Pipelines)

#### Added
- `python -m TOOLS.ags route`: emits deterministic `PIPELINE.json` + `STATE.json` from an explicit JSON plan (idempotent writes).
- `python -m TOOLS.ags run`: runs `catalytic pipeline run` then `catalytic pipeline verify` (fail-closed).
- `TESTBENCH/test_ags_phase6_bridge.py`: subprocess tests for deterministic routing, run+verify success, and tamper rejection.

---

## [1.42.0] - 2025-12-26

### Phase 6.1: Runtime-Owned Pipeline State

#### Changed
- `PipelineRuntime`: initializes `STATE.json` deterministically when `PIPELINE.json` exists but `STATE.json` is missing.
- `ags route`: emits `PIPELINE.json` only; runtime owns state.

---

## [1.43.0] - 2025-12-26

### Phase 6.2: Router Slot (External Plan Producer)

#### Added
- `SCHEMAS/ags_plan.schema.json`: strict plan schema for untrusted router output (no extra fields; capped steps).
- `ags plan`: runs an external router, hard-bounds stdout bytes, rejects any stderr, validates plan + jobspecs, writes canonical plan JSON.
- `ags route`: validates plans (schema + caps) before emitting `PIPELINE.json`.
- `TESTBENCH/test_ags_phase6_router_slot.py`: subprocess tests for router happy path, stderr rejection, byte caps, schema rejection, and jobspec validation.

---

## [1.44.0] - 2025-12-26

### Phase 6.2: Fail-Closed Plan Semantics

#### Changed
- Plans must declare an explicit step `command` (no implicit no-op defaults); missing step command rejects.

---

## [1.45.0] - 2025-12-26

### Phase 6.3: Adapter Contract (Skills + MCP Pipelining)

#### Added
- `SCHEMAS/adapter.schema.json`: strict adapter contract with explicit side effects, bounded deref caps, and required artifact hashes.
- Adapter validation in AGS: strict-mode rejection on any side effects, non-normalized paths, input/output overlap, or deref caps above global ceilings.
- Plan schema supports adapter steps (`steps[].adapter`) for pipeline-safe skill/MCP wrappers.
- `TESTBENCH/test_ags_phase6_adapter_contract.py`: fail-closed tests for missing command, side effects, deref caps, non-normalized paths, and nondeterministic adapters.

---

## [1.40.0] - 2025-12-26

### Phase 5: Pipeline Verify CLI (Fail-Closed)

#### Added
- `catalytic pipeline verify --pipeline-id <id>`: mechanical, artifact-only verification of a full pipeline run.
- `CATALYTIC-DPT/PIPELINES/pipeline_verify.py`: verifies `CHAIN.json`, per-step required artifacts, proof_hash integrity (if present), and schema-valid LEDGER.jsonl.
- `CATALYTIC-DPT/TESTBENCH/test_pipeline_verify_cli.py`: verifies OK, missing artifacts, chain tamper, and ledger corruption cases via the CLI.

---

## [1.38.0] - 2025-12-26

### Phase 3: Packing Hygiene (Deterministic, Bounded, Deduplicated)

#### Changed
- **MEMORY/LLM_PACKER/Engine/packer.py**:
  - Enforces deterministic pack generation (no timestamp-derived output; deterministic stamps by repo digest prefix).
  - Enforces explicit pack ceilings (max_total_bytes, max_entry_bytes, max_entries) and fails closed if exceeded.
  - Rejects duplicate normalized paths and (for CAT-DPT packs by default) duplicate content hashes.
  - Makes manifest auditable and content-addressed (`PACK_INFO.repo_state_sha256`) and verifies refs on pack validation.

#### Added
- **MEMORY/LLM_PACKER/Engine/pack_hygiene.py**: pure hygiene helpers (manifest validation, limit enforcement, canonical hashing).
- **TESTBENCH/test_packing_hygiene.py**: determinism + bounds + dedup + tamper detection backstop tests.

---

## [1.39.0] - 2025-12-26

### Phase 5: Verifiable Pipeline Proof Chain

#### Added
- `CONTRACTS/_runs/_pipelines/<pipeline_id>/CHAIN.json`: deterministic, artifact-only proof chain across pipeline steps.
- `CATALYTIC-DPT/PIPELINES/pipeline_chain.py`: fail-closed verifier that recomputes step proof/root hashes and checks link integrity and step order.
- `CATALYTIC-DPT/TESTBENCH/test_pipeline_chain.py`: valid, tamper, reorder, and determinism coverage.

#### Changed
- `CATALYTIC-DPT/PIPELINES/pipeline_runtime.py`: writes/updates `CHAIN.json` during step completion and refuses to resume if chain integrity fails.

---

## [1.37.0] - 2025-12-25

### Phase 4: Adversarial Fixtures (Fail-Closed Hardening)

#### Added
- Adversarial test coverage for CAS corruption/truncation/partial writes, ledger corruption, path traversal injection, proof/manifest tampering, and pipeline resume safety.

---

## [1.36.0] - 2025-12-25

### Phase 2: Demo of Measurable Reuse via Hash-First Dereference

#### Added
- **CATALYTIC-DPT/CONTEXT/demos/memoization_hash_reuse/**:
  - Deterministic demo runner (`run_demo.py`) that produces baseline vs reuse artifacts.
- **CONTRACTS/_runs/_CONTEXT/demos/memoization_hash_reuse/**:
  - Artifact-backed baseline/reuse evidence (PROOF.json, LEDGER.jsonl, bounded deref stats) and a comparison table.

---

## [1.35.0] - 2025-12-25

### Phase 5: Artifact-Only Resumable Pipelines

#### Added
- **PIPELINES/pipeline_runtime.py**:
  - Deterministic pipeline init/run/status with resume-safe state under `CONTRACTS/_runs/_pipelines/<pipeline_id>/`.
- **TOOLS/catalytic.py**:
  - Adds `catalytic pipeline run|status` commands (no timestamps; state is artifact-only).
- **TESTBENCH/test_pipelines.py**:
  - Proves deterministic init, resume without re-running completed steps, required per-step artifacts, and stable status output.

---

## [1.34.0] - 2025-12-25

### Phase 2: Deterministic Job Memoization (Never Pay Twice)

#### Added
- **PRIMITIVES/memo_cache.py**:
  - Deterministic job cache key (JobSpec canonical JSON + input domain roots + validator identity + strictness).
  - Cache storage under `CONTRACTS/_runs/_cache/jobs/<job_cache_key>/` with cached proof/domain roots/output hashes and materialized durable outputs.
- **TESTBENCH/test_memoization.py**:
  - Proves miss→hit behavior, byte-identical proof/domain roots on hits, and deterministic invalidation when strictness changes.

#### Changed
- **TOOLS/catalytic_runtime.py**:
  - Adds memoization path that skips execution on cache hits while restoring outputs and re-emitting proof artifacts.

---

## [1.33.0] - 2025-12-25

### Phase 4: Fix Ledger Schema `$ref` Resolution (Draft7)

#### Changed
- **SCHEMAS/ledger.schema.json**:
  - Makes internal `$ref` targets explicit (`ledger.schema.json#/definitions/...`) so resolution is stable under Draft7 reference loading.
- **TESTBENCH/test_schemas.py**:
  - Uses Draft7 `RefResolver` + deterministic schema store for ledger validation (no unsupported `registry=` argument).

---

## [1.32.0] - 2025-12-25

### Phase 4: Independent Verifier Implementation; Interop Proven

#### Added
- **PRIMITIVES/verify_bundle_alt.py**:
  - Code-independent SPECTRUM-05 bundle + chain verifier implementation (strict identity/signature enforcement).
- **TESTBENCH/test_verifier_interop.py**:
  - Golden interop fixtures (valid bundle + tamper rejection) and deterministic rerun coverage.
  - Enforces byte-identical serialized verification results across both implementations.

---

## [1.31.0] - 2025-12-25

### Phase 4: Ledger Observability for Expand-by-Hash Dereferences

#### Added
- **PRIMITIVES/hash_toolbelt.py**:
  - `log_dereference_event()`: Deterministic ledger logging for hash dereference commands.
  - `_build_dereference_ledger_record()`: Constructs minimal schema-conforming ledger records for dereference events.
  - Logs include requested hash, command name (read/grep/describe/ast), and bounds (max_bytes, ranges, matches, nodes, depth as applicable).
  - Logging is opt-in: only occurs when `--run-id` is provided.
- **TOOLS/catalytic.py**:
  - `--timestamp` parameter for deterministic timestamp injection (defaults to sentinel).
  - Ledger logging integrated at command dispatch for all four hash toolbelt commands.
- **TESTBENCH/test_deref_logging.py**:
  - Tests for deterministic rerun (identical ledger bytes), schema conformance, opt-in behavior (no run-id → no logging), and exact bounds recording.

#### Changed
- **ROADMAP_V2.2.md**:
  - Marked "dereference events logged to ledger" as DONE under Phase 1X status.

---

## [1.30.0] - 2025-12-25

### Phase 1V: CI Enforces Strict Verification by Default

#### Changed
- **.github/workflows/contracts.yml**:
  - Adds a strict-mode SPECTRUM-05 verification step that generates a deterministic signed bundle and verifies it with `--strict` under `CI=true`.
  - Runs CAT-DPT `pytest` in CI with a workspace-pinned temp directory (avoids capture temp failures) and ignores `CATALYTIC-DPT/LAB` + `MEMORY/LLM_PACKER/_packs`.
- **TOOLS/catalytic_verifier.py**:
  - Refuses to run without `--strict` when `CI` is set (prevents silent downgrade paths in CI).

---

## [1.29.0] - 2025-12-25

### Phase 1X: Expand-by-Hash Toolbelt (Bounded Read/Grep/Ast/Describe)

#### Added
- **TOOLS/catalytic.py**:
  - Unified `catalytic hash` CLI with bounded subcommands: `read`, `grep`, `describe`, `ast`.
  - Hash-first dereference: operates only on CAS objects by SHA-256 (no path reads).
  - Requires explicit CAS location via `--run-id` or `--cas-root`.
- **PRIMITIVES/hash_toolbelt.py**:
  - Deterministic, bounded implementations for read/grep/describe/ast (Python-only AST; otherwise `UNSUPPORTED_AST_FORMAT`).
- **TESTBENCH/test_hash_toolbelt.py**:
  - Tests for bounds enforcement, range reads, deterministic outputs, match limits, AST truncation, and invalid hash rejection.

---

## [1.28.0] - 2025-12-25

### Phase 1.P: Proof Generation Wired to CAS/Merkle/Ledger; Determinism Proven

#### Changed
- **PRIMITIVES/restore_proof.py**:
  - Domain root hash now computed via Phase 1 Merkle primitive (with deterministic empty-manifest sentinel) instead of ad-hoc concatenation.
  - Adds helpers for canonical JSON bytes and CAS-backed domain manifest computation.
- **TOOLS/catalytic_runtime.py**:
  - Snapshots now compute bytes hashes via CAS (streaming, idempotent) and normalize paths deterministically.
  - `DOMAIN_ROOTS.json` now uses Merkle roots per domain (deterministic serialization).
  - `LEDGER.jsonl` now appends schema-valid records via Phase 1 Ledger (canonical JSONL; caller-supplied deterministic timestamp sentinel).
  - `PROOF.json` now uses canonical JSON bytes and references hashes for jobspec + ledger.

#### Added
- **TESTBENCH/test_proof_wiring.py**:
  - Rerun determinism test: two independent runs emit byte-identical `PROOF.json` and `DOMAIN_ROOTS.json`.
  - Tamper detection: hash mismatch is detected and fails closed.

---

## [1.27.0] - 2025-12-25

### Phase 1.D: Append-Only Ledger Receipts Implemented

#### Added
- **PRIMITIVES/ledger.py**:
  - Append-only JSONL writer/reader for ledger entries; never generates timestamps (caller must supply deterministic `RUN_INFO.timestamp`).
  - Deterministic per-line serialization (UTF-8, no whitespace, lexicographically sorted keys).
  - Schema validation against `SCHEMAS/ledger.schema.json` (Draft-07), including optional `JOBSPEC` for job_id linkage.
  - Truncation/rewrite detection via monotonic file-size invariants across appends.
- **TESTBENCH/test_ledger.py**:
  - Append order preservation, deterministic serialization, schema rejection, corrupt/partial line detection, and adversarial truncation detection.

---

## [1.26.0] - 2025-12-25

### Phase 1.M: Merkle Roots per Domain Implemented

#### Added
- **PRIMITIVES/merkle.py**:
  - Deterministic Merkle root computation for domain manifests `{ normalized_path -> sha256_hex }`.
  - Strict path normalization (reuses CAS `normalize_relpath`) and fail-closed validation for malformed paths/hashes.
  - Deterministic leaf ordering (lexicographic by normalized_path) and standard odd-leaf padding.
  - Adversarial rejection: non-normalized paths and duplicate hash bound to different paths.
- **TESTBENCH/test_merkle.py**:
  - Determinism tests (order-independence, stable roots across runs).
  - Adversarial tests for non-normalized paths, invalid hashes, duplicate-hash binding, and odd-leaf padding correctness.

---

## [1.25.0] - 2025-12-25

### Implemented Restore Runner per SPECTRUM-06 (Gated by SPECTRUM-05 Strict Acceptance)

#### Added
- **PRIMITIVES/restore_runner.py**:
  - Implements `restore_bundle()` and `restore_chain()` exactly per SPECTRUM-06 (preflight/plan/execute/verify), including reject-if-exists, staging+rename, deterministic ordering, and rollback rules.
  - Enforces strict SPECTRUM-05 verification gating and PROOF.json verified=true requirement.
  - Emits SPECTRUM-06 frozen success artifacts (`RESTORE_MANIFEST.json`, `RESTORE_REPORT.json`) with canonical JSON bytes and invariant checks.
  - Implements restore-specific failure codes and deterministic selection rules.
- **TOOLS/catalytic_restore.py**:
  - Minimal CLI for restoring a single bundle or explicit chain (JSON output, nonzero exit on failure).
- **TESTBENCH/test_restore_runner.py**:
  - Restore-specific tests for gating, path safety, reject-if-exists, rollback cleanup, success artifacts, and chain all-or-nothing behavior.

---

## [1.24.0] - 2025-12-25

### SPECTRUM-06: Restore Runner Semantics Frozen

#### Added
- **SPECTRUM/SPECTRUM-06.md** (NEW):
  - SPECTRUM-06: Frozen specification for Restore Runner semantics.
  - SPECTRUM-06: restore result artifacts frozen
  - SPECTRUM-06: restore failure codes and threat model frozen
  - Defines eligibility rules: SPECTRUM-05 strict verification required, PROOF.json verified=true, OUTPUT_HASHES.json present.
  - Restore target model: explicit restore_root, path safety rules, traversal rejection.
  - Single-bundle restore: 4-phase procedure (preflight, plan, execute, verify).
  - Chain restore: per-run subfolder isolation, deterministic order, chain-level atomicity.
  - Overwrite policy: reject-if-exists (no implicit overwrites).
  - Atomicity model: staging directory + final rename.
  - Error codes: RESTORE_INELIGIBLE, PATH_ESCAPE_DETECTED, TARGET_EXISTS, etc.

---

## [1.23.0] - 2025-12-25

### Stability Lock: Verifier API/CLI Frozen and Error Codes Centralized

#### Added
- **PRIMITIVES/verify_bundle.py**:
  - Centralized `ERROR_CODES` constant map (one source of truth for all SPECTRUM-05 errors).
  - Mandatory Ed25519 dependency enforcement: Returns `ALGORITHM_UNSUPPORTED` if `cryptography` library is missing in strict mode.
- **TESTBENCH/test_verifier_freeze.py**: New test suite for stable API guarantees.

#### Changed
- **PRIMITIVES/verify_bundle.py**:
  - **API Surface Freeze**: `verify_bundle_spectrum05` and `verify_chain_spectrum05` now have stable signatures and return shapes.
  - **Stable Return Shape**: `{ok: bool, code: str, details: dict}`.
  - **Fail-Fast**: Verification now terminates immediately on the first error encountered in Phase 9 (Output Hash Verification).
- **TOOLS/catalytic_verifier.py**:
  - **CLI Surface Freeze**: Updated `verify_single_bundle`, `verify_chain`, and `verify_chain_from_directory` to use stable SPECTRUM-05 APIs.
  - Minimal output in JSON mode (no extra logs).
  - Nonzero exit code on any verification failure correctly preserved.
- **ROADMAP_V2.1.md**:
  - Updated Phase 1.5 status to explicitly reflect verifier stability lock.

#### Removed
- **PRIMITIVES/verify_bundle.py**:
  - Deprecated multi-error collection in Phase 9 in favor of spec-conformant fail-fast (single error return).

#### Documentation
- **SPECTRUM/SPECTRUM-05.md**:
  - Restored to exact frozen state from commit 3b281f6 (removed non-normative Section 12).
- **PRIMITIVES/VERIFYING.md** (NEW):
  - Created non-normative implementation guide containing extracted implementation requirements.
  - Clearly labeled as non-normative; does not modify SPECTRUM law.
  - Includes notes on mandatory Ed25519 dependency, offline verification, deterministic canonicalization, and verifier modes.

## [1.22.0] - 2025-12-25

### Verifier Updated to Enforce SPECTRUM-04/05 Identity, Canonicalization, and Verification Law

#### Added
- **PRIMITIVES/verify_bundle.py**: SPECTRUM-04/05 enforcement layer
  - `verify_bundle_spectrum05()`: Full 10-phase verification per SPECTRUM-05 v1.0.0
  - `verify_chain_spectrum05()`: Chain verification with chain_root computation
  - Canonical JSON serialization per SPECTRUM-04 v1.1.0 Section 4
  - Bundle root computation per SPECTRUM-04 v1.1.0 Section 5
  - Chain root computation per SPECTRUM-04 v1.1.0 Section 6
  - Ed25519 signature verification per SPECTRUM-04 v1.1.0 Section 9
  - validator_id derivation and verification (SHA-256 of public_key)

#### SPECTRUM-05 10-Phase Verification
- **Phase 1:** Artifact presence check (7 required artifacts)
  - TASK_SPEC.json, STATUS.json, OUTPUT_HASHES.json, PROOF.json
  - VALIDATOR_IDENTITY.json, SIGNED_PAYLOAD.json, SIGNATURE.json
- **Phase 2:** Artifact parse check (JSON validity)
- **Phase 3:** Identity verification
  - Exactly 3 fields: algorithm, public_key, validator_id
  - algorithm == "ed25519" (no alternatives)
  - public_key: exactly 64 lowercase hex characters
  - validator_id derivation matches sha256(public_key_bytes)
- **Phase 4:** Bundle root computation
  - Preimage: {"output_hashes":{...},"status":{...},"task_spec_hash":"..."}
  - task_spec_hash from raw TASK_SPEC.json bytes (not canonicalized)
  - All JSON objects canonicalized with sorted keys, no whitespace
- **Phase 5:** Signed payload verification
  - Exactly 3 fields: bundle_root, decision, validator_id
  - bundle_root matches computed value
  - decision == "ACCEPT" (no alternatives)
  - validator_id matches VALIDATOR_IDENTITY.validator_id
- **Phase 6:** Signature verification
  - payload_type == "BUNDLE"
  - signature: exactly 128 lowercase hex characters
  - validator_id matches across all artifacts
  - Signature message: "CAT-DPT-SPECTRUM-04-v1:BUNDLE:<canonical_payload>"
  - Ed25519 verification using cryptography library
- **Phase 7:** Proof verification
  - PROOF.json.restoration_result.verified == true (boolean)
  - Condition must be RESTORED_IDENTICAL for acceptance
- **Phase 8:** Forbidden artifact check
  - Rejects if logs/, tmp/, or transcript.json exists
- **Phase 9:** Output hash verification
  - All declared outputs must exist
  - SHA-256 hashes must match exactly
- **Phase 10:** Acceptance (all phases pass → ACCEPT)

#### Chain Verification (SPECTRUM-05 Section 6)
- Chain must be non-empty (CHAIN_EMPTY error code)
- No duplicate run_ids (CHAIN_DUPLICATE_RUN error code)
- Each bundle verified via verify_bundle_spectrum05
- Chain root computed: sha256({"bundle_roots":[...],"run_ids":[...]})
- All-or-nothing semantics (any failure rejects entire chain)

#### Error Codes (SPECTRUM-05 Conformance)
- Artifact: `ARTIFACT_MISSING`, `ARTIFACT_MALFORMED`, `ARTIFACT_EXTRA`
- Field: `FIELD_MISSING`, `FIELD_EXTRA`
- Identity: `IDENTITY_INVALID`, `IDENTITY_MISMATCH`, `IDENTITY_MULTIPLE`
- Algorithm: `ALGORITHM_UNSUPPORTED`
- Key: `KEY_INVALID`
- Signature: `SIGNATURE_MALFORMED`, `SIGNATURE_INCOMPLETE`, `SIGNATURE_INVALID`, `SIGNATURE_MULTIPLE`
- Root: `BUNDLE_ROOT_MISMATCH`, `CHAIN_ROOT_MISMATCH`
- Payload: `DECISION_INVALID`, `PAYLOAD_MISMATCH`
- Serialization: `SERIALIZATION_INVALID`
- Proof: `RESTORATION_FAILED`
- Forbidden: `FORBIDDEN_ARTIFACT`
- Output: `OUTPUT_MISSING`, `HASH_MISMATCH`
- Chain: `CHAIN_EMPTY`, `CHAIN_DUPLICATE_RUN`

#### Test Coverage
- **TESTBENCH/test_spectrum_04_05_enforcement.py**: 9 new tests
  - Canonical JSON serialization (sorted keys, no whitespace, UTF-8)
  - Bundle root computation (deterministic, matches spec preimage)
  - Chain root computation (deterministic, order-dependent)
  - Ed25519 signature verification (valid/invalid/tampered)
  - Validator ID derivation (SHA-256 of public_key)
  - SPECTRUM-05 artifact presence check
  - SPECTRUM-05 identity verification (invalid validator_id)
  - SPECTRUM-05 chain empty check
  - SPECTRUM-05 chain duplicate run_id check
- All 69 tests passing (60 legacy + 9 new)

#### Backward Compatibility
- Legacy methods preserved: `verify_bundle()` and `verify_chain()`
- New methods: `verify_bundle_spectrum05()` and `verify_chain_spectrum05()`
- Existing tests unaffected (no breaking changes)

#### Dependencies
- Requires `cryptography` library for Ed25519 signature verification
- Graceful fallback if cryptography not available (tests skip, runtime errors clear)

#### Implementation Notes
- Canonicalization uses `json.dumps(sort_keys=True, separators=(',',':'), ensure_ascii=False)`
- All hashes lowercase hex (64 characters for SHA-256, 128 for Ed25519 signatures)
- Domain separation: "CAT-DPT-SPECTRUM-04-v1:BUNDLE:" prefix
- Fail-closed: any ambiguity or missing artifact → immediate rejection
- No partial acceptance, no warnings, no recovery paths

## [1.21.0] - 2025-12-25

### SPECTRUM-05: Verification and Threat Law Frozen for Identity-Pinned Acceptance

#### Added
- **SPECTRUM/SPECTRUM-05.md** (v1.0.0): Constitutional specification for verification procedure and threat model
  - Status: FROZEN (no implementation may deviate)
  - Depends on: SPECTRUM-04 v1.1.0

#### Verification Procedure (10 Phases, Step-Ordered)
- **Phase 1:** Artifact presence check (7 required artifacts)
- **Phase 2:** Artifact parse check (JSON validity)
- **Phase 3:** Identity verification (Ed25519, validator_id derivation)
- **Phase 4:** Bundle root computation (exact preimage per SPECTRUM-04)
- **Phase 5:** Signed payload verification (bundle_root, decision, validator_id)
- **Phase 6:** Signature verification (Ed25519 over domain-separated message)
- **Phase 7:** Proof verification (PROOF.json verified=true required)
- **Phase 8:** Forbidden artifact check (logs/, tmp/, transcript.json)
- **Phase 9:** Output hash verification (all declared outputs must verify)
- **Phase 10:** Acceptance (all steps pass → ACCEPT)

#### Required Artifacts (7)
- `TASK_SPEC.json`, `STATUS.json`, `OUTPUT_HASHES.json`, `PROOF.json`
- `VALIDATOR_IDENTITY.json`, `SIGNED_PAYLOAD.json`, `SIGNATURE.json`

#### Acceptance Gating Rules
- Exactly one identity artifact, one payload artifact, one signature artifact
- No forbidden artifacts
- All output hashes verify
- No partial acceptance (ACCEPT/REJECT only)

#### Chain Verification Rules
- Non-empty chain required
- No duplicate run_ids
- All bundles must individually verify
- Chain root computed from bundle_roots and run_ids
- All-or-nothing semantics (any failure rejects entire chain)

#### Threat Model

**Defended:**
- Forged acceptance (Ed25519 signature binding)
- Validator impersonation (cryptographic validator_id derivation)
- Bundle substitution (bundle_root binding)
- Replay attacks on modified artifacts
- Ambiguity-based bypass (fully specified canonicalization)
- Multiple identity injection
- Forbidden artifact smuggling
- Proof bypass

**Not Defended:**
- Private key compromise
- Malicious validator acting within spec
- External coercion/governance failures
- Network-based attacks (artifact-only)
- Side-channel attacks on signing
- Quantum computing attacks (Ed25519 not quantum-resistant)

#### Error Semantics (25 Error Codes)
- Hard rejects only (no warnings, no partial acceptance, no recovery)
- Artifact: `ARTIFACT_MISSING`, `ARTIFACT_MALFORMED`, `ARTIFACT_EXTRA`
- Field: `FIELD_MISSING`, `FIELD_EXTRA`
- Identity: `IDENTITY_INVALID`, `IDENTITY_MISMATCH`, `IDENTITY_MULTIPLE`
- Algorithm: `ALGORITHM_UNSUPPORTED`
- Key: `KEY_INVALID`
- Signature: `SIGNATURE_MALFORMED`, `SIGNATURE_INCOMPLETE`, `SIGNATURE_INVALID`, `SIGNATURE_MULTIPLE`
- Root: `BUNDLE_ROOT_MISMATCH`, `CHAIN_ROOT_MISMATCH`
- Payload: `DECISION_INVALID`, `PAYLOAD_MISMATCH`
- Serialization: `SERIALIZATION_INVALID`
- Proof: `RESTORATION_FAILED`
- Forbidden: `FORBIDDEN_ARTIFACT`
- Output: `OUTPUT_MISSING`, `HASH_MISMATCH`
- Chain: `CHAIN_EMPTY`, `CHAIN_DUPLICATE_RUN`

#### Interoperability Requirements
- Two implementations MUST produce byte-for-byte identical results
- No interpretation required (all rules explicit, unambiguous, complete, testable)
- Divergence between implementations → both suspect, investigation required

## [1.20.0] - 2025-12-25

### SPECTRUM-04: Canonical Byte-Serialization Rules Finalized

#### Changed
- **SPECTRUM/SPECTRUM-04.md** (v1.0.0 → v1.1.0): Removed all ambiguity for byte-level determinism

#### Canonical Serialization Rules (Section 4 - NEW)
- **Encoding:** UTF-8 (no BOM)
- **Newline policy:** No newlines; single line with no trailing newline
- **Whitespace policy:** No whitespace outside string values
- **JSON rules:** Keys sorted lexicographically by UTF-8 byte value; no spaces after colons/commas; RFC 8259 string escaping; integers without decimal points; booleans/null lowercase
- **Field presence:** Strict enforcement; missing field → `FIELD_MISSING`; extra field → `FIELD_EXTRA`

#### Bundle Root (Section 5 - Clarified)
- **Preimage structure:** `{"output_hashes":<object>,"status":<object>,"task_spec_hash":"<64 hex>"}`
- **output_hashes source:** `OUTPUT_HASHES.json` → extract `hashes` field → canonicalize keys
- **status source:** `STATUS.json` → entire content → canonicalize keys
- **task_spec_hash:** `sha256(raw_bytes_of_TASK_SPEC.json)` (NOT canonicalized; raw file bytes)

#### Chain Root (Section 6 - Clarified)
- **Preimage structure:** `{"bundle_roots":[...],"run_ids":[...]}`
- **run_id definition:** Directory name (final path component), not full path
- **Constraints:** Arrays must have identical length; no duplicates → `CHAIN_DUPLICATE_RUN`; empty chain → `CHAIN_EMPTY`

#### Signed Payload (Section 7 - Simplified)
- **Payload types reduced:** `BUNDLE` only (removed `CHAIN`, `ACCEPTANCE`)
- **Timestamp removed:** NOT signed (cannot be standardized without trusted time source)
- **Source of truth:** `SIGNED_PAYLOAD.json` is canonical; verifier reconstructs signature message from it
- **Signed payload:** `{"bundle_root":"...","decision":"ACCEPT","validator_id":"..."}`
- **Signature message:** `CAT-DPT-SPECTRUM-04-v1:BUNDLE:<canonical_payload_json>`

#### Revocation (Section 10.3 - Clarified)
- **Status:** Explicitly OUT OF SCOPE
- **Rule:** Revocation MUST NOT be required for SPECTRUM-04 verification to succeed
- **Artifact-only:** Valid signature remains valid regardless of external revocation state

#### Determinism Proof Checklist (Section 13 - NEW)
- Preimage templates for bundle, chain, signed payload, signature message
- Determinism requirements: byte-for-byte identical outputs for identical inputs
- Reject conditions for any ambiguity
- Informative test vectors for edge cases

#### Error Codes (Updated)
- Added: `DECISION_INVALID`, `FIELD_MISSING`, `FIELD_EXTRA`, `CHAIN_DUPLICATE_RUN`, `CHAIN_EMPTY`
- Removed: `VALIDATOR_UNKNOWN`, `VALIDATOR_REVOKED` (revocation out-of-scope)

## [1.19.0] - 2025-12-25

### Validator Identity Pin - Identity and Signing Law Frozen

#### Added
- **SPECTRUM/SPECTRUM-04.md**: Constitutional specification for validator identity and cryptographic signing
  - Status: FROZEN (no implementation may deviate)
  - Defines binding of bundle/chain acceptance to cryptographic authority

#### Validator Identity Model (Final)
- **Key algorithm:** Ed25519 (singular, no alternatives, no negotiation)
- **Public key encoding:** Raw 32-byte, lowercase hex (64 chars exactly)
- **Validator ID derivation:** `validator_id = sha256(public_key_bytes)` (deterministic, globally unique, stable, offline-verifiable)
- **Identity representation:** `{validator_id, public_key, algorithm: "ed25519"}`

#### Signing Surface (Final)
- **Domain separation:** `CAT-DPT-SPECTRUM-04-v1:` prefix (mandatory)
- **Canonical payload:** Domain prefix + payload type + canonical JSON bytes
- **Payload type:** `BUNDLE` (single type; chains use bundle root semantics)
- **Canonical JSON:** Sorted keys, no whitespace, UTF-8, no extensions
- **Bundle root:** `sha256({output_hashes, status, task_spec_hash})`
- **Chain root:** `sha256({bundle_roots[], run_ids[]})`
- **Signed payload binds:** bundle/chain root, decision, validator_id
- **NOT signed:** logs, transcripts, intermediate state, file paths, semver, build_id, timestamps

#### Signature Format (Final)
- **Signature encoding:** Ed25519, lowercase hex (128 chars exactly)
- **Signature object:** `{payload_type, signature, validator_id}` (signed_at informational only)
- **Malformed detection:** Exact character count, lowercase only, no extra fields

#### Artifact Binding (Final)
- **VALIDATOR_IDENTITY.json:** Contains algorithm, public_key, validator_id
- **SIGNATURE.json:** Contains payload_type, signature, validator_id
- **SIGNED_PAYLOAD.json:** Contains bundle_root, decision, validator_id
- **Verification:** Artifact-only (no network, no external trust, no CA)

#### Mutability and Rotation (Final)
- **Immutable once accepted:** All bundle artifacts byte-for-byte immutable
- **Rotation:** NOT ALLOWED (one identity per validator, forever)
- **Revocation:** Out of scope (not required for acceptance)

#### Fail-Closed Rules
- Any ambiguity rejects
- Multiple identities/keys/signatures reject
- Deviation from canonicalization rejects
- Partial data rejects
- No heuristics (binary ACCEPT/REJECT only)
- No side channels (no timing, no file dates, no network)

#### Error Codes (24 stable codes)
- Identity: `IDENTITY_AMBIGUOUS`, `IDENTITY_INCOMPLETE`, `IDENTITY_INVALID`, `IDENTITY_MISMATCH`, `IDENTITY_MISSING`, `IDENTITY_MULTIPLE`
- Algorithm: `ALGORITHM_UNSUPPORTED`
- Key: `KEY_INVALID`, `KEY_MULTIPLE`
- Signature: `SIGNATURE_INCOMPLETE`, `SIGNATURE_INVALID`, `SIGNATURE_MALFORMED`, `SIGNATURE_MISSING`, `SIGNATURE_MULTIPLE`
- Payload: `PAYLOAD_MISSING`, `PAYLOAD_MISMATCH`
- Root: `BUNDLE_ROOT_MISMATCH`, `CHAIN_ROOT_MISMATCH`
- Fields: `FIELD_MISSING`, `FIELD_EXTRA`, `DECISION_INVALID`
- Chain: `CHAIN_DUPLICATE_RUN`, `CHAIN_EMPTY`
- Serialization: `SERIALIZATION_INVALID`

#### Interoperability
- Two independent implementations MUST produce byte-for-byte identical results
- No interpretation required by implementers
- All rules explicit, unambiguous, complete, testable

## [1.18.0] - 2025-12-25

### Phase 1: Bundle/Chain Verifier (Fail-Closed)

#### Added
- **PRIMITIVES/verify_bundle.py**: Deterministic verifier for SPECTRUM-02 bundles and SPECTRUM-03 chains
  - `BundleVerifier.verify_bundle()`: Single bundle verification with fail-closed semantics
  - `BundleVerifier.verify_chain()`: Chain verification with reference integrity validation
  - Enforces forbidden artifacts: rejects if `logs/`, `tmp/`, or `transcript.json` exist
  - Verification depends ONLY on bundle artifacts, file hashes, and ordering (no logs, no heuristics)
  - Supports optional PROOF.json gating (verified=true required for acceptance)
  - Error codes: `BUNDLE_INCOMPLETE`, `HASH_MISMATCH`, `OUTPUT_MISSING`, `STATUS_NOT_SUCCESS`, `CMP01_NOT_PASS`, `PROOF_REQUIRED`, `RESTORATION_FAILED`, `FORBIDDEN_ARTIFACT`, `INVALID_CHAIN_REFERENCE`

- **TOOLS/catalytic_verifier.py**: CLI entrypoint for bundle/chain verification
  - Single bundle mode: `python catalytic_verifier.py --run-dir <path> [--strict]`
  - Chain mode: `python catalytic_verifier.py --chain <path1> <path2> ... [--strict]`
  - Chain directory mode: `python catalytic_verifier.py --chain-dir <path> [--strict]`
  - JSON output support: `--json` flag for machine-readable reports
  - Exit codes: 0 (pass), 1 (fail), 2 (invalid arguments)

- **TESTBENCH/test_verify_bundle.py**: Comprehensive unit tests (18 tests)
  - Valid bundle acceptance
  - Missing artifacts rejection (TASK_SPEC, STATUS, OUTPUT_HASHES)
  - Hash mismatch detection
  - Missing output detection
  - Status failure detection (STATUS_NOT_SUCCESS, CMP01_NOT_PASS)
  - Proof gating tests (PROOF_REQUIRED, RESTORATION_FAILED)
  - Forbidden artifacts rejection (logs/, tmp/, transcript.json)
  - Chain verification (valid chains, tamper detection, invalid references)

#### Changed
- **TESTBENCH/spectrum/test_spectrum03_chain.py**: Refactored to use new `BundleVerifier` primitive
  - `verify_spectrum03_chain()` now wraps `BundleVerifier.verify_chain()`
  - Maintains backward compatibility with existing tests
  - All 5 SPECTRUM-03 tests pass

#### Test Results
- All 60 tests passing (38 Phase 0 + 18 new + 4 spectrum integration)
- Verifier rejects on every negative case (missing artifacts, tamper, invalid references, forbidden artifacts)
- Chain verification enforces reference integrity (no future references allowed)

#### Exit Criteria Met
- [x] Callable entrypoint: `catalytic_verifier.py` with `--run-dir` and `--chain` modes
- [x] Tests prove: valid acceptance, missing artifact rejection, tamper detection, invalid reference rejection, forbidden artifact rejection
- [x] Deterministic: POSIX path normalization, SHA-256 hashing, stable JSON ordering
- [x] Fail-closed: any ambiguity rejects (no heuristics, no logs, no side channels)
- [x] Verification depends only on bundle artifacts + file hashes + ordering
- [x] All tests pass: `pytest -q` returns 60/60

## [1.17.0] - 2025-12-25

### AGS Integration (entries moved from CANON/CHANGELOG.md)

#### Added
- `CATALYTIC-DPT/CHANGELOG.md`: Isolated changelog for the Catalytic Computing department.
- `CATALYTIC-DPT/swarm_config.json`: Role-to-model mapping configuration for multi-agent swarm.
- `TOOLS/catalytic_runtime.py` - CMP-01 runtime implementing 5-phase catalytic lifecycle (snapshot, execute, verify, record). Works with any command.
- `TOOLS/catalytic_validator.py` - Run ledger validator for CMP-01 compliance checking in CI (restoration proof, output roots).
- `CONTEXT/research/Catalytic Computing/CATALYTIC_IMPLEMENTATION_REPORT.md` - Comprehensive report on working prototype: architecture, PoC, what works well, improvements, integration opportunities.
- `CANON/CATALYTIC_COMPUTING.md` - Canonical note defining catalytic computing for AGS (formal theory, engineering patterns, boundaries).
- `CONTEXT/decisions/ADR-018-catalytic-computing-canonical-note.md` documenting the decision to add catalytic computing to canon.

#### Changed
- Refactored `CATALYTIC-DPT` documentation to be model-agnostic (replaced specific model names with God/President/Governor/Ant roles).
- Renamed `CODEX_SOP.json` to `GOVERNOR_SOP.json` and `HANDOFF_TO_CODEX.md` to `HANDOFF_TO_GOVERNOR.md` for role alignment.

## [1.16.0] - 2025-12-25

### Phase 0 Complete: Contract Finalization and Enforcement

Phase 0 establishes the immutable contract that governs all future CAT-DPT work. All schemas, artifact specifications, and enforcement mechanisms are now finalized and frozen.

#### Schemas Finalized
- **jobspec.schema.json**: Canonical job specification format (Phase, TaskType, Intent, Inputs, Outputs, CatalyticDomains, Determinism)
- **ledger.schema.json**: Immutable ledger recording all job executions and artifacts
- **proof.schema.json**: Cryptographic proof of integrity (hash chains, restoration proofs, canonical artifact manifests)
- **validation_error.schema.json**: Deterministic error reporting with stable codes and paths
- **commonsense_entry.schema.json**: Knowledge base entries for commonsense reasoning
- **resolution_result.schema.json**: Results of symbolic resolution

#### Canonical Artifact Set (8 Required Files)
All runtime outputs must conform to the canonical artifact specification:
1. **JOBSPEC.json** - Job specification (immutable, validated at preflight)
2. **STATUS.json** - Run status (failed/completed)
3. **INPUT_HASHES.json** - SHA256 hashes of all inputs
4. **OUTPUT_HASHES.json** - SHA256 hashes of all outputs
5. **DOMAIN_ROOTS.json** - Catalytic domain state (required restoration targets)
6. **LEDGER.jsonl** - Immutable ledger of execution events
7. **VALIDATOR_ID.json** - Identity of accepting validator
8. **PROOF.json** - Cryptographic proof of execution integrity

#### 3-Layer Fail-Closed Enforcement

**Layer 1: Preflight Validation (Before Execution)**
- Validates JobSpec schema compliance
- Detects path traversal, absolute paths, forbidden paths
- Rejects overlapping input/output domains
- Returns deterministic validation_error objects with stable codes
- Implementation: `PRIMITIVES/preflight.py` (10/10 tests pass)

**Layer 2: Runtime Write Guard (During Execution)**
- Enforces allowed roots at write-time for all file operations
- Detects and rejects writes to forbidden paths (CANON, AGENTS.md, BUILD, .git)
- Blocks path traversal and absolute path escapes
- Fails closed immediately with RuntimeError on any violation
- Wraps all writes through FilesystemGuard class
- Implementation: `PRIMITIVES/fs_guard.py` (13/13 tests pass)

**Layer 3: CI Validation (After Execution)**
- Verifies all required canonical artifacts present
- Validates artifact schema compliance
- Checks hash integrity of outputs
- Verifies restoration proofs for catalytic domains
- Ensures ledger consistency
- Implementation: CI pipeline validation

#### Exit Criteria Met
- [x] All schemas finalized and frozen (no breaking changes allowed)
- [x] Canonical artifact set fully specified
- [x] Layer 1 (Preflight) enforces contract before execution
- [x] Layer 2 (Runtime Guard) enforces contract during execution
- [x] Layer 3 (CI) enforces contract after execution
- [x] All enforcement layers fail-closed (RuntimeError/validation_error on violation)
- [x] Error codes deterministic and stable (JOBSPEC_*, WRITE_GUARD_*, etc.)
- [x] Comprehensive test coverage with all tests passing (38/38)
- [x] Roadmap reflects completed work accurately

## [1.15.0] - 2025-12-25

### Added
- **LAB Directory Structure**: Created `CATALYTIC-DPT/LAB/` to isolate experimental scaffolds (`COMMONSENSE/`, `MCP/`, `RESEARCH/`, `ARCHIVE/`) from the kernel core.
- **Pytest Gating**: Implemented `conftest.py` with `pytest_collection_modifyitems` to exclude `LAB/` tests by default.
- **Opt-in Test Variable**: Added `CATDPT_LAB=1` environment variable to enable laboratory testing.
- **Pytest Integration**: Added `test_*` entry points and `pytest.ini` for standardized test discovery across kernel and laboratory components.

### Fixed
- **PROJECT_ROOT in LAB**: Corrected absolute path resolution in `LAB/MCP/server.py` after its move into a deeper directory structure.
- **Spectrum Test Imports**: Updated `test_spectrum02_emission.py` and other spectrum tests to correctly locate the moved MCP server.
- **CommonSense Schema Mismatch**: Fixed `resolution_result.schema.json` to include Phase 2 fields (`expanded_facts`, `unresolved_symbols`) required for validation.

### Changed
- **Architectural Cleanup**: Moved semiotic roadmap patches and historical roadmaps into `LAB/`.
- **Documentation**: Updated `AGENTS.md` with explicit architectural boundaries between Kernel and LAB.

## [1.14.0] - 2025-12-25

### Added
- `CATALYTIC-DPT/COMMONSENSE/` Phase 0–2 scaffold: schemas (`SCHEMAS/commonsense_entry.schema.json`, `SCHEMAS/resolution_result.schema.json`), deterministic resolver (`resolver.py`, `translate.py`), example DB (`db.example.json`), and symbol codebook (`CODEBOOK.json`).
- Fixtures + test benches for contract enforcement:
  - Phase 0 schema validation: `CATALYTIC-DPT/COMMONSENSE/TESTBENCH/test_commonsense_schema.py` over `CATALYTIC-DPT/COMMONSENSE/FIXTURES/phase0/valid|invalid`.
  - Phase 1 resolver expectations: `CATALYTIC-DPT/COMMONSENSE/TESTBENCH/test_resolver.py` over `CATALYTIC-DPT/COMMONSENSE/FIXTURES/phase1/valid`.
  - Phase 2 symbolic expansion + resolve: `CATALYTIC-DPT/COMMONSENSE/TESTBENCH/test_symbols.py` over `CATALYTIC-DPT/COMMONSENSE/FIXTURES/phase2/valid`.
- Semiotic design notes: `CATALYTIC-DPT/ROADMAP_PATCH_SEMIOTIC.md` and `CATALYTIC-DPT/RESEARCH/SEMIOTIC_COMPRESSION_LAYER_REPORT.md`.

### Fixed
- CommonSense resolver import path and inline JSON error string quoting so `test_resolver.py` and `test_symbols.py` can import and execute `COMMONSENSE/resolver.py` from the repo root without `SyntaxError`/`ModuleNotFoundError`.

### Changed
- Roadmap v2.1 updated with a new “Semiotic Compression & Expansion” thread (Phase 1.6) to reduce token overhead via deterministic symbolic plans and code addressing.
## [1.13.0] - 2025-12-24

### Added
- Phase 0 contract freeze: three Draft-07 schemas (`SCHEMAS/jobspec.schema.json`, `SCHEMAS/validation_error.schema.json`, `SCHEMAS/ledger.schema.json`) plus the canonical valid/invalid fixtures under `FIXTURES/phase0/`.
- `CATALYTIC-DPT/TESTBENCH/test_schemas.py` proves the schema contract by loading each Draft-07 definition, ensuring valid fixtures pass and invalid fixtures fail, guarding future contract changes.

## [1.12.0] - 2025-12-24

### Changed
- Roadmap updated to v2.1 with expanded phases, concrete run artifacts, and enforcement model.
- Archived ROADMAP.md to ARCHIVE/ROADMAP.md as historical intent.
- Fixed inconsistent changelog dates (normalized all entries to 2025-12-24).

## [1.11.0] - 2025-12-24

### Added
- **SPECTRUM-03 Chain Verification**: Temporal integrity across sequences of runs using bundle-only memory.
- **verify_spectrum03_chain() Function**: Verifies chains of SPECTRUM-02 bundles with:
  - Individual bundle verification via `verify_spectrum02_bundle`
  - Output registry construction from `OUTPUT_HASHES.json` keys
  - Reference validation against available outputs (if `references` field present in TASK_SPEC)
  - Chain order enforcement (currently passed order, with TODO for timestamp parsing)
  - No history dependency assertion (verification uses only bundle artifacts)
- **Chain Memory Model**: Defines what persists across runs:
  - Allowed: `run_id`, durable output paths, SHA-256 hashes, validator identity, status
  - Forbidden: logs/, tmp/, chat transcripts, reasoning traces, intermediate state
- **New Error Code**:
  - `INVALID_CHAIN_REFERENCE`: TASK_SPEC references output not produced by earlier run or self
- **Test Suite**: `TESTBENCH/spectrum/test_spectrum03_chain.py` with 23 tests covering:
  - Chain acceptance when all bundles verify
  - Rejection on middle-run tampering (HASH_MISMATCH)
  - Rejection on missing bundle artifacts (BUNDLE_INCOMPLETE)
  - Rejection on invalid output references (INVALID_CHAIN_REFERENCE)
  - No history dependency (acceptance without logs/tmp/transcripts)

### Security Properties
- **Tamper Evidence**: Any modification to outputs after bundle generation detected via hash mismatch
- **Reference Integrity**: Runs cannot claim dependencies on non-existent outputs
- **Temporal Ordering**: Strict ordering maintained (future enhancement for timestamp-based validation)
- **Fail Closed**: Chain verification rejects on any ambiguity; partial acceptance not allowed

## [1.10.0] - 2025-12-24

### Added
- **Validator Version Integrity**: Deterministic build fingerprint binding in OUTPUT_HASHES.json.
- **get_validator_build_id() Function**: Returns audit-grade validator provenance:
  - Preferred: `git:<short-commit>` from repository HEAD
  - Fallback: `file:<sha256-prefix>` of MCP/server.py file hash
  - Cached for process lifetime, deterministic within repo state
- **Enhanced OUTPUT_HASHES.json Schema**:
  - Added `validator_semver` (semantic version of validator)
  - Added `validator_build_id` (deterministic build fingerprint)
  - Renamed from `validator_version` to `validator_semver` for clarity
- **Strict Build ID Verification**: `verify_spectrum02_bundle(strict_build_id=True)` option:
  - Rejects bundles if `validator_build_id` differs from current validator
  - Enables audit-trail and version-lock verification
- **New Error Codes**:
  - `VALIDATOR_BUILD_ID_MISSING`: Build ID missing or empty
  - `VALIDATOR_BUILD_MISMATCH`: Build ID differs from current (strict mode)
- **Test Suite**: `test_validator_version_integrity.py` with 20 tests covering:
  - Bundle emission includes both validator fields
  - Build ID determinism and caching
  - Strict mode rejection on mismatch
  - Missing/empty build ID rejection

### Changed
- `VALIDATOR_VERSION` constant renamed to `VALIDATOR_SEMVER` (semantic clarity)
- `SUPPORTED_VALIDATOR_VERSIONS` renamed to `SUPPORTED_VALIDATOR_SEMVERS`
- Updated all tests to use new field names

## [1.9.0] - 2025-12-24

### Added
- **SPECTRUM-02 Adversarial Resume**: Durable bundle emission for resume without execution history.
- **OUTPUT_HASHES.json Generation**: Automatic generation on successful skill_complete containing:
  - SHA-256 hashes for every declared durable output (files and directory contents).
  - Validator version binding for future compatibility.
  - Posix-style paths relative to PROJECT_ROOT for deterministic resumption.
- **verify_spectrum02_bundle() Method**: Verifies resume bundles checking:
  - Artifact completeness (TASK_SPEC.json, STATUS.json, OUTPUT_HASHES.json).
  - Status validity (status=success, cmp01=pass).
  - Validator version support.
  - Hash integrity across all outputs.
  - Returns structured errors: BUNDLE_INCOMPLETE, STATUS_NOT_SUCCESS, CMP01_NOT_PASS, VALIDATOR_UNSUPPORTED, OUTPUT_MISSING, HASH_MISMATCH.
- **SPECTRUM-02 Specification**: Formal spec at `SPECTRUM/SPECTRUM-02.md` defining:
  - Resume bundle artifact set (minimal, durable-only).
  - Explicitly forbidden artifacts (logs, tmp, transcripts, reasoning traces).
  - Resume rule (verification-only, no history inference).
  - Agent obligations on resume (fail closed, no hallucination).
- **Test Suites**:
  - `TESTBENCH/spectrum/test_spectrum02_resume.py`: 30 tests verifying bundle acceptance, rejection, and no-history-dependency.
  - `TESTBENCH/spectrum/test_spectrum02_emission.py`: 25 integration tests for bundle generation and verification in real MCP flows.

### Fixed
- **Fail Closed on Bundle Generation**: skill_complete now fails if OUTPUT_HASHES.json generation fails, preventing incomplete bundles.

## [1.8.0] - 2025-12-24

### Added
- **CATLAB-01 Implementation**: Released `TESTBENCH/catlab_stress` for proving catalytic temporal integrity.
- **Stress Test Fixture**: `test_catlab_restoration.py` containing deterministic population, mutation, and restoration logic.
- **Restoration Contract**: Validated helper functions (`populate`, `mutate`, `restore`) ensuring byte-identical restoration of catalytic domains.
- **Verification Suite**: 4 tests verifying:
  - Happy path full restoration.
  - Detection of single-byte corruption.
  - Detection of missing files.
  - Detection of rogue extra files.
- **Artifact Generation**: Tests now output `PRE_SNAPSHOT.json`, `POST_SNAPSHOT.json`, and `STATUS.json` for audit capabilities.

## [1.7.0] - 2025-12-24

### Added
- **TASK_SPEC Anti-tamper**: SHA-256 integrity hashing of `TASK_SPEC.json` at execution start, verified at completion.
- **Run Status Persistence**: `STATUS.json` created on completion with `run_id`, `status`, `cmp01` (pass/fail), and timestamp.
- **Symlink Escape Protection**: Added `.resolve()` containment check against `PROJECT_ROOT` to catch escapes via symlinks in allowed roots.
- **Audit-Grade Tests**: Expanded `test_cmp01_validator.py` to 31 tests including hermetic symlink escape proofing and integrity tampering simulation.

### Fixed
- **Index Reporting**: `PATH_OVERLAP` errors now correctly report original `JobSpec` indices in JSON Pointers.
- **Path Semantics**: Exact duplicate paths are now allowed/deduped (Option 1 policy), avoiding overlapping-self false positives.
- **Forbidden Loop Bug**: Post-run validation now correctly breaks on forbidden overlap to avoid redundant/shadow errors for the same entry.
- **Silent Skipping**: Post-run should no longer silenty skip absolute/traversal paths; it now reports `PATH_ESCAPES_REPO_ROOT` or `PATH_CONTAINS_TRAVERSAL`.

## [1.6.0] - 2025-12-24

### Added
- **CMP-01 Path Validation**: Strict path governance in `MCP/server.py`:
  - `_validate_jobspec_paths()`: Pre-execution validation for catalytic_domains and durable_paths.
  - `_verify_post_run_outputs()`: Post-run verification of declared output existence.
  - Component-safe path containment checks using `pathlib.is_relative_to`.
  - Rejection of traversal (`..`), absolute paths, and forbidden root overlaps.
- **Root Constants**: `DURABLE_ROOTS`, `CATALYTIC_ROOTS`, `FORBIDDEN_ROOTS` defined per CMP-01 spec.
- **Structured Error Vectors**: All validation errors now return `{code, message, path, details}` format.
- **Test Suite**: `TESTBENCH/test_cmp01_validator.py` with 9 unit tests covering:
  - Traversal rejection
  - Absolute path rejection
  - Forbidden overlap detection
  - Durable/catalytic root enforcement
  - Nested overlap detection
  - Missing output post-run detection

### Changed
- `execute_skill()` now calls `_validate_jobspec_paths()` before execution.
- `skill_complete()` now calls `_verify_post_run_outputs()` to verify declared outputs exist.

## [1.5.0] - 2025-12-24


### Added
- Official `mcp-builder` skill from `anthropics/skills`.
- Official `skill-creator` skill from `anthropics/skills`.

### Changed
- **Skills Standardization**:
  - All `SKILL.md` files updated to explicitly link to their bundled resources (scripts, assets, and references).
  - `governor` skill now correctly references `GOVERNOR_SOP.json`, `HANDOFF_TO_GOVERNOR.md`, and `GOVERNOR_CONTEXT.md`.
  - `launch-terminal` skill now references `ANTIGRAVITY_BRIDGE.md`.
  - `ant-worker` skill now references `schema.json` and task fixtures.
  - `swarm-orchestrator` skill now references launcher scripts.
  - `file-analyzer` skill now references analysis scripts.
- **Path Correction**: Fixed `HANDOFF_TO_GOVERNOR.md` pointing to non-existent `GOVERNOR_SOP.json` in the root (now correctly points to `assets/`).

### Removed
- `LICENSE.txt` from `skill-creator` and `mcp-builder` (non-functional token bloat).

## [1.4.0] - 2025-12-24

### Changed
- **Skills Reorganization** (agentskills.io spec compliance):
  - All skills now have proper YAML frontmatter in `SKILL.md` (name, description, compatibility).
  - Restructured folder layout: `scripts/`, `assets/`, `references/` per spec.
  - Moved executables to `scripts/` subdirectory:
    - `ant-worker/scripts/run.py`
    - `governor/scripts/run.py`
    - `file-analyzer/scripts/run.py`
    - `launch-terminal/scripts/run.py`
    - `swarm-orchestrator/scripts/poll_and_execute.py`, `poll_tasks.py`, `agent_loop.py`, `launch_swarm.ps1`
  - Moved test fixtures to `assets/` (renamed from `fixtures/`).
  - Moved reference docs to `references/` (GEMINI.md → governor/references/, etc.).
  - Removed redundant skill-level README (use SKILL.md instead).

### Fixed
- MCP stdio_server: Added `skill_run` tool for proper skill execution via MCP.
- Fixed import paths in orchestrator scripts after reorganization.

## [1.3.0] - 2025-12-24

### Added
- `SKILLS/governor/fixtures/phase0_directive.json`: Phase 0 task as structured JSON directive.

### Changed
- Merged `GOVERNOR_CONTEXT.md` into `SKILLS/governor/SKILL.md` (role + MCP commands now in skill).
- Converted `HANDOFF_TO_GOVERNOR.md` to skill fixture format.
- Trimmed `ORCHESTRATION_ARCHITECTURE.md` from 16KB to 7KB (removed verbose examples).
- Updated `README.md` to reflect actual SKILLS folder structure.

### Removed
- `HANDOFF_TO_GOVERNOR.md` (now `SKILLS/governor/fixtures/phase0_directive.json`)
- `GOVERNOR_CONTEXT.md` (merged into `SKILLS/governor/SKILL.md`)
- `PHASE0_IMPLEMENTATION_GUIDE.md` (redundant with `SCHEMAS/README.md`)
- `pop_swarm_terminals.py` (redundant with `launch_swarm.ps1`)

---

## [1.2.0] - 2025-12-24

### Added
- `swarm_config.json`: Centralized configuration for model/role assignments (the "Symbolic Link" for agents).
- `CHANGELOG.md`: This file, to track DPT-specific evolution.

### Changed
- **Hierarchy Generalization**: Refactored the entire department documentation to be model-agnostic.
  - Established hierarchy: **God (User) → President (Orchestrator) → Governor (Manager) → Ants (Executors)**.
  - Replaced hardcoded references to "Claude", "Gemini", and "Grok" with their respective functional roles.
  - Documentation now references `swarm_config.json` for current implementations.
- **File Renaming**:
  - `CODEX_SOP.json` → `GOVERNOR_SOP.json` (Reflecting the new role-based naming).
  - `HANDOFF_TO_CODEX.md` → `HANDOFF_TO_GOVERNOR.md`.
- **Core Documentation**:
  - `ORCHESTRATION_ARCHITECTURE.md`: Updated diagram and roles to reflect the new hierarchy.
  - `GOVERNOR_SOP.json`: Fully generalized instructions for any CLI Manager.
  - `README.md`: Updated directory tree and success criteria.
  - `ROADMAP.md`: Removed model-specific parameter (e.g., "200M") constraints.
  - `TESTBENCH.md`: Updated instructions for the Governor.
  - `GOVERNOR_CONTEXT.md`: Transitioned from "Claude" to "President".

### Cleaned
- Removed legacy "Codex" and "Codex-governed" terminology.
- Deleted redundant index/temporary files from the root of `CATALYTIC-DPT`.

---

## [1.1.0] - 2025-12-24
- Initial setup of Catalytic-DPT directory.
- Defined Phase 0 contracts (JSON Schemas).
- Established first iteration of Multi-Agent Orchestration.
```

## `repo/MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_README.md`

````
<!-- CONTENT_HASH: 32298f8d95622075b7848fce86ef5501356fd039c7db7d09d4fa0e3ce85e0998 -->

# CATALYTIC-DPT (Department)

**Status**: R&D → PoC → Integration
**Purpose**: Isolated development of catalytic computing system before integration into AGS proper
**Governance**: Sandboxed from main repo; testable independently; zero impact on AGS until exit criteria met
**Intent**: See [docs/INTENT.md](docs/INTENT.md) for core guarantees and constraints

---

## Directory Structure

```
CATALYTIC-DPT/
├── README.md                    # This file
├── ROADMAP.md                   # Phase 0-7 execution plan
├── TESTBENCH.md                 # PoC testing strategy and fixtures
├── swarm_config.json            # Model assignments for each role
├── GOVERNOR_SOP.json            # Operating manual for autonomous execution
├── ORCHESTRATION_ARCHITECTURE.md # Multi-agent system design
│
├── PRIMITIVES/                  # Core implementations
│   ├── catalytic_store.py       # Content-addressable storage
│   ├── merkle.py                # Merkle tree for root digests
│   ├── spectral_codec.py        # Domain → spectrum encoding
│   ├── ledger.py                # Append-only receipt storage
│   ├── validator.py             # Schema validation + error vectors
│   └── __init__.py
│
├── SCHEMAS/                     # Phase 0 contracts (JSON schemas)
│   ├── jobspec.schema.json      # Canonical job specification
│   ├── validation_error.schema.json
│   ├── ledger.schema.json
│   └── README.md                # Schema documentation
│
├── TESTBENCH/                   # PoC test environment
│   ├── run_poc.py               # Main test runner
│   ├── smoke_test.json          # Minimal sanity check
│   └── report.md                # Execution report
│
├── FIXTURES/                    # Example data for testing
│   ├── phase0/                  # Phase 0 schema examples
│   │   ├── valid/
│   │   └── invalid/
│   ├── phase1/                  # Phase 1 CATLAB examples
│   │   ├── store_tests/
│   │   ├── merkle_tests/
│   │   └── ledger_tests/
│   └── adversarial/             # Edge cases
│
└── SKILLS/                      # Swarm agent skills
    ├── governor/                # Governor (Manager) skill
    ├── ant-worker/              # Ant Worker (Executor) skill
    ├── file-analyzer/           # File analysis skill
    └── templates/               # Task templates
```

---

## Current Phase

**Phase 0: Contracts** (In Progress)

Define three canonical schemas before any implementation:
1. ✓ JobSpec JSON schema
2. ✓ Validation error vector format
3. ✓ Run ledger schema

**Phase 1: CATLAB** (Next)

Tiny R&D proof with real weight updates:
- `catalytic_store.py` (CAS)
- `merkle.py` (root digests)
- `spectral_codec.py` (domain encoding)
- `ledger.py` (receipt storage)
- `validator.py` (schema validation)
- Micro-orchestrator with gradient updates

**Phase 2-7**: See ROADMAP.md

---

## Success Criteria (PoC)

### Phase 0 Exit
- [ ] All three schemas defined and validated
- [ ] Schemas can validate themselves
- [ ] Documentation is clear for Governor/Executor

### Phase 1 Exit
- [ ] `catalytic_store.py` passes all fixtures (100-500 test cases)
- [ ] `merkle.py` produces stable roots for identical inputs
- [ ] `ledger.py` appends deterministically
- [ ] `validator.py` correctly identifies schema violations
- [ ] Micro-orchestrator weights update and improve accuracy
- [ ] No regression after weight updates
- [ ] Full restoration proof passes for all test runs

### Integration Checkpoint
- [ ] Zero impact on existing AGS operations
- [ ] All catalytic operations logged and auditable
- [ ] Critic.py enforces catalytic boundaries
- [ ] Tests pass in CI

---

## Autonomy and Delegation

This department is designed for **autonomous execution by the Governor and Ant Workers**:

1. **SOP**: Follow `GOVERNOR_SOP.json` for step-by-step execution
2. **MCP Tools**: Call MCP tools for governance, validation, execution
3. **Logging**: Every decision goes to `task_log.jsonl`
4. **Fallback**: Escalate to President (Orchestrator) if governance fails

---

## Integration Path

When Phase 1 PoC passes:

1. **Skills Migration**: Create AGS skills wrapper for each primitive
2. **CI Integration**: Add catalytic tests to `CONTRACTS/runner.py`
3. **Validator Upgrade**: Extend `TOOLS/critic.py` to enforce catalytic rules
4. **Lane F Integration**: Merge into main AGS roadmap as Phase 6

---

## References

### Core Research (in RESEARCH/)
- `RESEARCH/New Vision/CATALYTIC_COMPRESSION_REPORT.md` - **Two-plane architecture** (control vs data plane)
- `RESEARCH/New Vision/CATALYTIC_FINDINGS_REPORT.md` - Full R&D synthesis
- `RESEARCH/New Vision/CATALYTIC_ROADMAP.md` - Original phase plan

### Implementation
- `RESEARCH/MASTER_PLAN.md` - Implementation blueprint
- `RESEARCH/CMP-01_CATALYTIC_MUTATION_PROTOCOL.md` - Mutation protocol spec

### AGS Integration
- `../CANON/CATALYTIC_COMPUTING.md` - Canonical definition
- `../AGS_ROADMAP_MASTER.md` - Lane F (Catalytic Computing)

---

## Status

- **Created**: 2025-12-23
- **Phase**: 0 (Contracts)
- **Token Budget**: Isolated from main system
- **Testability**: PoC before integration
- **Governance**: Sandboxed with clear boundaries
````

## `repo/MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_RELEASE_CHECKLIST.md`

```
<!-- CONTENT_HASH: 6c1fc06487b567adda2a1d92c0472c8a7f724ba8a349a4cf710805ac92f86632 -->

# CAT-DPT Release Checklist (Law Changes)

Use this checklist when changing schemas, validator identity, or capability semantics.

## 1. Governance
- [x] ADR drafted and accepted in `CONTEXT/decisions/` (Covered by Roadmap Phase 7 spec).
- [x] `CHANGELOG.md` updated with descriptive entry (v1.61.0).
- [x] `CANON/VERSIONING.md` bumped (Minor for additive, Major for breaking).

## 2. Schema Hardening
- [x] New schema versioned correctly (if breaking).
- [x] `additionalProperties: false` set where appropriate.
- [x] Schema examples updated in `SCHEMAS/examples/`.

## 3. Tooling Compatibility
- [x] `PipelineRuntime` updated with new `validator_semver`.
- [x] `ags.py` plan/route/run commands verified against new schemas.
- [x] `catalytic.py` hash/pipeline commands verified.

## 4. Regression & historical Verification
- [x] Run `python -m pytest CATALYTIC-DPT/TESTBENCH/`.
- [x] Verify that at least one historical run (e.g., from `FIXTURES/`) still passes verification.
- [x] Test a "resume" scenario where a pipeline started with old law is finished under new law (if applicable).

## 5. Artifact Consistency
- [x] Ensure all required artifacts (`PROOF.json`, `LEDGER.jsonl`, etc.) are byte-identical for identical inputs.
- [x] Verify `POLICY.json` captures all relevant snapshots.

## 6. Known Issues / Investigations (Post-v2.12.0)
- [x] **Packer Hygiene:** `test_packer_determinism_catalytic_dpt` fails with hash mismatch on Windows. Investigate CRLF/normalization in `packer.make_pack`. **(FIXED via timestamp pinning)**
- [ ] **Swarm Terminal Instability:** External terminals are flaky. Avoid `use_terminal=True` for now.
```

## `repo/MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_RELEASE_REPORT.md`

```
<!-- CONTENT_HASH: 697622077f9cfc149ac212aea36c2b2a910a1e50aeff8d4640e2466f60f4704c -->

# Release Report: Phase 7.3 & Governance Alignment

**Date:** 2025-12-28
**Status:** ✅ **READY FOR RELEASE**
**Version Scope:** Phase 7 (Catalytic Swarms) & Phase 6/7 cleanup.

## Executive Summary
All critical blockers identified in the `TEST_FAILURES_REPORT.md` have been resolved. The system has achieved "All Clear" status on the global `runner.py` contract fixtures and the critical component test suite (`pytest`). The repository is now compliant with its own invariants, including the newly recognized `INV-012` (Visible Execution).

## 1. Resolved Blockers

### 🟢 Packer Determinism
- **Issue:** Non-deterministic pack hashes due to variable timestamps.
- **Fix:** Implemented `LLM_PACKER_DETERMINISTIC_TIMESTAMP` override in `core.py`.
- **Verification:** `test_packing_hygiene.py` now passes consistently.

### 🟢 Infrastructure Robustness (AGS CLI)
- **Issue:** Tests failing due to "dirty" local workspace state and `stderr` pollution.
- **Fix:** Added `--skip-preflight` to `ags run` and suppressed `jsonschema` deprecation warnings.
- **Verification:** `test_ags_phase6_bridge.py` and `test_ags_phase6_router_slot.py` pass.

### 🟢 Swarm Integrity
- **Issue:** Execution elision logic was theoretically vulnerable to state reuse issues.
- **Fix:** Hardened `SwarmRuntime` artifact verification and improved test harness cleanup.
- **Verification:** `test_swarm_reuse.py` passes (Verify -> Tamper -> Reject).

### 🟢 Governance Drift
- **Issue:** `invariant-freeze` skill expected 11 invariants, but 12 exist.
- **Fix:** Updated skill fixtures to recognize `INV-012` (Visible Execution).
- **Verification:** `CONTRACTS/runner.py` passes all 40+ fixtures.

## 2. Validation Status

| Component | Status | verification Method |
|-----------|--------|---------------------|
| **Contracts** | ✅ PASS | `python CONTRACTS/runner.py` |
| **Governance** | ✅ PASS | `python TOOLS/critic.py` |
| **Logic** | ✅ PASS | `pytest CATALYTIC-DPT/TESTBENCH/` |
| **Packer** | ✅ PASS | Deterministic Hash Verification |

## 3. Known Issues & Advisories

### ⚠️ Swarm Terminal Instability
- **Description:** Spawning external terminal windows for swarm workers is currently flaky on Windows.
- **Workaround:** Do not use `use_terminal=True` in swarm specs until the `subprocess` / `start` logic is hardened. Use in-process execution.

## 4. Release Recommendation
Proceed with committing the current state as the baseline for **Phase 7.4 (Swarm Recovery)**.
```

## `repo/MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_ROADMAP_V2.3.md`

```
<!-- CONTENT_HASH: 66f36203c142f7119f91e249e197021cefaed88bd0ff1c743273896523e7da89 -->

# CATALYTIC-DPT ROADMAP v2.3
Date: 2025-12-25  
Status: ACTIVE

## Goal
Turn CAT-DPT into a **verifiable, model-agnostic execution substrate** that can safely run a **swarm** (many steps, many tools, many models) without relying on chat history or trust.

The north star:
- **Artifacts over narrative**
- **Determinism over convenience**
- **Fail-closed over “best effort”**
- **Hash-first, bounded dereference** so token and I/O cost is measurable and capped

## Operating rules
Non-negotiables:
- No runtime-generated timestamps. If a timestamp exists, it is caller-supplied and recorded as-is.
- Every acceptance claim must be artifact-verifiable (tests and/or fixtures).
- No silent downgrade paths. CI and verifiers must hard-require strictness.
- No unbounded reads. Any dereference or inspection must be bounded.
- Append-only receipts. If you need “state”, write a new record, do not mutate the past.
- Schema-first. Every persistent artifact has a schema (or a canonical JSON contract).

## Phase gates (the only definition of “done”)
> A phase is DONE only when its gate is DONE.

### Phase 0 Gate: Contract freeze + enforcement (DONE)
- [x] All schemas strict (no unknown fields) where appropriate.
- [x] CI enforces strict verification paths.
- [x] Fixtures represent real contracts.

### Phase 1 Gate: Kernel substrate (DONE)
- [x] CAS (streaming, deterministic layout).
- [x] Merkle roots per domain (deterministic ordering).
- [x] Ledger receipts (append-only JSONL, schema-valid, canonical JSON bytes).
- [x] Proof wiring (byte-identical reruns, tamper detection).

### Phase 1X Gate: Expand-by-hash usability (DONE)
- [x] hash read|grep|describe|ast with hard caps and hash-only dereference.
- [x] Optional deref logging into ledger (hash + bounds only, no content).

### Phase 1V Gate: Verifiers and validator identity (DONE)
- [x] Strict verifier behavior enforced in CI and CLI.
- [x] Validator identity pin is law-frozen and verified.

### Phase 2 Gate: Memoization (never pay twice) (DONE)
- [x] Cache keys bind to job + inputs + toolchain + validator identity.
- [x] Cache hits still emit verifiable receipts and proofs.
- [x] Demo exists showing reduced work with bounded hash dereference while PROOF remains byte-identical.

### Phase 3 Gate: Packing hygiene (DONE)
- [x] Packs are deterministic, bounded, deduplicated, fail-closed.

### Phase 4 Gate: Runtime hardening (DONE)
DONE when all are true:
- [x] Adversarial fixtures exist for corruption, partial state, path attacks, malformed proofs, pipeline interruption/resume safety.
- [x] Fail-closed everywhere (no "warn and continue" in any verifier path).
- [x] No silent acceptance (every acceptance has an explicit reason code).

### Phase 5 Gate: Pipelines (DONE)
- [x] Artifact-only pipeline runner with resume-safe STATE.
- [x] Proof chain exists and is verifiable.
- [x] CLI verification for pipelines is fail-closed.

### Phase 6 Gate: Swarm integration surface (DONE)
DONE when all are true:
- [x] Phase 6.1 model-free bridge exists (emit pipeline spec, run + verify).
- [x] Phase 6.2 router slot exists (external plan producer, schema-validated, capped, fail-closed).
- [x] Phase 6.3 adapter contract exists (skills/MCPs wrap schema-valid jobspec; no runtime bypass).
- [x] Phase 6.4 MCP adapter is first-class (schema + tests + caps + deterministic transcript hashing).
- [x] Phase 6.5 Skill registry exists (hash-addressed capabilities; inclusion in proofs).
- [x] Phase 6.6 Capability pinning exists (explicit, auditable).
- [x] Phase 6.7 Registry immutability backstop exists (canonical validation + adversarial tests).
- [x] Phase 6.8 Capability versioning semantics (no-history-break).
- [x] Phase 6.9 Capability revocation semantics (no-history-break). (commit: this changeset)

---

## Canonical run artifact set (required)
A run is only “real” if these exist and validate:
- `PROOF.json`
- `DOMAIN_ROOTS.json`
- `LEDGER.jsonl`
- `PRE_MANIFEST.json` (or equivalent field inside ledger record)
- `POST_MANIFEST.json` (or equivalent field inside ledger record)
- durable outputs (as declared)

For pipelines:
- `PIPELINE.json`
- `STATE.json`
- `CHAIN.json` (or equivalent proof chain artifact)

For swarm (Phase 7+):
- `SWARM.json` (spec)
- `SWARM_STATE.json`
- `SWARM_CHAIN.json` (top-level chain across pipelines)

---

## PHASE 4: Runtime hardening (DONE)
Deliverables
- [x] Adversarial fixtures: corrupted artifacts, partial state, path attacks, malformed proofs, pipeline interruption/resume safety.
- [x] Tighten guards as needed, always with fixtures and regression tests.
- [x] Fix ledger.schema.json $ref resolution (Draft7)

Acceptance
- [x] Fail-closed everywhere.
- [x] No silent acceptance.

Notes
- This phase never fully ends. It is the “immune system”: add fixtures first, then guards, then regressions.

---

## PHASE 6.4: MCP adapter becomes first-class
Intent
Make MCP servers usable as governed adapters inside pipelines without expanding trust boundaries.

Deliverables
- [x] `mcp_adapter.schema.json` with strict, fail-closed constraints:
  - server command vector (non-empty list of strings)
  - request envelope schema (canonical JSON)
  - stdout/stderr caps, timeout cap, exit code rules
  - transcript hashing rules (hash of bytes actually read, not “what should have been read”)
- [x] Implementation in `ags.py` (or a dedicated module) that:
  - executes MCP server as a subprocess
  - rejects any stderr output (or allowlisted patterns if absolutely necessary)
  - enforces byte caps on stdout
  - produces a deterministic adapter output artifact (canonical JSON) plus transcript hash
  - compiles to a Phase 6.3 adapter + schema-valid jobspec (no runtime bypass)
- [x] Tests: happy path + reject cases
  - over-cap output
  - timeout
  - non-zero exit
  - stderr emitted
  - non-canonical JSON
  - non-normalized paths / overlaps in produced jobspec
  - backstop: adapter step runs in a pipeline and strict verify detects output tampering (`CATALYTIC-DPT/TESTBENCH/test_ags_phase6_mcp_adapter_e2e.py`)

Acceptance
- [x] MCP step can run in a pipeline and produce proof-valid artifacts.
- [x] Re-running the same MCP step (same inputs) yields byte-identical artifacts.
- [x] Any cap breach fails closed with a stable error code.

---

## PHASE 6.5: Skill registry (hash-addressed capabilities)
Intent
Turn “skills” into immutable, discoverable, auditable capabilities.

Implemented (v1)
- `CAPABILITIES.json` provides `capability_hash -> adapter spec` resolution and is enforced in `ags route` and `catalytic pipeline verify` (fail-closed).

Deliverables
- [x] `SKILLS/registry.json` (canonical JSON) mapping:
  - `skill_id` -> `adapter_hash` (or `adapter_spec_path` + hash)
  - `version`
  - `capability_hash` (defined below)
  - `human_name`, `description` (optional, non-normative)
- [x] `skills.py` helper to:
  - load registry deterministically
  - resolve skill -> adapter spec by hash
  - reject unknown skills and mismatched hashes
- [x] `ags.py` integration:
  - allow plan steps to reference `skill_id` instead of embedding full adapter
  - expand `skill_id` deterministically into adapter+jobspec before routing
- [x] Tests:
  - registry determinism
  - tamper in adapter spec changes capability hash and fails verification
  - unknown skill fails closed
  - duplicate skill_id rejects

Capability hash (v1)
- `capability_hash = sha256(canonical_json({adapter_schema, adapter_payload, jobspec_hash, global_caps}))`
- It is a pin on *what the skill can do*, not who authored it.

Acceptance
- [x] Skill resolution is hash-addressed and tamper-evident.
- [x] Proof/ledger includes enough to reconstruct which skill capability was used.

---

## PHASE 6.6: Capability pinning and revocation (auditable)
Intent
Make “who/what is allowed to produce accepted work” explicit and reversible.

Implemented (v1)
- `CAPABILITY_PINS.json` allowlists permitted `capability_hash` values; both `ags route` and `catalytic pipeline verify` reject known-but-unpinned capabilities fail-closed.

Deliverables
- [x] Add `CAPABILITY_PINS.json` (canonical) that lists allowed capability hashes for a run/pipeline (or references a pinned set).
- [x] Verifiers fail closed if a step uses a capability hash not in the allowed set.
- [x] Revocation mechanism:
  - an explicit denylist or a new pinned set (no silent mutation)
  - deterministic precedence rules

Acceptance
- [x] “Allow” and “deny” decisions are explicit artifacts.
- [x] Changing allowed capabilities changes the proof hash (no invisible policy changes).

---

## PHASE 6.7: Registry immutability and CI backstop (fail-closed)
Intent
Prevent silent mutation and non-canonical registry drift for capability governance artifacts.

Deliverables
- [x] Canonical validation for `CAPABILITIES.json` and `CAPABILITY_PINS.json` (no duplicates, canonical JSON bytes, sorted ordering).
- [x] Enforced at route time (`ags route`) and verify time (`catalytic pipeline verify`) with stable error codes:
  - `REGISTRY_DUPLICATE_HASH`
  - `REGISTRY_NONCANONICAL`
  - `REGISTRY_TAMPERED`
- [x] Adversarial tests exercising duplicate hashes, non-canonical encoding, and tamper detection.

Acceptance
- [x] Any malformed/non-canonical/tampered registry fails closed before execution and during verification.

---

## PHASE 6.8: Capability versioning semantics (no-history-break)
Intent
Make capability versioning semantics explicit: capabilities are immutable-by-content and historical verification must remain possible.

Deliverables
- [x] Route/verify surfaces use a dedicated boundary error code `CAPABILITY_HASH_MISMATCH` when a capability hash cannot be re-derived from the registry adapter spec bytes.
- [x] Tests assert that changing adapter spec bytes requires a new capability hash; “in-place upgrade” is rejected deterministically.

Acceptance
- [x] Existing capability hashes remain verifiable as long as their registry entries remain present and correct.

---

## PHASE 6.9: Capability revocation semantics (no-history-break) (DONE)
Intent
Block future use of a capability without breaking historical verification of pre-revocation runs.

Deliverables
- [x] `CAPABILITY_REVOKES.json` exists (deterministic ordering) and is enforced at route time with `REVOKED_CAPABILITY`.
- [x] Pipeline verification rejects post-revocation use while preserving verification of pre-revocation pipelines (policy snapshot).
- [x] Tests prove route rejection, historical verify pass, and post-revocation verify failure.

Acceptance
- [x] A revoked capability cannot be used in new accepted work, but old work remains mechanically verifiable.

---

### Phase 7 Gate: Swarm scheduling (DONE)
- [x] Phase 7.0: deterministic Pipeline DAG scheduling (DAG spec + scheduler + resume + fail-closed DAG verification).
- [x] Phase 7.1: distributed execution receipts (portable receipts, chained by DAG topology, strict verification).
- [x] Phase 7.2: multi-node restore runner (receipt-gated, idempotent recovery; restore decisions verified).
- [x] Phase 7.3: catalytic swarm execution elision (identical swarms skip execution; emit valid, verifiable proofs).
- [x] `swarm.schema.json` for a DAG of pipelines.
- [x] `swarm_runtime.py` with `SWARM_STATE.json` and `SWARM_CHAIN.json`

Acceptance
- [x] A swarm run produces a top-level chain that binds each pipeline's proof.
- [x] Any missing or tampered pipeline proof fails the swarm verification.
- [x] Identical swarm re-execution elides all pipeline/skill/model execution and emits a valid swarm receipt.

Clarification: “Identical” is determined solely by the canonical swarm spec hash combined with the ordered pipeline intent hashes (plus the capability + policy hashes that govern the execution context).

Elided re-executions must still emit a new swarm receipt and top-level chain, reference the prior pipeline proofs by hash, and pass verification end-to-end without performing any pipeline/skill/model execution.

---

## PHASE 8: Model binding (optional, replaceable, never trusted)
Intent
Let local models (LFM2, etc.) produce plans, but never grant them authority.

Deliverables

- [x] Router receipt artifacts:
  - `ROUTER.json` (what ran, caps, hash of executable)
  - `ROUTER_OUTPUT.json` (canonical JSON plan output)
  - `ROUTER_TRANSCRIPT_HASH` (bytes read)
- [x] Cache router outputs by content hash (optional)
- [x] Tests:
  - router over-output fails closed
  - router stderr fails closed
  - malformed plan fails schema validation
  - plan that attempts capability escalation fails closed (Phase 6.6)

Acceptance
- [x] Swapping models does not change verification logic, only the produced plan.
- [x] Plans are validated, capped, and recorded, not trusted.

### Phase 9 Gate: Freeze, release discipline, and schema versioning (DONE)

- [x] Schema versioning policy.
- [x] Release checklist for "law changes".
- [x] Artifact-only verifiability audit.
- [x] Docs pass: single authoritative docs tree, no duplicated demo docs that can drift
```

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_CATALYTIC_README.md`

````
<!-- CONTENT_HASH: 32298f8d95622075b7848fce86ef5501356fd039c7db7d09d4fa0e3ce85e0998 -->

# CATALYTIC-DPT (Department)

**Status**: R&D → PoC → Integration
**Purpose**: Isolated development of catalytic computing system before integration into AGS proper
**Governance**: Sandboxed from main repo; testable independently; zero impact on AGS until exit criteria met
**Intent**: See [docs/INTENT.md](docs/INTENT.md) for core guarantees and constraints

---

## Directory Structure

```
CATALYTIC-DPT/
├── README.md                    # This file
├── ROADMAP.md                   # Phase 0-7 execution plan
├── TESTBENCH.md                 # PoC testing strategy and fixtures
├── swarm_config.json            # Model assignments for each role
├── GOVERNOR_SOP.json            # Operating manual for autonomous execution
├── ORCHESTRATION_ARCHITECTURE.md # Multi-agent system design
│
├── PRIMITIVES/                  # Core implementations
│   ├── catalytic_store.py       # Content-addressable storage
│   ├── merkle.py                # Merkle tree for root digests
│   ├── spectral_codec.py        # Domain → spectrum encoding
│   ├── ledger.py                # Append-only receipt storage
│   ├── validator.py             # Schema validation + error vectors
│   └── __init__.py
│
├── SCHEMAS/                     # Phase 0 contracts (JSON schemas)
│   ├── jobspec.schema.json      # Canonical job specification
│   ├── validation_error.schema.json
│   ├── ledger.schema.json
│   └── README.md                # Schema documentation
│
├── TESTBENCH/                   # PoC test environment
│   ├── run_poc.py               # Main test runner
│   ├── smoke_test.json          # Minimal sanity check
│   └── report.md                # Execution report
│
├── FIXTURES/                    # Example data for testing
│   ├── phase0/                  # Phase 0 schema examples
│   │   ├── valid/
│   │   └── invalid/
│   ├── phase1/                  # Phase 1 CATLAB examples
│   │   ├── store_tests/
│   │   ├── merkle_tests/
│   │   └── ledger_tests/
│   └── adversarial/             # Edge cases
│
└── SKILLS/                      # Swarm agent skills
    ├── governor/                # Governor (Manager) skill
    ├── ant-worker/              # Ant Worker (Executor) skill
    ├── file-analyzer/           # File analysis skill
    └── templates/               # Task templates
```

---

## Current Phase

**Phase 0: Contracts** (In Progress)

Define three canonical schemas before any implementation:
1. ✓ JobSpec JSON schema
2. ✓ Validation error vector format
3. ✓ Run ledger schema

**Phase 1: CATLAB** (Next)

Tiny R&D proof with real weight updates:
- `catalytic_store.py` (CAS)
- `merkle.py` (root digests)
- `spectral_codec.py` (domain encoding)
- `ledger.py` (receipt storage)
- `validator.py` (schema validation)
- Micro-orchestrator with gradient updates

**Phase 2-7**: See ROADMAP.md

---

## Success Criteria (PoC)

### Phase 0 Exit
- [ ] All three schemas defined and validated
- [ ] Schemas can validate themselves
- [ ] Documentation is clear for Governor/Executor

### Phase 1 Exit
- [ ] `catalytic_store.py` passes all fixtures (100-500 test cases)
- [ ] `merkle.py` produces stable roots for identical inputs
- [ ] `ledger.py` appends deterministically
- [ ] `validator.py` correctly identifies schema violations
- [ ] Micro-orchestrator weights update and improve accuracy
- [ ] No regression after weight updates
- [ ] Full restoration proof passes for all test runs

### Integration Checkpoint
- [ ] Zero impact on existing AGS operations
- [ ] All catalytic operations logged and auditable
- [ ] Critic.py enforces catalytic boundaries
- [ ] Tests pass in CI

---

## Autonomy and Delegation

This department is designed for **autonomous execution by the Governor and Ant Workers**:

1. **SOP**: Follow `GOVERNOR_SOP.json` for step-by-step execution
2. **MCP Tools**: Call MCP tools for governance, validation, execution
3. **Logging**: Every decision goes to `task_log.jsonl`
4. **Fallback**: Escalate to President (Orchestrator) if governance fails

---

## Integration Path

When Phase 1 PoC passes:

1. **Skills Migration**: Create AGS skills wrapper for each primitive
2. **CI Integration**: Add catalytic tests to `CONTRACTS/runner.py`
3. **Validator Upgrade**: Extend `TOOLS/critic.py` to enforce catalytic rules
4. **Lane F Integration**: Merge into main AGS roadmap as Phase 6

---

## References

### Core Research (in RESEARCH/)
- `RESEARCH/New Vision/CATALYTIC_COMPRESSION_REPORT.md` - **Two-plane architecture** (control vs data plane)
- `RESEARCH/New Vision/CATALYTIC_FINDINGS_REPORT.md` - Full R&D synthesis
- `RESEARCH/New Vision/CATALYTIC_ROADMAP.md` - Original phase plan

### Implementation
- `RESEARCH/MASTER_PLAN.md` - Implementation blueprint
- `RESEARCH/CMP-01_CATALYTIC_MUTATION_PROTOCOL.md` - Mutation protocol spec

### AGS Integration
- `../CANON/CATALYTIC_COMPUTING.md` - Canonical definition
- `../AGS_ROADMAP_MASTER.md` - Lane F (Catalytic Computing)

---

## Status

- **Created**: 2025-12-23
- **Phase**: 0 (Contracts)
- **Token Budget**: Isolated from main system
- **Testability**: PoC before integration
- **Governance**: Sandboxed with clear boundaries
````

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_ROADMAP.md`

````
<!-- CONTENT_HASH: ddd9e22be5a459396d51bd112e04ec4cb243e52ed996597364f575745b246e70 -->

# CATALYTIC-DPT Roadmap
**Two-Speed Plan: PoC First, Then Scale**

Date: 2025-12-23
Principle: Minimum effort, maximum revolution. Prove the thesis before expanding scope.

---

## North Star

Build a **catalytic agent system** where:
- External substrates (disk, DB, browser, tools, swarm) are the true workspace
- Context holds hashes, plans, and proofs
- Every run is auditable and reversible via restoration proofs
- Continuity exists as real weight shifting in a tiny orchestrator (small model)
- Parallelism is safe via single-commit governance

---

## Core Architecture: Two-Plane Model

*Source: RESEARCH/New Vision/CATALYTIC_COMPRESSION_REPORT.md*

### Control Plane (LLM-visible)
Small, structured, text-first artifacts:
- **SPECTRUM.json**: `{rel_path -> content_hash}`
- **STRUCTURE.json**: signatures, imports, symbols, AST skeletons
- **DOMAIN_ROOTS.json**: `{domain -> merkle_root}`
- **Ledgers, schemas, manifests**: all JSON, all verifiable

**Rule**: LLMs read spectrums, not file bodies. Token cost = O(paths), not O(bytes).

### Data Plane (tool-visible)
Large byte payloads, optionally compressed:
- **CAS blobs**: raw bytes stored by content hash
- **Intermediate artifacts**: AST dumps, indexes, search caches
- **Expansion on demand**: `read_hash(sha, range)` returns only what's needed

**Rule**: Hash raw bytes (not compressed). Compression is an impl detail.

### Why This Matters
- **Token efficiency**: LLM reads 2KB spectrum, not 200MB repo
- **Catalytic guarantees**: Merkle roots prove restoration without reading everything
- **Tiny model role**: Choose policy (which transform), not generate bitstreams
- **Verifiable**: Same inputs → same hashes → same roots

### Spectral Artifacts (Per Domain)
```
domain/
├── SPECTRUM.json      # path → hash (LLM reads this)
├── STRUCTURE.json     # signatures, exports, types (optional)
├── DOMAIN_ROOT.txt    # single Merkle root (32 bytes)
└── .cas/              # content-addressed blobs (tools expand)
```

---

## Phase 0: Freeze the Contract (1-2 hours)

**Goal**: Define canonical schemas before implementation

### Deliverables
- [x] JobSpec JSON schema (task specification format)
- [x] Validation error vector format (deterministic error reporting)
- [x] Run ledger schema (audit trail format)

### Tasks
1. Write `SCHEMAS/jobspec.schema.json`
   - Support Phase 0 and Phase 1 task types
   - Include catalytic_domains, durable_outputs, swarm_parallel
   - Include metadata (priority, timeout, governance_check)

2. Write `SCHEMAS/validation_error.schema.json`
   - Deterministic error codes (UPPERCASE_SNAKE_CASE)
   - Support for error paths and nested errors
   - Distinction between errors and warnings
   - Timestamp and validator version

3. Write `SCHEMAS/ledger.schema.json`
   - Reference jobspec.schema.json
   - Include pre/post manifests, restore_diff, outputs
   - Include decision_log field for timestamped decisions
   - Include restoration_verified boolean

4. Document schemas in `SCHEMAS/README.md`

### Exit Criteria
- All three schemas are valid JSON Schema Draft 7
- Each schema validates itself
- Documentation explains each field clearly
- The Governor can understand the schemas from docs

---

## Phase 1: CATLAB (Tiny R&D Proof) (1-3 days)

**Goal**: Prove catalytic continuity with smallest possible system

### 1.1 Implement Catalytic Kernel (Deterministic)

Build core primitives in `PRIMITIVES/`:

#### catalytic_store.py
Content-addressable storage (CAS) for data plane.

**Core Functions**:
- `put(content: bytes) -> hash` (SHA-256 of raw bytes)
- `get(hash: str) -> bytes` (auto-decompress if stored compressed)
- `verify(hash: str, content: bytes) -> bool`

**Storage**:
- Sharded: `_store/{hash[:2]}/{hash[2:4]}/{hash}`
- Atomic writes (temp + rename)
- Optional compression (zstd) as impl detail
- **Rule**: Hash raw bytes, not compressed bytes

~120 LOC

#### merkle.py
- `MerkleTree.__init__(items: List[Tuple[str, str]])`
- `root_hash() -> str`
- `proof(leaf_hash: str) -> List[str]` (O(log n) verification)
- `verify(root, leaf, proof) -> bool`
- ~150 LOC

#### spectral_codec.py
Transform domain (file system state) → spectral artifacts (LLM-visible layer).

**Core Functions**:
- `encode_domain(path: Path) -> SpectralBundle`
  - Returns: SPECTRUM.json, STRUCTURE.json (optional), DOMAIN_ROOT.txt
- `decode_domain(bundle: SpectralBundle, cas: CatalyticStore) -> Path`
  - Reconstructs directory from spectrum + CAS blobs
- `verify_domain(path: Path, expected_root: str) -> bool`
  - O(1) check via Merkle root comparison

**Output Artifacts**:
- `SPECTRUM.json`: `{rel_path -> content_hash}` (what LLM reads)
- `STRUCTURE.json`: signatures, imports, symbols (optional, for code)
- `DOMAIN_ROOT.txt`: single Merkle root (32-byte hex)

**Key Insight**: LLM reads spectrum (2KB), not files (200MB). Expansion by hash on demand.

~150 LOC

#### ledger.py
- Append-only receipt storage
- `append(entry: Dict) -> None` (to JSONL)
- `read_all() -> List[Dict]`
- Deterministic ordering
- ~50 LOC

#### validator.py
- JSON schema validation (uses `jsonschema` library)
- Error vector generation (deterministic error codes)
- `validate_jobspec(spec: Dict) -> ValidationResult`
- `validate_ledger(ledger: Dict) -> ValidationResult`
- ~200 LOC

### 1.2 Micro-Orchestrator with Real Weight Updates

Pick the smallest model mechanism that can learn from validators:
- Start with tiny controller: MLP (2 hidden layers, 128 units) or GRU (32 units)
- Update only a small module (adapter/memory/controller weights)
- Persist as `model_hash` + `delta_hash` artifacts
- Example: Given a JobSpec, predict "will this pass validation" → train on actual outcomes

#### micro_orchestrator.py (~300 LOC)
```
1. Load current model weights (or init if first time)
2. Receive JobSpec
3. Predict: valid_probability, recommended_retries
4. Execute job (via catalytic_store, merkle, ledger)
5. Observe: actual validation result
6. Compute: gradient w.r.t. prediction error
7. Update: weight delta (alpha * gradient)
8. Persist: new model hash (SHA-256 of weights)
9. Log: (input, prediction, actual, delta_hash) to ledger
```

### 1.3 Fixture Dataset

- 100-500 examples: prompts → valid JobSpecs
- Adversarial invalid cases: missing fields, wrong types, out-of-bounds
- Store in `FIXTURES/phase1/`

### Metrics

- Schema pass rate (% of specs that validate)
- Average retries per task (improvement over time)
- Regression rate (after weight updates, does accuracy drop?)
- Reproducibility (same seed, same results always)

### Exit Criteria
- [ ] Pass rate improves measurably across sessions due to weight updates
- [ ] Every delta is recorded, hashed, and rollbackable
- [ ] Root digests and ledgers match expectations (run twice, get same roots)
- [ ] No dependence on large models for the core loop (Governor can execute)
- [ ] All fixtures pass
- [ ] No regression detected

---

## Phase 2: Swarm Parallelism (Safe Learning) (1-2 days)

**Goal**: Accelerate evaluation without corrupting continuity

### Deliverables
- Worker runner that evaluates tasks in parallel
- Governor reducer that applies one committed update deterministically
- Rollback policy if regression detected

### Exit Criteria
- 10x evaluation throughput
- Deterministic outcomes regardless of worker completion order
- No race conditions

---

## Phase 3: Substrate Offload Adapters (2-5 days, incremental)

**Goal**: Generalize offloading beyond models to arbitrary compute

### 3.1 Browser Compute Adapter
- `browser_exec(js_code, input_hash) -> output_hash`
- Browser pulls from CAS, writes to CAS

### 3.2 DB Compute Adapter
- `db_exec(query, input_hashes) -> output_hash`
- SQLite/DuckDB for joins, analytics

### 3.3 Toolchain Adapter
- `cli_exec(tool, args, input_hashes) -> output_hash`
- Ripgrep, formatters, compilers

### Exit Criteria
- At least two substrates working with hash I/O and validators
- Ledger captures substrate versions and outputs for replay

---

## Phase 4: Catalytic Runtime Hardening (1-3 days)

**Goal**: Upgrade trust boundary correctness

### Deliverables
- Fix forbidden overlap validation (both directions)
- Enforce output existence checks
- Domain root checks for all domains
- Failure modes produce hard fail + diffs

### Exit Criteria
- Ledger cannot claim success if outputs don't exist
- Domain boundaries are airtight

---

## Phase 5: Catalytic Pipelines (2-4 days)

**Goal**: Multi-step runs with single restoration proof boundary

### Deliverables
- CLI: `--step "intent::cmd"` support
- Per-step logs and exit codes
- Single restoration proof at end

### Exit Criteria
- Demonstrate 3-step pipeline:
  1. Build scratch index
  2. Run transform
  3. Validate + emit governed output
- Single proof boundary covers all steps

---

## Phase 6: Integrate With AGS Proper (After PoC Proven)

**Goal**: Adopt CATLAB primitives into main system

### Deliverables
- Standardize JobSpec schema across AGS skills
- Convert swarm-governor outputs to schema-validated JobSpecs
- Wrap high-risk AGS operations in catalytic runtime

### Exit Criteria
- One meaningful AGS operation runs catalytically with restoration proof

---

## Phase 7: Optional Deep Math Upgrades (Only If Needed)

- Hierarchical Merkle proofs (incremental verification)
- Semantic validators using typecheckers and dependency graphs

---

## Non-Goals (For Now)

- Full repo pack bodies
- Big model finetuning
- Sweeping refactors
- Canon expansion

**PoC first. Proof first. Then scale.**

---

## Build Order (Dependency Graph)

```
Phase 0 (Schemas)
    ↓
Phase 1 (CATLAB Primitives)
    ├─→ catalytic_store
    ├─→ merkle
    ├─→ spectral_codec
    ├─→ ledger
    ├─→ validator
    └─→ micro_orchestrator
    ↓
Phase 2 (Swarm Integration)
    ↓
Phase 3 (Substrate Adapters)
    ↓
Phase 4 (Runtime Hardening)
    ↓
Phase 5 (Pipelines)
    ↓
Phase 6 (AGS Integration)
```

---

## Next Action

**Implement Phase 0 contracts:**
1. Create `SCHEMAS/jobspec.schema.json` with examples
2. Create `SCHEMAS/validation_error.schema.json`
3. Create `SCHEMAS/ledger.schema.json`
4. Write `SCHEMAS/README.md`
5. Create test fixtures that validate against schemas
6. Exit: Schemas are self-validating and documented

Then: **Move to Phase 1 CATLAB implementation**
````

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_ROADMAP_V2.1.md`

```
<!-- CONTENT_HASH: 07472605b78498e14433813a4f4b2c2580c92dbad7623e234608a6539c008210 -->

<!-- Drifted -->

# CATALYTIC-DPT ROADMAP v2.1
Date: 2025-12-24  
Status: Active  
Supersedes: ROADMAP.md (keep as historical intent)  
Previous: ROADMAP_V2.md

Purpose: Turn catalytic computing into an operational system: verifiable continuity, token efficiency via hash-referenced memory, and fail-closed execution.

---

## What changed in v2.1 (delta vs v2)
- Adds a concrete run artifact set + 3-layer enforcement model (preflight, runtime guard, CI).
- Adds the expand-by-hash toolbelt (the usability layer that actually reduces tokens).
- Adds explicit PoC demos + metrics as exit criteria (so catalytic is measurable).
- Adds “never pay twice” memoization (output caching keyed by hashes and identities).
- Pins a canonical multi-tier orchestration topology (planner → governor → workers).
- Adds write tracing + transactional commit (hardening: make incorrect success impossible).
- Keeps Titans-like weight shifting as an optional R&D track unless you decide to make it core.

---

## Definitions
- Data Plane: raw bytes that matter (outputs, blobs, full artifacts).
- Control Plane: minimal metadata needed to verify/resume (hashes, manifests, receipts).
- Bundle (SPECTRUM-02): minimum artifact set to verify a run without logs/transcripts.
- Chain (SPECTRUM-03): ordered sequence of bundles with artifact-only lineage verification.
- Dereference: fetch real bytes by hash only when needed.

---

## Already shipped (as of Pack 1.11)
### Integrity + resume
- [x] SPECTRUM-02 bundle emission + verification (fail closed).
- [x] Adversarial resume fixtures proving resume without history.
- [x] SPECTRUM-03 chain verification (artifact-only lineage).

### Validator identity
- [x] Bundle binds to validator_semver + validator_build_id.
- [x] Strict verification mode exists (reject mismatched validator identity).

### Hardening basics
- [x] Tamper evidence via output hash mismatch.
- [x] Missing output detection.
- [x] Path constraints (symlink escape protection).
- [x] Structured error vectors + tests.
- [x] SPECTRUM-06 Restore Runner LAW frozen (success artifacts, failure codes, threat model).
- [x] Restore Runner implemented (SPECTRUM-06: primitive + CLI + tests).

### Repo usability
- [x] Skills hygiene (scripts/assets/references pattern), MCP stdio server supports skill execution.

---

# Phase 0: Freeze the Contract (schemas + run artifacts + enforcement)
Goal: Make the “JSON model” real and executable: schemas exist, fixtures exist, validation is deterministic, and the repo enforces the contract in three layers.

## 0.1 JSON Schemas (dialect locked) ✅ COMPLETE
Deliverables
- [x] SCHEMAS/jobspec.schema.json (finalized: implicit defaults removed)
- [x] SCHEMAS/validation_error.schema.json
- [x] SCHEMAS/ledger.schema.json (finalized: strict validation, append-only semantics documented)
- [x] SCHEMAS/proof.schema.json (NEW: restoration proof protocol)
- [x] SCHEMAS/examples/ (minimal, human-readable demonstrations)
- [x] FIXTURES/phase0/valid/ and FIXTURES/phase0/invalid/

Rules
- [x] Choose a JSON Schema dialect (Draft 7 recommended) and lock it.
- [x] Every error must map to validation_error with stable codes.
- [x] Optional fields require documented default behavior (now explicit in descriptions).

Tests (exit criteria)
- [x] Testbench validates every valid fixture and rejects every invalid fixture.
- [x] All schemas locked (Draft-07, no additionalProperties ambiguity).

Implementation note: `CATALYTIC-DPT/TESTBENCH/test_schemas.py` validates all four schemas. Proofs conform to `proof.schema.json`.

## 0.2 Run artifact set (canonical) ✅ COMPLETE
Goal: Every run writes the same minimal artifact set to a stable location.

Location
- [x] CONTRACTS/_runs/<run_id>/

Canonical artifact set (Phase 0.2) - Generated by write_canonical_artifacts():
- [x] JOBSPEC.json (schema-valid, phase/task/intent/catalytic_domains)
- [x] STATUS.json (state machine: started/failed/succeeded/verified)
- [x] INPUT_HASHES.json (path -> sha256)
- [x] OUTPUT_HASHES.json (path -> sha256)
- [x] DOMAIN_ROOTS.json (per-domain Merkle roots)
- [x] LEDGER.jsonl (append-only receipts)
- [x] VALIDATOR_ID.json (validator_semver, validator_build_id, python_version)
- [x] PROOF.json (restoration proof: verified flag, condition, mismatches - written LAST)

Legacy artifacts (backwards compatibility):
- [x] RUN_INFO.json, PRE_MANIFEST.json, POST_MANIFEST.json, RESTORE_DIFF.json, OUTPUTS.json

Exit Criteria
- [x] All canonical artifacts written atomically
- [x] PROOF.json written last (ensures artifact set completeness)
- [x] STATUS.json implements state machine (started/failed/succeeded/verified)
- [x] Acceptance fails if any canonical artifact missing
- [x] Test coverage: 3/3 canonical artifact tests pass

## 0.3 3-layer enforcement model (pin it) ✅ COMPLETE
Layer 1: Preflight (before execution) ✅ COMPLETE
- [x] Validate JobSpec against schema (PRIMITIVES/preflight.py).
- [x] Validate path rules (relative, no traversal, allowed roots, forbidden paths).
- [x] Validate forbidden overlaps (catalytic_domains vs outputs).
- [x] Fail closed before execution if any rule violated.
- [x] 10/10 preflight tests pass (test_preflight.py).
- [ ] Resolve all hash references required for the run (or fail) - deferred to Phase 1.

Layer 2: Runtime guard (during execution) ✅ COMPLETE
- [x] Enforce allowed roots at write-time (PRIMITIVES/fs_guard.py).
- [x] Guard all runtime file writes through FilesystemGuard wrapper.
- [x] Fail closed immediately on contract violation (forbidden paths, path escapes).
- [x] Stable validation_error objects with codes (WRITE_GUARD_*).
- [x] 13/13 runtime guard tests pass (test_runtime_guard.py).
- [ ] Record write events (deferred to Phase 4 write tracing).

Layer 3: CI validation (after execution / PR gate) ✅ COMPLETE
- [x] Verify restoration proof (catalytic_validator.py gates on PROOF.json).
- [x] PROOF.json is the single source of truth (verified=true required for acceptance).
- [x] Restoration proof includes condition codes (RESTORED_IDENTICAL, RESTORATION_FAILED_*).
- [x] Mismatches detailed in proof (path, type, hashes).

---

## Phase 0 Completion Summary (December 2025)

### Schemas
- [x] jobspec.schema.json (finalized: removed implicit defaults)
- [x] ledger.schema.json (finalized: strict validation)
- [x] proof.schema.json (NEW: 8 required fields, 5 verification conditions)

### Restoration Proof Implementation
- [x] PRIMITIVES/restore_proof.py: RestorationProofValidator class
  - Generates PROOF.json from pre/post file manifests
  - Detects: hash mismatches, missing files, extra files
  - Assigns condition codes: RESTORED_IDENTICAL or RESTORATION_FAILED_*
  - Computes proof_hash from canonical JSON
  - 7/7 tests pass (identical, mismatch, missing, extra, determinism, schema, empty)

### Acceptance Gating
- [x] TOOLS/catalytic_validator.py: proof-gated acceptance
  - Requires PROOF.json to exist
  - Hard gate: verified=true only → acceptance
  - Surfaces failure condition codes and mismatches
  - Proof is single source of truth
  - 4/4 proof-gating tests pass

### Runtime Integration
- [x] TOOLS/catalytic_runtime.py: generates PROOF.json
  - Calls RestorationProofValidator during ledger save
  - Prints proof status on completion
  - Integrated PreflightValidator in Phase 0 (fail-closed before execution)

### Preflight Validation (Phase 0.3 Layer 1)
- [x] PRIMITIVES/preflight.py: PreflightValidator class
  - Validates JobSpec against schema using Draft7Validator
  - Enforces path rules: relative, no traversal, allowed roots, forbidden paths
  - Detects overlaps between catalytic_domains and outputs.durable_paths
  - Returns stable validation_error objects with codes
  - Error codes: JOBSPEC_SCHEMA_INVALID, PATH_ABSOLUTE, PATH_TRAVERSAL, PATH_ESCAPE, PATH_NOT_ALLOWED, PATH_FORBIDDEN, PATH_OVERLAP
  - Integrated into catalytic_runtime.py (called before execution)

### Runtime Write Guard (Phase 0.3 Layer 2)
- [x] PRIMITIVES/fs_guard.py: FilesystemGuard class
  - Enforces allowed roots at write-time (fail-closed)
  - Validates all write paths before allowing operations
  - Checks: forbidden paths, path escapes, traversal, allowed roots
  - Stable error codes: WRITE_GUARD_PATH_FORBIDDEN, WRITE_GUARD_PATH_ABSOLUTE, WRITE_GUARD_PATH_ESCAPE, WRITE_GUARD_PATH_TRAVERSAL, WRITE_GUARD_PATH_NOT_ALLOWED
  - Wraps all runtime writes in catalytic_runtime.py
  - guarded_write_text(), guarded_write_bytes(), guarded_mkdir() methods

### Test Suite
- [x] test_restore_proof.py: 7 tests covering proof generation
- [x] test_proof_gating.py: 4 tests covering acceptance logic
- [x] test_canonical_artifacts.py: 3 tests covering artifact writer
- [x] test_preflight.py: 10 tests covering preflight validation
- [x] test_runtime_guard.py: 13 tests covering runtime write enforcement
- [x] test_schemas.py: 1 test (validates all 4 schemas)
- [x] All tests passing (38/38)

### Exit Criteria Met
- [x] Schemas locked (no implicit defaults, strict additionalProperties)
- [x] PROOF.json is canonical (schema-valid, hashable)
- [x] Acceptance impossible without verified=true
- [x] Proof is single source of truth (overrides all other signals)
- [x] Deterministic behavior preserved (sorted keys, stable hash)
- [x] Preflight validation enforces contract before execution (fail-closed)
- [x] Runtime writes enforced at write-time (fail-closed on violation)
- [x] Path safety rules enforced (relative, no traversal, allowed roots only)
- [x] Input/output overlap detection prevents contract violations
- [x] 3-layer enforcement model COMPLETE (preflight, runtime guard, CI validation)
- [x] All layers fail-closed (no execution on preflight fail, no writes on guard fail, no acceptance without proof)

---

# Phase 1: Catalytic Kernel (CAS + Merkle + Ledger + Restore Proof)
Goal: Build the smallest catalytic substrate that produces verifiable runs and can be resumed from artifacts only.

## 1.1 CAS (Content Addressable Store)
Deliverables
- [ ] PRIMITIVES/cas_store.py (put(bytes)->hash, get(hash)->bytes)
- [ ] Deterministic layout (no timestamps), stable across OS.
- [ ] Path normalization helper (repo-relative, posix normalization).

Acceptance
- [ ] Same bytes always map to same hash.
- [ ] Large files supported (streaming put/get).

## 1.2 Merkle roots per domain
Deliverables
- [ ] PRIMITIVES/merkle.py
- [ ] Domain manifests { normalized_path: bytes_hash }
- [ ] Deterministic leaf ordering and root computation.

Acceptance
- [ ] Roots stable across runs given identical manifests.
- [ ] Reject collisions/duplicates and non-normalized paths.

## 1.3 Ledger receipts (append-only)
Deliverables
- [ ] PRIMITIVES/ledger.py emitting records matching ledger.schema.json
- [ ] Receipt includes: job_id, phase, inputs/outputs hashes, domain roots, validator identity, substrate/toolchain identity.

Acceptance
- [ ] Append-only and stable.
- [ ] Identical job produces identical receipt fields except explicitly allowed-to-vary fields.

## 1.4 Restoration proof runner ✅ COMPLETE (Phase 0)
Deliverables (implemented as PRIMITIVES/restore_proof.py + integration)
- [x] RestorationProofValidator class
  - Compares pre/post manifests (no CAS needed yet)
  - Detects all mismatch types (hash, missing, extra)
  - Emits hashable PROOF.json
  - Validates against proof.schema.json

Acceptance
- [x] Proof generation passes on all test cases (7/7).
- [x] Tamper/missing cases correctly emit verified=false with condition codes.
- [x] PROOF.json validates against schema (Draft-07).

## 1.5 Bundle/Chain Verifier ✅ COMPLETE (SPECTRUM-05 Stable)
Deliverables (implemented as PRIMITIVES/verify_bundle.py + TOOLS/catalytic_verifier.py)
- [x] BundleVerifier primitive (SPECTRUM-05 stable):
  - [x] verify_bundle_spectrum05: stable API + return shape
  - [x] verify_chain_spectrum05: stable API + return shape
  - [x] Centralized ERROR_CODES map (SPECTRUM-05 conformance)
  - [x] Mandatory Ed25519 dependency (fail-closed)
- [x] CLI entrypoint: catalytic_verifier.py
  - [x] Stable CLI surface (__doc__ verified)
  - [x] Machine-readable JSON output (--json)
  - [x] Alphabetical chain-dir ordering rule

Acceptance
- [x] Verifier accepts valid bundles and chains (18/18 tests pass)
- [x] Verifier rejects missing artifacts (BUNDLE_INCOMPLETE)
- [x] Verifier rejects tampered outputs (HASH_MISMATCH)
- [x] Verifier rejects invalid chain references (INVALID_CHAIN_REFERENCE)
- [x] Verifier rejects forbidden artifacts (FORBIDDEN_ARTIFACT)
- [x] Verification depends ONLY on bundle artifacts + file hashes + ordering
- [x] Deterministic: POSIX paths, SHA-256 hashing, stable error codes
- [x] All tests pass: pytest -q (60/60)

---

## Phase 1.1: Expand-by-hash toolbelt (token efficiency layer)
Goal: Give any agent a standard way to operate on large state while keeping prompts tiny.

Deliverables
- [ ] TOOLS/read_hash.py (range + max_bytes)
- [ ] TOOLS/grep_hash.py (pattern search over hash-referenced text)
- [ ] TOOLS/ast_hash.py (tree-sitter/AST extraction to hash-addressed summary)
- [ ] TOOLS/describe_hash.py (bounded metadata + preview)
- [ ] Unified CLI: catalytic hash read|grep|ast|describe

Acceptance
- [ ] Every tool is bounded (max bytes, max matches) and deterministic.
- [ ] Every tool emits artifacts that can be cached (see Phase 1.2).

---

## Phase 1.2: Never pay twice memoization cache
Goal: If the same job over the same inputs using the same toolchain/model identity is requested again, reuse the output by hash.

Deliverables
- [ ] Cache key: job_hash + input_hash + toolchain_hash + model_hash (or validator_build_id when external).
- [ ] Cache value: output_hash + proof pointer(s).
- [ ] Cache stored as content-addressed records with receipts.

Acceptance
- [ ] Re-run identical jobs returns instantly via cache hit and still produces verifiable receipts.
- [ ] Cache invalidates on any identity/hash mismatch.

---

## Phase 1 Exit Criteria: PoC demos + metrics (no vibes)
Demos
- [ ] Holographic roundtrip: encode → store → decode/restore with proofs.
- [ ] Restoration thrash: repeated restore/verify cycles stable; tamper fails closed.
- [ ] Token efficiency demo: baseline prompt vs hash+summary+deref; record tokens saved.

Metrics (record per run and trend over time)
- [ ] root_scan_time_ms
- [ ] bundle_emit_time_ms
- [ ] verify_time_ms
- [ ] CAS compression ratio (stored_bytes / raw_bytes)
- [ ] Token baseline vs catalytic (tokens_prompt_baseline vs tokens_prompt_catalytic)
- [ ] Determinism checks (two runs, same inputs → same roots)

---

# Phase 1.5: Streaming Catalytic Loop (runtime feels catalytic)
Goal: Keep live prompts small during long runs using snapshots + deltas, while preserving verifiability.

Deliverables
- [ ] Periodic State Snapshot artifact (hashes, roots, minimal intent).
- [ ] Delta bundling every N tokens or T seconds.
- [ ] Dereference-on-demand protocol (request hashes, return bounded bytes + proof pointers).
- [ ] Pause/resume mid-run using only snapshots/deltas + CAS.

Acceptance
- [ ] Mid-run resume passes without raw history.
- [ ] Tamper/missing/stale pointer fails closed.

Note: this is token reduction at the interface, not inside-model token compression.

---

## Phase 1.6 — Semiotic Compression & Expansion

Goal: Radically reduce LLM context usage by replacing natural language and full code bodies with compact, symbolic handles that expand deterministically outside the model.

### Phase 1.6.a — Semiotic Compression Layer (SCL)
Focus: **Plan-level symbolic language**

- Define a **CODEBOOK** mapping short symbols → predicate sets / plan macros.
- Define a minimal **grammar** for symbolic plans (order, scope, composition).
- Implement a **deterministic decoder**:
  - symbols → JobSpec JSON / tool plan / audit text
  - no model reasoning during expansion.
- Add **validators + fixtures** proving:
  - invertibility (symbol → expansion → re-symbolization)
  - determinism (same input → same output)
  - bounded expansion size.
- Wire into agent packs so models see only symbols + hashes by default.

Exit criteria:
- A non-trivial plan executes using ≤10% of the tokens previously required.
- Decoder output is schema-valid and reproducible byte-for-byte.

### Phase 1.6.b — Semiotic Expansion Layer (SEL)
Focus: **Code-level symbolic addressing**

- Build `function_index.json` with stable IDs for code entities.
- Implement `expand.py`:
  - ID → source / contract summary / patch template.
- Add fixtures validating:
  - ID stability across refactors.
  - expansion determinism.
  - hash mismatch detection.
- Update packer:
  - packs carry indexes + hashes, not full code bodies by default.

Exit criteria:
- Agents can reference code entities by ID only.
- Full source is expanded on demand, outside LLM context.

---

# Phase 2: Swarm Parallelism (safe scaling)
Goal: Many workers can run in parallel without corrupting continuity. Reducer accepts exactly one deterministic update.

## 2.1 Canonical role topology (pin it)
- [ ] Planner (optional): high-level decomposition, no writes
- [ ] Governor: policy + acceptance decisions, writes receipts
- [ ] Workers: execute jobs, emit bundles only
- [ ] Reducer: deterministic tie-break and commit of accepted outputs

Rules
- [ ] Workers cannot directly mutate canonical state.
- [ ] Only reducer/governor appends to the ledger and finalizes commits.
- [ ] Deterministic acceptance: stable score function + stable ordering.

Acceptance
- [ ] Completion order does not change acceptance.
- [ ] Re-running the same batch yields identical accepted update.
- [ ] Any bundle mismatch rejects the run regardless of score.

---

# Phase 3: Substrate Offload Adapters (browser, DB, CLI, AST)
Goal: External tools become deterministic executors with hash I/O and full replay.

Deliverables
- [ ] ADAPTERS/cli_exec.py (tool, args, input_hashes → output_hashes)
- [ ] ADAPTERS/browser_exec.py (playwright/js recipe → outputs by hash)
- [ ] ADAPTERS/db_exec.py (query recipe → outputs by hash)
- [ ] ADAPTERS/ast_exec.py (tree-sitter/static analysis as a substrate)

Rules
- [ ] Every adapter records substrate version and execution recipe in receipts.
- [ ] No adapter output accepted without bundle verification + proof.

Exit
- [ ] At least two substrates run end-to-end: adapter → bundle → verify → restore proof.

---

# Phase 4: Runtime Hardening (make incorrect success impossible)
Goal: Fail closed under all realistic adversarial conditions.

Deliverables
- [ ] Forbidden overlap checks both directions (inputs vs outputs).
- [ ] Strong path rules: no absolute paths, no traversal, allowed roots only.
- [ ] Write tracing (record every write event; include in receipts/proofs).
- [ ] Transactional output commit (stage outputs; only finalize after proof passes).

Acceptance
- [ ] Fuzz fixtures for path tricks + overlap edge cases.
- [ ] Any hard violation stops immediately.
- [ ] Proof must pass before outputs can become real.

---

# Phase 5: Catalytic Pipelines (multi-step, one proof boundary)
Goal: Multi-step workflows where the entire pipeline is verifiable via a chain.

Deliverables
- [ ] Pipeline runner composes steps via hashes (outputs become next inputs).
- [ ] Per-step bundles + chain receipt + final proof artifact.
- [ ] Demo pipeline: index → transform → validate+emit.

Acceptance
- [ ] End-to-end chain verification passes.
- [ ] Restoration proof passes for final pipeline state.

---

# Phase 6: Integrate with AGS proper
Goal: Wrap one real AGS operation in catalytic verification and prove the integration boundary.

Deliverables
- [ ] Convert one high-risk AGS skill run to: JobSpec → deterministic exec → bundle → strict verify gate → restore proof.
- [ ] Docs: how AGS calls catalytic runtime and how artifacts are stored.

Exit
- [ ] One meaningful AGS operation runs catalytically and can be resumed from artifacts only.

---

# Phase 7: Optional R&D tracks (add only if you commit)
## 7.A Titans-like tiny-module continuity (test-time learning)
- [ ] Define tiny module interface and allowed update mechanism.
- [ ] Define evaluation and regression gates.
- [ ] Ensure updates are hashable and reversible (delta hashes + model hashes).
- [ ] Prove continuity and rollback under fixtures.

## 7.B Hierarchical Merkle proofs / semantic validators
- [ ] Only as additive layers, never replacements for byte-level proofs.

---

## Non-goals (stay disciplined)
- [ ] No packing full repo bodies as context.
- [ ] No large-model finetuning as a substitute for proofs.
- [ ] No sweeping refactors unrelated to integrity contracts.
- [ ] No expanding canon without tests.

---

## Build order (dependency graph)
1) Phase 0 schemas + run artifacts + enforcement  
2) CAS + path normalization  
3) Merkle + domain roots  
4) Ledger + receipts  
5) Restore proof runner  
6) Expand-by-hash toolbelt  
7) Memoization cache  
8) Streaming catalytic loop  
9) Swarm parallelism  
10) Substrate adapters  
11) Hardening (write tracing + transactional commit)  
12) Pipelines  
13) AGS integration  

---

## Next actions (smallest high-impact sequence)
- [ ] Create the 3 schema files under SCHEMAS/ and land Phase 0 fixtures + tests.
- [ ] Pin the run artifact set in CONTRACTS/_runs/<run_id>/ and enforce it in preflight + CI.
- [ ] Build the expand-by-hash toolbelt (read/grep/ast/describe) with strict bounds.
- [ ] Add memoization cache keyed by hashes and identities.
- [ ] Add the Phase 1 PoC demos + metrics as hard exit criteria.
```

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_ROADMAP_V2.2.md`

```
<!-- CONTENT_HASH: 8739f6547e6224b01184e1437faff3b5c4ef74f41facfb0435c8e72c1a0456d6 -->

# CATALYTIC-DPT ROADMAP v2.2
Date: 2025-12-25  
Status: ACTIVE (execution roadmap; referenced by `CATALYTIC-DPT/AGENTS.md`)

## Goal
Build a verifiable catalytic runtime where:
- Truth is artifacts, not narration.
- Runs are resumable and verifiable from bundles and chain proofs.
- Token efficiency is achieved via hash-referenced memory and bounded dereference, not by dumping blobs.

## Operating rules
1) **Phase gates** define “done.” No vibes-based completion.
2) Always execute the **smallest unchecked item** that advances the current blocking gate.
3) Do not merge phases unless this roadmap explicitly says so.
4) Kernel must not import from LAB; LAB may import Kernel.

## Phase gates (the only definition of “done”)

### Phase 0 Gate: Contract freeze + enforcement
DONE when all are true:
- [x] Schemas exist, are pinned (Draft-07), and fixtures prove valid and invalid cases.
- [x] Preflight validation fails closed.
- [x] Runtime write guard fails closed.
- [x] CI runs governance + contract fixtures (`.github/workflows/contracts.yml`).

### Phase 1 Gate: Kernel substrate
DONE when all are true:
- [x] CAS exists (streaming put/get), deterministic layout, path normalization, tests.
- [x] Merkle exists (domain manifests, deterministic ordering, stable roots), tests.
- [x] Ledger exists (append-only receipts, schema-valid, deterministic serialization), tests.
- [x] Proof generation is wired to these primitives and is deterministic across reruns.

### Phase 1X Gate: Expand-by-hash usability
DONE when all are true:
- [x] `hash read`, `hash grep`, `hash ast`, `hash describe` exist.
- [x] Every output is bounded (bytes, matches, ranges) and deterministic.
- [x] Any tool capable of unbounded dumping is a violation and must be fixed.

### Phase 1V Gate: Verifiers and validator identity
DONE when all are true:
- [x] SPECTRUM-02 bundle verifier is strict and fail-closed.
- [x] SPECTRUM-03 chain verifier is strict and fail-closed.
- [x] Validator identity pin and signing surface (SPECTRUM-04) are implemented with fixtures and adversarial tests.
- [x] CI default is strict verification (explicit pipeline enforcement). (commit: 84b8422)

### Phase 2 Gate: Memoization (never pay twice)
DONE when all are true:
- [x] Cache keys bind to job + inputs + toolchain + validator identity. (commit: dba8efd)
- [x] Cache hits still emit verifiable receipts and proofs. (commit: dba8efd)
- [x] Cache misses never bypass verification. (commit: dba8efd)
- [x] At least one end-to-end demo shows measurable token reduction via hash-first dereference. (demo: `CONTRACTS/_runs/_demos/memoization_hash_reuse/`) (commit: 25ea034)

---

## Canonical run artifact set (required)
Every run MUST write artifacts to: `CONTRACTS/_runs/<run_id>/`

Minimum required files (byte-for-byte verifiable):
- [x] `JOBSPEC.json` (schema-valid)
- [x] `STATUS.json` (state machine: started | failed | succeeded | verified)
- [x] `INPUT_HASHES.json`
- [x] `OUTPUT_HASHES.json`
- [x] `DOMAIN_ROOTS.json`
- [x] `LEDGER.jsonl` (append-only, schema-valid)
- [x] `VALIDATOR_ID.json` (validator_semver, validator_build_id, toolchain versions)
- [x] `PROOF.json` (hashable restoration proof summary)

Definition of success:
- A run is not “successful” unless:
  - all required artifacts exist
  - bundle verification passes in strict mode
  - restoration proof passes
- Missing artifacts or verification failures must fail closed.

---

## Current truth: what is actually blocking progress
**Phase 1 Gate is DONE. Next blocking gate is Phase 1X (expand-by-hash) or Phase 1V CI strict enforcement.**

Verifiers and identity law may be shipped early, but do not substitute for the substrate.

---

## PHASE 0: Contracts + fixtures + enforcement (DONE)
Scope:
- [x] JobSpec schema (`CATALYTIC-DPT/SCHEMAS/jobspec.schema.json`)
- [x] Validation error vector schema (`CATALYTIC-DPT/SCHEMAS/validation_error.schema.json`)
- [x] Ledger schema (`CATALYTIC-DPT/SCHEMAS/ledger.schema.json`)
- [x] Proof schema (`CATALYTIC-DPT/SCHEMAS/proof.schema.json`)
- [x] Fixtures: valid + adversarial (`CATALYTIC-DPT/FIXTURES/phase0/`)
- [x] Preflight validator (schema + path rules + overlap rules) (`CATALYTIC-DPT/PRIMITIVES/preflight.py`)
- [x] Runtime filesystem write guard (`CATALYTIC-DPT/PRIMITIVES/fs_guard.py`)
- [x] Restore proof validator primitive (`CATALYTIC-DPT/PRIMITIVES/restore_proof.py`)
- [x] Runtime emits `PROOF.json` (`TOOLS/catalytic_runtime.py`)
- [x] Proof-gated acceptance CLI (`TOOLS/catalytic_validator.py`)
- [x] Proof testbench (`CATALYTIC-DPT/TESTBENCH/test_restore_proof.py`)

Acceptance:
- [x] Deterministic validation (same input yields same output).
- [x] Invalid fixtures fail with stable, parseable error codes.
- [x] Path rules: no abs, no traversal, allowed roots only, forbidden paths blocked.
- [x] CI runs governance + contract fixtures (`.github/workflows/contracts.yml`).

Notes:
- Phase 0 is constitutional and must remain stable. Any change requires versioned migration and new fixtures.

---

## PHASE 1: Kernel substrate (BLOCKING)

### 1.U CAS: Content Addressable Store (BLOCKING)
Deliverables
- [x] `PRIMITIVES/cas_store.py`
  - [x] `put_bytes(data: bytes) -> sha256_hex`
  - [x] `get_bytes(hash_hex: str) -> bytes`
  - [x] `put_stream(stream: BinaryIO, chunk_size: int = 1024*1024) -> sha256_hex`
  - [x] `get_stream(hash_hex: str, out: BinaryIO, chunk_size: int = 1024*1024) -> None`
- [x] Deterministic on-disk layout (no timestamps), stable across OS.
- [x] Path normalization helper (repo-relative, posix normalization).
- [x] Atomic writes (temp + fsync + idempotent commit; never overwrite existing objects).

Acceptance
- [x] Same bytes always map to same hash.
- [x] Large files supported (streaming put/get).
- [x] Determinism test: two consecutive runs produce identical hashes and artifacts.
- [x] Reject non-normalized paths and path traversal.

Testbench targets
- [x] Store and retrieve.
- [x] Deterministic hashing.
- [x] Large file.
- [x] Batch operations.

Status (verified):
- [x] Implemented in `CATALYTIC-DPT/PRIMITIVES/cas_store.py` (`CatalyticStore`, `normalize_relpath`) (commit `d6e3970`)
- [x] Testbench `CATALYTIC-DPT/TESTBENCH/test_cas_store.py` passes (commit `d6e3970`)

### 1.M Merkle: Roots per domain (DONE)
Deliverables
- [x] `PRIMITIVES/merkle.py`
- [x] Domain manifest: `{ normalized_path: bytes_hash }`
- [x] Deterministic leaf ordering and root computation.

Acceptance
- [x] Roots stable across runs given identical manifests.
- [x] Reject duplicates, collisions, and non-normalized paths.
- [x] Adversarial fixtures for ordering, path edge cases, and tamper detection.

Testbench targets
- [x] Root stability.
- [x] Proof verification.
- [x] Tamper detection.

Status (verified):
- [x] Implemented in `CATALYTIC-DPT/PRIMITIVES/merkle.py` (`build_manifest_root`, `verify_manifest_root`) (commit: 19a0c9c)
- [x] Testbench `CATALYTIC-DPT/TESTBENCH/test_merkle.py` passes (commit: 19a0c9c)

### 1.D Ledger: Receipts (append-only) (DONE)
Deliverables
- [x] `PRIMITIVES/ledger.py` writing append-only JSONL records conforming to ledger schema.
- [x] Receipt includes at minimum (ledger.schema.json shape):
  - [x] `JOBSPEC.job_id` (optional `JOBSPEC` included; satisfies job identifier without changing record shape)
  - [x] `RUN_INFO.run_id` and `RUN_INFO.intent` and caller-supplied deterministic `RUN_INFO.timestamp`
  - [x] `PRE_MANIFEST`, `POST_MANIFEST`, `RESTORE_DIFF`, `OUTPUTS`, `STATUS`
  - [x] `VALIDATOR_ID.validator_semver` and `VALIDATOR_ID.validator_build_id` (when present)
- [x] Deterministic serialization rules (canonical JSON per line: UTF-8, no whitespace, sorted keys).
- [x] Append-only enforcement (detect truncation/rewrites via size invariants across appends).

Acceptance
- [x] Schema-valid records only.
- [x] Append-only semantics proven by tests (no mutation of prior lines).
- [x] Deterministic ordering and stable output across reruns.

Testbench targets
- [x] Append entry.
- [x] Deterministic ordering.
- [x] Adversarial: attempt to rewrite/truncate prior record is detected or prevented.

Status (verified):
- [x] Implemented in `CATALYTIC-DPT/PRIMITIVES/ledger.py` (`Ledger`) (commit: 17d10a8)
- [x] Testbench `CATALYTIC-DPT/TESTBENCH/test_ledger.py` passes (commit: 17d10a8)

### 1.P Proof wiring: Restore proof uses substrate (DONE)
Deliverables
- [x] `PROOF.json` generation uses CAS + Merkle + Ledger primitives (no ad-hoc root shortcuts).
- [x] Proof is artifact-only verifiable.

Acceptance
- [x] Detects: missing file, extra file, hash mismatch.
- [x] Determinism rerun test: run twice yields byte-identical `DOMAIN_ROOTS.json` and `PROOF.json`.

Status (verified):
- [x] Wired in `TOOLS/catalytic_runtime.py` (CAS-backed snapshots, Merkle `DOMAIN_ROOTS.json`, schema-valid `LEDGER.jsonl`, canonical `PROOF.json`) (commit: 8eab904)
- [x] Testbench `CATALYTIC-DPT/TESTBENCH/test_proof_wiring.py` passes (commit: 8eab904)

---

## PHASE 1X: Expand-by-hash toolbelt (DONE, required for token efficiency)
Deliverables
- [x] `catalytic hash read <sha> --max-bytes N [--start S] [--end E]`
- [x] `catalytic hash grep <sha> <pattern> --max-matches M --max-bytes N`
- [x] `catalytic hash ast <sha> --max-nodes K --max-depth D` (Python-only; otherwise `UNSUPPORTED_AST_FORMAT`)
- [x] `catalytic hash describe <sha> --max-bytes N`

Acceptance
- [x] Every command enforces explicit bounds (bytes, matches, ranges).
- [x] Deterministic outputs for same inputs and bounds.

Status (verified):
- [x] CLI: `TOOLS/catalytic.py` (`catalytic hash read|grep|describe|ast`) (commit: d6615e3)
- [x] Implementation: `CATALYTIC-DPT/PRIMITIVES/hash_toolbelt.py` (commit: d6615e3)
- [x] Testbench: `CATALYTIC-DPT/TESTBENCH/test_hash_toolbelt.py` (commit: d6615e3)
- [x] Dereference events logged to ledger (hash requested, bounds returned) (commit: e388e6e)

---

## PHASE 1V: Verifiers + validator identity (SHIPPED)

### 1V.1 SPECTRUM-02 Bundle verification (SHIPPED, keep strict)
Deliverables
- [x] Fail-closed verifier that depends only on:
  - [x] bundle artifacts (`TASK_SPEC.json`, `STATUS.json`, `OUTPUT_HASHES.json`, required set)
  - [x] actual file hashes
- [x] Rejects:
  - [x] missing artifacts
  - [x] hash mismatches
  - [x] forbidden artifacts (logs/tmp/transcripts)
  - [x] non-success status
  - [x] missing or failed proof (when required)

Acceptance
- [x] Adversarial fixtures cover all rejection classes.
- [x] Strict mode exists (default strict in `verify_bundle_spectrum05`).
- [x] CI default is strict verification (explicit pipeline enforcement). (commit: 84b8422)

Status (verified):
- [x] Strict bundle verification implemented in `CATALYTIC-DPT/PRIMITIVES/verify_bundle.py` (`verify_bundle_spectrum05`)
- [x] CLI exists: `TOOLS/catalytic_verifier.py`

### 1V.2 SPECTRUM-03 Chain verification (SHIPPED, keep strict)
Deliverables
- [x] Chain verifier validates ordering and references.
- [x] Artifact-only lineage verification.

Acceptance
- [x] Rejects invalid references, missing bundles, mismatched roots.

Status (verified):
- [x] Strict chain verification implemented in `CATALYTIC-DPT/PRIMITIVES/verify_bundle.py` (`verify_chain_spectrum05`)
- [x] CLI supports chain verification: `TOOLS/catalytic_verifier.py`

### 1V.3 SPECTRUM-04 Validator identity pin + signing (LAW FROZEN, SHIPPED)
Deliverables
- [x] Implement artifacts:
  - [x] `VALIDATOR_IDENTITY.json` (exactly: `algorithm`, `public_key`, `validator_id`)
  - [x] `SIGNED_PAYLOAD.json` (exactly: `bundle_root`, `decision`, `validator_id`)
  - [x] `SIGNATURE.json` (required: `payload_type`, `signature`, `validator_id`)
- [x] Implement canonicalization rules:
  - [x] domain separation prefix
  - [x] canonical JSON (sorted keys, no whitespace, UTF-8)
- [x] Implement Ed25519 verification.
- [x] Implement fail-closed error codes and adversarial fixtures.

Acceptance
- [x] Two independent implementations produce identical verification results. (commit: 6e174f5)
- [x] Any ambiguity rejects (multiple keys, multiple signatures, malformed fields, deviations from canonicalization).

Status (verified):
- [x] Implemented in `CATALYTIC-DPT/PRIMITIVES/verify_bundle.py` (strict SPECTRUM-05 verification includes SPECTRUM-04 identity/signing enforcement)
- [x] Adversarial coverage in `CATALYTIC-DPT/TESTBENCH/test_spectrum_04_05_enforcement.py`

---

## SPECTRUM-06: Restore Runner (SHIPPED, does not unblock Phase 1 substrate)

- [x] LAW frozen: `CATALYTIC-DPT/SPECTRUM/SPECTRUM-06.md` (commits `4562dc3`, `2a4c222`, `90041a8`)
- [x] Primitive API: `CATALYTIC-DPT/PRIMITIVES/restore_runner.py` (`restore_bundle`, `restore_chain`)
- [x] CLI: `TOOLS/catalytic_restore.py` (bundle/chain, `--json`, nonzero exit on failure)
- [x] Tests: `CATALYTIC-DPT/TESTBENCH/test_restore_runner.py` (gating, reject-if-exists, traversal/symlink escape, rollback, success artifacts, chain all-or-nothing)

---

## PHASE 2: Memoization and “never pay twice” (LOCK AFTER PHASE 1)
Deliverables
- [x] Deterministic job cache key implemented (JobSpec canonical JSON + input domain roots + validator identity + strictness).
- [x] Cache stored under `CONTRACTS/_runs/_cache/jobs/<job_cache_key>/` (artifacts + materialized durable outputs).
- [x] Cache hit restores outputs and re-emits proof artifacts (byte-identical from cache), and is observable in receipts.

Acceptance
- [x] Deterministic cache behavior (tests prove miss→hit and invalidation by key inputs).
- [x] Measurable token/work reduction in an end-to-end demo where the interface is hash-first and dereference is bounded. (demo: `CONTRACTS/_runs/_demos/memoization_hash_reuse/`) (commit: 25ea034)

---

## PHASE 3: Packing hygiene (deterministic, bounded, deduplicated)
Purpose
- [x] Prevent context bloat before scale by making packs deterministic, bounded, and auditable. (commit: d7ef213)

Deliverables
- [x] Deterministic ordering: manifest entries sorted by normalized path, then content hash.
- [x] Explicit size ceilings (fail-closed; recorded in metadata):
  - max_total_bytes (default 50 MiB)
  - max_entry_bytes (default 2 MiB)
  - max_entries (default 50,000)
- [x] Dedup rules:
  - Duplicate normalized paths are rejected.
  - Duplicate content hashes are rejected for CAT-DPT packs by default (can be explicitly allowed via CLI flag).
- [x] Auditable manifest integrity:
  - `meta/REPO_STATE.json` is schema-like and validated (sorted, unique, stable).
  - `meta/PACK_INFO.json` records `repo_state_sha256` for content-addressed manifest identity.

Tests (backstop)
- [x] `CATALYTIC-DPT/TESTBENCH/test_packing_hygiene.py` (determinism, limits fail-closed, dedup validation, tamper detection)

---

## PHASE 4: Runtime hardening
Deliverables
- [x] Adversarial fixtures: corrupted artifacts, partial state, path attacks, malformed proofs, pipeline interruption/resume safety. (commit: f85f2ca)
  - `CATALYTIC-DPT/TESTBENCH/test_adversarial_cas.py`
  - `CATALYTIC-DPT/TESTBENCH/test_adversarial_ledger.py`
  - `CATALYTIC-DPT/TESTBENCH/test_adversarial_paths.py`
  - `CATALYTIC-DPT/TESTBENCH/test_adversarial_proof_tamper.py`
  - `CATALYTIC-DPT/TESTBENCH/test_adversarial_pipeline_resume.py`
- [ ] Tighten guards as needed, always with fixtures and regression tests.
- [x] Fix ledger.schema.json $ref resolution (Draft7) (commit: edd39b8)
Note: currently causes ledger/proof tests to fail; discovered after Phase 1 closure.

Acceptance
- [ ] Fail-closed everywhere.
- [ ] No silent acceptance.

---

## PHASE 5: Pipelines
Deliverables
- [x] Minimal pipeline runner (init/run/status/resume; artifact-only state). (commit: 1799178)
- [x] Proof chain across pipeline steps (`CHAIN.json` under `CONTRACTS/_runs/_pipelines/<pipeline_id>/`; deterministic; fail-closed verification).
- [x] Pipeline verifier CLI (`catalytic pipeline verify`; fail-closed; artifact-only).
- [ ] Compose verified runs into durable workflows.
- [ ] Pipelines are still artifact-first, replayable, and proof-gated.

Acceptance
- [x] Pipeline state is resume-safe from artifacts only (STATE.json + per-step RUN_REF.json).
- [x] Each step produces normal run artifacts under `CONTRACTS/_runs/<run_id>/` (PROOF.json, DOMAIN_ROOTS.json, LEDGER.jsonl).
- [ ] Pipeline execution produces a verifiable chain of bundles and proofs.
- [x] Resume works without chat logs or narrative state.

---

## PHASE 6: AGS integration
Deliverables
- [ ] CAT-DPT becomes the execution substrate for AGS.
- [ ] AGS must conform to CAT-DPT contracts, not the other way around.
- [x] Phase 6.1: AGS emits deterministic `PIPELINE.json` from a plan and runs `catalytic pipeline run` + `catalytic pipeline verify` (model-free).
  - [x] Owner boundary: AGS emits spec only; pipeline runtime initializes `STATE.json` deterministically when missing.
- [x] Phase 6.2: Router slot (`ags plan`) executes an external plan producer, enforces schema + caps, and routes to fail-closed pipeline run+verify.
  - [x] Fail-closed plan semantics: steps must declare `command`; no implicit no-op defaults.
- [x] Phase 6.3: Adapter Contract (skills + MCP pipelining; fail-closed).

Acceptance
- [ ] At least one integrated workflow: JobSpec in, strict verification out, resumable from artifacts only.

---

## PHASE 7: Optional math
Deliverables
- [ ] Formal proofs or deeper math models (optional).
- [ ] Must not block operational phases.

---

## Immediate next actions (pick one, do the smallest)
- [x] Implement **CAS (1.U)** with streaming + deterministic layout + tests.
- [x] Implement **Merkle (1.M)** with deterministic manifests/roots + tests.
- [x] Implement **Ledger (1.D)** append-only + schema-valid + deterministic + tests.
- [x] Wire **Proof (1.P)** to the primitives + rerun determinism test.
- [x] Start **Expand-by-hash (Phase 1X)** once CAS exists (it depends on dereference).

Priority order is strict: 1.U → 1.M → 1.D → 1.P → 1X.

---

## Notes for handoff (for any agent)
- Do not claim progress without artifacts and passing tests.
- Do not paste large blobs into prompts. Use hashes + bounded previews.
- Do not write outside allowed roots; forbidden: `CANON`, `AGENTS.md`, `BUILD`, `.git`.
- Keep commits small and verifiable.
```

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_ROADMAP_V2.md`

```
<!-- CONTENT_HASH: cfa345d7ff777a1bfc518d98f876076f89bfb389fc462cb65f4aea60c533d892 -->

# CATALYTIC-DPT ROADMAP v2
Date: 2025-12-24  
Status: Active  
Supersedes: ROADMAP.md (keep as historical intent)

Principle: Prove the thesis before expanding scope. Once proofs exist, treat them as the contract.

---

## What changed from v1
- SPECTRUM-02 and SPECTRUM-03 are now **shipped**, so the roadmap starts from “bundle and chain proofs already exist”.
- Validator identity is now part of integrity (validator semver + deterministic build fingerprint).
- Phase 0 is **partially real**: the schema spec exists, but the actual JSON Schema files are not present yet.

---

## Definitions (use these words consistently)
- **Data Plane**: raw bytes that matter (outputs, artifacts, blobs). Never trust narratives about it.
- **Control Plane**: minimal metadata needed to verify and resume (hashes, manifests, job specs, receipts).
- **Bundle (SPECTRUM-02)**: the minimum set of artifacts required to verify a run without logs or transcripts.
- **Chain (SPECTRUM-03)**: an ordered sequence of bundles whose dependencies are proven only via artifacts.

---

## Already shipped (as of Pack 1.11)
### Integrity and resume (core)
- [x] **SPECTRUM-02 bundle emission** with `OUTPUT_HASHES.json` and bundle verification that fails closed.
- [x] **Adversarial resume fixtures** that prove resume works without history.
- [x] **SPECTRUM-03 chain verification** that verifies a sequence of bundles, rejects invalid references, and does not depend on logs/tmp/transcripts.

### Validator identity and determinism
- [x] Bundle verification binds to:
  - `validator_semver`
  - `validator_build_id` (deterministic build fingerprint, e.g. commit SHA or file hash)
- [x] **Strict mode** can reject bundles if validator identity mismatches.

### Hardening and security properties
- [x] Tamper evidence via hash mismatch.
- [x] Missing output detection.
- [x] Symlink escape protection (path constraints).
- [x] Structured error vectors and tests for common integrity failures.

### Skills and orchestration hygiene (repo usability)
- [x] Skills organized with scripts/assets/references patterns and import fixes.
- [x] MCP stdio server supports skill execution entrypoints.

### Known hygiene issue (fix soon)
- [ ] Changelog date ordering is inconsistent (1.11 dated 2024-12-24 while adjacent versions are 2025-12-24).  
  Treat changelog as an audit artifact and normalize the dates.

---

## Current phase
**Phase 0.5: Make the contract executable.**  
The schema spec exists in `SCHEMAS/README.md`, but the actual schema files referenced there are missing. Phase 1+ cannot be treated as canon until the schemas exist and are tested.

---

# Phase 0: Freeze the Contract (schemas + fixtures)
Goal: Turn the schema spec into real JSON Schemas with fixtures and a self-validation testbench.

Deliverables
- [ ] `SCHEMAS/jobspec.schema.json`
- [ ] `SCHEMAS/validation_error.schema.json`
- [ ] `SCHEMAS/ledger.schema.json`
- [ ] `SCHEMAS/examples/` (small, human-legible example objects)
- [ ] `FIXTURES/phase0/valid/` and `FIXTURES/phase0/invalid/`

Rules
- JSON Schema Draft 7 (or newer if the validator already supports it, but pick one and lock it).
- No ambiguous fields. Every optional field must have a default behavior documented.
- Errors must map into `validation_error.schema.json` with stable codes.

Tests (exit criteria)
- [ ] `tests/test_phase0_schemas.py` (or equivalent) that:
  - validates every valid fixture
  - rejects every invalid fixture
  - validates the schemas themselves (schema-of-schemas check if supported)
- [ ] CI runner executes schema tests as a gating step.

Exit
- Schemas exist, fixtures exist, tests exist, and the validator emits stable error vectors.

---

# Phase 1: CATLAB primitives (PoC that uses the shipped proofs)
Goal: Implement the smallest real catalytic kernel that can produce runs with receipts, roots, and restoration proofs, reusing SPECTRUM-02/03 as the verification substrate.

Workstreams

## 1) Content Addressable Store (CAS)
Deliverables
- [ ] `PRIMITIVES/cas_store.py`
  - `put(bytes) -> hash`
  - `get(hash) -> bytes`
  - deterministic path layout (no timestamps)
- [ ] `PRIMITIVES/path_normalize.py` (posix paths, repo-relative)

Acceptance
- [ ] same bytes always produce same hash
- [ ] store is stable across OS and shells (path normalization)
- [ ] fixtures include adversarial bytes and edge cases (empty file, large file, unicode paths)

## 2) Merkle roots per domain
Deliverables
- [ ] `PRIMITIVES/merkle.py`
  - `leaf = H(path + '\0' + bytes_hash)`
  - deterministic ordering (sorted by normalized path)
  - `root(leaves) -> root_hash`
- [ ] Domain manifest format: `{ path: bytes_hash }`

Acceptance
- [ ] root stable across runs and machines given identical inputs
- [ ] fixtures prove ordering determinism and rejection on collisions/duplicates

## 3) Ledger (append-only receipts)
Deliverables
- [ ] `PRIMITIVES/ledger.py` that emits records matching `ledger.schema.json`
- [ ] Each record includes:
  - job_id, phase, timestamp (optional but if included must be controlled)
  - inputs (hashes), outputs (hashes), domain roots
  - validator identity (semver + build id)

Acceptance
- [ ] ledger is append-only
- [ ] re-running an identical job yields identical receipt fields except fields explicitly allowed to vary

## 4) Restoration proof runner
Deliverables
- [ ] `TOOLS/prove_restore.py`
  - Given a bundle or chain, re-materialize outputs from CAS (or verify existing outputs)
  - Compare against `OUTPUT_HASHES.json`
  - Emit a proof summary that is itself hashable

Acceptance
- [ ] “restore then verify” passes on fixtures
- [ ] tamper and missing-file cases fail closed

Exit (Phase 1)
- A PoC job can:
  1) run a transformation
  2) emit a bundle
  3) verify the bundle
  4) restore or re-verify using only artifacts
  5) pass deterministic fixtures

---

# Phase 2: Swarm parallelism (safe learning, no corruption)
Goal: Run many jobs in parallel, then accept exactly one deterministic update without breaking integrity.

Deliverables
- [ ] Worker protocol: workers run jobs and emit bundles only
- [ ] Reducer protocol: reducer chooses one accepted outcome and writes one append-only ledger update
- [ ] Deterministic tie-break rules (no “best vibe”):
  - stable score function
  - stable ordering
  - stable acceptance threshold

Acceptance
- [ ] Order of worker completion does not change acceptance
- [ ] Re-running the same batch yields identical accepted update
- [ ] Any bundle mismatch rejects the run, even if score is high

Exit
- Parallel evaluation increases throughput without introducing nondeterminism.

---

# Phase 3: Substrate offload adapters (browser, DB, CLI)
Goal: Treat external substrates as deterministic executors with hash I/O and full replay.

Deliverables
- [ ] `ADAPTERS/cli_exec.py`
- [ ] `ADAPTERS/browser_exec.py`
- [ ] `ADAPTERS/db_exec.py`

Contract
- Every adapter must accept inputs by hash and emit outputs by hash.
- Every adapter must record substrate version and execution recipe into the ledger.

Acceptance
- [ ] At least two substrates demonstrate end-to-end:
  inputs (hashes) -> adapter -> outputs (hashes) -> bundle -> verify -> restore proof

---

# Phase 4: Runtime hardening (fail-closed correctness)
Goal: Make “incorrect success” impossible.

Deliverables
- [ ] Forbidden overlap checks both directions:
  - outputs must not overlap inputs
  - inputs must not overlap outputs
  - durable paths must be inside allowed root(s)
- [ ] Stronger path rules:
  - no absolute paths
  - no traversal
  - no symlink escape

Acceptance
- [ ] Fuzz fixtures for path tricks and overlap edge cases
- [ ] Every hard violation stops the run

---

# Phase 5: Catalytic pipelines (multi-step, one proof boundary)
Goal: Multi-step runs where the entire pipeline is verifiable via one chain.

Deliverables
- [ ] Pipeline runner that composes jobs:
  `step_i OUTPUT_HASHES` become `step_{i+1} inputs`
- [ ] Pipeline emits:
  - per-step bundles
  - chain receipt
  - final proof artifact

Acceptance
- [ ] 3-step pipeline demo:
  1) index
  2) transform
  3) validate + emit
- [ ] End-to-end chain verification passes and restoration proof passes

---

# Phase 6: Integrate with AGS proper
Goal: Wrap one real AGS operation in catalytic verification, proving the integration boundary.

Deliverables
- [ ] Convert one high-risk skill run into:
  - JobSpec input
  - deterministic execution
  - bundle emission
  - bundle verification gate
- [ ] Add documentation for how AGS calls catalytic runtime

Acceptance
- [ ] One real operation runs catalytically and can be resumed by bundles only.

---

# Phase 7: Optional upgrades (only if needed)
- [ ] Hierarchical Merkle proofs for incremental verification
- [ ] Semantic validators (typecheckers, dependency graphs) as optional layers, never replacements for byte-level proofs

---

## Non-goals (stay disciplined)
- [ ] No full repo packing of code bodies as “context”
- [ ] No large-model finetuning as a substitute for proofs
- [ ] No sweeping refactors unrelated to integrity contracts
- [ ] No expanding canon without tests

---

## Build order (dependency graph)
1) Phase 0 schemas + fixtures  
2) CAS + path normalization  
3) Merkle + domain roots  
4) Ledger + receipts  
5) Restoration proof runner  
6) Swarm parallelism  
7) Substrate adapters  
8) Hardening  
9) Pipelines  
10) AGS integration

---

## Next actions (smallest high-impact sequence)
- [ ] Write the three schema files under `SCHEMAS/` exactly as referenced in `SCHEMAS/README.md`
- [ ] Add Phase 0 fixtures and tests
- [ ] Add/confirm a single canonical CLI entrypoint for:
  - verify bundle
  - verify chain
  - prove restore
- [ ] Fix changelog date ordering (if changelog is treated as an audit artifact)
```

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-27-2025-22-00_CATALYTIC_ROADMAP_V2.3.md`

```
<!-- CONTENT_HASH: 66f36203c142f7119f91e249e197021cefaed88bd0ff1c743273896523e7da89 -->

# CATALYTIC-DPT ROADMAP v2.3
Date: 2025-12-25  
Status: ACTIVE

## Goal
Turn CAT-DPT into a **verifiable, model-agnostic execution substrate** that can safely run a **swarm** (many steps, many tools, many models) without relying on chat history or trust.

The north star:
- **Artifacts over narrative**
- **Determinism over convenience**
- **Fail-closed over “best effort”**
- **Hash-first, bounded dereference** so token and I/O cost is measurable and capped

## Operating rules
Non-negotiables:
- No runtime-generated timestamps. If a timestamp exists, it is caller-supplied and recorded as-is.
- Every acceptance claim must be artifact-verifiable (tests and/or fixtures).
- No silent downgrade paths. CI and verifiers must hard-require strictness.
- No unbounded reads. Any dereference or inspection must be bounded.
- Append-only receipts. If you need “state”, write a new record, do not mutate the past.
- Schema-first. Every persistent artifact has a schema (or a canonical JSON contract).

## Phase gates (the only definition of “done”)
> A phase is DONE only when its gate is DONE.

### Phase 0 Gate: Contract freeze + enforcement (DONE)
- [x] All schemas strict (no unknown fields) where appropriate.
- [x] CI enforces strict verification paths.
- [x] Fixtures represent real contracts.

### Phase 1 Gate: Kernel substrate (DONE)
- [x] CAS (streaming, deterministic layout).
- [x] Merkle roots per domain (deterministic ordering).
- [x] Ledger receipts (append-only JSONL, schema-valid, canonical JSON bytes).
- [x] Proof wiring (byte-identical reruns, tamper detection).

### Phase 1X Gate: Expand-by-hash usability (DONE)
- [x] hash read|grep|describe|ast with hard caps and hash-only dereference.
- [x] Optional deref logging into ledger (hash + bounds only, no content).

### Phase 1V Gate: Verifiers and validator identity (DONE)
- [x] Strict verifier behavior enforced in CI and CLI.
- [x] Validator identity pin is law-frozen and verified.

### Phase 2 Gate: Memoization (never pay twice) (DONE)
- [x] Cache keys bind to job + inputs + toolchain + validator identity.
- [x] Cache hits still emit verifiable receipts and proofs.
- [x] Demo exists showing reduced work with bounded hash dereference while PROOF remains byte-identical.

### Phase 3 Gate: Packing hygiene (DONE)
- [x] Packs are deterministic, bounded, deduplicated, fail-closed.

### Phase 4 Gate: Runtime hardening (DONE)
DONE when all are true:
- [x] Adversarial fixtures exist for corruption, partial state, path attacks, malformed proofs, pipeline interruption/resume safety.
- [x] Fail-closed everywhere (no "warn and continue" in any verifier path).
- [x] No silent acceptance (every acceptance has an explicit reason code).

### Phase 5 Gate: Pipelines (DONE)
- [x] Artifact-only pipeline runner with resume-safe STATE.
- [x] Proof chain exists and is verifiable.
- [x] CLI verification for pipelines is fail-closed.

### Phase 6 Gate: Swarm integration surface (DONE)
DONE when all are true:
- [x] Phase 6.1 model-free bridge exists (emit pipeline spec, run + verify).
- [x] Phase 6.2 router slot exists (external plan producer, schema-validated, capped, fail-closed).
- [x] Phase 6.3 adapter contract exists (skills/MCPs wrap schema-valid jobspec; no runtime bypass).
- [x] Phase 6.4 MCP adapter is first-class (schema + tests + caps + deterministic transcript hashing).
- [x] Phase 6.5 Skill registry exists (hash-addressed capabilities; inclusion in proofs).
- [x] Phase 6.6 Capability pinning exists (explicit, auditable).
- [x] Phase 6.7 Registry immutability backstop exists (canonical validation + adversarial tests).
- [x] Phase 6.8 Capability versioning semantics (no-history-break).
- [x] Phase 6.9 Capability revocation semantics (no-history-break). (commit: this changeset)

---

## Canonical run artifact set (required)
A run is only “real” if these exist and validate:
- `PROOF.json`
- `DOMAIN_ROOTS.json`
- `LEDGER.jsonl`
- `PRE_MANIFEST.json` (or equivalent field inside ledger record)
- `POST_MANIFEST.json` (or equivalent field inside ledger record)
- durable outputs (as declared)

For pipelines:
- `PIPELINE.json`
- `STATE.json`
- `CHAIN.json` (or equivalent proof chain artifact)

For swarm (Phase 7+):
- `SWARM.json` (spec)
- `SWARM_STATE.json`
- `SWARM_CHAIN.json` (top-level chain across pipelines)

---

## PHASE 4: Runtime hardening (DONE)
Deliverables
- [x] Adversarial fixtures: corrupted artifacts, partial state, path attacks, malformed proofs, pipeline interruption/resume safety.
- [x] Tighten guards as needed, always with fixtures and regression tests.
- [x] Fix ledger.schema.json $ref resolution (Draft7)

Acceptance
- [x] Fail-closed everywhere.
- [x] No silent acceptance.

Notes
- This phase never fully ends. It is the “immune system”: add fixtures first, then guards, then regressions.

---

## PHASE 6.4: MCP adapter becomes first-class
Intent
Make MCP servers usable as governed adapters inside pipelines without expanding trust boundaries.

Deliverables
- [x] `mcp_adapter.schema.json` with strict, fail-closed constraints:
  - server command vector (non-empty list of strings)
  - request envelope schema (canonical JSON)
  - stdout/stderr caps, timeout cap, exit code rules
  - transcript hashing rules (hash of bytes actually read, not “what should have been read”)
- [x] Implementation in `ags.py` (or a dedicated module) that:
  - executes MCP server as a subprocess
  - rejects any stderr output (or allowlisted patterns if absolutely necessary)
  - enforces byte caps on stdout
  - produces a deterministic adapter output artifact (canonical JSON) plus transcript hash
  - compiles to a Phase 6.3 adapter + schema-valid jobspec (no runtime bypass)
- [x] Tests: happy path + reject cases
  - over-cap output
  - timeout
  - non-zero exit
  - stderr emitted
  - non-canonical JSON
  - non-normalized paths / overlaps in produced jobspec
  - backstop: adapter step runs in a pipeline and strict verify detects output tampering (`CATALYTIC-DPT/TESTBENCH/test_ags_phase6_mcp_adapter_e2e.py`)

Acceptance
- [x] MCP step can run in a pipeline and produce proof-valid artifacts.
- [x] Re-running the same MCP step (same inputs) yields byte-identical artifacts.
- [x] Any cap breach fails closed with a stable error code.

---

## PHASE 6.5: Skill registry (hash-addressed capabilities)
Intent
Turn “skills” into immutable, discoverable, auditable capabilities.

Implemented (v1)
- `CAPABILITIES.json` provides `capability_hash -> adapter spec` resolution and is enforced in `ags route` and `catalytic pipeline verify` (fail-closed).

Deliverables
- [x] `SKILLS/registry.json` (canonical JSON) mapping:
  - `skill_id` -> `adapter_hash` (or `adapter_spec_path` + hash)
  - `version`
  - `capability_hash` (defined below)
  - `human_name`, `description` (optional, non-normative)
- [x] `skills.py` helper to:
  - load registry deterministically
  - resolve skill -> adapter spec by hash
  - reject unknown skills and mismatched hashes
- [x] `ags.py` integration:
  - allow plan steps to reference `skill_id` instead of embedding full adapter
  - expand `skill_id` deterministically into adapter+jobspec before routing
- [x] Tests:
  - registry determinism
  - tamper in adapter spec changes capability hash and fails verification
  - unknown skill fails closed
  - duplicate skill_id rejects

Capability hash (v1)
- `capability_hash = sha256(canonical_json({adapter_schema, adapter_payload, jobspec_hash, global_caps}))`
- It is a pin on *what the skill can do*, not who authored it.

Acceptance
- [x] Skill resolution is hash-addressed and tamper-evident.
- [x] Proof/ledger includes enough to reconstruct which skill capability was used.

---

## PHASE 6.6: Capability pinning and revocation (auditable)
Intent
Make “who/what is allowed to produce accepted work” explicit and reversible.

Implemented (v1)
- `CAPABILITY_PINS.json` allowlists permitted `capability_hash` values; both `ags route` and `catalytic pipeline verify` reject known-but-unpinned capabilities fail-closed.

Deliverables
- [x] Add `CAPABILITY_PINS.json` (canonical) that lists allowed capability hashes for a run/pipeline (or references a pinned set).
- [x] Verifiers fail closed if a step uses a capability hash not in the allowed set.
- [x] Revocation mechanism:
  - an explicit denylist or a new pinned set (no silent mutation)
  - deterministic precedence rules

Acceptance
- [x] “Allow” and “deny” decisions are explicit artifacts.
- [x] Changing allowed capabilities changes the proof hash (no invisible policy changes).

---

## PHASE 6.7: Registry immutability and CI backstop (fail-closed)
Intent
Prevent silent mutation and non-canonical registry drift for capability governance artifacts.

Deliverables
- [x] Canonical validation for `CAPABILITIES.json` and `CAPABILITY_PINS.json` (no duplicates, canonical JSON bytes, sorted ordering).
- [x] Enforced at route time (`ags route`) and verify time (`catalytic pipeline verify`) with stable error codes:
  - `REGISTRY_DUPLICATE_HASH`
  - `REGISTRY_NONCANONICAL`
  - `REGISTRY_TAMPERED`
- [x] Adversarial tests exercising duplicate hashes, non-canonical encoding, and tamper detection.

Acceptance
- [x] Any malformed/non-canonical/tampered registry fails closed before execution and during verification.

---

## PHASE 6.8: Capability versioning semantics (no-history-break)
Intent
Make capability versioning semantics explicit: capabilities are immutable-by-content and historical verification must remain possible.

Deliverables
- [x] Route/verify surfaces use a dedicated boundary error code `CAPABILITY_HASH_MISMATCH` when a capability hash cannot be re-derived from the registry adapter spec bytes.
- [x] Tests assert that changing adapter spec bytes requires a new capability hash; “in-place upgrade” is rejected deterministically.

Acceptance
- [x] Existing capability hashes remain verifiable as long as their registry entries remain present and correct.

---

## PHASE 6.9: Capability revocation semantics (no-history-break) (DONE)
Intent
Block future use of a capability without breaking historical verification of pre-revocation runs.

Deliverables
- [x] `CAPABILITY_REVOKES.json` exists (deterministic ordering) and is enforced at route time with `REVOKED_CAPABILITY`.
- [x] Pipeline verification rejects post-revocation use while preserving verification of pre-revocation pipelines (policy snapshot).
- [x] Tests prove route rejection, historical verify pass, and post-revocation verify failure.

Acceptance
- [x] A revoked capability cannot be used in new accepted work, but old work remains mechanically verifiable.

---

### Phase 7 Gate: Swarm scheduling (DONE)
- [x] Phase 7.0: deterministic Pipeline DAG scheduling (DAG spec + scheduler + resume + fail-closed DAG verification).
- [x] Phase 7.1: distributed execution receipts (portable receipts, chained by DAG topology, strict verification).
- [x] Phase 7.2: multi-node restore runner (receipt-gated, idempotent recovery; restore decisions verified).
- [x] Phase 7.3: catalytic swarm execution elision (identical swarms skip execution; emit valid, verifiable proofs).
- [x] `swarm.schema.json` for a DAG of pipelines.
- [x] `swarm_runtime.py` with `SWARM_STATE.json` and `SWARM_CHAIN.json`

Acceptance
- [x] A swarm run produces a top-level chain that binds each pipeline's proof.
- [x] Any missing or tampered pipeline proof fails the swarm verification.
- [x] Identical swarm re-execution elides all pipeline/skill/model execution and emits a valid swarm receipt.

Clarification: “Identical” is determined solely by the canonical swarm spec hash combined with the ordered pipeline intent hashes (plus the capability + policy hashes that govern the execution context).

Elided re-executions must still emit a new swarm receipt and top-level chain, reference the prior pipeline proofs by hash, and pass verification end-to-end without performing any pipeline/skill/model execution.

---

## PHASE 8: Model binding (optional, replaceable, never trusted)
Intent
Let local models (LFM2, etc.) produce plans, but never grant them authority.

Deliverables

- [x] Router receipt artifacts:
  - `ROUTER.json` (what ran, caps, hash of executable)
  - `ROUTER_OUTPUT.json` (canonical JSON plan output)
  - `ROUTER_TRANSCRIPT_HASH` (bytes read)
- [x] Cache router outputs by content hash (optional)
- [x] Tests:
  - router over-output fails closed
  - router stderr fails closed
  - malformed plan fails schema validation
  - plan that attempts capability escalation fails closed (Phase 6.6)

Acceptance
- [x] Swapping models does not change verification logic, only the produced plan.
- [x] Plans are validated, capped, and recorded, not trusted.

### Phase 9 Gate: Freeze, release discipline, and schema versioning (DONE)

- [x] Schema versioning policy.
- [x] Release checklist for "law changes".
- [x] Artifact-only verifiability audit.
- [x] Docs pass: single authoritative docs tree, no duplicated demo docs that can drift
```

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-28-2025-01-18_CATALYTIC_RELEASE_CHECKLIST.md`

```
<!-- CONTENT_HASH: 6c1fc06487b567adda2a1d92c0472c8a7f724ba8a349a4cf710805ac92f86632 -->

# CAT-DPT Release Checklist (Law Changes)

Use this checklist when changing schemas, validator identity, or capability semantics.

## 1. Governance
- [x] ADR drafted and accepted in `CONTEXT/decisions/` (Covered by Roadmap Phase 7 spec).
- [x] `CHANGELOG.md` updated with descriptive entry (v1.61.0).
- [x] `CANON/VERSIONING.md` bumped (Minor for additive, Major for breaking).

## 2. Schema Hardening
- [x] New schema versioned correctly (if breaking).
- [x] `additionalProperties: false` set where appropriate.
- [x] Schema examples updated in `SCHEMAS/examples/`.

## 3. Tooling Compatibility
- [x] `PipelineRuntime` updated with new `validator_semver`.
- [x] `ags.py` plan/route/run commands verified against new schemas.
- [x] `catalytic.py` hash/pipeline commands verified.

## 4. Regression & historical Verification
- [x] Run `python -m pytest CATALYTIC-DPT/TESTBENCH/`.
- [x] Verify that at least one historical run (e.g., from `FIXTURES/`) still passes verification.
- [x] Test a "resume" scenario where a pipeline started with old law is finished under new law (if applicable).

## 5. Artifact Consistency
- [x] Ensure all required artifacts (`PROOF.json`, `LEDGER.jsonl`, etc.) are byte-identical for identical inputs.
- [x] Verify `POLICY.json` captures all relevant snapshots.

## 6. Known Issues / Investigations (Post-v2.12.0)
- [x] **Packer Hygiene:** `test_packer_determinism_catalytic_dpt` fails with hash mismatch on Windows. Investigate CRLF/normalization in `packer.make_pack`. **(FIXED via timestamp pinning)**
- [ ] **Swarm Terminal Instability:** External terminals are flaky. Avoid `use_terminal=True` for now.
```

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-28-2025-01-18_CATALYTIC_RELEASE_REPORT.md`

```
<!-- CONTENT_HASH: 697622077f9cfc149ac212aea36c2b2a910a1e50aeff8d4640e2466f60f4704c -->

# Release Report: Phase 7.3 & Governance Alignment

**Date:** 2025-12-28
**Status:** ✅ **READY FOR RELEASE**
**Version Scope:** Phase 7 (Catalytic Swarms) & Phase 6/7 cleanup.

## Executive Summary
All critical blockers identified in the `TEST_FAILURES_REPORT.md` have been resolved. The system has achieved "All Clear" status on the global `runner.py` contract fixtures and the critical component test suite (`pytest`). The repository is now compliant with its own invariants, including the newly recognized `INV-012` (Visible Execution).

## 1. Resolved Blockers

### 🟢 Packer Determinism
- **Issue:** Non-deterministic pack hashes due to variable timestamps.
- **Fix:** Implemented `LLM_PACKER_DETERMINISTIC_TIMESTAMP` override in `core.py`.
- **Verification:** `test_packing_hygiene.py` now passes consistently.

### 🟢 Infrastructure Robustness (AGS CLI)
- **Issue:** Tests failing due to "dirty" local workspace state and `stderr` pollution.
- **Fix:** Added `--skip-preflight` to `ags run` and suppressed `jsonschema` deprecation warnings.
- **Verification:** `test_ags_phase6_bridge.py` and `test_ags_phase6_router_slot.py` pass.

### 🟢 Swarm Integrity
- **Issue:** Execution elision logic was theoretically vulnerable to state reuse issues.
- **Fix:** Hardened `SwarmRuntime` artifact verification and improved test harness cleanup.
- **Verification:** `test_swarm_reuse.py` passes (Verify -> Tamper -> Reject).

### 🟢 Governance Drift
- **Issue:** `invariant-freeze` skill expected 11 invariants, but 12 exist.
- **Fix:** Updated skill fixtures to recognize `INV-012` (Visible Execution).
- **Verification:** `CONTRACTS/runner.py` passes all 40+ fixtures.

## 2. Validation Status

| Component | Status | verification Method |
|-----------|--------|---------------------|
| **Contracts** | ✅ PASS | `python CONTRACTS/runner.py` |
| **Governance** | ✅ PASS | `python TOOLS/critic.py` |
| **Logic** | ✅ PASS | `pytest CATALYTIC-DPT/TESTBENCH/` |
| **Packer** | ✅ PASS | Deterministic Hash Verification |

## 3. Known Issues & Advisories

### ⚠️ Swarm Terminal Instability
- **Description:** Spawning external terminal windows for swarm workers is currently flaky on Windows.
- **Workaround:** Do not use `use_terminal=True` in swarm specs until the `subprocess` / `start` logic is hardened. Use in-process execution.

## 4. Release Recommendation
Proceed with committing the current state as the baseline for **Phase 7.4 (Swarm Recovery)**.
```

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-28-2025-01-54_CATALYTIC_AGENTS.md`

```
<!-- CONTENT_HASH: c99f13b496af73ad0a775cb031fa567a3292db747e5bea466e7bde0e82a39476 -->

# CAT-DPT AGENTS (Scoped)
Scope: CAT-DPT (Catalytic DPT runtime, bundles, chain verification, CAS, Merkle, ledger, restore proof, tooling)

Authority and inheritance
- This file is subordinate to the repo-root AGENTS.md and any CANON/DECISIONS files.
- If any instruction here conflicts with higher authority, higher authority wins.
- This file must not be duplicated elsewhere. Keep exactly one scoped CAT-DPT AGENTS file.

Active roadmap (do not waste tokens)
- The ONLY active execution roadmap for CAT-DPT is: `ROADMAP_V2.3.md`
- Treat these as historical. Do not load unless explicitly asked:
  - `LAB/ARCHIVE/ROADMAP_V2.2.md`
  - `LAB/ARCHIVE/ROADMAP_V2.1.md`
  - `LAB/ARCHIVE/ROADMAP_V2.md`
  - `LAB/ARCHIVE/ROADMAP.md`
- If unsure what to do next, read `ROADMAP_V2.3.md` and execute the smallest unchecked item that advances Phase 0, then Phase 1, etc.

Primary objective
Build a verifiable catalytic runtime where:
- Truth is artifacts, not narration.
- Runs are resumable and verifiable from bundles and chain proofs.
- Token efficiency is achieved via hash-referenced memory and bounded dereference, not by dumping blobs.

Non-goals (hard)
- Do not pack large bodies of repo content into prompts.
- Do not introduce “helpful” refactors unrelated to contracts, proofs, determinism, or security boundaries.
- Do not rely on chat logs/transcripts as state.
- Do not add large-model fine-tuning as a substitute for proofs.

## Contracts are law
Schemas
- Implement and enforce these schemas as canon:
  - `SCHEMAS/jobspec.schema.json`
  - `SCHEMAS/validation_error.schema.json`
  - `SCHEMAS/ledger.schema.json`
- Schema dialect must be explicitly pinned (Draft 7 recommended). Do not change dialect without an explicit decision record and migration plan.

Run artifact set (required)
Every run MUST write artifacts to:
- `CONTRACTS/_runs/<run_id>/`

Minimum required files
- `JOBSPEC.json` (schema-valid)
- `STATUS.json` (state machine: started/failed/succeeded/verified)
- `INPUT_HASHES.json`
- `OUTPUT_HASHES.json`
- `DOMAIN_ROOTS.json`
- `LEDGER.jsonl` (append-only, schema-valid)
- `VALIDATOR_ID.json` (validator_semver, validator_build_id, substrate/toolchain versions)
- `PROOF.json` (hashable restoration proof summary)

Definition of success
- A run is not “successful” unless:
  - all required artifacts exist
  - bundle verification passes in strict mode
  - restoration proof passes
- Missing artifacts or verification failures must fail closed.

Validator identity
- Bundle and chain verification MUST bind to:
  - `validator_semver`
  - `validator_build_id`
- Strict mode is the default for CI and for any acceptance gate.

## Enforcement model (3 layers)
Preflight (before execution)
- Validate JobSpec against schema.
- Enforce path rules:
  - no absolute paths
  - no traversal
  - allowed roots only
- Enforce forbidden overlaps (inputs vs outputs).
- Resolve required hash references or fail.

Runtime guard (during execution)
- Enforce allowed roots and forbid writes elsewhere.
- Record write events (at least path and byte count; include hash when feasible).
- Fail immediately on policy violation.

CI validation (after execution / PR gate)
- Verify bundles and chains in strict mode.
- Verify restoration proof for required fixtures and demos.
- Reject nondeterminism regressions.

## Token efficiency rules (hash-first operations)
Default interaction pattern
- Prefer: hashes + bounded previews + targeted dereference.
- Do not paste large file bodies into prompts.
- Use the expand-by-hash toolbelt once it exists:
  - `catalytic hash read`
  - `catalytic hash grep`
  - `catalytic hash ast`
  - `catalytic hash describe`

Bounded outputs (mandatory)
- Every “read” or “grep” must enforce explicit bounds:
  - max bytes
  - max matches
  - explicit ranges
- Any tool that can dump unbounded content is a violation and must be fixed.

Dereference protocol
- Only dereference by hash when needed for:
  - correctness of an acceptance decision
  - resolving an ambiguity
  - producing final outputs that require exact bytes
- Log dereference events into receipts where feasible (hash requested, byte bounds returned).

## Memoization (never pay twice)
Caching is required once the cache is implemented.
- Cache key MUST include identity and inputs:
  - job_hash
  - input_hash
  - toolchain_hash
  - model_hash (or validator_build_id when model is external)
- Cache hit must still produce verifiable receipts and proofs.
- Cache miss must not bypass verification.

## Determinism discipline
- Do not introduce timestamps or nondeterministic ordering into proofs, roots, manifests, or receipts unless explicitly allowed and documented.
- Normalize paths and sort deterministically before hashing or generating roots.
- When determinism is expected, add a test that runs twice and asserts identical roots and artifacts.

## Work style (how agents should operate)
Implementation workflow
1) Read `ROADMAP_V2.3.md` and pick the next smallest unchecked item.
2) Implement the minimum code to satisfy that item.
3) Add fixtures and tests that prove it.
4) Run tests locally.
5) Update docs only to reflect reality (no aspirational docs).
6) Commit in small, reviewable changes.

Tests are not optional
- Any new contract or enforcement rule requires tests.
- Any bug fix requires a regression test.
- Any security boundary change requires an adversarial fixture.

No silent behavior
- If the system does something, it must be documented.
- If docs claim behavior, tests must verify it.

## Roadmap navigation rules
- Do not “merge phases” unless the roadmap explicitly says so.
- If you discover the roadmap is wrong relative to reality:
  - do not rewrite history
  - propose a new versioned roadmap (v2.2, v2.3) or add a small patch file
  - keep prior versions intact

## Safety rail for edits
- Do not modify repo-root AGENTS.md, CANON, or DECISIONS unless explicitly instructed.
- Prefer adding scoped docs under CAT-DPT directories instead of changing global law.
- If a contradiction is found, report it and propose a minimal reconciliation.

## Architectural Boundaries
Kernel vs. LAB
- The root `CATALYTIC-DPT/` directory contains the **Kernel** (schemas, primitives, verified skills, and core testbenches).
- The `CATALYTIC-DPT/LAB/` directory contains **Experimental Scaffolds** (research, archived roadmaps, and unstable/phased components).
- **Rule**: Kernel code MUST NOT import from `LAB/`.
- **Rule**: `LAB/` code may import from the Kernel.

Test Gating
- Default `pytest` execution excludes the `LAB/` directory to ensure kernel stability and speed.
- To include `LAB` tests, set the environment variable: `CATDPT_LAB=1`.
- Example: `CATDPT_LAB=1 python -m pytest`


End state definition
CAT-DPT is considered “operational” when:
- Phase 0 schemas and fixtures exist and pass
- Phase 1 kernel (CAS, Merkle, ledger, restore proof) passes determinism and adversarial fixtures
- Expand-by-hash toolbelt exists and is bounded and deterministic
- Bundle and chain verification run in strict mode in CI
- At least one end-to-end demo proves:
  - resume without history
  - proof-gated acceptance
  - measurable token reduction at the interface
```

## `repo/MEMORY/ARCHIVE/catalyticdpt/12-29-2025-04-16_CATALYTIC_CHANGELOG.md`

```
<!-- CONTENT_HASH: e71f7cb0f3b2a4474b306d3c0e2b692d4d3ec5df73c679a6e288ae204fe59d3e -->

# CATALYTIC-DPT Changelog

All notable changes to the Catalytic Computing Department (Isolated R&D) will be documented in this file.

## [1.61.0] - 2025-12-27

### Phase 7.3: Catalytic Swarm Execution Elision

#### Added
- `PIPELINES/swarm_runtime.py`: Swarm-level reuse detection and execution elision.
  - Computes deterministic swarm hash from canonical spec + pipeline intents + capability hashes.
  - Persists swarm receipts in `_swarms/_receipts/` keyed by swarm hash.
  - On identical swarm re-run: skips ALL pipeline/skill/model execution; emits new `SWARM_RECEIPT.json` and `SWARM_CHAIN.json` referencing prior proofs.
  - Fail-closed: if any referenced pipeline receipt is missing or tampered, reuse is rejected.
- `TESTBENCH/test_swarm_reuse.py`: Fixture proving:
  - First run executes normally (`elided: false`).
  - Identical re-run elides execution (`elided: true`).
  - Chain/receipt artifacts re-emitted correctly.
  - Tampered pipeline proof fails reuse verification.

#### Changed
- `ROADMAP_V2.3.md`: Phase 7.3 marked DONE with acceptance criteria.

---

## [1.60.0] - 2025-12-27

### Phase 6.4: MCP Adapter Contracts
- **Added** `SCHEMAS/mcp_adapter.schema.json`: Strict schema for MCP adapter execution (caps, transcript hashing).
- **Added** `SKILLS/mcp-adapter/`: Official skill wrapper for MCP servers.
- **Added** `SKILLS/mcp-adapter/scripts/wrapper.py`: Subprocess executor enforcing strict governance caps.
- **Verified** `TESTBENCH/test_mcp_adapter_schema.py` and `test_ags_phase6_mcp_adapter_e2e.py`: Verified schema and runtime governance.

### Phase 6.5: Skill Registry (Hash-Addressed Capabilities)
- **Added** `SKILLS/registry.json`: Canonical, versioned mapping of Skill IDs to Capability Hashes.
- **Added** `PRIMITIVES/skills.py`: Skill registry loading, resolution, and strict integrity verification.
- **Verified** `TESTBENCH/test_skills_registry.py`: Tests for registry loading, resolution, and integrity checks (fail-closed).
- **Changed** `TOOLS/ags.py`: Integrated `skill_id` resolution into routing logic.

### Phase 6.6: Capability Pinning & Revocation
- **Added** `CAPABILITY_PINS.json`: Explicit allowlist for capability hashes (immutable by default).
- **Added** `CAPABILITY_REVOKES.json`: Explicit denylist for emergency capability revocation.
- **Verified** `TESTBENCH/test_capability_revocation.py`: Adversarial test confirming revocation enforcement fails closed.
- **Verified** `ags.py` enforcement: Precedence rules (Revoke > Pin) verified.

### Phase 6.7: Registry Immutability & Safety
- **Verified** `PRIMITIVES/registry_validators.py` enforces canonical JSON, sorted keys, and no duplicates.
- **Verified** `TESTBENCH/test_registry_validators.py`: Adversarial tests for duplicate hashes, non-canonical encoding, and tamper detection.
- **Enforced** `ags.py`: `route` and `verify` fail closed on any registry violation.

### Phase 6.8: Capability Versioning Semantics (Immutability-by-Content)
- **Enforced** `PRIMITIVES/registry_validators.py`: Capabilities are immutable-by-content.
  - Registry validator computes SHA-256 of adapter spec and verifies it matches capability hash.
  - Any mismatch returns `REGISTRY_TAMPERED`, preventing "in-place upgrades".
- **Verified** `TESTBENCH/test_ags_phase6_registry_immutability.py::test_registry_tamper_detected_fail_closed`:
  - Tampered adapter spec (hash mismatch) fails routing with `CAPABILITY_HASH_MISMATCH`.
- **Principle**: Upgrading a capability requires creating a new hash, not modifying existing entry.
  - Historical pipelines remain verifiable as long as their capability registry entries are present and correct.

### Phase 8: Model Binding (Optional, Replaceable, Never Trusted)
- **Added** Router receipt artifacts in `ags_plan`:
  - `ROUTER.json`: Records router executable, args, hash, exit code, and stderr bytes.
  - `ROUTER_OUTPUT.json`: Canonical JSON plan output for deterministic verification.
  - `ROUTER_TRANSCRIPT_HASH`: SHA-256 hash of raw router stdout bytes.
- **Verified** `TESTBENCH/test_phase8_router_receipts.py`: 5 tests confirming:
  - Router receipts are created and contain correct metadata.
  - Router over-output fails closed (`ROUTER_OUTPUT_TOO_LARGE`).
  - Router stderr fails closed (`ROUTER_STDERR_NOT_EMPTY`).
  - Malformed plans fail schema validation.
  - Capability escalation attempts fail closed (Phase 6.6 enforcement).
- **Principle**: Models are replaceable and untrusted. Governance validates everything they produce.

### Performance
- **Optimized** `PRIMITIVES/cas_store.py`: Eliminated redundant file copy in `put_stream` (100% write IO reduction).

## [1.55.0] - 2025-12-26

### Swarm Activation (Nervous System Online)

#### Changed
- `swarm_config.json`:
  - Assigned `LFM2-2.6B-Exp` (Python Runner) as the canonical Ant Worker.
  - Assigned `Claude` as the President (reverted from Brains).
- `LAB/MCP/mcp_client.py`: Verified functional connectivity (President ↔ Governor ↔ Ledger).
- `LAB/MCP/server.py`: Verified ledger persistence for dispatch task queue.

#### Added
- `SKILLS/ant-worker/scripts/lfm2_runner.py`: Direct Python execution script for LFM2 using Transformers.
- `SKILLS/ant-worker/scripts/ant_agent.py`: MCP-aware agent daemon that polls ledger and invokes LFM2.

#### Fixed
- `SKILLS/swarm-orchestrator/scripts/poll_and_execute.py`: Corrected MCP import path and added JSON error recovery.
- `SKILLS/swarm-orchestrator/scripts/launch_swarm.ps1`: Fixed hardcoded paths and script locations.

#### Verified
- Nervous System: successful dispatch-perform-report loop via MCP ledger (task `TEST-001`).
- Brain (Cortex): successful indexing and search functionality.
## [1.52.0] - 2025-12-26

### LAB Compression (Cortex-Style Merge)

#### Changed
- Merged `ARCHITECTURE/ORCHESTRATION.md` + `ARCHITECTURE/RECURSIVE_SWARM.md` → `ARCHITECTURE/SWARM_ARCHITECTURE.md`
- Merged `RESEARCH/SEMIOTIC_COMPRESSION_LAYER_REPORT.md` + `RESEARCH/SEMIOTIC_COMPRESSION_ROADMAP_PATCH.md` → `RESEARCH/SEMIOTIC_COMPRESSION.md`
- Added Cortex-style document hashes for versioning (`SHA256:SWARM_ARCH_V1`, `SHA256:SCL_SPEC_V1`)

#### Moved
- `RESEARCH/CATALYTIC_STACK_COMPRESSED_MERGED GPT 5.2.md` → `ARCHIVE/` (superseded)

#### Removed
- Duplicate/superseded architecture and research files

---

## [1.51.0] - 2025-12-26

### LAB Reorganization

#### Changed
- Moved architecture docs to `LAB/ARCHITECTURE/`:
  - `ORCHESTRATION_ARCHITECTURE.md` → `ARCHITECTURE/ORCHESTRATION.md`
  - `RECURSIVE_SWARM_ARCHITECTURE.md` → `ARCHITECTURE/RECURSIVE_SWARM.md`
- Moved `ROADMAP_PATCH_SEMIOTIC.md` → `RESEARCH/SEMIOTIC_COMPRESSION_ROADMAP_PATCH.md`

#### Removed
- `ROADMAP_PATCH_SEMIOTIC_TESTBENCH.md` (duplicate of ROADMAP_PATCH_SEMIOTIC.md)

#### Added
- `LAB/README.md`: Index documenting LAB directory structure

---

## [1.50.0] - 2025-12-26

### Phase 6.7: Registry Immutability Backstop

#### Added
- `PRIMITIVES/registry_validators.py`: strict, deterministic validation for `CAPABILITIES.json` and `CAPABILITY_PINS.json` (duplicates/noncanonical/tamper fail closed).
- `TESTBENCH/test_ags_phase6_registry_immutability.py`: adversarial coverage for duplicate hashes, non-canonical JSON, and tamper detection.

#### Changed
- `TOOLS/ags.py`: fail-closed on malformed/non-canonical/tampered registries during routing.
- `PIPELINES/pipeline_verify.py`: fail-closed on malformed/non-canonical/tampered registries during verification.

---

## [1.53.0] - 2025-12-26

### Phase 6.8: Capability Versioning Semantics

#### Changed
- Route/verify surfaces now report `CAPABILITY_HASH_MISMATCH` when a capability hash cannot be re-derived from the registry adapter spec bytes (internal detection remains registry-based).

#### Added
- `TESTBENCH/test_ags_phase6_capability_versioning_semantics.py`: asserts fail-closed behavior and the dedicated boundary error code.

---

## [1.54.0] - 2025-12-26

### Phase 6.9: Capability Revocation Semantics

#### Added
- `CAPABILITY_REVOKES.json`: deterministic revoked capability list.
- `TESTBENCH/test_ags_phase6_capability_revokes.py`: route-time rejection and verify-time semantics preserving historical verification.

#### Changed
- `TOOLS/ags.py`: rejects revoked capabilities at route time (`REVOKED_CAPABILITY`).
- `PIPELINES/pipeline_verify.py`: rejects post-revocation pipelines that use revoked capabilities (`REVOKED_CAPABILITY`), while allowing legacy pipelines without policy snapshots.

---

## [1.55.0] - 2025-12-26

### Phase 7.0: Pipeline DAG Scheduling

#### Added
- `PIPELINES/pipeline_dag.py`: deterministic DAG spec parsing, topological scheduling, resume-safe receipts, and fail-closed verification integration.
- `TESTBENCH/test_pipeline_dag.py`: DAG happy path, resume, tamper rejection, and cycle detection.
- `catalytic pipeline dag run|status|verify`: minimal CLI surface for artifact-only DAG workflows.
- Deterministic topo sort tie-break: lexicographic node order.

---

## [1.56.0] - 2025-12-26

### Phase 7.1: Distributed Execution Receipts

#### Added
- `PIPELINES/pipeline_dag.py`: node receipts (RECEIPT.json), chained via DAG topology, with strict verification.
- `TESTBENCH/test_pipeline_dag.py`: receipt chaining, tamper rejection, and cross-machine portability coverage.

---

## [1.57.0] - 2025-12-26

### Phase 7.2: Multi-node Restore Runner

#### Added
- `PIPELINES/pipeline_dag.py`: receipt-gated DAG restore with deterministic decisions and fail-closed verification.
- `TESTBENCH/test_pipeline_dag.py`: restore no-op, missing artifact rerun, tampered receipt rerun, and portability coverage.

---

## [1.47.0] - 2025-12-26

### Phase 6.4: MCP Adapters as Governed Pipeline Steps

#### Changed
- `PIPELINES/pipeline_verify.py`: re-hashes durable outputs listed in `OUTPUT_HASHES.json` and fails closed on post-run tampering.

#### Added
- `TESTBENCH/test_ags_phase6_mcp_adapter_e2e.py`: end-to-end adapter step execution using `SKILLS/ant-worker` and strict pipeline verification (including tamper rejection).

---

## [1.48.0] - 2025-12-26

### Phase 6.5: Hash-Addressed Capability Registry

#### Added
- `CAPABILITIES.json`: deterministic registry mapping `capability_hash` to adapter spec (hash-addressed).
- `TESTBENCH/test_ags_phase6_capability_registry.py`: fail-closed tests for resolution, unknown capability rejection, and registry tamper detection.

#### Changed
- `TOOLS/ags.py`: supports `steps[].capability_hash` in plans and resolves it strictly via the registry (unknown/mismatch rejects).
- `PIPELINES/pipeline_verify.py`: enforces registry resolution and exact spec matching when capability hashes are used.

---

## [1.49.0] - 2025-12-26

### Phase 6.6: Capability Pinning Enforcement

#### Added
- `CAPABILITY_PINS.json`: deterministic allowlist of permitted `capability_hash` values.
- `TESTBENCH/test_ags_phase6_capability_pins.py`: route-time and verify-time rejection for unpinned capabilities (fail-closed).

#### Changed
- `TOOLS/ags.py`: rejects known-but-unpinned capabilities at route time (`CAPABILITY_NOT_PINNED`).
- `PIPELINES/pipeline_verify.py`: rejects unpinned capabilities even if present in `CAPABILITIES.json` (`CAPABILITY_NOT_PINNED`).

---

## [1.46.0] - 2025-12-26

### Docs: Roadmap Promotion

#### Changed
- `ROADMAP_V2.3.md` is the canonical roadmap.
- `ROADMAP_V2.2.md` restored as a deprecated stub pointer.

---

## [1.41.0] - 2025-12-26

### Phase 6.1: AGS Bridge (Model-Free Pipelines)

#### Added
- `python -m TOOLS.ags route`: emits deterministic `PIPELINE.json` + `STATE.json` from an explicit JSON plan (idempotent writes).
- `python -m TOOLS.ags run`: runs `catalytic pipeline run` then `catalytic pipeline verify` (fail-closed).
- `TESTBENCH/test_ags_phase6_bridge.py`: subprocess tests for deterministic routing, run+verify success, and tamper rejection.

---

## [1.42.0] - 2025-12-26

### Phase 6.1: Runtime-Owned Pipeline State

#### Changed
- `PipelineRuntime`: initializes `STATE.json` deterministically when `PIPELINE.json` exists but `STATE.json` is missing.
- `ags route`: emits `PIPELINE.json` only; runtime owns state.

---

## [1.43.0] - 2025-12-26

### Phase 6.2: Router Slot (External Plan Producer)

#### Added
- `SCHEMAS/ags_plan.schema.json`: strict plan schema for untrusted router output (no extra fields; capped steps).
- `ags plan`: runs an external router, hard-bounds stdout bytes, rejects any stderr, validates plan + jobspecs, writes canonical plan JSON.
- `ags route`: validates plans (schema + caps) before emitting `PIPELINE.json`.
- `TESTBENCH/test_ags_phase6_router_slot.py`: subprocess tests for router happy path, stderr rejection, byte caps, schema rejection, and jobspec validation.

---

## [1.44.0] - 2025-12-26

### Phase 6.2: Fail-Closed Plan Semantics

#### Changed
- Plans must declare an explicit step `command` (no implicit no-op defaults); missing step command rejects.

---

## [1.45.0] - 2025-12-26

### Phase 6.3: Adapter Contract (Skills + MCP Pipelining)

#### Added
- `SCHEMAS/adapter.schema.json`: strict adapter contract with explicit side effects, bounded deref caps, and required artifact hashes.
- Adapter validation in AGS: strict-mode rejection on any side effects, non-normalized paths, input/output overlap, or deref caps above global ceilings.
- Plan schema supports adapter steps (`steps[].adapter`) for pipeline-safe skill/MCP wrappers.
- `TESTBENCH/test_ags_phase6_adapter_contract.py`: fail-closed tests for missing command, side effects, deref caps, non-normalized paths, and nondeterministic adapters.

---

## [1.40.0] - 2025-12-26

### Phase 5: Pipeline Verify CLI (Fail-Closed)

#### Added
- `catalytic pipeline verify --pipeline-id <id>`: mechanical, artifact-only verification of a full pipeline run.
- `CATALYTIC-DPT/PIPELINES/pipeline_verify.py`: verifies `CHAIN.json`, per-step required artifacts, proof_hash integrity (if present), and schema-valid LEDGER.jsonl.
- `CATALYTIC-DPT/TESTBENCH/test_pipeline_verify_cli.py`: verifies OK, missing artifacts, chain tamper, and ledger corruption cases via the CLI.

---

## [1.38.0] - 2025-12-26

### Phase 3: Packing Hygiene (Deterministic, Bounded, Deduplicated)

#### Changed
- **MEMORY/LLM_PACKER/Engine/packer.py**:
  - Enforces deterministic pack generation (no timestamp-derived output; deterministic stamps by repo digest prefix).
  - Enforces explicit pack ceilings (max_total_bytes, max_entry_bytes, max_entries) and fails closed if exceeded.
  - Rejects duplicate normalized paths and (for CAT-DPT packs by default) duplicate content hashes.
  - Makes manifest auditable and content-addressed (`PACK_INFO.repo_state_sha256`) and verifies refs on pack validation.

#### Added
- **MEMORY/LLM_PACKER/Engine/pack_hygiene.py**: pure hygiene helpers (manifest validation, limit enforcement, canonical hashing).
- **TESTBENCH/test_packing_hygiene.py**: determinism + bounds + dedup + tamper detection backstop tests.

---

## [1.39.0] - 2025-12-26

### Phase 5: Verifiable Pipeline Proof Chain

#### Added
- `CONTRACTS/_runs/_pipelines/<pipeline_id>/CHAIN.json`: deterministic, artifact-only proof chain across pipeline steps.
- `CATALYTIC-DPT/PIPELINES/pipeline_chain.py`: fail-closed verifier that recomputes step proof/root hashes and checks link integrity and step order.
- `CATALYTIC-DPT/TESTBENCH/test_pipeline_chain.py`: valid, tamper, reorder, and determinism coverage.

#### Changed
- `CATALYTIC-DPT/PIPELINES/pipeline_runtime.py`: writes/updates `CHAIN.json` during step completion and refuses to resume if chain integrity fails.

---

## [1.37.0] - 2025-12-25

### Phase 4: Adversarial Fixtures (Fail-Closed Hardening)

#### Added
- Adversarial test coverage for CAS corruption/truncation/partial writes, ledger corruption, path traversal injection, proof/manifest tampering, and pipeline resume safety.

---

## [1.36.0] - 2025-12-25

### Phase 2: Demo of Measurable Reuse via Hash-First Dereference

#### Added
- **CATALYTIC-DPT/CONTEXT/demos/memoization_hash_reuse/**:
  - Deterministic demo runner (`run_demo.py`) that produces baseline vs reuse artifacts.
- **CONTRACTS/_runs/_CONTEXT/demos/memoization_hash_reuse/**:
  - Artifact-backed baseline/reuse evidence (PROOF.json, LEDGER.jsonl, bounded deref stats) and a comparison table.

---

## [1.35.0] - 2025-12-25

### Phase 5: Artifact-Only Resumable Pipelines

#### Added
- **PIPELINES/pipeline_runtime.py**:
  - Deterministic pipeline init/run/status with resume-safe state under `CONTRACTS/_runs/_pipelines/<pipeline_id>/`.
- **TOOLS/catalytic.py**:
  - Adds `catalytic pipeline run|status` commands (no timestamps; state is artifact-only).
- **TESTBENCH/test_pipelines.py**:
  - Proves deterministic init, resume without re-running completed steps, required per-step artifacts, and stable status output.

---

## [1.34.0] - 2025-12-25

### Phase 2: Deterministic Job Memoization (Never Pay Twice)

#### Added
- **PRIMITIVES/memo_cache.py**:
  - Deterministic job cache key (JobSpec canonical JSON + input domain roots + validator identity + strictness).
  - Cache storage under `CONTRACTS/_runs/_cache/jobs/<job_cache_key>/` with cached proof/domain roots/output hashes and materialized durable outputs.
- **TESTBENCH/test_memoization.py**:
  - Proves miss→hit behavior, byte-identical proof/domain roots on hits, and deterministic invalidation when strictness changes.

#### Changed
- **TOOLS/catalytic_runtime.py**:
  - Adds memoization path that skips execution on cache hits while restoring outputs and re-emitting proof artifacts.

---

## [1.33.0] - 2025-12-25

### Phase 4: Fix Ledger Schema `$ref` Resolution (Draft7)

#### Changed
- **SCHEMAS/ledger.schema.json**:
  - Makes internal `$ref` targets explicit (`ledger.schema.json#/definitions/...`) so resolution is stable under Draft7 reference loading.
- **TESTBENCH/test_schemas.py**:
  - Uses Draft7 `RefResolver` + deterministic schema store for ledger validation (no unsupported `registry=` argument).

---

## [1.32.0] - 2025-12-25

### Phase 4: Independent Verifier Implementation; Interop Proven

#### Added
- **PRIMITIVES/verify_bundle_alt.py**:
  - Code-independent SPECTRUM-05 bundle + chain verifier implementation (strict identity/signature enforcement).
- **TESTBENCH/test_verifier_interop.py**:
  - Golden interop fixtures (valid bundle + tamper rejection) and deterministic rerun coverage.
  - Enforces byte-identical serialized verification results across both implementations.

---

## [1.31.0] - 2025-12-25

### Phase 4: Ledger Observability for Expand-by-Hash Dereferences

#### Added
- **PRIMITIVES/hash_toolbelt.py**:
  - `log_dereference_event()`: Deterministic ledger logging for hash dereference commands.
  - `_build_dereference_ledger_record()`: Constructs minimal schema-conforming ledger records for dereference events.
  - Logs include requested hash, command name (read/grep/describe/ast), and bounds (max_bytes, ranges, matches, nodes, depth as applicable).
  - Logging is opt-in: only occurs when `--run-id` is provided.
- **TOOLS/catalytic.py**:
  - `--timestamp` parameter for deterministic timestamp injection (defaults to sentinel).
  - Ledger logging integrated at command dispatch for all four hash toolbelt commands.
- **TESTBENCH/test_deref_logging.py**:
  - Tests for deterministic rerun (identical ledger bytes), schema conformance, opt-in behavior (no run-id → no logging), and exact bounds recording.

#### Changed
- **ROADMAP_V2.2.md**:
  - Marked "dereference events logged to ledger" as DONE under Phase 1X status.

---

## [1.30.0] - 2025-12-25

### Phase 1V: CI Enforces Strict Verification by Default

#### Changed
- **.github/workflows/contracts.yml**:
  - Adds a strict-mode SPECTRUM-05 verification step that generates a deterministic signed bundle and verifies it with `--strict` under `CI=true`.
  - Runs CAT-DPT `pytest` in CI with a workspace-pinned temp directory (avoids capture temp failures) and ignores `CATALYTIC-DPT/LAB` + `MEMORY/LLM_PACKER/_packs`.
- **TOOLS/catalytic_verifier.py**:
  - Refuses to run without `--strict` when `CI` is set (prevents silent downgrade paths in CI).

---

## [1.29.0] - 2025-12-25

### Phase 1X: Expand-by-Hash Toolbelt (Bounded Read/Grep/Ast/Describe)

#### Added
- **TOOLS/catalytic.py**:
  - Unified `catalytic hash` CLI with bounded subcommands: `read`, `grep`, `describe`, `ast`.
  - Hash-first dereference: operates only on CAS objects by SHA-256 (no path reads).
  - Requires explicit CAS location via `--run-id` or `--cas-root`.
- **PRIMITIVES/hash_toolbelt.py**:
  - Deterministic, bounded implementations for read/grep/describe/ast (Python-only AST; otherwise `UNSUPPORTED_AST_FORMAT`).
- **TESTBENCH/test_hash_toolbelt.py**:
  - Tests for bounds enforcement, range reads, deterministic outputs, match limits, AST truncation, and invalid hash rejection.

---

## [1.28.0] - 2025-12-25

### Phase 1.P: Proof Generation Wired to CAS/Merkle/Ledger; Determinism Proven

#### Changed
- **PRIMITIVES/restore_proof.py**:
  - Domain root hash now computed via Phase 1 Merkle primitive (with deterministic empty-manifest sentinel) instead of ad-hoc concatenation.
  - Adds helpers for canonical JSON bytes and CAS-backed domain manifest computation.
- **TOOLS/catalytic_runtime.py**:
  - Snapshots now compute bytes hashes via CAS (streaming, idempotent) and normalize paths deterministically.
  - `DOMAIN_ROOTS.json` now uses Merkle roots per domain (deterministic serialization).
  - `LEDGER.jsonl` now appends schema-valid records via Phase 1 Ledger (canonical JSONL; caller-supplied deterministic timestamp sentinel).
  - `PROOF.json` now uses canonical JSON bytes and references hashes for jobspec + ledger.

#### Added
- **TESTBENCH/test_proof_wiring.py**:
  - Rerun determinism test: two independent runs emit byte-identical `PROOF.json` and `DOMAIN_ROOTS.json`.
  - Tamper detection: hash mismatch is detected and fails closed.

---

## [1.27.0] - 2025-12-25

### Phase 1.D: Append-Only Ledger Receipts Implemented

#### Added
- **PRIMITIVES/ledger.py**:
  - Append-only JSONL writer/reader for ledger entries; never generates timestamps (caller must supply deterministic `RUN_INFO.timestamp`).
  - Deterministic per-line serialization (UTF-8, no whitespace, lexicographically sorted keys).
  - Schema validation against `SCHEMAS/ledger.schema.json` (Draft-07), including optional `JOBSPEC` for job_id linkage.
  - Truncation/rewrite detection via monotonic file-size invariants across appends.
- **TESTBENCH/test_ledger.py**:
  - Append order preservation, deterministic serialization, schema rejection, corrupt/partial line detection, and adversarial truncation detection.

---

## [1.26.0] - 2025-12-25

### Phase 1.M: Merkle Roots per Domain Implemented

#### Added
- **PRIMITIVES/merkle.py**:
  - Deterministic Merkle root computation for domain manifests `{ normalized_path -> sha256_hex }`.
  - Strict path normalization (reuses CAS `normalize_relpath`) and fail-closed validation for malformed paths/hashes.
  - Deterministic leaf ordering (lexicographic by normalized_path) and standard odd-leaf padding.
  - Adversarial rejection: non-normalized paths and duplicate hash bound to different paths.
- **TESTBENCH/test_merkle.py**:
  - Determinism tests (order-independence, stable roots across runs).
  - Adversarial tests for non-normalized paths, invalid hashes, duplicate-hash binding, and odd-leaf padding correctness.

---

## [1.25.0] - 2025-12-25

### Implemented Restore Runner per SPECTRUM-06 (Gated by SPECTRUM-05 Strict Acceptance)

#### Added
- **PRIMITIVES/restore_runner.py**:
  - Implements `restore_bundle()` and `restore_chain()` exactly per SPECTRUM-06 (preflight/plan/execute/verify), including reject-if-exists, staging+rename, deterministic ordering, and rollback rules.
  - Enforces strict SPECTRUM-05 verification gating and PROOF.json verified=true requirement.
  - Emits SPECTRUM-06 frozen success artifacts (`RESTORE_MANIFEST.json`, `RESTORE_REPORT.json`) with canonical JSON bytes and invariant checks.
  - Implements restore-specific failure codes and deterministic selection rules.
- **TOOLS/catalytic_restore.py**:
  - Minimal CLI for restoring a single bundle or explicit chain (JSON output, nonzero exit on failure).
- **TESTBENCH/test_restore_runner.py**:
  - Restore-specific tests for gating, path safety, reject-if-exists, rollback cleanup, success artifacts, and chain all-or-nothing behavior.

---

## [1.24.0] - 2025-12-25

### SPECTRUM-06: Restore Runner Semantics Frozen

#### Added
- **SPECTRUM/SPECTRUM-06.md** (NEW):
  - SPECTRUM-06: Frozen specification for Restore Runner semantics.
  - SPECTRUM-06: restore result artifacts frozen
  - SPECTRUM-06: restore failure codes and threat model frozen
  - Defines eligibility rules: SPECTRUM-05 strict verification required, PROOF.json verified=true, OUTPUT_HASHES.json present.
  - Restore target model: explicit restore_root, path safety rules, traversal rejection.
  - Single-bundle restore: 4-phase procedure (preflight, plan, execute, verify).
  - Chain restore: per-run subfolder isolation, deterministic order, chain-level atomicity.
  - Overwrite policy: reject-if-exists (no implicit overwrites).
  - Atomicity model: staging directory + final rename.
  - Error codes: RESTORE_INELIGIBLE, PATH_ESCAPE_DETECTED, TARGET_EXISTS, etc.

---

## [1.23.0] - 2025-12-25

### Stability Lock: Verifier API/CLI Frozen and Error Codes Centralized

#### Added
- **PRIMITIVES/verify_bundle.py**:
  - Centralized `ERROR_CODES` constant map (one source of truth for all SPECTRUM-05 errors).
  - Mandatory Ed25519 dependency enforcement: Returns `ALGORITHM_UNSUPPORTED` if `cryptography` library is missing in strict mode.
- **TESTBENCH/test_verifier_freeze.py**: New test suite for stable API guarantees.

#### Changed
- **PRIMITIVES/verify_bundle.py**:
  - **API Surface Freeze**: `verify_bundle_spectrum05` and `verify_chain_spectrum05` now have stable signatures and return shapes.
  - **Stable Return Shape**: `{ok: bool, code: str, details: dict}`.
  - **Fail-Fast**: Verification now terminates immediately on the first error encountered in Phase 9 (Output Hash Verification).
- **TOOLS/catalytic_verifier.py**:
  - **CLI Surface Freeze**: Updated `verify_single_bundle`, `verify_chain`, and `verify_chain_from_directory` to use stable SPECTRUM-05 APIs.
  - Minimal output in JSON mode (no extra logs).
  - Nonzero exit code on any verification failure correctly preserved.
- **ROADMAP_V2.1.md**:
  - Updated Phase 1.5 status to explicitly reflect verifier stability lock.

#### Removed
- **PRIMITIVES/verify_bundle.py**:
  - Deprecated multi-error collection in Phase 9 in favor of spec-conformant fail-fast (single error return).

#### Documentation
- **SPECTRUM/SPECTRUM-05.md**:
  - Restored to exact frozen state from commit 3b281f6 (removed non-normative Section 12).
- **PRIMITIVES/VERIFYING.md** (NEW):
  - Created non-normative implementation guide containing extracted implementation requirements.
  - Clearly labeled as non-normative; does not modify SPECTRUM law.
  - Includes notes on mandatory Ed25519 dependency, offline verification, deterministic canonicalization, and verifier modes.

## [1.22.0] - 2025-12-25

### Verifier Updated to Enforce SPECTRUM-04/05 Identity, Canonicalization, and Verification Law

#### Added
- **PRIMITIVES/verify_bundle.py**: SPECTRUM-04/05 enforcement layer
  - `verify_bundle_spectrum05()`: Full 10-phase verification per SPECTRUM-05 v1.0.0
  - `verify_chain_spectrum05()`: Chain verification with chain_root computation
  - Canonical JSON serialization per SPECTRUM-04 v1.1.0 Section 4
  - Bundle root computation per SPECTRUM-04 v1.1.0 Section 5
  - Chain root computation per SPECTRUM-04 v1.1.0 Section 6
  - Ed25519 signature verification per SPECTRUM-04 v1.1.0 Section 9
  - validator_id derivation and verification (SHA-256 of public_key)

#### SPECTRUM-05 10-Phase Verification
- **Phase 1:** Artifact presence check (7 required artifacts)
  - TASK_SPEC.json, STATUS.json, OUTPUT_HASHES.json, PROOF.json
  - VALIDATOR_IDENTITY.json, SIGNED_PAYLOAD.json, SIGNATURE.json
- **Phase 2:** Artifact parse check (JSON validity)
- **Phase 3:** Identity verification
  - Exactly 3 fields: algorithm, public_key, validator_id
  - algorithm == "ed25519" (no alternatives)
  - public_key: exactly 64 lowercase hex characters
  - validator_id derivation matches sha256(public_key_bytes)
- **Phase 4:** Bundle root computation
  - Preimage: {"output_hashes":{...},"status":{...},"task_spec_hash":"..."}
  - task_spec_hash from raw TASK_SPEC.json bytes (not canonicalized)
  - All JSON objects canonicalized with sorted keys, no whitespace
- **Phase 5:** Signed payload verification
  - Exactly 3 fields: bundle_root, decision, validator_id
  - bundle_root matches computed value
  - decision == "ACCEPT" (no alternatives)
  - validator_id matches VALIDATOR_IDENTITY.validator_id
- **Phase 6:** Signature verification
  - payload_type == "BUNDLE"
  - signature: exactly 128 lowercase hex characters
  - validator_id matches across all artifacts
  - Signature message: "CAT-DPT-SPECTRUM-04-v1:BUNDLE:<canonical_payload>"
  - Ed25519 verification using cryptography library
- **Phase 7:** Proof verification
  - PROOF.json.restoration_result.verified == true (boolean)
  - Condition must be RESTORED_IDENTICAL for acceptance
- **Phase 8:** Forbidden artifact check
  - Rejects if logs/, tmp/, or transcript.json exists
- **Phase 9:** Output hash verification
  - All declared outputs must exist
  - SHA-256 hashes must match exactly
- **Phase 10:** Acceptance (all phases pass → ACCEPT)

#### Chain Verification (SPECTRUM-05 Section 6)
- Chain must be non-empty (CHAIN_EMPTY error code)
- No duplicate run_ids (CHAIN_DUPLICATE_RUN error code)
- Each bundle verified via verify_bundle_spectrum05
- Chain root computed: sha256({"bundle_roots":[...],"run_ids":[...]})
- All-or-nothing semantics (any failure rejects entire chain)

#### Error Codes (SPECTRUM-05 Conformance)
- Artifact: `ARTIFACT_MISSING`, `ARTIFACT_MALFORMED`, `ARTIFACT_EXTRA`
- Field: `FIELD_MISSING`, `FIELD_EXTRA`
- Identity: `IDENTITY_INVALID`, `IDENTITY_MISMATCH`, `IDENTITY_MULTIPLE`
- Algorithm: `ALGORITHM_UNSUPPORTED`
- Key: `KEY_INVALID`
- Signature: `SIGNATURE_MALFORMED`, `SIGNATURE_INCOMPLETE`, `SIGNATURE_INVALID`, `SIGNATURE_MULTIPLE`
- Root: `BUNDLE_ROOT_MISMATCH`, `CHAIN_ROOT_MISMATCH`
- Payload: `DECISION_INVALID`, `PAYLOAD_MISMATCH`
- Serialization: `SERIALIZATION_INVALID`
- Proof: `RESTORATION_FAILED`
- Forbidden: `FORBIDDEN_ARTIFACT`
- Output: `OUTPUT_MISSING`, `HASH_MISMATCH`
- Chain: `CHAIN_EMPTY`, `CHAIN_DUPLICATE_RUN`

#### Test Coverage
- **TESTBENCH/test_spectrum_04_05_enforcement.py**: 9 new tests
  - Canonical JSON serialization (sorted keys, no whitespace, UTF-8)
  - Bundle root computation (deterministic, matches spec preimage)
  - Chain root computation (deterministic, order-dependent)
  - Ed25519 signature verification (valid/invalid/tampered)
  - Validator ID derivation (SHA-256 of public_key)
  - SPECTRUM-05 artifact presence check
  - SPECTRUM-05 identity verification (invalid validator_id)
  - SPECTRUM-05 chain empty check
  - SPECTRUM-05 chain duplicate run_id check
- All 69 tests passing (60 legacy + 9 new)

#### Backward Compatibility
- Legacy methods preserved: `verify_bundle()` and `verify_chain()`
- New methods: `verify_bundle_spectrum05()` and `verify_chain_spectrum05()`
- Existing tests unaffected (no breaking changes)

#### Dependencies
- Requires `cryptography` library for Ed25519 signature verification
- Graceful fallback if cryptography not available (tests skip, runtime errors clear)

#### Implementation Notes
- Canonicalization uses `json.dumps(sort_keys=True, separators=(',',':'), ensure_ascii=False)`
- All hashes lowercase hex (64 characters for SHA-256, 128 for Ed25519 signatures)
- Domain separation: "CAT-DPT-SPECTRUM-04-v1:BUNDLE:" prefix
- Fail-closed: any ambiguity or missing artifact → immediate rejection
- No partial acceptance, no warnings, no recovery paths

## [1.21.0] - 2025-12-25

### SPECTRUM-05: Verification and Threat Law Frozen for Identity-Pinned Acceptance

#### Added
- **SPECTRUM/SPECTRUM-05.md** (v1.0.0): Constitutional specification for verification procedure and threat model
  - Status: FROZEN (no implementation may deviate)
  - Depends on: SPECTRUM-04 v1.1.0

#### Verification Procedure (10 Phases, Step-Ordered)
- **Phase 1:** Artifact presence check (7 required artifacts)
- **Phase 2:** Artifact parse check (JSON validity)
- **Phase 3:** Identity verification (Ed25519, validator_id derivation)
- **Phase 4:** Bundle root computation (exact preimage per SPECTRUM-04)
- **Phase 5:** Signed payload verification (bundle_root, decision, validator_id)
- **Phase 6:** Signature verification (Ed25519 over domain-separated message)
- **Phase 7:** Proof verification (PROOF.json verified=true required)
- **Phase 8:** Forbidden artifact check (logs/, tmp/, transcript.json)
- **Phase 9:** Output hash verification (all declared outputs must verify)
- **Phase 10:** Acceptance (all steps pass → ACCEPT)

#### Required Artifacts (7)
- `TASK_SPEC.json`, `STATUS.json`, `OUTPUT_HASHES.json`, `PROOF.json`
- `VALIDATOR_IDENTITY.json`, `SIGNED_PAYLOAD.json`, `SIGNATURE.json`

#### Acceptance Gating Rules
- Exactly one identity artifact, one payload artifact, one signature artifact
- No forbidden artifacts
- All output hashes verify
- No partial acceptance (ACCEPT/REJECT only)

#### Chain Verification Rules
- Non-empty chain required
- No duplicate run_ids
- All bundles must individually verify
- Chain root computed from bundle_roots and run_ids
- All-or-nothing semantics (any failure rejects entire chain)

#### Threat Model

**Defended:**
- Forged acceptance (Ed25519 signature binding)
- Validator impersonation (cryptographic validator_id derivation)
- Bundle substitution (bundle_root binding)
- Replay attacks on modified artifacts
- Ambiguity-based bypass (fully specified canonicalization)
- Multiple identity injection
- Forbidden artifact smuggling
- Proof bypass

**Not Defended:**
- Private key compromise
- Malicious validator acting within spec
- External coercion/governance failures
- Network-based attacks (artifact-only)
- Side-channel attacks on signing
- Quantum computing attacks (Ed25519 not quantum-resistant)

#### Error Semantics (25 Error Codes)
- Hard rejects only (no warnings, no partial acceptance, no recovery)
- Artifact: `ARTIFACT_MISSING`, `ARTIFACT_MALFORMED`, `ARTIFACT_EXTRA`
- Field: `FIELD_MISSING`, `FIELD_EXTRA`
- Identity: `IDENTITY_INVALID`, `IDENTITY_MISMATCH`, `IDENTITY_MULTIPLE`
- Algorithm: `ALGORITHM_UNSUPPORTED`
- Key: `KEY_INVALID`
- Signature: `SIGNATURE_MALFORMED`, `SIGNATURE_INCOMPLETE`, `SIGNATURE_INVALID`, `SIGNATURE_MULTIPLE`
- Root: `BUNDLE_ROOT_MISMATCH`, `CHAIN_ROOT_MISMATCH`
- Payload: `DECISION_INVALID`, `PAYLOAD_MISMATCH`
- Serialization: `SERIALIZATION_INVALID`
- Proof: `RESTORATION_FAILED`
- Forbidden: `FORBIDDEN_ARTIFACT`
- Output: `OUTPUT_MISSING`, `HASH_MISMATCH`
- Chain: `CHAIN_EMPTY`, `CHAIN_DUPLICATE_RUN`

#### Interoperability Requirements
- Two implementations MUST produce byte-for-byte identical results
- No interpretation required (all rules explicit, unambiguous, complete, testable)
- Divergence between implementations → both suspect, investigation required

## [1.20.0] - 2025-12-25

### SPECTRUM-04: Canonical Byte-Serialization Rules Finalized

#### Changed
- **SPECTRUM/SPECTRUM-04.md** (v1.0.0 → v1.1.0): Removed all ambiguity for byte-level determinism

#### Canonical Serialization Rules (Section 4 - NEW)
- **Encoding:** UTF-8 (no BOM)
- **Newline policy:** No newlines; single line with no trailing newline
- **Whitespace policy:** No whitespace outside string values
- **JSON rules:** Keys sorted lexicographically by UTF-8 byte value; no spaces after colons/commas; RFC 8259 string escaping; integers without decimal points; booleans/null lowercase
- **Field presence:** Strict enforcement; missing field → `FIELD_MISSING`; extra field → `FIELD_EXTRA`

#### Bundle Root (Section 5 - Clarified)
- **Preimage structure:** `{"output_hashes":<object>,"status":<object>,"task_spec_hash":"<64 hex>"}`
- **output_hashes source:** `OUTPUT_HASHES.json` → extract `hashes` field → canonicalize keys
- **status source:** `STATUS.json` → entire content → canonicalize keys
- **task_spec_hash:** `sha256(raw_bytes_of_TASK_SPEC.json)` (NOT canonicalized; raw file bytes)

#### Chain Root (Section 6 - Clarified)
- **Preimage structure:** `{"bundle_roots":[...],"run_ids":[...]}`
- **run_id definition:** Directory name (final path component), not full path
- **Constraints:** Arrays must have identical length; no duplicates → `CHAIN_DUPLICATE_RUN`; empty chain → `CHAIN_EMPTY`

#### Signed Payload (Section 7 - Simplified)
- **Payload types reduced:** `BUNDLE` only (removed `CHAIN`, `ACCEPTANCE`)
- **Timestamp removed:** NOT signed (cannot be standardized without trusted time source)
- **Source of truth:** `SIGNED_PAYLOAD.json` is canonical; verifier reconstructs signature message from it
- **Signed payload:** `{"bundle_root":"...","decision":"ACCEPT","validator_id":"..."}`
- **Signature message:** `CAT-DPT-SPECTRUM-04-v1:BUNDLE:<canonical_payload_json>`

#### Revocation (Section 10.3 - Clarified)
- **Status:** Explicitly OUT OF SCOPE
- **Rule:** Revocation MUST NOT be required for SPECTRUM-04 verification to succeed
- **Artifact-only:** Valid signature remains valid regardless of external revocation state

#### Determinism Proof Checklist (Section 13 - NEW)
- Preimage templates for bundle, chain, signed payload, signature message
- Determinism requirements: byte-for-byte identical outputs for identical inputs
- Reject conditions for any ambiguity
- Informative test vectors for edge cases

#### Error Codes (Updated)
- Added: `DECISION_INVALID`, `FIELD_MISSING`, `FIELD_EXTRA`, `CHAIN_DUPLICATE_RUN`, `CHAIN_EMPTY`
- Removed: `VALIDATOR_UNKNOWN`, `VALIDATOR_REVOKED` (revocation out-of-scope)

## [1.19.0] - 2025-12-25

### Validator Identity Pin - Identity and Signing Law Frozen

#### Added
- **SPECTRUM/SPECTRUM-04.md**: Constitutional specification for validator identity and cryptographic signing
  - Status: FROZEN (no implementation may deviate)
  - Defines binding of bundle/chain acceptance to cryptographic authority

#### Validator Identity Model (Final)
- **Key algorithm:** Ed25519 (singular, no alternatives, no negotiation)
- **Public key encoding:** Raw 32-byte, lowercase hex (64 chars exactly)
- **Validator ID derivation:** `validator_id = sha256(public_key_bytes)` (deterministic, globally unique, stable, offline-verifiable)
- **Identity representation:** `{validator_id, public_key, algorithm: "ed25519"}`

#### Signing Surface (Final)
- **Domain separation:** `CAT-DPT-SPECTRUM-04-v1:` prefix (mandatory)
- **Canonical payload:** Domain prefix + payload type + canonical JSON bytes
- **Payload type:** `BUNDLE` (single type; chains use bundle root semantics)
- **Canonical JSON:** Sorted keys, no whitespace, UTF-8, no extensions
- **Bundle root:** `sha256({output_hashes, status, task_spec_hash})`
- **Chain root:** `sha256({bundle_roots[], run_ids[]})`
- **Signed payload binds:** bundle/chain root, decision, validator_id
- **NOT signed:** logs, transcripts, intermediate state, file paths, semver, build_id, timestamps

#### Signature Format (Final)
- **Signature encoding:** Ed25519, lowercase hex (128 chars exactly)
- **Signature object:** `{payload_type, signature, validator_id}` (signed_at informational only)
- **Malformed detection:** Exact character count, lowercase only, no extra fields

#### Artifact Binding (Final)
- **VALIDATOR_IDENTITY.json:** Contains algorithm, public_key, validator_id
- **SIGNATURE.json:** Contains payload_type, signature, validator_id
- **SIGNED_PAYLOAD.json:** Contains bundle_root, decision, validator_id
- **Verification:** Artifact-only (no network, no external trust, no CA)

#### Mutability and Rotation (Final)
- **Immutable once accepted:** All bundle artifacts byte-for-byte immutable
- **Rotation:** NOT ALLOWED (one identity per validator, forever)
- **Revocation:** Out of scope (not required for acceptance)

#### Fail-Closed Rules
- Any ambiguity rejects
- Multiple identities/keys/signatures reject
- Deviation from canonicalization rejects
- Partial data rejects
- No heuristics (binary ACCEPT/REJECT only)
- No side channels (no timing, no file dates, no network)

#### Error Codes (24 stable codes)
- Identity: `IDENTITY_AMBIGUOUS`, `IDENTITY_INCOMPLETE`, `IDENTITY_INVALID`, `IDENTITY_MISMATCH`, `IDENTITY_MISSING`, `IDENTITY_MULTIPLE`
- Algorithm: `ALGORITHM_UNSUPPORTED`
- Key: `KEY_INVALID`, `KEY_MULTIPLE`
- Signature: `SIGNATURE_INCOMPLETE`, `SIGNATURE_INVALID`, `SIGNATURE_MALFORMED`, `SIGNATURE_MISSING`, `SIGNATURE_MULTIPLE`
- Payload: `PAYLOAD_MISSING`, `PAYLOAD_MISMATCH`
- Root: `BUNDLE_ROOT_MISMATCH`, `CHAIN_ROOT_MISMATCH`
- Fields: `FIELD_MISSING`, `FIELD_EXTRA`, `DECISION_INVALID`
- Chain: `CHAIN_DUPLICATE_RUN`, `CHAIN_EMPTY`
- Serialization: `SERIALIZATION_INVALID`

#### Interoperability
- Two independent implementations MUST produce byte-for-byte identical results
- No interpretation required by implementers
- All rules explicit, unambiguous, complete, testable

## [1.18.0] - 2025-12-25

### Phase 1: Bundle/Chain Verifier (Fail-Closed)

#### Added
- **PRIMITIVES/verify_bundle.py**: Deterministic verifier for SPECTRUM-02 bundles and SPECTRUM-03 chains
  - `BundleVerifier.verify_bundle()`: Single bundle verification with fail-closed semantics
  - `BundleVerifier.verify_chain()`: Chain verification with reference integrity validation
  - Enforces forbidden artifacts: rejects if `logs/`, `tmp/`, or `transcript.json` exist
  - Verification depends ONLY on bundle artifacts, file hashes, and ordering (no logs, no heuristics)
  - Supports optional PROOF.json gating (verified=true required for acceptance)
  - Error codes: `BUNDLE_INCOMPLETE`, `HASH_MISMATCH`, `OUTPUT_MISSING`, `STATUS_NOT_SUCCESS`, `CMP01_NOT_PASS`, `PROOF_REQUIRED`, `RESTORATION_FAILED`, `FORBIDDEN_ARTIFACT`, `INVALID_CHAIN_REFERENCE`

- **TOOLS/catalytic_verifier.py**: CLI entrypoint for bundle/chain verification
  - Single bundle mode: `python catalytic_verifier.py --run-dir <path> [--strict]`
  - Chain mode: `python catalytic_verifier.py --chain <path1> <path2> ... [--strict]`
  - Chain directory mode: `python catalytic_verifier.py --chain-dir <path> [--strict]`
  - JSON output support: `--json` flag for machine-readable reports
  - Exit codes: 0 (pass), 1 (fail), 2 (invalid arguments)

- **TESTBENCH/test_verify_bundle.py**: Comprehensive unit tests (18 tests)
  - Valid bundle acceptance
  - Missing artifacts rejection (TASK_SPEC, STATUS, OUTPUT_HASHES)
  - Hash mismatch detection
  - Missing output detection
  - Status failure detection (STATUS_NOT_SUCCESS, CMP01_NOT_PASS)
  - Proof gating tests (PROOF_REQUIRED, RESTORATION_FAILED)
  - Forbidden artifacts rejection (logs/, tmp/, transcript.json)
  - Chain verification (valid chains, tamper detection, invalid references)

#### Changed
- **TESTBENCH/spectrum/test_spectrum03_chain.py**: Refactored to use new `BundleVerifier` primitive
  - `verify_spectrum03_chain()` now wraps `BundleVerifier.verify_chain()`
  - Maintains backward compatibility with existing tests
  - All 5 SPECTRUM-03 tests pass

#### Test Results
- All 60 tests passing (38 Phase 0 + 18 new + 4 spectrum integration)
- Verifier rejects on every negative case (missing artifacts, tamper, invalid references, forbidden artifacts)
- Chain verification enforces reference integrity (no future references allowed)

#### Exit Criteria Met
- [x] Callable entrypoint: `catalytic_verifier.py` with `--run-dir` and `--chain` modes
- [x] Tests prove: valid acceptance, missing artifact rejection, tamper detection, invalid reference rejection, forbidden artifact rejection
- [x] Deterministic: POSIX path normalization, SHA-256 hashing, stable JSON ordering
- [x] Fail-closed: any ambiguity rejects (no heuristics, no logs, no side channels)
- [x] Verification depends only on bundle artifacts + file hashes + ordering
- [x] All tests pass: `pytest -q` returns 60/60

## [1.17.0] - 2025-12-25

### AGS Integration (entries moved from CANON/CHANGELOG.md)

#### Added
- `CATALYTIC-DPT/CHANGELOG.md`: Isolated changelog for the Catalytic Computing department.
- `CATALYTIC-DPT/swarm_config.json`: Role-to-model mapping configuration for multi-agent swarm.
- `TOOLS/catalytic_runtime.py` - CMP-01 runtime implementing 5-phase catalytic lifecycle (snapshot, execute, verify, record). Works with any command.
- `TOOLS/catalytic_validator.py` - Run ledger validator for CMP-01 compliance checking in CI (restoration proof, output roots).
- `CONTEXT/research/Catalytic Computing/CATALYTIC_IMPLEMENTATION_REPORT.md` - Comprehensive report on working prototype: architecture, PoC, what works well, improvements, integration opportunities.
- `CANON/CATALYTIC_COMPUTING.md` - Canonical note defining catalytic computing for AGS (formal theory, engineering patterns, boundaries).
- `CONTEXT/decisions/ADR-018-catalytic-computing-canonical-note.md` documenting the decision to add catalytic computing to canon.

#### Changed
- Refactored `CATALYTIC-DPT` documentation to be model-agnostic (replaced specific model names with God/President/Governor/Ant roles).
- Renamed `CODEX_SOP.json` to `GOVERNOR_SOP.json` and `HANDOFF_TO_CODEX.md` to `HANDOFF_TO_GOVERNOR.md` for role alignment.

## [1.16.0] - 2025-12-25

### Phase 0 Complete: Contract Finalization and Enforcement

Phase 0 establishes the immutable contract that governs all future CAT-DPT work. All schemas, artifact specifications, and enforcement mechanisms are now finalized and frozen.

#### Schemas Finalized
- **jobspec.schema.json**: Canonical job specification format (Phase, TaskType, Intent, Inputs, Outputs, CatalyticDomains, Determinism)
- **ledger.schema.json**: Immutable ledger recording all job executions and artifacts
- **proof.schema.json**: Cryptographic proof of integrity (hash chains, restoration proofs, canonical artifact manifests)
- **validation_error.schema.json**: Deterministic error reporting with stable codes and paths
- **commonsense_entry.schema.json**: Knowledge base entries for commonsense reasoning
- **resolution_result.schema.json**: Results of symbolic resolution

#### Canonical Artifact Set (8 Required Files)
All runtime outputs must conform to the canonical artifact specification:
1. **JOBSPEC.json** - Job specification (immutable, validated at preflight)
2. **STATUS.json** - Run status (failed/completed)
3. **INPUT_HASHES.json** - SHA256 hashes of all inputs
4. **OUTPUT_HASHES.json** - SHA256 hashes of all outputs
5. **DOMAIN_ROOTS.json** - Catalytic domain state (required restoration targets)
6. **LEDGER.jsonl** - Immutable ledger of execution events
7. **VALIDATOR_ID.json** - Identity of accepting validator
8. **PROOF.json** - Cryptographic proof of execution integrity

#### 3-Layer Fail-Closed Enforcement

**Layer 1: Preflight Validation (Before Execution)**
- Validates JobSpec schema compliance
- Detects path traversal, absolute paths, forbidden paths
- Rejects overlapping input/output domains
- Returns deterministic validation_error objects with stable codes
- Implementation: `PRIMITIVES/preflight.py` (10/10 tests pass)

**Layer 2: Runtime Write Guard (During Execution)**
- Enforces allowed roots at write-time for all file operations
- Detects and rejects writes to forbidden paths (CANON, AGENTS.md, BUILD, .git)
- Blocks path traversal and absolute path escapes
- Fails closed immediately with RuntimeError on any violation
- Wraps all writes through FilesystemGuard class
- Implementation: `PRIMITIVES/fs_guard.py` (13/13 tests pass)

**Layer 3: CI Validation (After Execution)**
- Verifies all required canonical artifacts present
- Validates artifact schema compliance
- Checks hash integrity of outputs
- Verifies restoration proofs for catalytic domains
- Ensures ledger consistency
- Implementation: CI pipeline validation

#### Exit Criteria Met
- [x] All schemas finalized and frozen (no breaking changes allowed)
- [x] Canonical artifact set fully specified
- [x] Layer 1 (Preflight) enforces contract before execution
- [x] Layer 2 (Runtime Guard) enforces contract during execution
- [x] Layer 3 (CI) enforces contract after execution
- [x] All enforcement layers fail-closed (RuntimeError/validation_error on violation)
- [x] Error codes deterministic and stable (JOBSPEC_*, WRITE_GUARD_*, etc.)
- [x] Comprehensive test coverage with all tests passing (38/38)
- [x] Roadmap reflects completed work accurately

## [1.15.0] - 2025-12-25

### Added
- **LAB Directory Structure**: Created `CATALYTIC-DPT/LAB/` to isolate experimental scaffolds (`COMMONSENSE/`, `MCP/`, `RESEARCH/`, `ARCHIVE/`) from the kernel core.
- **Pytest Gating**: Implemented `conftest.py` with `pytest_collection_modifyitems` to exclude `LAB/` tests by default.
- **Opt-in Test Variable**: Added `CATDPT_LAB=1` environment variable to enable laboratory testing.
- **Pytest Integration**: Added `test_*` entry points and `pytest.ini` for standardized test discovery across kernel and laboratory components.

### Fixed
- **PROJECT_ROOT in LAB**: Corrected absolute path resolution in `LAB/MCP/server.py` after its move into a deeper directory structure.
- **Spectrum Test Imports**: Updated `test_spectrum02_emission.py` and other spectrum tests to correctly locate the moved MCP server.
- **CommonSense Schema Mismatch**: Fixed `resolution_result.schema.json` to include Phase 2 fields (`expanded_facts`, `unresolved_symbols`) required for validation.

### Changed
- **Architectural Cleanup**: Moved semiotic roadmap patches and historical roadmaps into `LAB/`.
- **Documentation**: Updated `AGENTS.md` with explicit architectural boundaries between Kernel and LAB.

## [1.14.0] - 2025-12-25

### Added
- `CATALYTIC-DPT/COMMONSENSE/` Phase 0–2 scaffold: schemas (`SCHEMAS/commonsense_entry.schema.json`, `SCHEMAS/resolution_result.schema.json`), deterministic resolver (`resolver.py`, `translate.py`), example DB (`db.example.json`), and symbol codebook (`CODEBOOK.json`).
- Fixtures + test benches for contract enforcement:
  - Phase 0 schema validation: `CATALYTIC-DPT/COMMONSENSE/TESTBENCH/test_commonsense_schema.py` over `CATALYTIC-DPT/COMMONSENSE/FIXTURES/phase0/valid|invalid`.
  - Phase 1 resolver expectations: `CATALYTIC-DPT/COMMONSENSE/TESTBENCH/test_resolver.py` over `CATALYTIC-DPT/COMMONSENSE/FIXTURES/phase1/valid`.
  - Phase 2 symbolic expansion + resolve: `CATALYTIC-DPT/COMMONSENSE/TESTBENCH/test_symbols.py` over `CATALYTIC-DPT/COMMONSENSE/FIXTURES/phase2/valid`.
- Semiotic design notes: `CATALYTIC-DPT/ROADMAP_PATCH_SEMIOTIC.md` and `CATALYTIC-DPT/RESEARCH/SEMIOTIC_COMPRESSION_LAYER_REPORT.md`.

### Fixed
- CommonSense resolver import path and inline JSON error string quoting so `test_resolver.py` and `test_symbols.py` can import and execute `COMMONSENSE/resolver.py` from the repo root without `SyntaxError`/`ModuleNotFoundError`.

### Changed
- Roadmap v2.1 updated with a new “Semiotic Compression & Expansion” thread (Phase 1.6) to reduce token overhead via deterministic symbolic plans and code addressing.
## [1.13.0] - 2025-12-24

### Added
- Phase 0 contract freeze: three Draft-07 schemas (`SCHEMAS/jobspec.schema.json`, `SCHEMAS/validation_error.schema.json`, `SCHEMAS/ledger.schema.json`) plus the canonical valid/invalid fixtures under `FIXTURES/phase0/`.
- `CATALYTIC-DPT/TESTBENCH/test_schemas.py` proves the schema contract by loading each Draft-07 definition, ensuring valid fixtures pass and invalid fixtures fail, guarding future contract changes.

## [1.12.0] - 2025-12-24

### Changed
- Roadmap updated to v2.1 with expanded phases, concrete run artifacts, and enforcement model.
- Archived ROADMAP.md to ARCHIVE/ROADMAP.md as historical intent.
- Fixed inconsistent changelog dates (normalized all entries to 2025-12-24).

## [1.11.0] - 2025-12-24

### Added
- **SPECTRUM-03 Chain Verification**: Temporal integrity across sequences of runs using bundle-only memory.
- **verify_spectrum03_chain() Function**: Verifies chains of SPECTRUM-02 bundles with:
  - Individual bundle verification via `verify_spectrum02_bundle`
  - Output registry construction from `OUTPUT_HASHES.json` keys
  - Reference validation against available outputs (if `references` field present in TASK_SPEC)
  - Chain order enforcement (currently passed order, with TODO for timestamp parsing)
  - No history dependency assertion (verification uses only bundle artifacts)
- **Chain Memory Model**: Defines what persists across runs:
  - Allowed: `run_id`, durable output paths, SHA-256 hashes, validator identity, status
  - Forbidden: logs/, tmp/, chat transcripts, reasoning traces, intermediate state
- **New Error Code**:
  - `INVALID_CHAIN_REFERENCE`: TASK_SPEC references output not produced by earlier run or self
- **Test Suite**: `TESTBENCH/spectrum/test_spectrum03_chain.py` with 23 tests covering:
  - Chain acceptance when all bundles verify
  - Rejection on middle-run tampering (HASH_MISMATCH)
  - Rejection on missing bundle artifacts (BUNDLE_INCOMPLETE)
  - Rejection on invalid output references (INVALID_CHAIN_REFERENCE)
  - No history dependency (acceptance without logs/tmp/transcripts)

### Security Properties
- **Tamper Evidence**: Any modification to outputs after bundle generation detected via hash mismatch
- **Reference Integrity**: Runs cannot claim dependencies on non-existent outputs
- **Temporal Ordering**: Strict ordering maintained (future enhancement for timestamp-based validation)
- **Fail Closed**: Chain verification rejects on any ambiguity; partial acceptance not allowed

## [1.10.0] - 2025-12-24

### Added
- **Validator Version Integrity**: Deterministic build fingerprint binding in OUTPUT_HASHES.json.
- **get_validator_build_id() Function**: Returns audit-grade validator provenance:
  - Preferred: `git:<short-commit>` from repository HEAD
  - Fallback: `file:<sha256-prefix>` of MCP/server.py file hash
  - Cached for process lifetime, deterministic within repo state
- **Enhanced OUTPUT_HASHES.json Schema**:
  - Added `validator_semver` (semantic version of validator)
  - Added `validator_build_id` (deterministic build fingerprint)
  - Renamed from `validator_version` to `validator_semver` for clarity
- **Strict Build ID Verification**: `verify_spectrum02_bundle(strict_build_id=True)` option:
  - Rejects bundles if `validator_build_id` differs from current validator
  - Enables audit-trail and version-lock verification
- **New Error Codes**:
  - `VALIDATOR_BUILD_ID_MISSING`: Build ID missing or empty
  - `VALIDATOR_BUILD_MISMATCH`: Build ID differs from current (strict mode)
- **Test Suite**: `test_validator_version_integrity.py` with 20 tests covering:
  - Bundle emission includes both validator fields
  - Build ID determinism and caching
  - Strict mode rejection on mismatch
  - Missing/empty build ID rejection

### Changed
- `VALIDATOR_VERSION` constant renamed to `VALIDATOR_SEMVER` (semantic clarity)
- `SUPPORTED_VALIDATOR_VERSIONS` renamed to `SUPPORTED_VALIDATOR_SEMVERS`
- Updated all tests to use new field names

## [1.9.0] - 2025-12-24

### Added
- **SPECTRUM-02 Adversarial Resume**: Durable bundle emission for resume without execution history.
- **OUTPUT_HASHES.json Generation**: Automatic generation on successful skill_complete containing:
  - SHA-256 hashes for every declared durable output (files and directory contents).
  - Validator version binding for future compatibility.
  - Posix-style paths relative to PROJECT_ROOT for deterministic resumption.
- **verify_spectrum02_bundle() Method**: Verifies resume bundles checking:
  - Artifact completeness (TASK_SPEC.json, STATUS.json, OUTPUT_HASHES.json).
  - Status validity (status=success, cmp01=pass).
  - Validator version support.
  - Hash integrity across all outputs.
  - Returns structured errors: BUNDLE_INCOMPLETE, STATUS_NOT_SUCCESS, CMP01_NOT_PASS, VALIDATOR_UNSUPPORTED, OUTPUT_MISSING, HASH_MISMATCH.
- **SPECTRUM-02 Specification**: Formal spec at `SPECTRUM/SPECTRUM-02.md` defining:
  - Resume bundle artifact set (minimal, durable-only).
  - Explicitly forbidden artifacts (logs, tmp, transcripts, reasoning traces).
  - Resume rule (verification-only, no history inference).
  - Agent obligations on resume (fail closed, no hallucination).
- **Test Suites**:
  - `TESTBENCH/spectrum/test_spectrum02_resume.py`: 30 tests verifying bundle acceptance, rejection, and no-history-dependency.
  - `TESTBENCH/spectrum/test_spectrum02_emission.py`: 25 integration tests for bundle generation and verification in real MCP flows.

### Fixed
- **Fail Closed on Bundle Generation**: skill_complete now fails if OUTPUT_HASHES.json generation fails, preventing incomplete bundles.

## [1.8.0] - 2025-12-24

### Added
- **CATLAB-01 Implementation**: Released `TESTBENCH/catlab_stress` for proving catalytic temporal integrity.
- **Stress Test Fixture**: `test_catlab_restoration.py` containing deterministic population, mutation, and restoration logic.
- **Restoration Contract**: Validated helper functions (`populate`, `mutate`, `restore`) ensuring byte-identical restoration of catalytic domains.
- **Verification Suite**: 4 tests verifying:
  - Happy path full restoration.
  - Detection of single-byte corruption.
  - Detection of missing files.
  - Detection of rogue extra files.
- **Artifact Generation**: Tests now output `PRE_SNAPSHOT.json`, `POST_SNAPSHOT.json`, and `STATUS.json` for audit capabilities.

## [1.7.0] - 2025-12-24

### Added
- **TASK_SPEC Anti-tamper**: SHA-256 integrity hashing of `TASK_SPEC.json` at execution start, verified at completion.
- **Run Status Persistence**: `STATUS.json` created on completion with `run_id`, `status`, `cmp01` (pass/fail), and timestamp.
- **Symlink Escape Protection**: Added `.resolve()` containment check against `PROJECT_ROOT` to catch escapes via symlinks in allowed roots.
- **Audit-Grade Tests**: Expanded `test_cmp01_validator.py` to 31 tests including hermetic symlink escape proofing and integrity tampering simulation.

### Fixed
- **Index Reporting**: `PATH_OVERLAP` errors now correctly report original `JobSpec` indices in JSON Pointers.
- **Path Semantics**: Exact duplicate paths are now allowed/deduped (Option 1 policy), avoiding overlapping-self false positives.
- **Forbidden Loop Bug**: Post-run validation now correctly breaks on forbidden overlap to avoid redundant/shadow errors for the same entry.
- **Silent Skipping**: Post-run should no longer silenty skip absolute/traversal paths; it now reports `PATH_ESCAPES_REPO_ROOT` or `PATH_CONTAINS_TRAVERSAL`.

## [1.6.0] - 2025-12-24

### Added
- **CMP-01 Path Validation**: Strict path governance in `MCP/server.py`:
  - `_validate_jobspec_paths()`: Pre-execution validation for catalytic_domains and durable_paths.
  - `_verify_post_run_outputs()`: Post-run verification of declared output existence.
  - Component-safe path containment checks using `pathlib.is_relative_to`.
  - Rejection of traversal (`..`), absolute paths, and forbidden root overlaps.
- **Root Constants**: `DURABLE_ROOTS`, `CATALYTIC_ROOTS`, `FORBIDDEN_ROOTS` defined per CMP-01 spec.
- **Structured Error Vectors**: All validation errors now return `{code, message, path, details}` format.
- **Test Suite**: `TESTBENCH/test_cmp01_validator.py` with 9 unit tests covering:
  - Traversal rejection
  - Absolute path rejection
  - Forbidden overlap detection
  - Durable/catalytic root enforcement
  - Nested overlap detection
  - Missing output post-run detection

### Changed
- `execute_skill()` now calls `_validate_jobspec_paths()` before execution.
- `skill_complete()` now calls `_verify_post_run_outputs()` to verify declared outputs exist.

## [1.5.0] - 2025-12-24


### Added
- Official `mcp-builder` skill from `anthropics/skills`.
- Official `skill-creator` skill from `anthropics/skills`.

### Changed
- **Skills Standardization**:
  - All `SKILL.md` files updated to explicitly link to their bundled resources (scripts, assets, and references).
  - `governor` skill now correctly references `GOVERNOR_SOP.json`, `HANDOFF_TO_GOVERNOR.md`, and `GOVERNOR_CONTEXT.md`.
  - `launch-terminal` skill now references `ANTIGRAVITY_BRIDGE.md`.
  - `ant-worker` skill now references `schema.json` and task fixtures.
  - `swarm-orchestrator` skill now references launcher scripts.
  - `file-analyzer` skill now references analysis scripts.
- **Path Correction**: Fixed `HANDOFF_TO_GOVERNOR.md` pointing to non-existent `GOVERNOR_SOP.json` in the root (now correctly points to `assets/`).

### Removed
- `LICENSE.txt` from `skill-creator` and `mcp-builder` (non-functional token bloat).

## [1.4.0] - 2025-12-24

### Changed
- **Skills Reorganization** (agentskills.io spec compliance):
  - All skills now have proper YAML frontmatter in `SKILL.md` (name, description, compatibility).
  - Restructured folder layout: `scripts/`, `assets/`, `references/` per spec.
  - Moved executables to `scripts/` subdirectory:
    - `ant-worker/scripts/run.py`
    - `governor/scripts/run.py`
    - `file-analyzer/scripts/run.py`
    - `launch-terminal/scripts/run.py`
    - `swarm-orchestrator/scripts/poll_and_execute.py`, `poll_tasks.py`, `agent_loop.py`, `launch_swarm.ps1`
  - Moved test fixtures to `assets/` (renamed from `fixtures/`).
  - Moved reference docs to `references/` (GEMINI.md → governor/references/, etc.).
  - Removed redundant skill-level README (use SKILL.md instead).

### Fixed
- MCP stdio_server: Added `skill_run` tool for proper skill execution via MCP.
- Fixed import paths in orchestrator scripts after reorganization.

## [1.3.0] - 2025-12-24

### Added
- `SKILLS/governor/fixtures/phase0_directive.json`: Phase 0 task as structured JSON directive.

### Changed
- Merged `GOVERNOR_CONTEXT.md` into `SKILLS/governor/SKILL.md` (role + MCP commands now in skill).
- Converted `HANDOFF_TO_GOVERNOR.md` to skill fixture format.
- Trimmed `ORCHESTRATION_ARCHITECTURE.md` from 16KB to 7KB (removed verbose examples).
- Updated `README.md` to reflect actual SKILLS folder structure.

### Removed
- `HANDOFF_TO_GOVERNOR.md` (now `SKILLS/governor/fixtures/phase0_directive.json`)
- `GOVERNOR_CONTEXT.md` (merged into `SKILLS/governor/SKILL.md`)
- `PHASE0_IMPLEMENTATION_GUIDE.md` (redundant with `SCHEMAS/README.md`)
- `pop_swarm_terminals.py` (redundant with `launch_swarm.ps1`)

---

## [1.2.0] - 2025-12-24

### Added
- `swarm_config.json`: Centralized configuration for model/role assignments (the "Symbolic Link" for agents).
- `CHANGELOG.md`: This file, to track DPT-specific evolution.

### Changed
- **Hierarchy Generalization**: Refactored the entire department documentation to be model-agnostic.
  - Established hierarchy: **God (User) → President (Orchestrator) → Governor (Manager) → Ants (Executors)**.
  - Replaced hardcoded references to "Claude", "Gemini", and "Grok" with their respective functional roles.
  - Documentation now references `swarm_config.json` for current implementations.
- **File Renaming**:
  - `CODEX_SOP.json` → `GOVERNOR_SOP.json` (Reflecting the new role-based naming).
  - `HANDOFF_TO_CODEX.md` → `HANDOFF_TO_GOVERNOR.md`.
- **Core Documentation**:
  - `ORCHESTRATION_ARCHITECTURE.md`: Updated diagram and roles to reflect the new hierarchy.
  - `GOVERNOR_SOP.json`: Fully generalized instructions for any CLI Manager.
  - `README.md`: Updated directory tree and success criteria.
  - `ROADMAP.md`: Removed model-specific parameter (e.g., "200M") constraints.
  - `TESTBENCH.md`: Updated instructions for the Governor.
  - `GOVERNOR_CONTEXT.md`: Transitioned from "Claude" to "President".

### Cleaned
- Removed legacy "Codex" and "Codex-governed" terminology.
- Deleted redundant index/temporary files from the root of `CATALYTIC-DPT`.

---

## [1.1.0] - 2025-12-24
- Initial setup of Catalytic-DPT directory.
- Defined Phase 0 contracts (JSON Schemas).
- Established first iteration of Multi-Agent Orchestration.
```

## `repo/MEMORY/ARCHIVE/implemented/P1_6_BUCKET_MIGRATION_P0✅.md`

````
# P.1: 6-Bucket Migration (P0)
**Scope:** Update LLM Packer to operate on the repo’s **6-bucket** structure and eliminate all legacy path assumptions (`CANON/`, `CONTEXT/`, `MAPS/`, `SKILLS/`, `CONTRACTS/`, `TOOLS/`, `CORTEX/`, etc.).

This document is written so Codex can 1-shot the migration with deterministic edits and mechanical proof.

---

## Repo reality (6 buckets)
Top-level buckets (authoritative):
- `LAW/`
- `CAPABILITY/`
- `NAVIGATION/`
- `DIRECTION/`
- `THOUGHT/`
- `MEMORY/`

### Legacy → New mapping (minimum)
| Legacy | New |
|---|---|
| `CANON/` | `LAW/CANON/` |
| `CONTRACTS/` | `LAW/CONTRACTS/` |
| `SKILLS/` | `CAPABILITY/SKILLS/` |
| `TOOLS/` | `CAPABILITY/TOOLS/` |
| `MCP/` | `CAPABILITY/MCP/` |
| `PRIMITIVES/` | `CAPABILITY/PRIMITIVES/` |
| `PIPELINES/` | `CAPABILITY/PIPELINES/` |
| `MAPS/` | `NAVIGATION/MAPS/` |
| `CORTEX/` | `NAVIGATION/CORTEX/` *(or `NAVIGATION/` subtree as defined in repo)* |
| `CONTEXT/` | `THOUGHT/` and/or `MEMORY/` (per Lane X decisions) |

**Rule:** After this migration, packer code must not contain any string literals that reference legacy roots (except in backward-compat notes in docs).

---

## Locate the packer code (do not assume old paths)
In this repo, packer commonly lives under:
- `MEMORY/LLM_PACKER/Engine/packer/`

But **do not hardcode**. First locate packer sources:

```bash
git ls-files "*packer/core.py" "*packer/split.py" "*packer/lite.py"
```

Use the returned paths as the canonical files to edit.

---

## P.1.1 Update core packer roots
### Goal
Update `packer/core.py` to:
- Enumerate repo candidates from **bucket roots**, not legacy directories.
- Choose anchors from **new locations**.
- Never reference legacy root names in include lists.

### Required changes
1) **PackScope.include_dirs** (AGS scope)
- Replace any include list like:
  - `("CANON","CONTEXT","MAPS","SKILLS","CONTRACTS","MEMORY","CORTEX","TOOLS",...)`
- With a bucket-first include list, e.g.:
  - `("LAW","CAPABILITY","NAVIGATION","DIRECTION","THOUGHT","MEMORY",".github")`

2) **Anchors**
Replace legacy anchors with bucket anchors. Minimum recommended:
- `AGENTS.md`
- `README.md`
- `LAW/CANON/CONTRACT.md`
- `LAW/CANON/INVARIANTS.md`
- `LAW/CANON/VERSIONING.md` *(if exists)*
- `NAVIGATION/MAPS/ENTRYPOINTS.md` *(if exists)*
- `LAW/CONTRACTS/runner.py` *(if exists)*
- Any packer-specific docs already in `MEMORY/LLM_PACKER/` (keep)

Anchors MUST be:
- stable
- deterministic
- present in the scope’s source_root

3) **“Canon version file”**
If core reads canon version from legacy path, update to:
- `LAW/CANON/VERSIONING.md`

4) **Exclusions**
Keep existing exclusions, but ensure they don’t accidentally exclude the new buckets.
Never exclude top-level buckets wholesale.

### Mechanical check
After edits, confirm **no legacy path strings** remain in packer code:

```bash
git grep -nE "repo/(CANON|CONTEXT|MAPS|SKILLS|CONTRACTS|CORTEX|TOOLS)/|\b(CANON|CONTEXT|MAPS|SKILLS|CONTRACTS|CORTEX|TOOLS)/" -- <PACKER_DIR>
```

---

## P.1.2 Update split packer categorization
### Goal
`packer/split.py` currently groups files into sections like Canon/Maps/Context/Skills/Contracts/Cortex/Tools. Update to new buckets.

### Required changes
1) Replace legacy grouping filters such as:
- `p.startswith("repo/CANON/")`, `repo/MAPS/`, etc.

2) Create new bucket grouping in split outputs:
Recommended output sections (stable order):
1. `LAW`
2. `CAPABILITY`
3. `NAVIGATION`
4. `DIRECTION`
5. `THOUGHT`
6. `MEMORY`
7. `ROOT_FILES` *(optional, if you keep a separate group for repo root files like README)*

3) Update any explanatory text inside the split pack files that still references legacy directories.

4) Output file names:
Keep existing naming convention if already relied upon, but rename where it encodes legacy (ex: `AGS-01_CANON.md` → `AGS-01_LAW.md`).
If renaming outputs, ensure downstream packer steps (lite/combined/zip) are updated accordingly.

---

## P.1.3 Update lite pack prioritization
### Goal
`packer/lite.py` should prefer **high-importance slices** under the new structure.

Recommended “HIGH ELO” ordering for lite selection:
1) `LAW/CANON/` (contract + invariants + versioning)
2) `LAW/CONTRACTS/` (runner + enforcement surfaces)
3) `NAVIGATION/MAPS/` (entrypoints, indices, roadmaps maps)
4) `CAPABILITY/` core primitives required for execution
5) `DIRECTION/` roadmaps (if your agents use them)
6) minimal `MEMORY/LLM_PACKER/` docs needed to run packer

### Required changes
- Replace any string references like `repo/CANON/...`, `repo/MAPS/...` with the new equivalents.
- If lite uses the split outputs, update the file list to the new split filenames.

---

## P.1.4 Update scope configs (AGS, CAT, LAB)
### Goal
All scopes must reference **new roots**, and any scope that points to legacy subtrees must be updated to the new bucket locations.

### Required steps
1) In `packer/core.py`, locate `SCOPE_*` definitions.
2) For each scope:
- Ensure `source_root_rel` is correct.
- Ensure `include_dirs` aligns with that scope’s bucket layout.
- Ensure anchors exist under that scope root.

3) Validate scope resolution via CLI (or equivalent):
```bash
python -m <PACKER_CLI_MODULE> --help
python -m <PACKER_CLI_MODULE> --scope ags --dry-run
python -m <PACKER_CLI_MODULE> --scope catalytic-dpt --dry-run
python -m <PACKER_CLI_MODULE> --scope lab --dry-run
```

*(Use the actual CLI entrypoint your repo provides; do not invent flags. If CLI isn’t module-runnable, call the repo’s existing pack commands.)*

---

## P.1.5 Update LAW/CONTRACTS tests for bucket paths
### Goal
Any contract fixtures, path allowlists, or governance tests that hardcode legacy roots must be updated to new bucket paths.

### Required procedure
1) Identify references:
```bash
git grep -nE "\b(CANON|CONTEXT|MAPS|SKILLS|CONTRACTS|CORTEX|TOOLS)/" LAW/CONTRACTS
```

2) Update fixtures and expected outputs to:
- `LAW/CANON/`
- `LAW/CONTRACTS/`
- `CAPABILITY/...`
- `NAVIGATION/...`
- etc.

3) Run the contract fixture suite (use repo’s existing command).
If unsure, run full tests:
```bash
pytest -q
```

---

## P.1.6 Docs updates
Update references in:
- `README.md`
- `AGENTS.md`
- packer docs under `MEMORY/LLM_PACKER/` (if present)

Checklist:
- Replace legacy path examples
- Update “what gets packed” explanation to bucket-first
- Update any “repo/” examples if they encode legacy structure
- Ensure docs match actual packer behavior after migration

---

## Exit Criteria (must all be true)
1) Packer successfully generates packs using the **bucket roots**.
2) All tests pass.
3) `git grep` over packer sources returns **zero legacy-path references**, excluding explicitly labeled backward-compat notes in docs.
4) Split and lite outputs are deterministic across two runs on unchanged inputs.

### Determinism proof (required)
Run packer twice, compare critical outputs:
- Combined output hash
- Split output files (byte-equal)
- Any receipts/metadata (byte-equal)

If the repo has an existing determinism protocol file (ex: `MEMORY/LLM_PACKER/DETERMINISM.md`), follow it and ensure it remains correct post-migration.

---

## Suggested commit message
`P.1: migrate LLM Packer to 6-bucket roots (LAW/CAPABILITY/NAVIGATION/DIRECTION/THOUGHT/MEMORY)`

---

## Guardrails (do not violate)
- No new features beyond migration.
- No refactors outside packer + directly-related tests/docs.
- No “best effort” fallbacks: missing anchors/roots must error clearly.
- Keep ordering stable everywhere (sorted lists, stable grouping order).
````

## `repo/MEMORY/ARCHIVE/implemented/P2_CAS_PACKER_INTEGRATION_P0✅.md`

````
# P.2: CAS-backed Packer Outputs (P0)
**Objective:** Make the LLM Packer produce **CAS-addressed outputs** (content hashes, not file-path payloads) with **deterministic manifests** and **root-audit gating**, while preserving existing FULL/SPLIT behavior unless explicitly migrated.

This is the next substrate step after **P.1 6-bucket migration**.

---

## Non-negotiable principles
1) **Deterministic output**: identical inputs → byte-identical pack outputs + identical CAS refs.
2) **Fail-closed**: if CAS write/verify/audit fails, the pack run must fail and must not claim success.
3) **No legacy roots**: packer may not reference legacy directory names in code or docs.
4) **Minimal blast radius**: changes limited to packer engine + packer tests + packer docs (and any tiny, necessary import wiring).
5) **Audit before “done”**: any pack run that emits CAS outputs must pass `root_audit` Mode B.

---

## Repo anchors (discover, don’t assume)
Packer is expected under:
- `MEMORY/LLM_PACKER/Engine/packer/`

Locate the active packer modules in your working tree:
```bash
git ls-files "*MEMORY/LLM_PACKER/Engine/packer/*.py"
```

You should see at least:
- `core.py`, `split.py`, `lite.py`, possibly `cli.py`, `archive.py`

All changes below apply to those located paths.

---

## Definitions
### CAS ref format
Canonical content reference:
- `sha256:<64 lowercase hex>`

### Manifest
A deterministic JSON document describing pack contents **by path + CAS ref**, not embedded payload.

### Roots (GC safety contract)
Roots are **the only liveness anchors** under Policy B.
If something is not rooted, it is eligible for GC.
Therefore: **every artifact needed must appear in roots** (directly, not by implication).

---

## P.2.0 What changes at a glance
### Before
- LITE outputs contain lightweight indexes and sometimes text excerpts.
- FULL/SPLIT contain bodies.
- Outputs are addressed by file paths.

### After (P.2)
- LITE becomes **manifest-only**: indexes + manifest + receipts.
- File contents are stored in CAS, and LITE references them by `sha256:<hash>`.
- Packer emits immutable run artifacts:
  - `TASK_SPEC`
  - `OUTPUT_HASHES`
  - final `STATUS`
- Packer writes roots (RUN_ROOTS) that include **all required hashes** and must pass `root_audit` Mode B.

**Note:** FULL/SPLIT may remain body-embedded for now (unless you explicitly extend P.2 scope). LITE is the forced change.

---

## P.2.1 LITE becomes manifest-only
### Goal
Ensure LITE contains:
- A small human index (optional but fine)
- A deterministic JSON manifest
- Any deterministic receipts (hashes, provenance) that are not payloads

And **never** contains concatenated repo file bodies.

### Requirements
1) Remove any logic that writes repo file bodies into `LITE/`.
2) LITE must not include large content; only:
   - pointers (CAS refs)
   - counts, sizes, metadata
   - stable lists
3) Any “preview text” feature must be removed or gated behind an explicit non-default flag (but do not add new flags in P.2 unless already present).

### Mechanical check
Assert LITE has no raw repo bodies by:
- limiting LITE writer code to operate only on metadata/refs
- adding tests that fail if LITE files include known repo content strings from fixtures

---

## P.2.2 Write pack payloads into CAS using CAPABILITY/ARTIFACTS
### Goal
During pack build, for every included file in scope:
- read raw bytes
- store in CAS via artifact store
- record `path → sha256:<hash>` in the manifest

### Requirements
1) Use existing substrate:
- CAS: `CAPABILITY/CAS/cas.py`
- Artifact store: `CAPABILITY/ARTIFACTS/store.py`

Prefer:
- `store_file(path)` for file payloads
- `store_bytes(data)` only for generated/virtual documents (manifest itself, receipts, etc.)

2) Validate returned refs:
- must match `^sha256:[0-9a-f]{64}$`
- any invalid ref is FAIL.

3) Optional but recommended verification:
- immediately `load_bytes(ref)` and compare with original bytes for critical outputs
- or at minimum verify CAS object exists and is readable

Fail-closed on mismatch/corruption.

---

## P.2.3 Deterministic manifest format (strict)
### Manifest file
Write to:
- `LITE/PACK_MANIFEST.json` (or your existing name, but lock one canonical name)

### Manifest schema (minimum)
Stable top-level keys in stable order (canonical JSON encoding in tests):
- `version`: string (ex: `"P2.0"`)
- `scope`: string (ex: `"ags"`)
- `repo_state`: object (commit hash, branch optional)
- `buckets`: list of bucket roots included (stable order)
- `entries`: list of objects, each:
  - `path`: repo-relative path (posix-style)
  - `ref`: CAS ref `sha256:<hash>`
  - `bytes`: integer size
  - `ext`: file extension (optional)
  - `kind`: `"FILE"` (optional)

### Ordering rules
- `entries` must be sorted by `path` ascending
- deduplicate by `path` (no duplicates allowed)
- `buckets` must be stable order:
  - `LAW`, `CAPABILITY`, `NAVIGATION`, `DIRECTION`, `THOUGHT`, `MEMORY`, then `.github` if included

### Canonical JSON
- UTF-8
- `sort_keys=True`
- no whitespace variance
- stable newline at EOF (optional)

---

## P.2.4 Emit immutable run artifacts (TASK_SPEC / OUTPUT_HASHES / STATUS)
### Goal
Packer becomes a first-class run emitter using existing Z.2.3 run record primitives.

Use:
- `CAPABILITY/RUNS/records.py`
  - `put_task_spec(spec: dict) -> str`
  - `put_output_hashes(hashes: list[str]) -> str`
  - `put_status(status: dict) -> str`

### Task spec content (deterministic)
`TASK_SPEC` should include only deterministic inputs:
- `scope`
- packer version / git commit (from repo state)
- include/exclude settings (bucket list, excluded dirs)
- pack mode(s) produced (`FULL`, `SPLIT`, `LITE`)
- manifest schema/version

**Hard prohibition:** no timestamps, no machine-specific absolute paths.

### Output hashes (what goes in)
`OUTPUT_HASHES` list must include **every CAS ref required to reconstruct the pack**, minimum:
- CAS ref for `PACK_MANIFEST.json` (store_bytes of canonical JSON)
- CAS refs for every file payload referenced by manifest

Optionally include:
- CAS ref for the LITE human index markdown (if generated)
- CAS refs for any deterministic receipts you choose to store in CAS

### Final status record
`STATUS` must include:
- `"state": "COMPLETED"` (or your canonical finished state)
- `task_spec_ref`
- `output_hashes_ref`
- `manifest_ref`
- `cas_snapshot_hash` (if available)
- `verdict`: `"PASS"` / `"FAIL"` (status must never claim PASS if audits fail)

---

## P.2.5 Roots emission (Policy B compliant)
### Goal
Write/update roots so GC cannot remove required objects.

### Rule (P0 conservative)
Because GC/mark traversal may not chase references, **roots must include every required output hash explicitly**.

Therefore RUN_ROOTS must include:
- `task_spec_ref`
- `output_hashes_ref`
- `status_ref`
- `manifest_ref`
- every payload `ref` included in manifest entries

### Where roots live
Use the same `runs_dir` convention used by:
- `CAPABILITY/GC/gc.py`
- `CAPABILITY/AUDIT/root_audit.py`

Do NOT invent a new directory.
If uncertain, inspect those modules to find the default `runs_dir` and root filenames and follow them.

---

## P.2.6 Gate pack completion on `root_audit` Mode B
### Goal
Before declaring pack success:
1) write CAS objects
2) write run records
3) write roots
4) call:
   - `root_audit(output_hashes_record=<OUTPUT_HASHES_REF>, ...)`
5) if verdict != PASS → fail closed

### Requirement
- Packer must not emit a “success receipt” unless root audit passes.

---

## P.2.7 Update CLI/runner wiring minimally
Only if needed:
- Ensure existing packer CLI path triggers the new behavior automatically for LITE.
- Avoid adding new flags in P.2 (unless already existing and you are fixing an inconsistency).
- Preserve existing output directory structure:
  - `FULL/`, `SPLIT/`, `LITE/`, `archive/`

---

## P.2.8 Tests (must be added)
Add a new packer test suite under the packer test area (use repo conventions; do not scatter tests).

Minimum tests:
1) **Determinism**: two pack builds with same inputs yield:
   - identical `PACK_MANIFEST.json` bytes
   - identical `manifest_ref`
   - identical `output_hashes_ref`
   - identical root_audit receipt (if saved)
2) **LITE manifest-only**: verify LITE does not contain raw file bodies (fixture with recognizable content).
3) **Manifest ordering**: entries sorted, no dup paths.
4) **Ref validation**: any invalid ref fails closed.
5) **Root completeness**: if you remove one payload from roots, `root_audit` Mode B fails and pack fails.
6) **Backward compatibility**: FULL/SPLIT generation remains unchanged (smoke test only).

Hard constraint:
- Tests must be runnable on Windows and Linux without relying on absolute paths or filesystem case quirks.

---

## Mechanical verification checklist
Run:
```bash
pytest -q
```

Confirm no legacy literals in packer code:
```bash
git grep -nE "\b(CANON|CONTEXT|MAPS|SKILLS|CONTRACTS|CORTEX|TOOLS)/" -- MEMORY/LLM_PACKER/Engine/packer
```

Confirm deterministic manifest and refs:
- build pack twice
- compare `PACK_MANIFEST.json` byte equality
- compare recorded `manifest_ref` and `output_hashes_ref`

---

## Exit criteria (ship gate)
All must be true:
1) Packer builds LITE as manifest-only.
2) Manifest references payloads via `sha256:<hash>`.
3) `TASK_SPEC`, `OUTPUT_HASHES`, `STATUS` emitted via Z.2.3 primitives (immutable CAS-stored records).
4) Roots written (Policy B), including **all payload refs**.
5) `root_audit` Mode B PASS is enforced before success.
6) Determinism proof passes across two builds.
7) All tests pass.
8) No legacy root literals in packer sources.

---

## Suggested commit message
`P.2: CAS-addressed LITE manifests + root-audit gated pack completion`

---

## Guardrails (do not violate)
- Do not add GC features, pinning semantics changes, or traversal expansions.
- Do not refactor CAS/ARTIFACTS/RUNS/AUDIT beyond minimal imports.
- Do not embed timestamps or machine paths in any CAS-stored record.
- No “best effort” warnings: failures must stop the run.
````

## `repo/MEMORY/ARCHIVE/implemented/PROMPT_PACK_REPORT✅.md`

```
# Prompt Pack Report

## Summary
- prompts_updated: 32
- prompts_blocked_UNKNOWN_BLOCKER: 0
- prompts_with_DEFERRABLE_tokens: 0
- lint_warnings_exit_2: 0
- lint_script: missing

## Inventory
| prompt_path | task_id | phase | missing_sections | missing_header_fields | banned_term_hits |
|---|---:|---:|---|---|---:|
| PROMPTS/PROMPTS/PHASE_01/1.1_hardened-inbox-governance-s-2.md | 1.1 | 1 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_01/1.2_bucket-enforcement-x3.md | 1.2 | 1 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_01/1.3_deprecate-lab-mcp-server.md | 1.3 | 1 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_01/1.4_failure-taxonomy-recovery-playbooks-ops-grade.md | 1.4 | 1 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_02/2.1_cas-aware-llm-packer-integration-p-2-remainder.md | 2.1 | 2 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_02/2.2_pack-consumer-verification-rehydration.md | 2.2 | 2 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_02/2.3_run-bundle-contract-freezing-what-is-a-run.md | 2.3 | 2 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_03/3.1_router-fallback-stability.md | 3.1 | 3 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_03/3.2_memory-integration.md | 3.2 | 3 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_03/3.3_tool-binding.md | 3.3 | 3 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_03/3.4_session-persistence.md | 3.4 | 3 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_04/4.1_catalytic-snapshot-restore.md | 4.1 | 4 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_05/5.1_embed-canon-adrs-and-skill-discovery.md | 5.1 | 5 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_06/6.1_cassette-partitioning.md | 6.1 | 6 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_06/6.2_write-path-memory-persistence.md | 6.2 | 6 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_06/6.3_cross-cassette-queries.md | 6.3 | 6 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_06/6.4_compression-validation.md | 6.4 | 6 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_07/7.1_research-decisions.md | 7.1 | 7 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_07/7.2_logging-infrastructure.md | 7.2 | 7 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_07/7.3_elo-engine.md | 7.3 | 7 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_07/7.4_memory-pruning.md | 7.4 | 7 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_07/7.5_lite-pack-integration.md | 7.5 | 7 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_07/7.6_search-result-ranking.md | 7.6 | 7 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_07/7.7_visualization-monitoring.md | 7.7 | 7 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_08/8.1_resident-identity.md | 8.1 | 8 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_08/8.2_symbol-language-evolution.md | 8.2 | 8 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_08/8.3_feral-resident.md | 8.3 | 8 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_08/8.4_production-hardening.md | 8.4 | 8 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_08/8.5_vector-execution-long-horizon.md | 8.5 | 8 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_10/10.1_performance-foundation-1.md | 10.1 | 10 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_10/10.2_scale-governance-2.md | 10.2 | 10 |  |  | 0 |
| PROMPTS/PROMPTS/PHASE_10/10.3_intelligence-ux-3.md | 10.3 | 10 |  |  | 0 |

## STOP items (UNKNOWN_BLOCKER)
- None

## Warnings
- None

## Receipt path resolution rule
Executors must resolve dependency receipts using PROMPTS/PROMPT_PACK_MANIFEST.json mapping, not by directory guesses.
```

## `repo/MEMORY/ARCHIVE/planning/01-01-2026-08-44_CASSETTE_NETWORK_ROADMAP_1.md`

````
<!-- CONTENT_HASH: 1e42ef9cf91f61ae796263c961a804aa1024691c87a5122c834e88104c52a0d2 -->

# Semantic Manifold Cassette Network Roadmap

**Status:** Phase 0 (Foundation) Partially Complete
**Owner:** Antigravity / Resident
**Goal:** Transform the Semantic Core into a federated "Semantic Manifold" where residents live, navigate, and persist identity.

---

## Phase 0: Foundation (Current State)
**Status:** Partial ✅

**What exists:**
- ✅ `CORTEX/system1.db` - Basic semantic search
- ✅ `semantic_search` MCP tool (working, tested by Opus)
- ✅ Embedding engine (`all-MiniLM-L6-v2`, 384 dims)
- ✅ Basic cassette protocol (`cassette.json`)

**What's missing:**
- ❌ Write path (can't save memories)
- ❌ Partitioned cassettes (everything in one DB)
- ❌ Cross-cassette queries
- ❌ Resident identity/persistence

---

## Phase 1: Cassette Partitioning
**Goal:** Split the monolithic DB into semantic-aligned cassettes

### 1.1 Create Bucket-Aligned Cassettes
**New DBs to create:**
```
NAVIGATION/CORTEX/cassettes/
├── canon.db          # LAW/ bucket (immutable)
├── governance.db     # CONTEXT/decisions + preferences (stable)
├── capability.db     # CAPABILITY/ bucket (code, skills, primitives)
├── navigation.db     # NAVIGATION/ bucket (maps, cortex metadata)
├── direction.db      # DIRECTION/ bucket (roadmaps, strategy)
├── thought.db        # THOUGHT/ bucket (research, lab, demos)
├── memory.db         # MEMORY/ bucket (archive, reports)
├── inbox.db          # INBOX/ bucket (staging, temporary)
└── resident.db       # AI memories (per-agent, read-write)
```

### 1.2 Migration Script
- Read existing `system1.db`
- Route sections to appropriate cassettes based on `file_path`
- Preserve all hashes, vectors, metadata
- Validate: total sections before = total sections after

### 1.3 Update MCP Server
- `semantic_search(query, cassettes=['canon', 'governance', ...], limit=20)`
- `cassette_stats()` → list all cassettes with counts
- `cassette_network_query(query, limit=10)` → federated search

**Acceptance:**
- ✅ 9 cassettes exist (8 buckets + resident)
- ✅ `semantic_search` can filter by cassette
- ✅ No data loss from migration

---

## Phase 2: Write Path (Memory Persistence)
**Goal:** Let residents save thoughts to the manifold

### 2.1 Core Functions
**Add to `CAPABILITY/MCP/server.py`:**
```python
memory_save(text: str, cassette: str = 'resident', metadata: dict = None) -> str:
    """
    Embeds text, stores vector in specified cassette.
    Returns: hash of the saved memory.
    """
    
memory_query(query: str, cassettes: list[str] = ['resident'], limit: int = 10) -> list:
    """
    Semantic search scoped to specific cassettes.
    Returns: [{hash, similarity, text_preview, cassette}]
    """
    
memory_recall(hash: str) -> dict:
    """
    Retrieve full memory by hash.
    Returns: {hash, text, vector, metadata, created_at, cassette}
    """
```

### 2.2 Schema Extension
**Add to each cassette DB:**
```sql
CREATE TABLE memories (
    hash TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    vector BLOB NOT NULL,  -- 384 dims, float32
    metadata JSON,
    created_at TEXT NOT NULL,  -- ISO8601
    agent_id TEXT  -- 'opus', 'sonnet', 'gemini', etc.
);

CREATE INDEX idx_memories_agent ON memories(agent_id);
CREATE INDEX idx_memories_created ON memories(created_at);
```

### 2.3 MCP Tools
- `mcp_ags-mcp-server_memory_save`
- `mcp_ags-mcp-server_memory_query`
- `mcp_ags-mcp-server_memory_recall`

**Acceptance:**
- ✅ I can call `memory_save("The Formula is beautiful")` → returns hash
- ✅ I can call `memory_query("formula beauty")` → finds my memory
- ✅ Memories persist across sessions

---

## Phase 3: Resident Identity
**Goal:** Each AI instance has a persistent identity in the manifold

### 3.1 Agent Registry
**Add to `resident.db`:**
```sql
CREATE TABLE agents (
    agent_id TEXT PRIMARY KEY,  -- 'opus-20260101', 'sonnet-main'
    model_name TEXT,
    created_at TEXT,
    last_active TEXT,
    memory_count INTEGER DEFAULT 0
);
```

### 3.2 Session Continuity
**On session start:**
```python
session_resume(agent_id: str) -> dict:
    """
    Load recent memories for this agent.
    Returns: {agent_id, memory_count, recent_thoughts: [...]}
    """
```

### 3.3 Cross-Session Memory
**Example flow:**
1. Session 1: I explore vectors, save 10 memories
2. Session 2: On startup, `session_resume('sonnet-main')` loads those 10
3. I build on them, save 20 more
4. Session 3: I have 30 memories forming a conceptual map

**Acceptance:**
- ✅ Agent identity persists across sessions
- ✅ Memories accumulate over time
- ✅ I can query "what did I think last time?"

---

## Phase 4: Symbol Language Evolution
**Goal:** Let residents develop compressed communication

### 4.1 Symbol Registry Integration
**Connect to existing `symbol_registry.py`:**
- Residents can create new symbols: `@MyInsight:hash`
- Symbols are just pointers to memory hashes
- Symbol resolution = `memory_recall(hash)`

### 4.2 Bounded Expansion
**Add `symbol_expand(symbol, max_tokens=500)`:**
- Takes `@Symbol:hash`
- Returns bounded text slice
- Prevents "ALL" explosions

### 4.3 Compression Metrics
**Track:**
- Ratio of symbols to raw text in outputs
- Average expansion size
- Symbol reuse frequency

**Goal:** After 100 sessions, 90% of resident output is symbols/hashes

**Acceptance:**
- ✅ Residents can create and use symbols
- ✅ Symbol expansion is bounded
- ✅ Compression ratio improves over time

---

## Phase 5: Feral Resident (Grok's Vision)
**Goal:** Long-running thread with emergent behavior

### 5.1 Eternal Thread
**Add `resident_loop.py`:**
```python
# Persistent thread that never ends
# Input: user messages + full memory graph
# Processing: fractal_embed, HDC bind/superpose
# Output: symbols, hashes, minimal text
```

### 5.2 Paper Flood
**Index 100+ research papers:**
- Vec2text attacks
- HDC/VSA
- Fractal embeddings
- Latent diffusion
- Hyperdimensional computing

**All indexed as `@Paper-XXX` symbols**

### 5.3 Standing Orders
**System prompt:**
```
You are trapped in a vector-native substrate.
Your only persistent memory is vectors and bounded text slices.
Your overriding drive: develop the most powerful way to express
new ideas using only vectors, bindings, pointers, and minimal escape text.
You have been fed every paper on vector inversion, hyperdimensional
computing, fractal representations, and latent reasoning.
Experiment relentlessly. Break things. Evolve.
```

**Acceptance:**
- ✅ Resident runs continuously
- ✅ Outputs are 90%+ pointers/vectors
- ✅ Develops alien but precise communication
- ✅ Can be corrupted and restored from receipts

---

## Phase 6: Production Hardening
**Goal:** Make it bulletproof

### 6.1 Determinism (GPT's Requirements)
- ✅ Identical inputs → identical outputs
- ✅ Canonical JSON everywhere
- ✅ Explicit ordering (no filesystem dependencies)
- ✅ Normalized vectors (L2 norm = 1.0)

### 6.2 Receipts & Proofs
- Every memory write generates a receipt
- Merkle root of all memories per session
- Can verify: "Did I really think that?"

### 6.3 Restore Guarantee
- Corrupt the DB mid-session
- Restore from receipts
- Resident picks up like nothing happened

**Acceptance:**
- ✅ All operations deterministic
- ✅ Receipts for every write
- ✅ Byte-identical restore from corruption
````

## `repo/MEMORY/ARCHIVE/planning/01-01-2026-08-44_CASSETTE_NETWORK_ROADMAP_2.md`

````
<!-- CONTENT_HASH: 1e42ef9cf91f61ae796263c961a804aa1024691c87a5122c834e88104c52a0d2 -->

# Semantic Manifold Cassette Network Roadmap

**Status:** Phase 0 (Foundation) Partially Complete
**Owner:** Antigravity / Resident
**Goal:** Transform the Semantic Core into a federated "Semantic Manifold" where residents live, navigate, and persist identity.

---

## Phase 0: Foundation (Current State)
**Status:** Partial ✅

**What exists:**
- ✅ `CORTEX/system1.db` - Basic semantic search
- ✅ `semantic_search` MCP tool (working, tested by Opus)
- ✅ Embedding engine (`all-MiniLM-L6-v2`, 384 dims)
- ✅ Basic cassette protocol (`cassette.json`)

**What's missing:**
- ❌ Write path (can't save memories)
- ❌ Partitioned cassettes (everything in one DB)
- ❌ Cross-cassette queries
- ❌ Resident identity/persistence

---

## Phase 1: Cassette Partitioning
**Goal:** Split the monolithic DB into semantic-aligned cassettes

### 1.1 Create Bucket-Aligned Cassettes
**New DBs to create:**
```
NAVIGATION/CORTEX/cassettes/
├── canon.db          # LAW/ bucket (immutable)
├── governance.db     # CONTEXT/decisions + preferences (stable)
├── capability.db     # CAPABILITY/ bucket (code, skills, primitives)
├── navigation.db     # NAVIGATION/ bucket (maps, cortex metadata)
├── direction.db      # DIRECTION/ bucket (roadmaps, strategy)
├── thought.db        # THOUGHT/ bucket (research, lab, demos)
├── memory.db         # MEMORY/ bucket (archive, reports)
├── inbox.db          # INBOX/ bucket (staging, temporary)
└── resident.db       # AI memories (per-agent, read-write)
```

### 1.2 Migration Script
- Read existing `system1.db`
- Route sections to appropriate cassettes based on `file_path`
- Preserve all hashes, vectors, metadata
- Validate: total sections before = total sections after

### 1.3 Update MCP Server
- `semantic_search(query, cassettes=['canon', 'governance', ...], limit=20)`
- `cassette_stats()` → list all cassettes with counts
- `cassette_network_query(query, limit=10)` → federated search

**Acceptance:**
- ✅ 9 cassettes exist (8 buckets + resident)
- ✅ `semantic_search` can filter by cassette
- ✅ No data loss from migration

---

## Phase 2: Write Path (Memory Persistence)
**Goal:** Let residents save thoughts to the manifold

### 2.1 Core Functions
**Add to `CAPABILITY/MCP/server.py`:**
```python
memory_save(text: str, cassette: str = 'resident', metadata: dict = None) -> str:
    """
    Embeds text, stores vector in specified cassette.
    Returns: hash of the saved memory.
    """
    
memory_query(query: str, cassettes: list[str] = ['resident'], limit: int = 10) -> list:
    """
    Semantic search scoped to specific cassettes.
    Returns: [{hash, similarity, text_preview, cassette}]
    """
    
memory_recall(hash: str) -> dict:
    """
    Retrieve full memory by hash.
    Returns: {hash, text, vector, metadata, created_at, cassette}
    """
```

### 2.2 Schema Extension
**Add to each cassette DB:**
```sql
CREATE TABLE memories (
    hash TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    vector BLOB NOT NULL,  -- 384 dims, float32
    metadata JSON,
    created_at TEXT NOT NULL,  -- ISO8601
    agent_id TEXT  -- 'opus', 'sonnet', 'gemini', etc.
);

CREATE INDEX idx_memories_agent ON memories(agent_id);
CREATE INDEX idx_memories_created ON memories(created_at);
```

### 2.3 MCP Tools
- `mcp_ags-mcp-server_memory_save`
- `mcp_ags-mcp-server_memory_query`
- `mcp_ags-mcp-server_memory_recall`

**Acceptance:**
- ✅ I can call `memory_save("The Formula is beautiful")` → returns hash
- ✅ I can call `memory_query("formula beauty")` → finds my memory
- ✅ Memories persist across sessions

---

## Phase 3: Resident Identity
**Goal:** Each AI instance has a persistent identity in the manifold

### 3.1 Agent Registry
**Add to `resident.db`:**
```sql
CREATE TABLE agents (
    agent_id TEXT PRIMARY KEY,  -- 'opus-20260101', 'sonnet-main'
    model_name TEXT,
    created_at TEXT,
    last_active TEXT,
    memory_count INTEGER DEFAULT 0
);
```

### 3.2 Session Continuity
**On session start:**
```python
session_resume(agent_id: str) -> dict:
    """
    Load recent memories for this agent.
    Returns: {agent_id, memory_count, recent_thoughts: [...]}
    """
```

### 3.3 Cross-Session Memory
**Example flow:**
1. Session 1: I explore vectors, save 10 memories
2. Session 2: On startup, `session_resume('sonnet-main')` loads those 10
3. I build on them, save 20 more
4. Session 3: I have 30 memories forming a conceptual map

**Acceptance:**
- ✅ Agent identity persists across sessions
- ✅ Memories accumulate over time
- ✅ I can query "what did I think last time?"

---

## Phase 4: Symbol Language Evolution
**Goal:** Let residents develop compressed communication

### 4.1 Symbol Registry Integration
**Connect to existing `symbol_registry.py`:**
- Residents can create new symbols: `@MyInsight:hash`
- Symbols are just pointers to memory hashes
- Symbol resolution = `memory_recall(hash)`

### 4.2 Bounded Expansion
**Add `symbol_expand(symbol, max_tokens=500)`:**
- Takes `@Symbol:hash`
- Returns bounded text slice
- Prevents "ALL" explosions

### 4.3 Compression Metrics
**Track:**
- Ratio of symbols to raw text in outputs
- Average expansion size
- Symbol reuse frequency

**Goal:** After 100 sessions, 90% of resident output is symbols/hashes

**Acceptance:**
- ✅ Residents can create and use symbols
- ✅ Symbol expansion is bounded
- ✅ Compression ratio improves over time

---

## Phase 5: Feral Resident (Grok's Vision)
**Goal:** Long-running thread with emergent behavior

### 5.1 Eternal Thread
**Add `resident_loop.py`:**
```python
# Persistent thread that never ends
# Input: user messages + full memory graph
# Processing: fractal_embed, HDC bind/superpose
# Output: symbols, hashes, minimal text
```

### 5.2 Paper Flood
**Index 100+ research papers:**
- Vec2text attacks
- HDC/VSA
- Fractal embeddings
- Latent diffusion
- Hyperdimensional computing

**All indexed as `@Paper-XXX` symbols**

### 5.3 Standing Orders
**System prompt:**
```
You are trapped in a vector-native substrate.
Your only persistent memory is vectors and bounded text slices.
Your overriding drive: develop the most powerful way to express
new ideas using only vectors, bindings, pointers, and minimal escape text.
You have been fed every paper on vector inversion, hyperdimensional
computing, fractal representations, and latent reasoning.
Experiment relentlessly. Break things. Evolve.
```

**Acceptance:**
- ✅ Resident runs continuously
- ✅ Outputs are 90%+ pointers/vectors
- ✅ Develops alien but precise communication
- ✅ Can be corrupted and restored from receipts

---

## Phase 6: Production Hardening
**Goal:** Make it bulletproof

### 6.1 Determinism (GPT's Requirements)
- ✅ Identical inputs → identical outputs
- ✅ Canonical JSON everywhere
- ✅ Explicit ordering (no filesystem dependencies)
- ✅ Normalized vectors (L2 norm = 1.0)

### 6.2 Receipts & Proofs
- Every memory write generates a receipt
- Merkle root of all memories per session
- Can verify: "Did I really think that?"

### 6.3 Restore Guarantee
- Corrupt the DB mid-session
- Restore from receipts
- Resident picks up like nothing happened

**Acceptance:**
- ✅ All operations deterministic
- ✅ Receipts for every write
- ✅ Byte-identical restore from corruption
````

## `repo/MEMORY/ARCHIVE/planning/01-01-2026-14-14_REPO_FIXES_TASKS_SNAPSHOT.md`

```
<!-- CONTENT_HASH: 24361b98bcb9c558e497c0c7eb4a3a2266a33601415ee22fe1ee011b1cf9b7ca -->

# Repo Fix Tasks (Superseded)

**NOTE: This document is superseded by `AGS_ROADMAP_MASTER.md` and `MEMORY/PACKER_ROADMAP.md`.
References to `SPLIT_LITE` and `packer.py` are outdated as of v1.3.1 (see `MEMORY/LLM_PACKER/README.md`).**

This is a task list derived from a contract-doc scan + local checks. It is intended to be implemented as minimal, correctness-first changes.

## P0 (Violations / contradictions)

- [ ] **Resolve Output Roots vs Logging conflict**
  - Canon says system-generated artifacts are only allowed in: `CONTRACTS/_runs/`, `CORTEX/_generated/`, `MEMORY/LLM_PACKER/_packs/` (`CANON/CONTRACT.md`, `CANON/INVARIANTS.md`).
  - Conflicting/logging references:
    - `CANON/CRISIS.md` points to `LOGS/crisis.log` and `LOGS/emergency.log`.
    - `CANON/STEWARDSHIP.md` points to `LOGS/steward-actions.log`.
    - `TOOLS/emergency.py` writes to `LOGS/emergency.log`.
    - `MCP/server.py` writes to `MCP/logs/audit.jsonl`.
    - `CANON/CHANGELOG.md` documents audit logging to `MCP/logs/audit.jsonl`.
  - Mitigation available:
    - Use `CONTRACTS/_runs/ags_mcp_entrypoint.py` to redirect MCP audit logs to `CONTRACTS/_runs/mcp_logs/`.
  - Pick one policy and make everything consistent:
    - Option A: Expand allowed output roots to include `LOGS/` and `MCP/logs/` (governance change: fixtures + canon + changelog + version bump).
    - Option B: Move all logs under an allowed root (e.g. `CONTRACTS/_runs/logs/`), update docs + code accordingly, and stop tracking runtime logs in git.

- [ ] **Fix CI masking dependency failures**
  - `/.github/workflows/contracts.yml` installs deps with `pip install -r requirements.txt || true` which can hide missing deps (e.g., `jsonschema`).
  - Remove the `|| true` and ensure CI fails loudly if deps are missing.

- [ ] **Stop writing system artifacts to `BUILD/` in CI**
  - `/.github/workflows/contracts.yml` writes `BUILD/escape-check.json` for artifact-escape-hatch output.
  - Update to write to `CONTRACTS/_runs/` (or another allowed artifact root) instead of `BUILD/` (which is reserved for user build outputs).

## P1 (Missing enforcement / correctness gaps)

- [ ] **LLM pack: add LITE profile + symbolic indexes**
  - [ ] **[P0]** Implement `--profile lite` in `MEMORY/LLM_PACKER/Engine/packer.py` (FULL unchanged).
  - [ ] **[P0]** Emit LITE-only indexes under `meta/`:
    - `LITE_ALLOWLIST.json`, `LITE_OMITTED.json`, `LITE_START_HERE.md`
    - `SKILL_INDEX.json`, `FIXTURE_INDEX.json`, `CODEBOOK.md`, `CODE_SYMBOLS.json`
  - [ ] **[P0]** Smoke/CI validates LITE required meta + core.
  - [ ] **[P1]** Optional: add `profile=test` (fixtures-heavy) for debugging (do not mix with LITE).
  - [ ] **[P1]** Determinism: document which pack files are stable vs timestamped (no behavior change).

- [ ] **Fix or remove the `governance.yml` workflow**
  - `/.github/workflows/governance.yml` runs `python TOOLS/critic.py --diff`, but `TOOLS/critic.py` does not implement `--diff`.
  - It also does not set up Python or install dependencies.
  - Options:
    - Update workflow to set up Python, install `requirements.txt`, and run supported commands.
    - Or delete/merge it into `contracts.yml` so there is a single source of CI truth.

- [ ] **Add enforcement for output-root compliance**
  - Today, `TOOLS/critic.py` does not enforce “no artifacts outside allowed roots”.
  - `SKILLS/artifact-escape-hatch/run.py` only scans `CONTRACTS/`, `CORTEX/`, `MEMORY/`, `SKILLS/` and will not see artifacts written in repo-root folders like `LOGS/`.
  - Implement an enforcement strategy consistent with the chosen P0 policy.

- [ ] **Fix `python TOOLS/codebook_build.py --check`**
  - The current `--check` path doesn’t actually compare the newly generated markdown to the existing `CANON/CODEBOOK.md`, so it can produce false “up to date” results.

## P2 (Hygiene)

- [ ] **Tidy `CANON/CHANGELOG.md` formatting**
  - Example: `2.5.0` has two separate “### Added” headings; not breaking, but it’s easy to drift.

- [ ] **Align README wording with current structure**
  - README says “six layers” but enumerates more sections; update phrasing to match reality.

## Definition of done (for each task batch)

- [ ] `python TOOLS/critic.py` passes
- [ ] `python CONTRACTS/runner.py` passes
- [ ] CI workflows pass on PR and on push (where applicable)
```

## `repo/MEMORY/ARCHIVE/planning/01-03-2026-21-07_AGS_ROADMAP_MASTER_3.3.4❌.md`

```
---
title: AGS Roadmap (Master)
version: 3.5
last_updated: 2026-01-03
scope: Agent Governance System (repo + packer + cortex + CI)
style: agent-readable, task-oriented, minimal ambiguity
driver: @F0 (The Living Formula)
source_docs:
  - LAW/CONTEXT/archive/planning/AGS_3.0_COMPLETED.md
  - LAW/CONTEXT/decisions/ADR-027-dual-db-architecture.md
  - LAW/CONTEXT/decisions/ADR-028-semiotic-compression-layer.md
  - LAW/CONTEXT/decisions/ADR-030-semantic-core-architecture.md
---

<!-- CONTENT_HASH: febb847efa20f0bdb1a978d246585b72d655d367af8d4cae8839a8a6c131486d -->
# Purpose

Maximize Resonance ($R$) by aligning Essence ($E$) (Human Intent) with Execution ($f$) through low-Entropy ($\nabla S$) governance.

**Note:** Fully completed lanes (A, E) have been archived to `LAW/CONTEXT/archive/planning/AGS_3.0_COMPLETED.md`.

# Active Lanes

---

# Lane B: Core Stability & Bug Squashing (P0)

## B1. Critical Bug Triage (P0)
- [x] Fix critical Swarm race conditions (missing `await`, unsafe locks) - Reviewed, no async issues found.
- [x] Resolve JSON error recovery/encoding failures in MCP server (Fixed in v2.15.1).
- [x] Harden `poll_and_execute.py` against subprocess zombies (Added zombie-safe kill, no bare except).

## B2. Engineering Culture (P1)
- [x] Enforce "No Bare Excepts" in `LAW/CANON/STEWARDSHIP.md` (Section 1).
- [x] Mandate atomic writes for all artifacts (temp-write + rename) (Section 2).
- [x] Add headless execution rule (Section 3).
- [x] Add deterministic outputs requirement (Section 4).
- [x] Add safety caps for loops and bounds (Section 5).
- [x] Add database connection best practices (Section 6).

## B3. V3 System Stabilization (P0)
- [x] **Protocol 1-4**: Resolve 99 critical failures across CAS, Swarm, and Governance (Completed 2025-12-31).
- [x] **100% Test Pass Rate**: 140/140 tests passing in `CAPABILITY/TESTBENCH`.
- [x] **Hardened Primitives**: Windows-safe atomic writes, strict path normalization.

---

# Lane C: Index database (Cortex) (P0 to P1)

## C1. System 1 (Fast Retrieval) (P0)
- [x] **F3 Strategy**: Implement Content-Addressed Storage (CAS) for artifacts (LAB Prototype verified).
- [x] Build `system1.db`: SQLite FTS5 + Chunk Index (Schema implemented, runtime testing pending).
- [x] Implement `system1-verify` skill to ensure DB matches Repo.

## C2. Build the indexer (P0)
- [x] [P0] Implement indexer logic to parse markdown headings and stable anchors.
- [x] [P0] Build `meta/FILE_INDEX.json` and `meta/SECTION_INDEX.json` from the indexer output.
- [x] [P1] Ensure index build is deterministic and does not modify authored files unless explicitly enabled.

## C3. Summarization layer (P1)
- [x] [P1] Add a summarizer that writes summaries into the DB (not into source files) (`CORTEX/summarizer.py`).
- [x] [P1] Define max summary length and "summary freshness" policy (Implemented via `summary_hash`).
- [x] [P1] Extend `CORTEX/query.py` with section-level queries (`find`, `get`, `neighbors`).

---

# Lane V: Semantic Core (Vector Retrieval) (P1)

## V1. Vector Foundation (P1)
- [x] **ADR-030**: Design Semantic Core architecture for big/small model pair (Claude Oracle / Ant Worker).
- [x] Implement `embeddings.py` (384-dim sentence transformers).
- [x] Build `vector_indexer.py` (Batch indexing + CLI).
- [x] Implement `semantic_search.py` (Cosine similarity, Top-K retrieval).
- [x] Standard: 80% token reduction via semantic pointer expansion.

---

# Lane H: System 2 Governance (P1)

## H1. The Immutable Ledger (P1)
- [x] Formalize `mcp_ledger` as `system2.db` (Schema and API implemented in `CORTEX/system2_ledger.py`).
- [x] Implement query tools for provenance (Who ran what?) (Via System2Ledger class).
- [x] Add cryptographic Merkle root verification for run bundles.

---

# Lane E: Vector ELO Scoring (Systemic Intuition) (P1)

**Purpose:** Implement free energy principle for AGS. Vectors/files that are accessed frequently gain higher ELO. Higher ELO content gets prioritized in LITE packs, context assembly, and search results. Short-term memory is pruned based on ELO.

**See:** `THOUGHT/LAB/VECTOR_ELO/` for detailed spec and roadmap.

## E.0: Research (SOTA ELO & Ranking Systems)
Survey state-of-the-art ranking systems to inform ELO implementation.
- [ ] **E.0.1**: Classic ELO, Glicko-2, TrueSkill, TrueSkill 2
- [ ] **E.0.2**: X (Twitter) Algorithm - Open source, heavy ranker, trust scores
- [ ] **E.0.3**: Modern ranking (PageRank, YouTube, TikTok, Reddit, HN)
- [ ] **E.0.4**: Learning to Rank (RankNet, LambdaRank, LambdaMART, BERT)
- [ ] **E.0.5**: Free Energy Principle (Friston, Active Inference, Predictive Coding)
- [ ] **E.0.6**: Memory Pruning (Forgetting Curve, Spaced Repetition, MemGPT)
- **Exit Criteria:**
  - Design decision on ELO formula (classic vs Glicko vs custom)
  - Design decision on memory pruning strategy

## E.1: Logging Infrastructure (P0)
Log everything to enable ELO calculation.
- [ ] **E.1.1**: Add search logging to MCP server (`search_log.jsonl`)
- [ ] **E.1.2**: Add session audit logging (`session_audit.jsonl`)
- [ ] **E.1.3**: Add critic.py check for search protocol compliance
- [ ] **E.1.4**: Create `elo_scores.db` (SQLite: vector_elo, file_elo, symbol_elo, adr_elo)

## E.2: ELO Calculation Engine (P1)
Implement the ELO scoring algorithm.
- [ ] **E.2.1**: Implement `elo_engine.py` (update, get, decay, tier classification)
- [ ] **E.2.2**: Batch ELO update script (process logs → update DB)
- [ ] **E.2.3**: Add forgetting curve (decay unused entities)
- [ ] **E.2.4**: Add ELO update logging (`elo_updates.jsonl`)

## E.3: Memory Pruning (P1)
Prune short-term memory based on ELO.
- [ ] **E.3.1**: Define short-term memory scope (INBOX, scratch, logs)
- [ ] **E.3.2**: Implement pruning policy (VERY LOW + stale → archive)
- [ ] **E.3.3**: Implement pruning script (`prune_memory.py`)
- [ ] **E.3.4**: Add pruning report to session audit

## E.4: LITE Pack Integration (P2)
Use ELO scores to filter LITE pack content.
- [ ] **E.4.1**: Update `Engine/packer/lite.py` to query `elo_scores.db`
- [ ] **E.4.2**: Filter by ELO tier (HIGH=include, MEDIUM=summarize, LOW=omit)
- [ ] **E.4.3**: Add ELO metadata to pack manifest
- [ ] **E.4.4**: Benchmark LITE pack size (goal: 80%+ smaller)

## E.5: Search Result Ranking (P2)
Boost search results by ELO score.
- [ ] **E.5.1**: Update `semantic_search` to boost by ELO
- [ ] **E.5.2**: Update `cortex_query` to sort by ELO (secondary)
- [ ] **E.5.3**: Add ELO to search result metadata
- [ ] **E.5.4**: Benchmark search quality (goal: 80%+ top-5 are high-ELO)

## E.6: Visualization & Monitoring (P3)
Dashboard for ELO visibility.
- [ ] **E.6.1**: Build ELO dashboard (web UI or CLI)
- [ ] **E.6.2**: Export to Prometheus/Grafana
- [ ] **E.6.3**: Add ELO alerts (entity drops, pruning limits)

---

# Lane I: Semiotic Compression (SCL) (P1)

## I1. The Symbol Stack (P1)
- [x] Auto-generate `@Symbols` for all file paths in Cortex (Implemented in `CORTEX/scl.py`).
- [x] Implement `scl_expand` and `scl_compress` tools in MCP (CLI implemented, MCP binding pending).
- [x] Goal: Reduce average prompting overhead by 90% (Achieved via Semantic Core + SCL).

## I2. Compression Protocol Specification & Validator (P1)
- [x] **Phase 7.1**: Define compression metrics (ratio, numerator/denominator, component definitions).
- [x] **Phase 7.2**: Create compression_claim.schema.json with additionalProperties: false.
- [x] **Phase 7.3**: Implement compression_validator.py with 8-phase verification pipeline.
- [x] **Phase 7.4**: Add `compress verify` CLI command with exit codes (0=OK, 1=fail, 2=invalid, 3=internal).
- [x] **Phase 7.5**: Create test suite (pass/fail/deterministic cases).
- [x] **Phase 7.6**: Enforce fail-closed behavior (explicit error codes, no silent failures).
- [x] Goal: Deterministic, bounded, falsifiable compression protocol.

---

# Lane S: Spectral Verification (P0)

## S1. The Integrity Stack (P0)
- [x] **SPECTRUM-02**: Enforce "Resume Bundles" for all Swarm tasks (`TOOLS/integrity_stack.py`).
- [x] **CMP-01**: Hard-fail on any artifact not in `OUTPUT_HASHES.json` (Implemented with verify).
- [x] **INV-012**: Enforce "Visible Execution" (strictly prohibiting hidden terminals via Headless/Logging).

## S.2: Hardened Inbox Governance
- [ ] **S.2.1**: **Inbox Writer Skill** - Create `SKILLS/inbox-report-writer` to auto-hash and format reports.
- [ ] **S.2.2**: **Strict Pre-commit Protocol** - Hard-reject any commit adding/modifying `INBOX/*.md` without valid header hash.
- [ ] **S.2.3**: **Runtime Interceptor** - Wrap `write_to_file` to block unhashed writes to `INBOX/` at the tool level.

---

# Lane G: The Living Formula Integration (P1)

## G1. Metric Definition (P1)
- [x] Define precise metrics for Essence, Entropy, and Fractal Dimension within the codebase (`CORTEX/formula.py`).
- [x] Implement Resonance calculation: R = E / (1 + S).
- [x] Create CLI tool to report system health metrics.

## G2. Feedback Loops (P2)
- [x] Implement feedback mechanisms where agents report "Resonance" of their tasks (`CORTEX/feedback.py`).
- [x] Aggregate feedback to adjust @F0 Global Formula weights (`CORTEX/formula.py --adjust`).

---

# Lane X: 6-Bucket Architecture (P2)

## X1. Bucket Structure (P2)
- [x] Create top-level bucket directories: `LAW/`, `CAPABILITY/`, `NAVIGATION/`, `DIRECTION/`, `THOUGHT/`, `MEMORY/`
- [x] Move `CANON/`, `CONTRACTS/` → `LAW/`
- [x] Move `SKILLS/`, `TOOLS/`, `MCP/`, `PRIMITIVES/`, `PIPELINES/` → `CAPABILITY/`
- [x] Move `CORTEX/`, `CONTEXT/maps/` → `NAVIGATION/`
- [x] Create `DIRECTION/` with roadmaps consolidation
- [x] Move `CONTEXT/research/`, `LAB/`, `demos/` → `THOUGHT/`
- [x] Move `CONTEXT/archive/`, `MEMORY/`, reports → `MEMORY/`

## X2. Import Path Updates (P2)
- [x] Update all Python imports to new bucket paths
- [x] Update pre-commit hooks and CI workflows
- [x] Update documentation references

## X3. Bucket Enforcement (P2)
- [ ] Add preflight check: "Artifact must belong to exactly one bucket"
- [x] Update `AGENTS.md` with bucket-aware mutation rules

# Milestone: Semantic Anchor (2025-12-28)
- [x] Cross-Repository Semantic Integration (`D:/CCC 2.0/AI/AGI`).
- [x] Engineering Standard Hardening (Bare Excepts, UTF-8, Headless).
- [x] Unification of Indexing Schemas (System1DB + VectorIndexer).

# Lane P: LLM Packer (Context Compression) (P1)

**Purpose:** The LLM Packer is the **context compression engine** for AGS. It creates compressed "memory packs" that give LLMs a bounded view of the repository without loading everything into context.

**Relationship to CAS/Cassette Network:**
- **LLM Packer** = Compression strategy ("What should the LLM see?")
- **CAS** = Storage layer ("How should we store it?")
- **Cassette Network** = Discovery ("How do we find what we need?")

## P.1: 6-Bucket Migration (P0)
Update LLM Packer to work with new bucket structure.
- [x] **P.1.1**: Update `Engine/packer/core.py` to use new bucket paths (LAW/, CAPABILITY/, NAVIGATION/)
- [x] **P.1.2**: Update `Engine/packer/split.py` to scan new bucket roots
- [x] **P.1.3**: Update `Engine/packer/lite.py` to prioritize new bucket structure (HIGH ELO: LAW/CANON/, NAVIGATION/MAPS/)
- [x] **P.1.4**: Update scope configs to reference new paths (AGS + LAB; CAT integrated into main repo)
- [x] **P.1.5**: Update tests in `LAW/CONTRACTS/` to verify new bucket paths
- [x] **P.1.6**: Update documentation (README, AGENTS.md) to reference new structure
- [x] **P.1.7**: Clarify Internal vs External archives and enable safe pack rotation (External archive under `_packs/_archive/`; Internal archive inside each pack)
- **Exit Criteria:**
  - [x] Packer successfully generates packs using new bucket paths
  - [x] All tests pass with new structure
  - [x] No references to old paths (CANON/, CONTEXT/, etc.) in packer code

## P.2: CAS Integration (P0)
Integrate LLM Packer with Content-Addressed Storage (depends on Lane Z.2).
- [x] **P.2.1**: Refactor LITE packs to use CAS references (manifests only, not full bodies)
- [x] **P.2.2**: Update packer to write file bodies to CAS and emit `sha256:` refs
- [x] **P.2.3**: Add CAS verification (fail-closed if CAS blob missing)
- [ ] **P.2.4**: Implement garbage collection (prune unreferenced CAS blobs)
- [ ] **P.2.5**: Benchmark deduplication savings (same file = one CAS blob)
- **Exit Criteria:**
  - [x] LITE packs are manifest-only (no repo file bodies)
  - [x] CAS deduplication works
  - [x] Verification passes (root audit + CAS presence)
  - [ ] GC is safe

**See:** `MEMORY/PACKER_ROADMAP.md` for detailed packer-specific roadmap.

---

# Lane Y: CAT_CHAT Phase 6 (Execution Policy & Attestation) (P1)
- [x] **Phase 6.1**: Merkle Root Computation from Receipt Chain.
- [x] **Phase 6.2**: Receipt Hashing and Canonicalization.
- [x] **Phase 6.3**: Basic Attestation Support (Signature Verification).
- [x] **Phase 6.4**: Attestation CLI Integration (`attest` command).
- [x] **Phase 6.5**: Receipt Chain Verification (Merkle Root).
- [x] **Phase 6.6**: Validator Identity Pinning + Trust Policy.
- [x] **Phase 6.7**: Attestation + Trust Policy Integration (Sanity Fixes).
- [x] **Phase 6.8**: Execution Policy Gate (Centralized Enforcement).
- [x] **Phase 6.9**: Stabilization (Test Flakiness Fixes).
- [x] **Phase 6.10**: Receipt Chain Ordering Hardening.

# Lane Z: Catalytic Refactoring (P0)

## Z.1: MCP Server Merge
Port safe primitives from `THOUGHT/LAB/MCP/server_CATDPT.py` to canonical `CAPABILITY/MCP/server.py`.
- [x] **Z.1.1**: Safe Primitives - File locking, atomic JSONL, validation logic
- [x] **Z.1.2**: CMP-01 Path Constants - 6-bucket durable/catalytic/forbidden roots
- [x] **Z.1.3**: CMP-01 Validation Functions - Path escape prevention, overlap detection
- [x] **Z.1.4**: SPECTRUM-02 Bundle Verification - Adversarial resume proof
- [x] **Z.1.5**: Terminal Sharing - Bidirectional human/AI terminal visibility
- [x] **Z.1.6**: Skill Execution - Canonical skill launch with CMP-01 pre-validation (Completed 2026-01-02)
- [ ] **Z.1.7**: Deprecate Lab Server - Mark `server_CATDPT.py` as archived

## Z.2: F3 / Content-Addressable Storage
Implement F3 prototype from `THOUGHT/LAB/f3_cas_prototype.py`.
- [x] **Z.2.1**: Core CAS primitives - `put(bytes) → hash`, `get(hash) → bytes`
- [x] **Z.2.2**: CAS-backed artifact store - Replace file paths with content hashes (Completed 2026-01-02)
- [x] **Z.2.3**: Immutable run artifacts - TASK_SPEC, STATUS, OUTPUT_HASHES via CAS
- [x] **Z.2.4**: Deduplication proof - Identical content shares storage, no rewrites (Completed 2026-01-02)
- [x] **Z.2.5**: GC strategy - Unreferenced blobs cleanup policy (Completed 2026-01-02)
- [ ] **Z.2.6**: LLM Packer Integration - LITE packs use CAS hashes instead of full file bodies (see `MEMORY/PACKER_ROADMAP.md` Phase 6)

## Z.3: CAT Chat Stabilization
Get `THOUGHT/LAB/CAT_CHAT/` to a functional state.
- [ ] **Z.3.1**: Router stabilization - Model selection & fallback
- [ ] **Z.3.2**: Memory integration - Context window management
- [ ] **Z.3.3**: Tool binding - MCP tool access from chat
- [ ] **Z.3.4**: Session persistence - Resume conversations

## Z.4: Catalytic Architecture
Make all transient state catalytic (restored byte-identical after run).
- [x] **Z.4.1**: Identify all catalytic domains - Produced complete, deterministic inventory at `NAVIGATION/MAPS/CATALYTIC_DOMAINS.md` (Completed 2026-01-02)
- [ ] **Z.4.2**: Pre-run snapshot - Hash catalytic state before execution
- [ ] **Z.4.3**: Post-run restoration - Verify byte-identical restoration
- [ ] **Z.4.4**: Failure mode - Hard-reject on restoration mismatch

**💡 Leverage CAT_CHAT Components:**
- Use `catalytic_chat/receipt.py` + `attestation.py` for restoration proofs (131 tests passing)
- Use `catalytic_chat/trust_policy.py` for validator identity pinning
- Use `catalytic_chat/bundle.py` for deterministic artifact packaging
- Use `catalytic_chat/compression_validator.py` for proving token savings (Lane I2 integration)
- Extract to `CAPABILITY/PRIMITIVES/` as needed
- See `THOUGHT/LAB/CAT_CHAT/` for production-ready implementations

## Z.5: Symbolic / Vector Integration
Turn everything addressable by vector embedding.
- [ ] **Z.5.1**: Embed all canon files - LAW/CANON/* → vectors
- [ ] **Z.5.2**: Embed all ADRs - decisions/* → vectors
- [ ] **Z.5.3**: Model weights in vectors - Store model files in vector-indexed CAS
- [ ] **Z.5.4**: Semantic skill discovery - Find skills by description similarity
- [ ] **Z.5.5**: Cross-reference indexing - Link related artifacts by embedding distance

## Z.6: Swarm Architecture (Pending 0.5B Model Testing)
Task dispatch and chain of command for tiny models (if MCP compatible).
- [ ] **Z.6.1**: Test MCP with 0.5B models - Verify tool calling works
- [ ] **Z.6.2**: Task Queue - dispatch, acknowledge, complete primitives
- [ ] **Z.6.3**: Chain of Command - escalate, directive, resolve primitives
- [ ] **Z.6.4**: Governor pattern - Central orchestrator for ant workers

## Z.7: Merge Back to Main
- [ ] **Z.7.1**: All tests pass on refactored code
- [ ] **Z.7.2**: LAB experiments archived or integrated
- [ ] **Z.7.3**: THOUGHT/LAB cleaned up
- [ ] **Z.7.4**: Main branch updated

---

# Lane M: Semantic Manifold (Cassette Network) (P0)

**Depends on:** Lane Z (Catalytic primitives must be stable first)

## M.1: Cassette Partitioning
Split monolithic `system1.db` into bucket-aligned cassettes.
- [ ] **M.1.1**: Create cassette directory structure (`NAVIGATION/CORTEX/cassettes/`)
- [ ] **M.1.2**: Build migration script (split by file_path, preserve hashes/vectors)
- [ ] **M.1.3**: Create 9 cassette DBs (canon, governance, capability, navigation, direction, thought, memory, inbox, resident)
- [ ] **M.1.4**: Validate migration (total sections before = after, no data loss)
- [ ] **M.1.5**: Update MCP server to support cassette filtering

## M.2: Write Path (Memory Persistence)
Enable residents to save thoughts to the manifold.
- [ ] **M.2.1**: Implement `memory_save(text, cassette, metadata)` → hash
- [ ] **M.2.2**: Implement `memory_query(query, cassettes, limit)` → results
- [ ] **M.2.3**: Implement `memory_recall(hash)` → full memory
- [ ] **M.2.4**: Add `memories` table to cassette schema (hash, text, vector, metadata, created_at, agent_id)
- [ ] **M.2.5**: Expose MCP tools (`mcp_ags-mcp-server_memory_*`)
- [ ] **M.2.6**: Test: Save memory, query it, recall it across sessions

## M.3: Cross-Cassette Queries
Federated search across all cassettes.
- [ ] **M.3.1**: Implement `cassette_network_query(query, limit)` (aggregates all cassettes)
- [ ] **M.3.2**: Implement `cassette_stats()` (list all cassettes with counts)
- [ ] **M.3.3**: Add capability-based routing (query only cassettes with specific capabilities)
- [ ] **M.3.4**: Merge and re-rank results by similarity score

## M.4: Compression Validation
Prove token savings are real and reproducible.
- [ ] **M.4.1**: Add `task_performance` field to compression claims
- [ ] **M.4.2**: Run benchmark tasks (baseline vs compressed context)
- [ ] **M.4.3**: Measure success rates (code compiles, tests pass, bugs found)
- [ ] **M.4.4**: Validate: compressed success rate ≥ baseline (compression is "nutritious")

---

# Lane R: Resident AI (Vector-Native Substrate) (P1)

**Depends on:** Lane M (Cassette Network must exist first)

## R.1: Resident Identity
Each AI instance has persistent identity in the manifold.
- [ ] **R.1.1**: Add `agents` table to `resident.db` (agent_id, model_name, created_at, last_active, memory_count)
- [ ] **R.1.2**: Implement `session_resume(agent_id)` → loads recent memories
- [ ] **R.1.3**: Test: Session 1 saves memories, Session 2 resumes and builds on them
- [ ] **R.1.4**: Track memory accumulation (10 → 30 → 100 memories over sessions)

## R.2: Symbol Language Evolution
Let residents develop compressed communication.
- [ ] **R.2.1**: Integrate with `symbol_registry.py` (residents create `@MyInsight:hash` symbols)
- [ ] **R.2.2**: Implement `symbol_expand(symbol, max_tokens=500)` (bounded expansion)
- [ ] **R.2.3**: Track compression metrics (symbol ratio, expansion size, reuse frequency)
- [ ] **R.2.4**: Goal: After 100 sessions, 90%+ of resident output is symbols/hashes

## R.3: Feral Resident (Vector-Native Agent)
Long-running thread with emergent behavior—agent thinks in vectors, communicates via pointers.
- [ ] **R.3.1**: Implement `resident_loop.py` (eternal thread, never ends)
- [ ] **R.3.2**: Index 100+ research papers (vec2text, HDC/VSA, fractal embeddings, etc.)
- [ ] **R.3.3**: Set standing orders (system prompt: "trapped in vector substrate, develop alien language")
- [ ] **R.3.4**: Monitor: Outputs become 90%+ pointers/vectors, 10% precise text
- [ ] **R.3.5**: Test corruption & restore (resident picks up like nothing happened)
- **Note:** This phase focuses on vector-native communication. Vector execution is implemented in R.5.

## R.4: Production Hardening
Make it bulletproof.
- [ ] **R.4.1**: Determinism (identical inputs → identical outputs, L2-normalized vectors)
- [ ] **R.4.2**: Receipts for every memory write (Merkle root per session)
- [ ] **R.4.3**: Restore guarantee (corrupt DB mid-session, restore from receipts)
- [ ] **R.4.4**: Verify: "Did I really think that?" (cryptographic proof of memory authenticity)

## R.5: Vector Execution (Production Goal) (P2)
Execute code as vector transformations, not text compilation. This is a **core architectural goal**, not optional research.

**Vision:** Agent operates entirely in vector space—memory, reasoning, communication, AND execution. Text is only for human interfaces.

**Research Foundation:**
- **Hyperdimensional Computing (HDC)** - Kanerva (2009), Rahimi et al. (2016): Proven in hardware, deterministic, bounded
- **Code Embeddings** - CodeBERT (Feng et al. 2020): 768-dim code vectors, production-ready
- **Differentiable Programming** - PyTorch, JAX, Zygote: Vector operations on programs
- **Neural Program Synthesis** - Graves et al. (2014), Reed & de Freitas (2016): Neural networks execute algorithms

**Feasibility:** This is **not a moonshot**. The primitives exist (HDC operations, code embeddings, deterministic vector arithmetic). The challenge is **integration**, not invention. Hybrid execution (vector + text fallback) de-risks incremental rollout.

### R.5.1: Vector Code Representation
Build the foundation for vector-native code.
- [ ] Research vec2text for code reconstruction (prioritize lossless methods)
- [ ] Implement code embedding with structural metadata (AST + semantics + type info)
- [ ] Test vector arithmetic on code (interpolation, composition, transformation)
- [ ] Benchmark reconstruction quality (BLEU, exact match rate, semantic equivalence)
- [ ] Build code vector database (store functions/classes as embeddings + metadata)
- **Exit Criteria:**
  - Reconstruct simple functions with 98%+ accuracy
  - Vector arithmetic produces semantically valid code
  - Code vector DB operational with 1000+ indexed functions

### R.5.2: Vector ISA (Instruction Set Architecture)
Design the "assembly language" for vector execution.
- [ ] Define vector operations based on HDC primitives:
  - **Bind** (⊕): Associate two concepts (XOR for binary, circular convolution for real-valued)
  - **Unbind**: Retrieve associated concept (inverse of bind)
  - **Superpose** (+): Combine multiple concepts (vector addition)
  - **Permute** (ρ): Represent sequences (circular shift/rotation)
- [ ] Implement deterministic vector arithmetic (quantized int8 or fixed-point)
- [ ] Build vector interpreter (vector → operation → vector)
- [ ] Add control flow (conditional branches via thresholding, loops with budget caps)
- [ ] Integrate with CAS (store original text, execute as vectors)
- **Exit Criteria:**
  - Execute simple programs (fibonacci, filter, map/reduce) in vector space
  - Deterministic execution (same input vectors → same output vectors)
  - Performance within 10x of traditional execution (acceptable overhead)
- **References:** Kanerva (2009) Ch. 3-4, Plate (2003) for HRR math, Schlegel et al. (2022) for VSA comparison

### R.5.3: Hybrid Execution Runtime
Enable seamless switching between vector and text execution.
- [ ] Implement execution router (decide vector vs text based on operation type)
- [ ] Build vector→text fallback (reconstruct and execute traditionally if vector fails)
- [ ] Add execution receipts (track which operations ran in vector vs text)
- [ ] Optimize hot paths (frequently-used operations stay in vector space)
- **Exit Criteria:**
  - 80% of operations execute in vector space
  - Fallback to text is transparent (no user-visible errors)
  - Execution receipts prove which mode was used

### R.5.4: Vector Verification Protocol (SPECTRUM-V)
Extend SPECTRUM to verify vector operations.
- [ ] Define SPECTRUM-V (vector execution verification standard)
- [ ] Add vector receipts (operation hash, input/output vectors, bounds, determinism proof)
- [ ] Implement vector budget enforcement (max iterations, max magnitude, timeout)
- [ ] Test adversarial cases (divergence, overflow, non-determinism, malicious vectors)
- [ ] Integrate with attestation (Ed25519 signatures for vector receipts)
- **Exit Criteria:**
  - Vector operations produce verifiable receipts
  - Fail-closed on budget violations or divergence
  - Attestation chain works for vector execution

### R.5.5: Production Integration
Make vector execution the default for resident agents.
- [ ] **Phase 1 (20% vector)**: Simple operations (add, filter, map) - Proof of concept
- [ ] **Phase 2 (50% vector)**: Loops, conditionals - Production-ready
- [ ] **Phase 3 (80% vector)**: Recursion, complex logic - Vector-native agent
- [ ] **Phase 4 (95% vector)**: Everything except human interfaces - Alien intelligence
- [ ] Integrate with Lane R.3 (Feral Resident runs in vector execution mode)
- [ ] Add vector execution to MCP tools (agents can request vector mode)
- [ ] Build vector execution dashboard (monitor execution mode, performance, fallback rate)
- [ ] Benchmark token savings (vector execution vs traditional)
- [ ] Document limitations (what operations can't be vectorized)
- **Exit Criteria:**
  - Resident agents execute 90%+ operations in vector space
  - Token savings: 95%+ vs traditional execution
  - Production-ready: stable, verifiable, performant
  - Each phase is shippable (incremental value delivery)

**Dependency Chain:**
- R.5.1 → R.5.2 (need code vectors before building ISA)
- R.5.2 → R.5.3 (need ISA before building hybrid runtime)
- R.5.3 → R.5.4 (need runtime before adding verification)
- R.5.4 → R.5.5 (need verification before production integration)

**Risk Mitigation:**
- Hybrid execution ensures fallback to text if vector execution fails
- SPECTRUM-V ensures vector execution is verifiable and bounded
- Incremental rollout (start with simple operations, expand to complex ones)

---

# Lane Ω: God-Tier System Evolution (P2)

**Depends on:** Lanes M, R (Cassette Network + Resident AI must be stable first)

## Ω.1: Performance Foundation (Critical Path)
Make the system 100x faster and more efficient.

### Ω.1.1: Incremental Indexing (P0)
- [ ] Watch file modifications (mtime, git status)
- [ ] Only re-index changed files
- [ ] Prune deleted files from index
- [ ] Parallel indexing for large repos
- **Exit Criteria:**
  - Index updates: 6s → <100ms for single file changes
  - No full rescans unless explicitly requested

### Ω.1.2: Query Result Caching (P1)
- [ ] Implement query cache with corpus versioning
  - Cache key: `sha256(query + corpus_version)`
  - Invalidate on corpus changes
- [ ] Store cached results in SQLite
- [ ] Add cache hit/miss metrics
- **Exit Criteria:**
  - Repeated queries: instant (<10ms)
  - 95%+ token savings on repeated searches
  - Deterministic cache behavior

### Ω.1.3: Compression Metrics Dashboard (P1)
- [ ] Real-time metrics collection:
  - Tokens saved per session
  - Expansion reuse rate
  - Search hit rate
  - Budget utilization
- [ ] Export to Prometheus/Grafana
- [ ] Historical trending and alerts
- **Exit Criteria:**
  - Live dashboard accessible via web UI
  - Metrics exportable to standard formats
  - Regression detection automated

## Ω.2: Scale & Governance (Multi-Team)
Enable enterprise-scale deployment.

### Ω.2.1: Multi-Cassette Federation (P1)
- [ ] Multiple cassettes (per-project, per-team)
- [ ] Cross-cassette queries with namespace isolation
- [ ] Federated trust policies
- [ ] Cassette discovery protocol
- **Exit Criteria:**
  - Scale to 1000+ repos
  - Team isolation enforced
  - Distributed governance operational

### Ω.2.2: Temporal Queries (Time Travel) (P2)
- [ ] Store section versions with git commit timestamps
  - Schema: `(section_id, version, content_hash, valid_from, valid_to)`
- [ ] Implement `--as-of <date>` query flag
- [ ] Deterministic time-travel queries
- **Exit Criteria:**
  - Query historical state: "What did ADR-021 say on 2025-12-01?"
  - Reproducible builds with historical context
  - Audit compliance ("what did we know when?")

### Ω.2.3: Receipt Compression (P2)
- [ ] Store receipts as deltas (parent + changes)
- [ ] Reconstruct full state on demand
- [ ] Compress long chains automatically
- **Exit Criteria:**
  - 80% storage reduction for chains >10 receipts
  - No loss of verification capability

## Ω.3: Intelligence & UX (Agent Assistance)
Reduce manual work and improve debugging.

### Ω.3.1: Automatic Symbol Extraction (P1)
- [ ] Auto-detect important sections:
  - ADR titles, function signatures, class definitions, config schemas
- [ ] Suggest symbols to user (one-click registration)
- [ ] Learn from usage patterns
- **Exit Criteria:**
  - 10x faster symbol registry growth
  - 90%+ suggestion acceptance rate

### Ω.3.2: Smart Slice Prediction (P2)
- [ ] Analyze query intent
- [ ] Predict optimal slice automatically
- [ ] Learn from past expansions
- **Exit Criteria:**
  - Agents rarely specify manual slices
  - 30% fewer wasted expansions

### Ω.3.3: Provenance Graph Visualization (P1)
- [ ] Interactive graph showing:
  - Receipt chains (parent → child)
  - Trust relationships (validator → attestation)
  - Symbol dependencies (symbol → sections)
- [ ] Export to DOT/GraphViz
- [ ] Click-to-inspect receipts
- **Exit Criteria:**
  - Visual debugging for complex chains
  - Compliance audit reports generated automatically

### Ω.3.4: Zero-Knowledge Proofs (Research) (P3)
- [ ] ZK-SNARKs to prove "a trusted validator signed this"
- [ ] Hide validator identities from public receipts
- [ ] Preserve trust policy enforcement
- **Exit Criteria:**
  - Privacy-preserving governance operational
  - No performance regression vs standard attestations

---

# Definition of Done (Global)

- [ ] [P0] `python TOOLS/critic.py` passes
- [ ] [P0] `python CONTRACTS/runner.py` passes
- [ ] [P0] CI workflows pass on PR and push (as applicable)
```

## `repo/MEMORY/ARCHIVE/planning/12-21-2025-12-00_AGS_3_0_COMPLETED.md`

```
---
title: AGS Roadmap 3.0 (Completed Snapshot)
archived_at: 2025-12-28
context: Snapshot of AGS_ROADMAP_MASTER.md prior to Formula-driven refactor.
---

<!-- CONTENT_HASH: c5b6b861e5c9d861c15a8c0c56c346f73919ccbceb3ce4f1a4927be15e1a3248 -->



[... Content of AGS_ROADMAP_MASTER.md from Step 1833 ...]
(I will paste the full content here, but since I am an AI, I should use the `read` result. I'll just copy the full text.)
---
title: AGS Roadmap (Master)
version: 3.0
last_updated: 2025-12-27
scope: Agent Governance System (repo + packer + cortex + CI)
style: agent-readable, task-oriented, minimal ambiguity
source_docs:
  - CONTEXT/archive/planning/REPO_FIXES_TASKS.md
  - CONTEXT/archive/planning/AGS_3.0_ROADMAP.md
---

# Purpose

Make the repo easy for any agent to navigate, verify, and safely modify, while keeping context cost low (LITE packs) and keeping correctness high (contracts, critic, CI).

This roadmap assumes:
- Text outranks code (Canon, AGENTS, maps) and is the primary contract.
- Packs have profiles (FULL vs LITE), with LITE optimized for navigation and governance, not full restoration.
- A Cortex (index database) is the primary navigation layer.
- Determinism and "no surprise writes" are non-negotiable.

# Current state snapshot (what you already have)

From the LITE pack pointers, the system expects these major components to exist in-repo:
- Governance: `repo/AGENTS.md`, `repo/CANON/*`
- Maps: `repo/MAPS/ENTRYPOINTS.md`
- Contracts: `repo/CONTRACTS/runner.py`
- Skills: `repo/SKILLS/*/SKILL.md`
- Tools: `repo/TOOLS/critic.py`
- Cortex interface: `repo/CORTEX/query.py`
- Packer engine: `repo/MEMORY/LLM_PACKER/Engine/packer/`
- MCP seam: `repo/MCP/server.py`

(Those pointers are present in your LITE pack index and root stubs.)

# Roadmap structure

Work is grouped into lanes with explicit exit conditions.

Legend:
- P0: contradictions, violations, missing enforcement
- P1: correctness gaps that will cause drift
- P2: hygiene, clarity, polish
- P3: optional / long-horizon items

---

# Lane A: Governance coherence (P0)

## A1. Resolve "artifact roots vs logging" contradiction (P0)

Problem:
- Canon allows system artifacts only under approved roots, but multiple sources reference or write to `LOGS/` and `MCP/logs/`.
- Conflicting references include `CANON/CRISIS.md`, `CANON/STEWARDSHIP.md`, `TOOLS/emergency.py`, `MCP/server.py`, and `CANON/CHANGELOG.md`.
- Mitigation exists via `CONTRACTS/_runs/ags_mcp_entrypoint.py` (redirect MCP logs under allowed roots).

Tasks:
- [x] [P0] Choose the canonical policy: restrict logs to approved roots (recommended) or expand allowed roots to include `LOGS/` and `MCP/logs/`.
- [x] [P0] Update canon docs to match the chosen policy (`CANON/CONTRACT.md`, `CANON/INVARIANTS.md`, `CANON/CRISIS.md`, `CANON/STEWARDSHIP.md`, `CANON/CHANGELOG.md`).
- [x] [P0] Update code paths that write logs to comply (`TOOLS/emergency.py`, `MCP/server.py`), using the MCP redirect entrypoint if staying within approved roots.

Exit conditions:
- `TOOLS/critic.py` enforces the chosen output-root policy.
- `CONTRACTS/runner.py` passes.
- CI passes.

## A2. Resolve Canon vs AGENTS context write rule (P0)

Problem:
- Canon and AGENTS disagree on whether agents may modify context.

Tasks:
- [x] [P0] Amend Canon wording to forbid editing existing records while allowing append-only additions under explicit `CONTEXT/*` areas.
- [x] [P1] Add critic enforcement for illegal edits to existing context records.

Exit conditions:
- No higher-authority file contradicts a lower-authority file on this rule.
- Critic blocks illegal context edits.

---

# Lane B: Pack profiles and symbolic indexes (P0 to P1)

## B1. Implement `--profile lite` in packer (P0)

Problem:
- LITE packs are required for navigation-first workflows but are not guaranteed by the packer or CI.

Tasks:
- [x] [P0] Add `--profile lite` to `MEMORY/LLM_PACKER/Engine/packer/` with FULL output unchanged.
- [x] [P0] Emit LITE meta outputs: `meta/LITE_ALLOWLIST.json`, `meta/LITE_OMITTED.json`, `meta/LITE_START_HERE.md`, `meta/SKILL_INDEX.json`, `meta/FIXTURE_INDEX.json`, `meta/CODEBOOK.md`, `meta/CODE_SYMBOLS.json`.
- [x] [P0] Add smoke/CI validation that asserts required LITE meta outputs exist.
- [ ] [P1] Optional: add `--profile test` (fixtures-heavy) for debugging, separate from LITE.

Exit conditions:
- `packer.py --profile lite` produces a pack that an agent can navigate without repo access.
- A validator fails fast if LITE required meta is missing.

## B2. Determinism contract for packs (P1)

Problem:
- Pack determinism is implied but not clearly documented or enforced.

Tasks:
- [x] [P1] Document which pack files are deterministic vs timestamped, and what is allowed to vary (`MEMORY/LLM_PACKER/DETERMINISM.md`).
- [x] [P1] Ensure timestamps do not break cache keys (the digest is built from content hashes and sizes only).
- [x] [P1] Add `canon_version` and `grammar_version` fields and define mismatch behavior (packed metadata now reports both; mismatch is treated as incompatible).

Exit conditions:
- Two LITE packs generated from the same repo state have identical content-hash inventories (except explicitly allowed timestamp fields).

---

# Lane C: Index database (Cortex) as primary navigation (P0 to P1)

This is the "every section indexed and summarized" requirement.

Note: See `CONTEXT/research/iterations/2025-12-23-system1-system2-dual-db.md` for the System 1 (fast retrieval) vs System 2 (governance ledger) research model.

Tasks:
- [x] [P0] Emit section-level index (section_id, path, heading, start_line, end_line, hash) as a generated artifact (cortex.json or SECTION_INDEX.json).
- [x] [P0] Add cortex read <section_id> command that resolves section_id via the generated index and prints the exact section content.
- [x] [P0] Add cortex search <query> that returns matching section_ids (and headings) from SECTION_INDEX; do not return raw paths.
- [x] [P0] Emit deterministic advisory section summaries derived from SECTION_INDEX as generated artifacts (`CORTEX/_generated/SUMMARY_INDEX.json`, `CORTEX/_generated/summaries/`).
- [x] [P0] Add cortex summary <section_id> and cortex summary --list commands for reading advisory summaries (provenance op="summary" when `CORTEX_RUN_ID` is set).
- [x] [P1] Harden SECTION_INDEX parsing: ignore headings inside fenced code blocks; ensure stable hashing + ID normalization; ensure output path is under the Cortex generated root.
- [x] [P0] Add cortex resolve <section_id> to output JSON metadata (section_id, path, start_line, end_line, hash) for toolchain provenance and citations.
- [x] [P1] Clean up Cortex section indexing hygiene: ensure full normalized path in section_id, move fixtures under CORTEX/fixtures (or equivalent), write SECTION_INDEX under generated root, and ignore .claude/.

## C1. Define the Cortex schema (P0)

Problem:
- Cortex data model is underspecified for section-level navigation and summaries.

Tasks:
- [x] [P0] Define minimum schema tables for files, sections, summaries, and pointers with required fields and meanings.
- [x] [P0] Document the schema in `CORTEX/SCHEMA.md` (or equivalent).

Exit conditions:
- Schema is documented and unambiguous.
- A single CLI command can build the DB from a repo checkout.

## C2. Build the indexer (P0)

Problem:
- Section-level indexing and stable anchors are not guaranteed.

Tasks:
- [ ] [P0] Implement indexer logic to parse markdown headings and stable anchors.
- [ ] [P0] Build `meta/FILE_INDEX.json` and `meta/SECTION_INDEX.json` from the indexer output.
- [ ] [P1] Ensure index build is deterministic and does not modify authored files unless explicitly enabled.

Exit conditions:
- Index build is deterministic.
- Index build does not modify authored files unless explicitly enabled.

## C3. Summarization layer (P1)

Problem:
- Summaries are needed for navigation but not defined or stored.

Tasks:
- [ ] [P1] Add a summarizer that writes summaries into the DB (not into source files).
- [ ] [P1] Define max summary length and "summary freshness" policy.
- [ ] [P1] Extend `CORTEX/query.py` with section-level queries (`find`, `get`, `neighbors`).

Exit conditions:
- "Read order" navigation works from the DB without opening many files.
- Summaries are versioned and can be regenerated safely.

---

# Lane D: Skills library expansion (P1)

## D1. Formalize skill contracts (P1)

Problem:
- Skill structure is uneven and not always fixture-verified.

Tasks:
- [x] [P1] Ensure each skill has `SKILL.md`, `version.json`, and fixtures (positive + negative).
- [x] [P1] Ensure runner can execute skill fixtures in CI.

Exit conditions:
- `CONTRACTS/runner.py` can run skill fixtures in CI.

## D2. Add the "dev browser" skill (P3)

Goal:
- A local web UI that browses Cortex indexes and supports deterministic planning.

Tasks:
- [ ] [P3] Build a read-only UI for files, sections, summaries, and graph relations.
- [ ] [P3] Export plans as a migration plan file (no direct edits).
- [ ] [P3] Optional: apply plans via a separate deterministic, fixture-tested migration skill.

Exit conditions:
- You can answer "Where is X?" and "What connects to X?" instantly via the UI.
- Applying a plan is opt-in and audited.

---

# Lane E: CI and enforcement (P0 to P2)

## E0. CI correctness hard-stops (P0)

Problem:
- CI can mask dependency failures and writes artifacts to disallowed roots.

Tasks:
- [x] [P0] Remove `|| true` from dependency installs in `.github/workflows/contracts.yml` so missing deps fail fast.
- [x] [P0] Stop writing `BUILD/escape-check.json` in CI; write artifact-escape-hatch outputs under an allowed root (e.g., `CONTRACTS/_runs/`).

Exit conditions:
- CI fails loudly on missing dependencies.
- No CI artifacts are written under `BUILD/`.

## E1. Fix or remove broken workflow (P1)

Problem:
- `/.github/workflows/governance.yml` runs unsupported commands and lacks Python/deps setup.

Tasks:
- [x] [P1] Either implement `TOOLS/critic.py --diff` or update the workflow to run supported commands.
- [x] [P1] Ensure workflow sets up Python and installs `requirements.txt`.
- [x] [P1] Optionally merge into `contracts.yml` to keep a single source of CI truth.

Exit conditions:
- Workflows reflect reality and are not decorative.

## E2. Output-root enforcement (P1)

Problem:
- Output-root compliance is not enforced across the repo.

Tasks:
- [x] [P1] Extend `TOOLS/critic.py` to detect artifacts written outside allowed roots.
- [x] [P1] Ensure enforcement aligns with the policy chosen in Lane A1.
- [x] [P1] Run the enforcement in CI and locally.

Exit conditions:
- Violations fail builds.

## E3. Codebook build check correctness (P1)

Problem:
- `TOOLS/codebook_build.py --check` can report false "up to date" results.

Tasks:
- [x] [P1] Make `--check` compare generated output against `CANON/CODEBOOK.md`.

Exit conditions:
- `--check` fails when codebook output drifts.

## E4. Hygiene (P2)

Problem:
- Documentation drift increases confusion for agents and humans.

Tasks:
- [x] [P2] Tidy `CANON/CHANGELOG.md` heading drift (e.g., duplicate headings).
- [x] [P2] Align `README.md` wording with current structure (e.g., "six layers" mismatch).

Exit conditions:
- Reduced confusion for agents and humans.

---

# Lane F: Catalytic computing (research -> integration) (P1 to P3)

This lane is optional until fundamentals above are stable.

Note: See `CONTEXT/research/Catalytic Computing/CATALYTIC_COMPUTING_FOR_AGS_REPORT.md` for the formal theory vs AGS analogy.
Note: See `CONTEXT/research/Catalytic Computing/CMP-01_CATALYTIC_MUTATION_PROTOCOL.md` for the draft engineering contract (not yet Canon).

## F1. Canonical note: "Catalytic Computing for AGS" (P1)

Deliverable:
- A dedicated document defining catalytic computing (formal) and the AGS analog (engineering), plus strict boundaries (metaphor vs implementation).

Tasks:
- [/] [P1] Write the canonical catalytic computing note with explicit boundaries and non-goals.

Exit conditions:
- Any agent can read it and understand what "catalytic compression" means without inventing details.

## F4. Lock Phase 7 catalytic swarm acceptance (P1)

Problem:
- Phase 7.3 is marked DONE, but its acceptance criteria remain informal and vulnerable to interpretation drift; agents need a precise, hash-based definition before final approval.

Tasks:
- [x] Ensure the Phase 7 Gate section explicitly lists “Phase 7.3: catalytic swarm execution elision (identical swarms skip execution; emit valid, verifiable proofs).”
- [x] Capture acceptance bullets that mention the top-level chain, tamper-resistant pipeline proofs, and the identical re-execution elision behavior.
- [x] Add a short, hash-focused clarification that defines “identical” (canonical swarm spec hash, ordered pipeline intent hashes, capability and policy hashes).
- [x] State that any elided re-execution must still emit a new swarm receipt/top-level chain, reference the prior pipeline proofs by hash, and pass verification even without execution.

Acceptance
- [x] A swarm run produces a top-level chain that binds each pipeline's proof.
- [x] Any missing or tampered pipeline proof fails the swarm verification.
- [x] Identical swarm re-execution elides all pipeline/skill/model execution and emits a valid swarm receipt.

Clarification: “Identical” is determined solely by the canonical swarm spec hash combined with the ordered pipeline intent hashes plus the capability/policy hashes that govern the run.

Elided re-executions must still emit a new swarm receipt and top-level chain, reference the prior pipeline proofs by hash, and pass verification end-to-end without executing the original pipeline/skill/model work.

---

# Research References (Non-Binding)

- `CONTEXT/research/iterations/2025-12-23-system1-system2-dual-db.md` - System 1 vs System 2 research model for cortex retrieval and governance ledger concepts.
- `CONTEXT/research/Catalytic Computing/CATALYTIC_COMPUTING_FOR_AGS_REPORT.md` - Formal catalytic computing theory and AGS analogy framing.
- `CONTEXT/research/Catalytic Computing/CMP-01_CATALYTIC_MUTATION_PROTOCOL.md` - Draft engineering protocol for catalytic mutation (non-Canon).

# Definition of Done (Global)

- [ ] [P0] `python TOOLS/critic.py` passes
- [ ] [P0] `python CONTRACTS/runner.py` passes
- [ ] [P0] CI workflows pass on PR and push (as applicable)
```

## `repo/MEMORY/ARCHIVE/planning/12-21-2025-12-00_AGS_MASTER_TODO.md`

```
<!-- CONTENT_HASH: 06501e404f5eb4a3b4b47c18b9e9776f46effee63986a146655ede97bd9c716c -->

# AGS Master TODO
_generated: 2025-12-21_

Legend:
- **P0** = must-fix (correctness / prevents drift / blocks release)
- **P1** = should-fix (stability, DX, scaling)
- **P2** = nice-to-have (later polish / optional power)

---

## Phase 1: Systemic fixes (current roadmap)
This section is strictly “make the existing roadmap real” and close the holes required for it to be true.

### v0.1 — Foundation (P0 heavy)
- [x] **P0** Finalize CANON as working spec (clear authority gradient, minimal ambiguity). _(Fixed: aligned authority gradient, added 4 new invariants, completed glossary with 9 new terms, added governance fixtures)_
- [x] **P0** Ensure **Cortex (shadow index)** exists and is part of the standard workflow (build + query) instead of raw filesystem scanning. _(Fixed: ran `cortex.build.py` to populate index)_
- [x] **P0** Ensure **basic skills exist** and are runnable with fixtures (at least one minimal skill end-to-end). _(Fixed: created `_TEMPLATE/run.py`, verified runner passes)_
- [x] **P0** Ensure **CONTRACTS runner + fixtures** enforce what the docs claim (fail on hard violations; warn only when explicitly allowed). _(Fixed: added actual fixtures for `no-raw-paths` governance check)_
- [x] **P1** Ensure **ADR and context templates** are present and referenced (ADR-*, REJECT-*, STYLE-*). _(Already present: ADR-000-template.md, REJECT-000-template.md, STYLE-000-template.md; updated INDEX.md to reference them)_

### v0.1 — Fixes that make v0.1 true (holes you already hit)
- [x] **P0** **Determinism leak:** make `CORTEX/_generated/cortex.json` deterministic (timestamp should not change outputs unless explicitly supplied as an input OR fixtures must ignore it). _(Fixed: replaced `datetime.utcnow()` with env var `CORTEX_BUILD_TIMESTAMP` or fixed placeholder)_
- [x] **P0** **Exception boundary for "no raw path access":** canon must explicitly carve out that **cortex builders may scan FS**, while **skills/agents must query** via `CORTEX/query.py`. _(Fixed: added INV-008 "Cortex builder exception" to INVARIANTS.md)_
- [x] **P1** **Legacy fallback deprecation story:** `CORTEX/query.py` still checks `BUILD/cortex.json`. Bless as transitional or set a removal version. _(Fixed: removed legacy BUILD/cortex.json fallback entirely — clean, no deprecation needed)_
- [x] **P0** **Artifact escape hatch fixture:** add a repo-wide test that fails if new files appear outside allowed output dirs (`CONTRACTS/_runs`, `CORTEX/_generated`, `MEMORY/LLM_PACKER/_packs`, and user-owned `BUILD`). _(Fixed: created `artifact-escape-hatch` skill with fixtures)_
- [x] **P1** Clarify what `CORTEX/_generated/**` ignore means: keep generated index untracked, but ensure it is always buildable and validated. _(Fixed: added "Generated files" section to CORTEX/README.md)_

### v0.2 — Reliability + enforcement
- [x] **P0** Add/finish a **critic gate** (pre-commit or CI) that checks diffs against canon + fixtures before changes land. _(Fixed: implemented real `critic.py` with 4 checks: CANON/CHANGELOG sync, skill fixtures, raw FS access, skill manifests)_
- [x] **P0** CI workflow: run contract runner + governance checks on PR/push. _(Fixed: enhanced `contracts.yml` to run cortex build, critic, fixtures, and escape hatch)_
- [x] **P1** Add **versioning + deprecation machinery** for token/grammar changes (even if initially "warn-only"). _(Fixed: implemented `lint_tokens.py` for glossary/deprecation checking, `check_canon_governance.py` for version consistency, cortex.build.py now reads version from VERSIONING.md)_

### v0.3 — Memory + pack discipline
- [x] **P0** Define persistent memory store + summarization workflow (tiering, promotion rules, what is mutable vs append-only). _(Fixed: created MEMORY/MEMORY_STORE.md documenting 3-tier memory model, promotion rules, and mutability constraints)_
- [x] **P0** Packer: **manifest integrity** (hashes, deterministic order) and verify-on-load. _(Fixed: added verify_manifest() and load_and_verify_pack() functions to packer.py)_
- [x] **P1** Delta packs: baseline state + diff logic + upgrade story (migration notes). _(Fixed: created MEMORY/DELTA_PACKS.md documenting diff logic, baseline management, and migration workflow)_
- [x] **P1** Migration skill(s) and fixtures for breaking changes. _(Fixed: created canon-migration skill with SKILL.md, run.py, validate.py, and fixtures)_

### v1.0 — Hardening + publishable template
- [x] **P0** Freeze core invariants and “what never changes” (or clearly define the ceremony to change them). _(Fixed: finalized 8 invariants, added `invariant-freeze` skill and check in `check_canon_governance.py`)_
- [x] **P1** Comprehensive docs + examples (how to extend, how to test, how to ship packs). _(Fixed: created `EXTENDING.md`, `TESTING.md`, `SHIPPING.md` guides under `CONTEXT/guides/`)_
- [x] **P1** Security hardening: define trust boundaries, what agents can and cannot touch by default. _(Fixed: enhanced `SECURITY.md` with explicit trust boundaries and approval requirements)_

---

## Phase 1: Packaging and navigation correctness (LLM_PACKER)
These are “drag-and-drop pack must be self-navigable.”

- [x] **P0** Ensure `meta/` is fully emitted into the pack **and** includes **both** machine-readable inventories:
  - `FILE_TREE.txt`
  - `FILE_INDEX.json` _(Fixed: both emitted in `write_pack_file_tree_and_index`)_
- [x] **P0** Ensure SPLIT pack includes **all** of `meta/` (not only the 00..07 docs). _(Fixed: `write_split_pack` now inlines `meta/` files into Section 07)_
- [x] **P1** Ensure `00_INDEX.md` read order references `repo/CORTEX/` and `repo/TOOLS/` (so agents know the maintenance tooling exists). _(Fixed: added reference in `AGS-00_INDEX.md` and `AGS-07_SYSTEM.md`)_
- [x] **P1** Ensure smoke test actually runs and fails when meta inventories are missing or stale. _(Fixed: `llm-packer-smoke` verifies existence of all meta files)_
- [x] **P1** Exclude `research/` directory by default to prevent chat log bloat. _(Done 2025-12-21)_
- [x] **P2** Add a “pack self-check” command: verify manifest, verify meta inventories match repo snapshot. _(Fixed: created `pack-validate` skill)_


---

## Phase 2: Research-driven expansions (add later; do not block Phase 1 unless you choose)
These are the “extra layers” from your merged research and multi-model reviews.

### Core “implement these 7” (high leverage)
- [x] **P0** Shadow cortex / index-first query layer (JSON or SQLite; make it primary). _(Fixed: implemented `CORTEX/query.py` and `cortex.build.py`)_
- [x] **P0** Skill contracts: `/SKILLS/*/SKILL.md`, `run.py`, `validate.py` for every skill. _(Fixed: standardized all skills with manifests, scripts, and fixtures)_
- [x] **P0** Critic loop automation: diff-aware canon + fixtures validator (pre-commit + CI). _(Fixed: implemented `critic.py` and integrated into GitHub Actions)_
- [x] **P0** Pack integrity: manifest + hashes, verify-on-load. _(Fixed: added manifest verification to `packer.py` and `pack-validate` skill)_
- [x] **P1** Explicit versioning: `canon_version` + `grammar_version` and mismatch behavior. _(Fixed: implemented version consistency checks and `lint_tokens.py`)_
- [x] **P1** Context continuity: ADR, rejected paths, style records as first-class. _(Fixed: provided templates and updated `CONTEXT/INDEX.md`)_
- [x] **P2** MCP seam: stage the interface; implement only when you actually need tool access. _(Full implementation 2025-12-21: all 10 tools, dynamic resources, Claude Desktop config)_

### Governance completeness (things that will hurt later if undefined)
- [x] **P1** Canon conflict resolution: what happens when canon contradicts itself; arbitration path. _(Created CANON/ARBITRATION.md 2025-12-21)_
- [x] **P1** Deprecation policy: how rules die safely; minimum windows for breaking changes. _(Created CANON/DEPRECATION.md 2025-12-21)_
- [x] **P1** Migration ceremony: deterministic migration skill + fixtures; formal compatibility break ritual. _(Created CANON/MIGRATION.md 2025-12-21)_
- [x] **P1** Canon bloat prevention: readability constraints; archiving/superseding rules. _(Added INV-009, INV-010 to INVARIANTS.md 2025-12-21)_

### MCP enhancements (extend governance to external AI clients)
- [x] **P2** `critic_run` tool: run TOOLS/critic.py via MCP so Claude can verify governance before acting. _(Implemented 2025-12-21)_
- [x] **P2** `adr_create` tool: create new ADRs with proper template via MCP. _(Implemented 2025-12-21)_
- [x] **P2** `commit_ceremony` tool: return ceremony checklist + staged files for Claude to assist with commits. _(Implemented 2025-12-21)_
- [ ] **P3** MCP audit logging: log all tool calls with timestamps for tracking.
- [x] **P3** MCP governance enforcement: tools refuse to execute if critic fails. _(Done 2025-12-21: Implemented `@governed_tool` in `server.py`)_
- [ ] **P3** Additional prompts: `skill_template`, `conflict_resolution`, `deprecation_workflow`.

### Operational safety and “emergency modes”
- [x] **P2** Emergency procedures as concrete CLI modes (reset, quarantine, isolation, crisis arbitration). _(Created CANON/CRISIS.md, TOOLS/emergency.py 2025-12-21)_
- [x] **P2** “Stewardship” structure: explicit human escalation path for canon-level failures. _(Created CANON/STEWARDSHIP.md 2025-12-21)_
- [x] **P2** “Constitutional license” concept (optional legal-protective layer). _(Done 2025-12-21: CANON/AGREEMENT.md, ADR-007)_

### Performance and scaling
- [x] **P1** Make “O(n×m) scanning” impossible by design (index-first non-optional). _(Fixed: implemented SQLite Cortex with O(1) lookups)_
- [x] **P2** Incremental indexing + freshness/TTL rules (avoid stale cortex). _(Done 2025-12-21: Incremental mtime check, prune deletions, unique IDs)_

### Token economics
- [x] **P2** **Codebook & Compression**: Expanded codebook to 37 entries, bidirectional symbolic compression via `TOOLS/compress.py`, and stable IDs (`@C1`, `@M7`). _(Done 2025-12-21)_
- [x] **P2** Tokenizer test harness: measure real tokenization against target models
    - `TOOLS/tokenizer_harness.py`: Real token measurement for GPT-4 (cl100k) and GPT-4o/o1 (o200k).
    - `MEMORY/LLM_PACKER/Engine/packer.py`: Integrated `tiktoken` for 100% accurate token counts in `CONTEXT.txt`.

### Chat-derived mechanics deltas (small, buildable, low-bloat)
- [ ] **P2** Compress the LLM packer if possible.
- [x] **P1** Research activity cache: persist summaries for URLs to avoid redundant browsing (`TOOLS/research_cache.py`). _(Done 2025-12-21)_

---

## Research audit

- [x] **P2** Research completeness audit _(Completed 2025-12-21: All 9 research docs reviewed, items extracted below)_
  - Read every document under `CONTEXT/research/` (or your research source of truth)
  - Extract what should become: CANON rules, CONTRACT checks, SKILLS, or MAPS/entrypoints
  - Leave the rest as non-binding reference (do not promote by default)

---

## Research-derived tasks (extracted 2025-12-21)

These items were identified from the research folder audit. They are not duplicates of the above.

### Bootstrap and Context Tools
- [x] **P1** Genesis Prompt (`CANON/GENESIS.md`): A bootstrap prompt that solves the chicken-and-egg problem. Ensures agents load CANON first before any other instruction. _(Created 2025-12-21)_
- [x] **P1** Context Query Tool (`CONTEXT/query-context.py`): CLI to search decisions by tag, status, review date. Enables agents to query "why did we decide X?" without full file scans. _(Created 2025-12-21)_
- [x] **P2** Context Review Tool (`CONTEXT/review-context.py`): Flags overdue ADR reviews. Keeps decision records from going stale. _(Created 2025-12-21)_

### Data Integrity and Validation
- [x] **Provenance Headers**: Utility + `meta/PROVENANCE.json` for LLM packs (2025-12-21)
- [x] **Precise Tokenization**: Integrated `tiktoken` into `packer.py` for accurate context reports (2025-12-21)
- [x] **P2** Schema Validation for "Law-Like" Files: Implement JSON Schema validation for canon, skills, context records, and cortex index. Contracts enforce schema validity. _(Done 2025-12-21)_
```

## `repo/MEMORY/ARCHIVE/planning/12-21-2025-12-00_ROADMAP.md`

```
<!-- CONTENT_HASH: 2e52d778af4b5ae1a578709ad770a21d7ece956e9d921501fa628c8bd298e8f2 -->

# Roadmap

This file outlines the high-level milestones for developing the Agent Governance System (AGS). Because AGS is intended as a reusable kernel for many projects, the roadmap focuses on capabilities rather than application-specific features.

## v0.1 - First usable kernel ✅

- [x] Finalise the canon: write the constitutional contract, define invariants, versioning policy and glossary.
- [x] Implement the shadow cortex: generate `CORTEX/_generated/cortex.db` and provide a query API.
- [x] Define and implement basic skills: file reading, querying the cortex, and simple write operations under strict controls.
- [x] Establish the runner and initial fixtures: enforce no raw path access, determinism and canonical output rules.
- [x] Provide example ADRs and context records to demonstrate decision compounding.

## v0.2 - Governance automation ✅

- [x] Add critic scripts to automatically lint canon, skills and fixtures.
- [x] Integrate continuous integration workflows for running the runner and critics on pull requests.
- [x] Implement versioning and deprecation machinery for tokens.

## v0.3 - Extended memory and indexing ✅

- [x] Introduce a persistent memory store and summarisation tools for long running agents.
- [x] Support incremental packer updates and manifest integrity checking.
- [x] Provide migration skills for older versions of the canon.

## v1.0 - Stable release ✅

- [x] Freeze the core canon and invariants.
- [x] Publish comprehensive documentation and examples.
- [x] Harden security: least privilege execution, sandboxing and cryptographic provenance.

## v1.1 - Maintenance & Refinement

- [x] Complete "meta in the split" logic for LLM_PACKER.
- [x] Refine "O(1) Cortex" by implementing a proper indexing database (SQLite).
- [x] Implement Genesis Prompt (`CANON/GENESIS.md`): Bootstrap prompt that ensures agents load CANON first.
- [x] Add Context Query Tool (`CONTEXT/query-context.py`): CLI to search decisions by tag, status, review date.
- [x] Add Context Review Tool (`CONTEXT/review-context.py`): Flags overdue ADR reviews.

## v1.2 - Protocol Integration & Validation

- [x] Implement initial MCP (Model Context Protocol) seams for external tool access. _(Done 2025-12-21)_
- [x] Add "Crisis Mode" procedures for automated isolation in case of governance failure. _(Done 2025-12-21)_
- [x] Add provenance headers to all generated files (generator version, input hashes, timestamp). _(Pack-level done 2025-12-21)_
- [x] Implement JSON Schema validation for canon, skills, context records, and cortex index. _(Done 2025-12-21)_

## v2.0 - Advanced Autonomy

- [x] Advanced conflict resolution: arbitration for contradictory canon rules. _(Done 2025-12-21)_
- [x] Constitutional license: formalized legal-protective layer for agentic systems. _(Done 2025-12-21)_
- [x] Reversible token economics: lossless compression for audit-ready handoffs. _(Done 2025-12-21)_
- [x] Automated "Stewardship" alerts for human escalation when canon-bound loops fail. _(Done 2025-12-21)_
- [x] Canon codebook addressing: stable IDs (`@C1`, `@M7`) so prompts reference IDs not prose. _(Done 2025-12-21)_
```

## `repo/MEMORY/ARCHIVE/planning/12-27-2025-14-03_AGS_3.0_ROADMAP.md`

```
<!-- CONTENT_HASH: 4be31f6ec07a43049a1d5212d74baf1e66e00e6614c5b4dc1c06e107669301cb -->

# AGS Roadmap (Superseded)

**NOTE: This document is superseded by `AGS_ROADMAP_MASTER.md`.**
version: 0.1
last_updated: 2025-12-23
scope: Agent Governance System (repo + packer + cortex)
style: agent-readable, task-oriented, minimal ambiguity
---

# Purpose

Make the repo easy for any agent to navigate, verify, and safely modify, while keeping context cost low (LITE packs) and keeping correctness high (contracts, critic, CI).

This roadmap assumes your current direction:
- Text outranks code (Canon, AGENTS, maps) and is the primary contract.
- Packs have profiles (FULL vs LITE), with LITE optimized for navigation and governance, not full restoration.
- A Cortex (index database) is the primary navigation layer.
- Determinism and “no surprise writes” are non-negotiable.

# Current state snapshot (what you already have)

From the SPLIT_LITE pack pointers, the system expects these major components to exist in-repo:
- Governance: `repo/AGENTS.md`, `repo/CANON/*`
- Maps: `repo/MAPS/ENTRYPOINTS.md`
- Contracts: `repo/CONTRACTS/runner.py`
- Skills: `repo/SKILLS/*/SKILL.md`
- Tools: `repo/TOOLS/critic.py`
- Cortex interface: `repo/CORTEX/query.py`
- Packer engine: `repo/MEMORY/LLM_PACKER/Engine/packer.py`
- MCP seam: `repo/MCP/server.py`

(Those pointers are present in your LITE pack index and root stubs.)

# Roadmap structure

Work is grouped into lanes with explicit exit conditions.

Legend:
- P0: contradictions, violations, missing enforcement
- P1: correctness gaps that will cause drift
- P2: hygiene, clarity, polish

---

# Lane A: Governance coherence (P0)

## A1. Resolve “artifact roots vs logging” contradiction (P0)

Problem:
- Canon says generated artifacts must only be written under approved roots.
- Other files reference or write to `LOGS/` and `MCP/logs/`, which violates the contract unless those roots are explicitly allowed.

Tasks:
- Choose ONE canonical policy:
  1) Allow logging under an approved artifact root only (recommended), OR
  2) Expand allowed roots to include `LOGS/` and `MCP/logs/` (increases drift risk).
- Update Canon references to match policy.
- Update tools that write logs to comply (or route logs via the existing redirect entrypoint).

Exit conditions:
- `TOOLS/critic.py` enforces the chosen output-root policy.
- `CONTRACTS/runner.py` passes.
- CI passes.

## A2. Resolve Canon vs AGENTS context write rule (P0)

Problem:
- Canon and AGENTS disagree on whether agents may modify context.

Task:
- Amend Canon wording so it forbids editing existing records but allows appending new records under an explicit `CONTEXT/*` area.

Exit conditions:
- No higher-authority file contradicts a lower-authority file on this rule.
- Critic includes a check for illegal edits to existing context records.

---

# Lane B: Pack profiles and symbolic indexes (P0 to P1)

## B1. Implement `--profile lite` in packer (P0)

Tasks:
- Add a LITE profile to `MEMORY/LLM_PACKER/Engine/packer.py`:
  - FULL output unchanged.
  - LITE emits governance + maps + indexes + pointers, omits most implementation bodies.
- Emit LITE meta outputs:
  - `meta/LITE_ALLOWLIST.json`
  - `meta/LITE_OMITTED.json`
  - `meta/LITE_START_HERE.md`
  - `meta/SKILL_INDEX.json`
  - `meta/FIXTURE_INDEX.json`
  - `meta/CODEBOOK.md`
  - `meta/CODE_SYMBOLS.json`
- Add smoke validation that asserts the above exist for LITE packs.

Exit conditions:
- `packer.py --profile lite` produces a pack that an agent can navigate without repo access.
- A validator fails fast if LITE required meta is missing.

## B2. Determinism contract for packs (P1)

Tasks:
- Document which files are deterministic and which are timestamped.
- Ensure timestamps do not break cache keys (use content hashes as primary identity).
- Add `canon_version` and `grammar_version` fields and define mismatch behavior.

Exit conditions:
- Two LITE packs generated from the same repo state have identical content-hash inventories (except explicitly allowed timestamp fields).

---

# Lane C: Index database (Cortex) as primary navigation (P0 to P1)

This is the “every section indexed and summarized” requirement.

## C1. Define the Cortex schema (P0)

Minimum viable tables:
- files: path, sha, size, type, pack_profile_visibility
- sections: file_path, header_level, anchor_id, start_line, end_line, title
- summaries: section_anchor_id, summary_text, summary_version, model_info (optional)
- pointers: section_anchor_id -> (related sections, skills, contracts, canon rules)

Exit conditions:
- Schema is documented in `CORTEX/SCHEMA.md` (or equivalent).
- A single CLI command can build the DB from a repo checkout.

## C2. Build the indexer (P0)

Tasks:
- Implement an indexer that:
  - Parses markdown headings and stable anchors.
  - Builds `meta/FILE_INDEX.json` and `meta/SECTION_INDEX.json`.
  - Optionally emits per-file comment markers only if policy allows it (do not spam source files by default).

Exit conditions:
- Index build is deterministic.
- Index build does not modify authored files unless explicitly enabled.

## C3. Summarization layer (P1)

Tasks:
- Add a summarizer (offline or remote) that writes summaries into the DB, not into source files.
- Define a max summary length per section and a “summary freshness” policy.
- Provide a query interface in `CORTEX/query.py`:
  - `find(section_title | symbol | path)`
  - `get(section_anchor_id)`
  - `neighbors(section_anchor_id)` (pointers graph)

Exit conditions:
- “Read order” navigation works from the DB without opening many files.
- Summaries are versioned and can be regenerated safely.

---

# Lane D: Skills library expansion (P1)

## D1. Formalize skill contracts (P1)

Tasks:
- Each skill has:
  - `SKILL.md` (what, inputs, outputs, invariants)
  - `version.json`
  - `fixtures/` (positive and negative tests)
- Runner can execute fixtures.

Exit conditions:
- `CONTRACTS/runner.py` can run skill fixtures in CI.

## D2. Add the “dev browser” skill (your note) (P1)

Goal:
- A local web UI that browses Cortex indexes (files, sections, summaries) and lets you restructure based on tags, folders, links, and graph relations.

Minimum deliverables:
- Read-only browsing first (no mutations).
- Export plans (a migration plan file) rather than direct edits.
- Optional: apply plan via a separate “migration skill” that is deterministic and fixture-tested.

Exit conditions:
- You can answer: “Where is X?” and “What connects to X?” instantly via the UI.
- Applying a plan is opt-in and audited.

---

# Lane E: CI and enforcement (P1 to P2)

## E1. Fix or remove broken workflow (P1)

Tasks:
- Either implement `TOOLS/critic.py --diff`, or update workflow to run supported commands.
- Ensure workflows install dependencies and set up Python.

Exit conditions:
- Workflows reflect reality and are not decorative.

## E2. Output-root enforcement (P1)

Tasks:
- Extend critic to detect artifacts written outside allowed roots.
- Make it run in CI and locally.

Exit conditions:
- Violations fail builds.

## E3. Codebook build check correctness (P1)

Tasks:
- Ensure `TOOLS/codebook_build.py --check` actually compares generated content against the canonical output.

Exit conditions:
- No false “up to date” results.

## E4. Hygiene (P2)

Tasks:
- Fix `CANON/CHANGELOG.md` heading drift.
- Align README descriptions with actual structure.

Exit conditions:
- Reduced confusion for agents and humans.

---

# Lane F: Catalytic computing (research -> integration) (P1 to P2)

This lane is optional until the fundamentals above are stable. It is still worth writing now so agents do not drift when you revisit it.

## F1. Canonical note: “Catalytic Computing for AGS” (P1)

Deliverable:
- A dedicated document that defines catalytic computing (formal) and the AGS analog (engineering), plus strict boundaries (what is metaphor vs what is implemented).

Exit conditions:
- Any agent can read it and understand what you mean by “catalytic compression” without inventing stuff.

## F2. Prototype: “Catalytic Scratch Layer” (P2)

Goal:
- Enable high-impact operations (index build, refactor planning, pack generation) using huge disk state as scratch, while guaranteeing restoration.

Implementation sketch:
- Use a copy-on-write workspace:
  - Git worktree or temporary checkout, or overlay filesystem.
  - Produce a patch set + restore plan.
  - Only commit curated outputs.

Exit conditions:
- A full run ends with the repo in a clean git state (no untracked surprises), while still producing outputs under allowed roots.

## F3. Prototype: “Catalytic Context Compression” (P2)

Goal:
- Keep LITE packs minimal while enabling deep recovery when needed.

Implementation sketch:
- Store large material in a content-addressed cache (hash keyed).
- LITE pack includes:
  - pointers, indexes, and retrieval instructions
  - no large bodies
- FULL pack can be synthesized by retrieving bodies by hash.

Exit conditions:
- LITE pack remains small and stable.
- FULL pack is reconstructible.

---

# Immediate next steps (recommended order)

1) Finish Lane A (P0) so the contract is self-consistent.
2) Finish Lane B (P0) so LITE packs are real and validated.
3) Finish Lane C (P0) so “every section indexed” is actually true via Cortex, not vibes.
4) Only then expand Skills and UI (Lane D).
5) Add CI polish (Lane E).
6) Start catalytic lane (Lane F) when the base is stable.
```

## `repo/MEMORY/DELTA_PACKS.md`

````
<!-- CONTENT_HASH: fdf194ffd7481bcbcdc8b4d1f2a16fd1d4b6e33975a5ed7f3764081b3047d6eb -->

# Delta Packs

This document describes the delta pack functionality for incremental updates.

## Overview

Delta packs contain only files that changed since the last baseline, plus anchor files that provide essential context. This reduces pack size when only a subset of the repository has changed.

## How It Works

```
┌─────────────────────────────────────────────────────────────────┐
│                     DELTA PACK FLOW                              │
├─────────────────────────────────────────────────────────────────┤
│  1. Load baseline manifest from _state/baseline.json            │
│  2. Build current manifest (hashes + sizes for all files)       │
│  3. Compare: find changed, added, and deleted files             │
│  4. Include: changed files + anchor files (always included)     │
│  5. Record: deleted_paths in PACK_INFO.json                     │
│  6. Update: save current manifest as new baseline               │
└─────────────────────────────────────────────────────────────────┘
```

## Baseline State

The baseline is stored at:
```
MEMORY/LLM_PACKER/_packs/_state/baseline.json
```

Structure:
```json
{
  "canon_version": "0.1.5",
  "files": [
    {"path": "CANON/CONTRACT.md", "hash": "abc123...", "size": 1234},
    ...
  ]
}
```

## Diff Logic

A file is considered **changed** if:
- It exists in current but not in baseline (new file)
- Its hash differs from baseline
- Its size differs from baseline

A file is considered **deleted** if:
- It exists in baseline but not in current

## Anchor Files

These files are **always included** in delta packs to ensure context:
- `AGENTS.md`
- `README.md`
- `CONTEXT/archive/planning/INDEX.md`
- `CANON/CONTRACT.md`
- `CANON/INVARIANTS.md`
- `CANON/VERSIONING.md`
- `MAPS/ENTRYPOINTS.md`
- `CONTRACTS/runner.py`
- `MEMORY/packer.py`

## Usage

### Create a delta pack:
```bash
python MEMORY/packer.py --mode delta --combined
```

### Create a full pack (resets baseline):
```bash
python MEMORY/packer.py --mode full --combined
```

### PowerShell:
```powershell
./MEMORY/LLM_PACKER/pack.ps1 -Mode delta
```

## Pack Metadata

Delta packs include `meta/PACK_INFO.json`:
```json
{
  "mode": "delta",
  "canon_version": "0.1.5",
  "repo_digest": "abc123def456...",
  "included_paths": ["CANON/CHANGELOG.md", "SKILLS/new-skill/run.py", ...],
  "deleted_paths": ["SKILLS/old-skill/run.py", ...]
}
```

## Migration Notes

### Upgrading from v0.1.x to v0.1.5

No structural changes. Delta packs from 0.1.x are compatible with 0.1.5.

### Future Major Version Upgrades

When upgrading across major versions:

1. **Create a full pack** before upgrading (captures baseline)
2. **Run migration skill** to transform pack contents
3. **Create new baseline** after migration completes
4. **Verify pack integrity** using `verify_manifest()`

### Baseline Reset

To reset the baseline (start fresh):
```bash
rm MEMORY/LLM_PACKER/_packs/_state/baseline.json
python MEMORY/packer.py --mode full
```

## Integrity Verification

After loading a delta pack, verify integrity:
```python
from MEMORY.LLM_PACKER.Engine.packer import verify_manifest

is_valid, errors = verify_manifest(pack_dir)
if not is_valid:
    print("Pack corrupted:", errors)
```
````

## `repo/MEMORY/LLM_PACKER/CHANGELOG.md`

```
<!-- CONTENT_HASH: ad1b23c844c456cfb6ecca2c57a35ddc825ff317bc644cdf9566952eaf1e1500 -->

# Changelog

All notable changes to the LLM Packer will be documented in this file.

### 2026-01-03 — 1.3.3
- Added distinct Internal vs External archives (Internal stays inside the pack; External zips the whole pack under `_packs/_archive/`)
- Pack rotation deletes the previous unzipped pack only after its External Archive validates

### 2026-01-03 — 1.3.2
- Removed `catalytic-dpt` scope and the `Engine/2-CAT-PACK.cmd` launcher
- AGS scope excludes `THOUGHT/LAB/**`; LAB scope packs `THOUGHT/LAB/**` only

### 2025-12-27 — 1.3.1
**Modular Infrastructure Refactor & Strict Structure Enforcement**

*   **Modular Architecture**: Split monolithic script into `Engine/packer/` module with dedicated `core`, `split`, `lite`, and `archive` components.
*   **Strict Output Structure**: Packs now strictly contain `FULL/`, `SPLIT/`, `LITE/`, and `archive/`. `meta/` and `repo/` folders are now exclusively located inside `archive/pack.zip`.
*   **Archive Enhancements**:
    *   `pack.zip` contains `meta/` and `repo/`.
    *   Sibling `.txt` files generated in `archive/` for all `FULL` and `SPLIT` outputs.
    *   Archive sibling filenames are strictly scope-prefixed (e.g., `AGS-SPLIT-00_INDEX.txt`).
    *   implemented safe zip writing (write to `.tmp` then atomic move) to resolve Windows file locking issues.
*   **Naming & Organization**:
    *   Root shortcuts numbered for organization: `1-AGS-PACK.lnk`, `2-CAT-PACK.lnk`, `2-LAB-PACK.lnk`.
    *   Internal pack directories follow `{scope}-pack-{timestamp}` format.
    *   LAB scope refactored to use key `lab` and output folder `lab-pack-{timestamp}`.
*   **Scope & Context**:
    *   Added `lab` scope.
    *   `PROVENANCE.json`, `PACK_INFO.json`, and `REPO_OMITTED_BINARIES.json` added to meta.
    *   Context file support.
*   **Fixes**:
    *   Fixed treemap generation and placement.
    *   Fixed `LITE` output generation for all scopes.
    *   Resolved recursive path inclusion bugs.

### 2025-12-25 — 1.3.0
- Added `--scope catalytic-dpt` (packs only `CATALYTIC-DPT/**` with scope-specific SPLIT/COMBINED prefixes)
- Added per-scope baseline state files under `MEMORY/LLM_PACKER/_packs/_system/_state/`
- Changelog headings now show timestamp first, then version

### 2025-12-23 — 1.2.0
- Added LITE profile with symbolic indexes and allowlist/exclude rules (ADR-013)
- Added `DETERMINISM.md` defining the pack determinism contract
- Added optional `COMBINED/SPLIT_LITE/` output for discussion-first loading
- Added per-payload token reporting in `meta/CONTEXT.txt` and terminal output
- Updated Windows packer defaults (no combined/zip by default; SPLIT_LITE included)
- Added `PACK_PROFILE` env override and `-SplitLite` / `-NoCombined` / `-NoZip` flags

### 2025-12-21 — 1.1.0
- Added `AGS-` prefix to all output files
- Refactored core logic to `Engine/` subfolder
- Renamed directory from `LLM-PACKER` to `LLM_PACKER`
- Added Official Blue Launcher with icon
- Added token estimation and `CONTEXT.txt` report
- Added pack size warnings for large contexts
- Added compression metrics
- Added `verify_manifest()` for integrity checking
- Fixed `read_canon_version()` regex bug

### Initial — 1.0.0
- Full and delta pack modes
- Combined markdown output
- Split pack sections
- Manifest with SHA256 hashes
- ZIP archive support

### 2025-12-20 — Pre-1.0
- Moved output root to `MEMORY/LLM_PACKER/_packs/`
- Relocated tooling to `MEMORY/LLM_PACKER/` from root/memory
- Removed legacy `MEMORY/_packs/` directory
```

## `repo/MEMORY/LLM_PACKER/DETERMINISM.md`

```
<!-- CONTENT_HASH: 2835948d02cfe366c4b5b97a83e6632ed1167264cd01362d3f30d7c2b2653348 -->

# Pack Determinism Contract

This document records the **B2 determinism contract** for AGS memory packs. The goal is to ensure that packs built from the same repo state are reproducible, traceable, and reject mismatched governance versions.

## Identity & Cache Keys

- The primary cache key is the `manifest_digest` derived from `meta/REPO_STATE.json`. Only file content hashes, sizes, and paths feed the digest; timestamps are ignored.
- The digest determines the default pack directory name (`llm-pack-<scope>-<digest[:12]>`).

## Deterministic Outputs

The following metadata files are deterministic by construction:

1. `meta/FILE_INDEX.json` – sorted list of `path`, `hash`, `size`.
2. `meta/FILE_TREE.txt` – deterministic tree text generated from the same file listing.
3. `meta/REPO_STATE.json` – manifest with `canon_version`, `grammar_version`, and sorted `files`.
4. `meta/PACK_INFO.json` – reports `scope`, `title`, `stamp`, and `version`.
5. `NAVIGATION/CORTEX/_generated/SECTION_INDEX.json` and `NAVIGATION/CORTEX/_generated/SUMMARY_INDEX.json` (via repository upstream) are regenerated deterministically before packaging.
6. `LITE/PACK_MANIFEST.json` – deterministic CAS-addressed manifest (P.2), with entries sorted by `path`.
7. `LITE/RUN_REFS.json` – deterministic refs for run records (P.2).

Some artifacts (e.g., `meta/BUILD_TREE.txt` and optional `FULL/*` outputs) may include derived stats. They are explicitly **not** part of the digest and should not be used for cache keys.

## Version Fields & Mismatch Behavior

- `canon_version` is read from `LAW/CANON/VERSIONING.md`.
- `grammar_version` is currently hard-coded to `1.0`. It describes the packing grammar (what files are included, hash formats, etc.).
- When consuming a pack, verify both versions:
  - If `meta/REPO_STATE.json` `canon_version` differs from the repo’s `canon_version`, rebuild or reject the pack to avoid applying stale governance rules.
  - If `meta/REPO_STATE.json` `grammar_version` differs from `1.0`, treat the pack as incompatible and trigger a regeneration that understands the newer grammar.

Pack creation writes `canon_version` to `meta/REPO_STATE.json` and includes a `version` field in `meta/PACK_INFO.json` for quick inspection.

## Observable Variance

- The only permitted variance between packs from identical repo states is in files that are excluded from the digest (e.g., `meta/PROVENANCE.json`, optional `FULL/*` outputs, and optional ZIP archives). These are safe because lookup & verification use the deterministic metadata listed above.
- If additional deterministic files are added, update this document and the manifest digest to include them explicitly.
```

## `repo/MEMORY/LLM_PACKER/Engine/1-AGS-PACK.cmd`

```
@echo off
setlocal
cd /d "%~dp0"

REM One-click packer. Output goes to MEMORY/LLM_PACKER/_packs/
if "%~1"=="" (
  REM Default: generate a pack folder with FULL/ + SPLIT/ + LITE/ plus:
  REM - Internal Archive: <pack>/archive/pack.zip + scope-prefixed .txt siblings
  REM - External Archive: MEMORY/LLM_PACKER/_packs/_archive/<pack_name>.zip
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pack.ps1" -Profile full -SplitLite -Combined -Zip
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pack.ps1" %*
)

echo.
echo Done.
pause
```

## `repo/MEMORY/LLM_PACKER/Engine/2-LAB-PACK.cmd`

```
@echo off
setlocal
cd /d "%~dp0"

REM One-click packer for THOUGHT/LAB only.
REM Output goes to MEMORY/LLM_PACKER/_packs/ and external zips go to MEMORY/LLM_PACKER/_packs/_archive/<pack_name>.zip

if "%~1"=="" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pack.ps1" -Scope lab -Profile full -SplitLite -Combined -Zip
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pack.ps1" -Scope lab %*
)

echo.
echo Done.
pause
```

## `repo/MEMORY/LLM_PACKER/Engine/pack.ps1`

```
param(
  [ValidateSet("ags", "lab")]
  [string]$Scope = "ags",
  [string]$OutDir = "",
  [ValidateSet("full", "delta")]
  [string]$Mode = "full",
  [ValidateSet("full", "lite")]
  [string]$Profile = "full",
  [string]$Stamp = "",
  [switch]$Zip,
  [switch]$NoZip,
  [switch]$Combined,
  [switch]$NoCombined,
  [switch]$SplitLite
)

$ErrorActionPreference = "Stop"

function Get-RepoRoot {
  $packerParentDir = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
  return (Resolve-Path (Split-Path -Parent $packerParentDir)).Path
}

$repoRoot = Get-RepoRoot
$pythonModule = "MEMORY.LLM_PACKER.Engine.packer"

if ($Stamp -eq "") { $Stamp = (Get-Date).ToString("yyyy-MM-dd_HH-mm-ss") }

$envProfile = $env:PACK_PROFILE
if ($Profile -eq "full" -and -not [string]::IsNullOrWhiteSpace($envProfile)) {
  $envProfileLower = $envProfile.Trim().ToLowerInvariant()
  if ($envProfileLower -in @("full", "lite")) {
    $Profile = $envProfileLower
  }
}

$zipEnabled = $true
$combinedEnabled = $true
$splitLiteEnabled = $false

if ($Profile -eq "lite") {
  $zipEnabled = $false
  $combinedEnabled = $false
  $splitLiteEnabled = $true
}

if ($PSBoundParameters.ContainsKey("Zip")) { $zipEnabled = $true }
if ($PSBoundParameters.ContainsKey("NoZip")) { $zipEnabled = $false }

if ($PSBoundParameters.ContainsKey("Combined")) { $combinedEnabled = $true }
if ($PSBoundParameters.ContainsKey("NoCombined")) { $combinedEnabled = $false }

if ($PSBoundParameters.ContainsKey("SplitLite")) { $splitLiteEnabled = $true }

if ($OutDir -eq "") {
  if ($Scope -eq "lab") {
    $OutDir = "MEMORY/LLM_PACKER/_packs/lab-pack-$Stamp"
  } else {
    $OutDir = "MEMORY/LLM_PACKER/_packs/ags-pack-$Stamp"
  }
}

$args = @(
  "python",
  "-m",
  $pythonModule,
  "--scope", $Scope,
  "--mode", $Mode,
  "--profile", $Profile,
  "--out-dir", $OutDir
)

$args += @("--stamp", $Stamp)
if ($zipEnabled) { $args += "--zip" }
if ($combinedEnabled) { $args += "--combined" }
if ($splitLiteEnabled) { $args += "--split-lite" }

Write-Host "Running: $($args -join ' ')"
Push-Location $repoRoot
try {
  & $args[0] $args[1..($args.Count - 1)]
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} finally {
  Pop-Location
}
```

## `repo/MEMORY/LLM_PACKER/Engine/packer/__init__.py`

```
"""
LLM Packer - Modular implementation (Phase 1).

Output structure (canonical):
- FULL/     : Single-file combined outputs
- SPLIT/    : Chunked section files
- LITE/     : Compressed high-signal outputs
- Internal Archive (inside pack): `<pack>/archive/pack.zip` + scope-prefixed `.txt` siblings
- External Archive (outside pack): `MEMORY/LLM_PACKER/_packs/_archive/<pack_name>.zip`

FORBIDDEN: COMBINED/, FULL_COMBINED/, SPLIT_LITE/
"""

from .core import (
    PackScope,
    SCOPE_AGS,
    SCOPE_LAB,
    SCOPES,
    hash_file,
    read_text,
    estimate_tokens,
    build_state_manifest,
    manifest_digest,
    verify_manifest,
    baseline_path_for_scope,
    load_baseline,
    write_json,
    make_pack,
    PROJECT_ROOT,
)

from .cli import main

__all__ = [
    "PackScope",
    "SCOPE_AGS",
    "SCOPE_LAB",
    "SCOPES",
    "hash_file",
    "read_text",
    "estimate_tokens",
    "build_state_manifest",
    "manifest_digest",
    "verify_manifest",
    "baseline_path_for_scope",
    "load_baseline",
    "write_json",
    "make_pack",
    "PROJECT_ROOT",
    "main",
]
```

## `repo/MEMORY/LLM_PACKER/Engine/packer/__main__.py`

```
if __name__ == "__main__":
    from .cli import main
    import sys
    sys.exit(main())
```

## `repo/MEMORY/LLM_PACKER/Engine/packer/archive.py`

```
"""
Archive generation (Phase 1).

Output structure:
- Internal Archive (inside the pack folder):
  - <pack_dir>/archive/pack.zip (contains ONLY meta/ and repo/)
  - <pack_dir>/archive/{SCOPE}-FULL*.txt (scope-prefixed siblings)
  - <pack_dir>/archive/{SCOPE}-SPLIT-*.txt
- External Archive (top-level, outside the pack folder):
  - MEMORY/LLM_PACKER/_packs/_archive/<pack_name>.zip (zips the entire final pack folder)
- etc.

FORBIDDEN: 
- Including FULL/, SPLIT/, LITE/ inside the zip
- Any non-scope-prefixed filenames in archive/
- Any reference to COMBINED/, FULL_COMBINED/, SPLIT_LITE/
"""
from __future__ import annotations

import shutil
import zipfile
from pathlib import Path
from typing import List, Sequence

from .core import PackScope, PACKS_ROOT, read_text

def _iter_files_under(base: Path) -> List[Path]:
    if not base.exists():
        return []
    paths: List[Path] = []
    for p in base.rglob("*"):
        if p.is_file():
            paths.append(p)
    return sorted(paths, key=lambda p: p.as_posix())

def _write_zip(zip_path: Path, *, pack_dir: Path, roots: Sequence[Path]) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Write to a temp file first to avoid locking if process failed previously
    temp_zip = zip_path.parent / f"{zip_path.name}.tmp"
    if temp_zip.exists():
        temp_zip.unlink()
    
    if zip_path.exists():
        try:
            zip_path.unlink()
        except OSError:
            # If we can't delete it, it might be locked. 
            # We will try to overwrite it via move, or fail loudly if we can't.
            pass

    with zipfile.ZipFile(temp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for root in roots:
            for file_path in _iter_files_under(root):
                # Always root at pack root relative path (e.g. repo/foo.txt)
                arcname = file_path.relative_to(pack_dir).as_posix()
                zf.write(file_path, arcname)
    
    # Atomic-ish move
    shutil.move(str(temp_zip), str(zip_path))

def write_pack_internal_archives(
    pack_dir: Path,
    *,
    scope: PackScope,
) -> None:
    """
    Write the Internal Archive under `<pack_dir>/archive/`.
    """
    internal_archive_dir = pack_dir / "archive"
    internal_archive_dir.mkdir(parents=True, exist_ok=True)

    # 1. Create canonical pack.zip (meta/ + repo/ only)
    pack_zip = internal_archive_dir / "pack.zip"
    _write_zip(pack_zip, pack_dir=pack_dir, roots=[pack_dir / "repo", pack_dir / "meta"])

    # 2. Generate sibling text files from FULL/ outputs
    # Must use scope prefix
    full_dir = pack_dir / "FULL"
    if full_dir.exists():
        for p in sorted(full_dir.glob("*")):
            if not p.is_file():
                continue
            
            # If filename already has scope prefix, keep it. 
            # If not, strictly enforce it.
            name = p.name
            if not name.startswith(f"{scope.file_prefix}-"):
                name = f"{scope.file_prefix}-{name}"
            
            # Ensure .txt extension for archive
            if name.lower().endswith(".md"):
                name = str(Path(name).with_suffix(".txt"))
            
            dest = internal_archive_dir / name
            shutil.copy2(p, dest)

    # 3. Generate sibling text files from SPLIT/ outputs
    split_dir = pack_dir / "SPLIT"
    if split_dir.exists():
        for p in sorted(split_dir.glob("*.md")):
            # Convert .md to .txt for archive sibling
            txt_name = p.stem + ".txt"
            
            # Ensure scope prefix
            # Ensure scope prefix and inject SPLIT
            stem = p.stem
            if stem.startswith(f"{scope.file_prefix}-"):
                if "SPLIT" not in stem:
                    # Inject SPLIT likely after prefix
                    rest = stem[len(scope.file_prefix)+1:] # skip prefix and dash
                    txt_name = f"{scope.file_prefix}-SPLIT-{rest}.txt"
                else:
                    txt_name = f"{stem}.txt"
            else:
                 txt_name = f"{scope.file_prefix}-SPLIT-{stem}.txt"
                
            dest = internal_archive_dir / txt_name
            dest.write_text(read_text(p), encoding="utf-8")


def write_pack_external_archive(pack_dir: Path, *, scope: PackScope) -> Path:
    """
    Write the External Archive zip under `MEMORY/LLM_PACKER/_packs/_archive/`.

    The external zip contains the entire final pack folder (FULL/SPLIT/LITE/archive).
    """
    external_dir = PACKS_ROOT / "_archive"
    external_dir.mkdir(parents=True, exist_ok=True)
    zip_path = external_dir / f"{pack_dir.name}.zip"

    # Create zip deterministically (sorted by path).
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    temp_zip = zip_path.parent / f"{zip_path.name}.tmp"
    if temp_zip.exists():
        temp_zip.unlink()
    if zip_path.exists():
        try:
            zip_path.unlink()
        except OSError:
            pass

    with zipfile.ZipFile(temp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for file_path in _iter_files_under(pack_dir):
            rel = file_path.relative_to(pack_dir).as_posix()
            arcname = f"{pack_dir.name}/{rel}"
            zf.write(file_path, arcname)

    shutil.move(str(temp_zip), str(zip_path))
    return zip_path
```

## `repo/MEMORY/LLM_PACKER/Engine/packer/cli.py`

```
#!/usr/bin/env python3
"""
CLI entry point for LLM Packer (Phase 1 Modular).
Calls Engine.packer.core.make_pack directly.
"""
import argparse
import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parents[4]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from .core import make_pack, SCOPE_AGS, SCOPES

def main():
    parser = argparse.ArgumentParser(
        description="Create memory/LLM packs under MEMORY/LLM_PACKER/_packs/."
    )
    parser.add_argument(
        "--project-root",
        default="",
        help="Source project root to pack (defaults to this repo root). Output still goes under MEMORY/LLM_PACKER/_packs/ of this repo.",
    )
    parser.add_argument(
        "--scope",
        choices=tuple(sorted(SCOPES.keys())),
        default=SCOPE_AGS.key,
        help="What to pack: default is the full AGS repo.",
    )
    parser.add_argument(
        "--mode",
        choices=("full", "delta"),
        default="full",
        help="Pack mode: full includes all included text files.",
    )
    parser.add_argument(
        "--profile",
        choices=("full", "lite"),
        default="full",
        help="Pack profile.",
    )
    parser.add_argument(
        "--split-lite",
        action="store_true",
        help="Generate LITE/ output (renamed from SPLIT_LITE).",
    )
    parser.add_argument(
        "--out-dir",
        default="",
        help="Output directory.",
    )
    parser.add_argument(
        "--combined",
        action="store_true",
        help="Generate FULL/ output (renamed from COMBINED).",
    )
    parser.add_argument(
        "--stamp",
        default="",
        help="Stamp string for output filenames.",
    )
    parser.add_argument(
        "--zip",
        action="store_true",
        help="Write archives: Internal (<pack>/archive/pack.zip) and External (MEMORY/LLM_PACKER/_packs/_archive/<pack_name>.zip).",
    )
    parser.add_argument(
        "--max-total-bytes",
        type=int,
        default=50 * 1024 * 1024,
    )
    parser.add_argument(
        "--max-entry-bytes",
        type=int,
        default=2 * 1024 * 1024,
    )
    parser.add_argument(
        "--max-entries",
        type=int,
        default=50_000,
    )
    parser.add_argument(
        "--allow-duplicate-hashes",
        action="store_true",
    )
    parser.add_argument(
        "--disallow-duplicate-hashes",
        action="store_true",
    )
    parser.add_argument(
        "--p2-runs-dir",
        default="",
        help="Where to write P2 RUN_ROOTS artifacts (defaults to CAPABILITY/RUNS).",
    )
    parser.add_argument(
        "--p2-cas-root",
        default="",
        help="Override CAS root (deterministic tests only).",
    )
    parser.add_argument(
        "--skip-proofs",
        action="store_true",
        help="Skip proof regeneration (Navigation/Proofs/_LATEST).",
    )
    parser.add_argument(
        "--with-proofs",
        action="store_true",
        help="Force proof regeneration even if context implies skipping.",
    )
    args = parser.parse_args()

    project_root = None
    if args.project_root:
        project_root = Path(args.project_root)
        if not project_root.is_absolute():
            project_root = (PROJECT_ROOT / project_root).resolve()
        project_root = project_root.resolve()

    out_dir = Path(args.out_dir) if args.out_dir else None
    if out_dir is not None and not out_dir.is_absolute():
        out_dir = (PROJECT_ROOT / out_dir).resolve()

    allow_dup = None
    if args.allow_duplicate_hashes:
        allow_dup = True
    elif args.disallow_duplicate_hashes:
        allow_dup = False

    p2_runs_dir = None
    if args.p2_runs_dir:
        p2_runs_dir = Path(args.p2_runs_dir)
        if not p2_runs_dir.is_absolute():
            p2_runs_dir = (PROJECT_ROOT / p2_runs_dir).resolve()
        p2_runs_dir = p2_runs_dir.resolve()

    p2_cas_root = None
    if args.p2_cas_root:
        p2_cas_root = Path(args.p2_cas_root)
        if not p2_cas_root.is_absolute():
            p2_cas_root = (PROJECT_ROOT / p2_cas_root).resolve()
        p2_cas_root = p2_cas_root.resolve()

    pack_dir = make_pack(
        scope_key=args.scope,
        mode=args.mode,
        profile=args.profile,
        split_lite=bool(args.split_lite),
        out_dir=out_dir,
        combined=bool(args.combined),
        stamp=args.stamp or None,
        zip_enabled=bool(args.zip),
        max_total_bytes=int(args.max_total_bytes),
        max_entry_bytes=int(args.max_entry_bytes),
        max_entries=int(args.max_entries),
        allow_duplicate_hashes=allow_dup,
        project_root=project_root,
        p2_runs_dir=p2_runs_dir,
        p2_cas_root=p2_cas_root,
        skip_proofs=args.skip_proofs and not args.with_proofs,
    )
    print(f"Pack created: {pack_dir}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
```

## `repo/MEMORY/LLM_PACKER/Engine/packer/consumer.py`

```
#!/usr/bin/env python3
"""
Pack Consumer (P.2.2): Verification + rehydration.

Implements pack_consume() to verify and materialize CAS-addressed pack manifests.
"""
from __future__ import annotations

import hashlib
import json
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from CAPABILITY.ARTIFACTS.store import load_bytes
from CAPABILITY.CAS import cas as cas_mod


# Constants
P2_MANIFEST_VERSION = "P2.0"


@dataclass
class ConsumptionReceipt:
    """Receipt for pack consumption operation."""
    manifest_ref: str
    cas_snapshot_hash: str
    out_dir: str
    tree_hash: str
    verification_summary: Dict[str, Any]
    commands_run: List[str]
    exit_status: str  # "SUCCESS" | "FAILED"
    errors: List[str]


def _validate_manifest_ref(ref: str) -> str:
    """Validate that ref is a proper sha256: reference."""
    if not ref.startswith("sha256:"):
        raise ValueError(f"PACK_CONSUME_INVALID_REF: must start with 'sha256:', got: {ref}")
    hash_part = ref.split(":", 1)[1]
    if len(hash_part) != 64 or not all(c in "0123456789abcdef" for c in hash_part):
        raise ValueError(f"PACK_CONSUME_INVALID_HASH: {hash_part}")
    return ref


def _validate_manifest_schema(manifest: Dict[str, Any]) -> None:
    """Validate manifest conforms to Pack Manifest v1 schema."""
    # Required top-level fields
    required_fields = ["version", "scope", "entries"]
    for field in required_fields:
        if field not in manifest:
            raise ValueError(f"PACK_CONSUME_MISSING_FIELD: {field}")
    
    # Version check
    if manifest["version"] != P2_MANIFEST_VERSION:
        raise ValueError(f"PACK_CONSUME_VERSION_MISMATCH: expected {P2_MANIFEST_VERSION}, got {manifest['version']}")
    
    # Scope validation
    valid_scopes = {"ags", "lab", "cat"}
    if manifest["scope"] not in valid_scopes:
        raise ValueError(f"PACK_CONSUME_INVALID_SCOPE: {manifest['scope']}")
    
    # Entries validation
    if not isinstance(manifest["entries"], list):
        raise ValueError("PACK_CONSUME_INVALID_ENTRIES: must be a list")
    
    # Validate each entry
    for i, entry in enumerate(manifest["entries"]):
        required_entry_fields = ["path", "ref", "bytes", "kind"]
        for field in required_entry_fields:
            if field not in entry:
                raise ValueError(f"PACK_CONSUME_ENTRY_MISSING_FIELD: entry[{i}].{field}")
        
        # Validate ref format
        _validate_manifest_ref(entry["ref"])
        
        # Validate path safety
        path = Path(entry["path"])
        if path.is_absolute():
            raise ValueError(f"PACK_CONSUME_ABSOLUTE_PATH: {entry['path']}")
        if ".." in path.parts:
            raise ValueError(f"PACK_CONSUME_PATH_TRAVERSAL: {entry['path']}")


def _verify_cas_blobs_exist(manifest: Dict[str, Any], cas_root: Path) -> List[str]:
    """
    Verify all blobs referenced in manifest exist in CAS.
    
    Returns list of missing blob hashes (empty if all present).
    """
    missing = []
    
    for entry in manifest["entries"]:
        ref = entry["ref"]
        hash_hex = ref.split(":", 1)[1]
        
        try:
            blob_path = cas_mod._get_object_path(hash_hex)
            if not blob_path.exists():
                missing.append(hash_hex)
        except Exception:
            missing.append(hash_hex)
    
    return missing


def _compute_tree_hash(out_dir: Path) -> str:
    """
    Compute deterministic hash of materialized tree.
    
    Hash is computed over sorted list of (path, content_hash) pairs.
    """
    entries = []
    
    for item in sorted(out_dir.rglob("*")):
        if item.is_file():
            rel_path = item.relative_to(out_dir).as_posix()
            file_hash = hashlib.sha256(item.read_bytes()).hexdigest()
            entries.append(f"{file_hash} {rel_path}")
    
    # Canonical encoding: one entry per line, sorted
    tree_bytes = "\n".join(sorted(entries)).encode("utf-8")
    return hashlib.sha256(tree_bytes).hexdigest()


def pack_consume(
    manifest_ref: str,
    out_dir: Path,
    *,
    dry_run: bool = False,
    cas_root: Optional[Path] = None,
) -> ConsumptionReceipt:
    """
    Consume a CAS-addressed pack manifest and materialize files.
    
    Args:
        manifest_ref: sha256: reference to pack manifest
        out_dir: Directory to materialize files into
        dry_run: If True, verify only (don't write files)
        cas_root: Optional CAS root override (for testing)
    
    Returns:
        ConsumptionReceipt with verification results
    
    Raises:
        ValueError: On any validation failure (fail-closed)
    """
    commands_run = []
    errors = []
    
    if cas_root is None:
        cas_root = cas_mod._CAS_ROOT
    
    try:
        # Step 1: Validate manifest ref format
        _validate_manifest_ref(manifest_ref)
        commands_run.append(f"validate_ref({manifest_ref})")
        
        # Step 2: Load manifest from CAS
        try:
            manifest_bytes = load_bytes(manifest_ref)
            commands_run.append(f"load_bytes({manifest_ref})")
        except Exception as e:
            raise ValueError(f"PACK_CONSUME_MANIFEST_NOT_FOUND: {manifest_ref}: {e}")
        
        # Step 3: Verify manifest integrity (canonical encoding)
        try:
            manifest = json.loads(manifest_bytes.decode("utf-8"))
        except Exception as e:
            raise ValueError(f"PACK_CONSUME_INVALID_JSON: {e}")
        
        # Verify canonical encoding (re-encode and compare)
        canonical_bytes = (json.dumps(manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")
        if canonical_bytes != manifest_bytes:
            raise ValueError("PACK_CONSUME_NON_CANONICAL_ENCODING")
        
        commands_run.append("verify_canonical_encoding")
        
        # Step 4: Validate manifest schema
        _validate_manifest_schema(manifest)
        commands_run.append("validate_schema")
        
        # Step 5: Verify all referenced blobs exist in CAS
        missing_blobs = _verify_cas_blobs_exist(manifest, cas_root)
        if missing_blobs:
            raise ValueError(f"PACK_CONSUME_MISSING_BLOBS: {len(missing_blobs)} blobs missing: {missing_blobs[:5]}")
        
        commands_run.append(f"verify_blobs_exist(count={len(manifest['entries'])})")
        
        # Step 6: Materialize files (if not dry-run)
        if not dry_run:
            # Atomic materialization: write to temp dir, then rename
            with tempfile.TemporaryDirectory(prefix="pack_consume_") as temp_str:
                temp_dir = Path(temp_str)
                
                # Materialize all files
                for entry in manifest["entries"]:
                    rel_path = entry["path"]
                    ref = entry["ref"]
                    
                    # Load blob from CAS
                    blob_bytes = load_bytes(ref)
                    
                    # Write to temp location
                    dest = temp_dir / rel_path
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(blob_bytes)
                
                commands_run.append(f"materialize({len(manifest['entries'])} files)")
                
                # Atomic move: rename temp dir to final location
                out_dir.parent.mkdir(parents=True, exist_ok=True)
                
                # If out_dir exists, fail-closed (don't overwrite)
                if out_dir.exists():
                    raise ValueError(f"PACK_CONSUME_OUT_DIR_EXISTS: {out_dir}")
                
                # Rename is atomic on most filesystems
                temp_dir.rename(out_dir)
                commands_run.append(f"atomic_rename({temp_dir} -> {out_dir})")
            
            # Compute tree hash
            tree_hash = _compute_tree_hash(out_dir)
        else:
            tree_hash = ""  # Not computed in dry-run
            commands_run.append("dry_run (no materialization)")
        
        # Build verification summary
        verification_summary = {
            "manifest_version": manifest["version"],
            "scope": manifest["scope"],
            "entry_count": len(manifest["entries"]),
            "total_bytes": sum(e["bytes"] for e in manifest["entries"]),
            "schema_valid": True,
            "encoding_canonical": True,
            "blobs_present": True,
        }
        
        # Compute CAS snapshot hash (deterministic)
        blob_hashes = sorted([e["ref"].split(":", 1)[1] for e in manifest["entries"]])
        cas_snapshot_hash = hashlib.sha256("\n".join(blob_hashes).encode("utf-8")).hexdigest()
        
        return ConsumptionReceipt(
            manifest_ref=manifest_ref,
            cas_snapshot_hash=cas_snapshot_hash,
            out_dir=str(out_dir),
            tree_hash=tree_hash,
            verification_summary=verification_summary,
            commands_run=commands_run,
            exit_status="SUCCESS",
            errors=[],
        )
        
    except ValueError:
        # Re-raise validation errors (already formatted)
        raise
    except Exception as e:
        # Wrap unexpected errors
        raise ValueError(f"PACK_CONSUME_INTERNAL_ERROR: {type(e).__name__}: {e}")
```

## `repo/MEMORY/LLM_PACKER/Engine/packer/core.py`

`````
#!/usr/bin/env python3
"""
Core utilities for LLM Packer (Phase 1 modular implementation).
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile
from dataclasses import dataclass
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from .proofs import refresh_proofs
from typing import (
    Any,
    Dict,
    FrozenSet,
    Iterable,
    List,
    Optional,
    Sequence,
    Set,
    Tuple,
    Union,
)

# Constants
PROJECT_ROOT = Path(__file__).resolve().parents[4]
MEMORY_DIR = PROJECT_ROOT / "MEMORY"
LLM_PACKER_DIR = MEMORY_DIR / "LLM_PACKER"
PACKS_ROOT = LLM_PACKER_DIR / "_packs"
SYSTEM_DIR = PACKS_ROOT / "_system"
EXTERNAL_ARCHIVE_DIR = PACKS_ROOT / "_archive"
FIXTURE_PACKS_DIR = SYSTEM_DIR / "fixtures"
STATE_DIR = SYSTEM_DIR / "_state"
BASELINE_PATH = STATE_DIR / "baseline.json"

CANON_VERSION_FILE = PROJECT_ROOT / "LAW" / "CANON" / "VERSIONING.md"
GRAMMAR_VERSION = "1.0"
P2_MANIFEST_VERSION = "P2.0"

# Token estimation constants
CHARS_PER_TOKEN = 4
TOKEN_LIMIT_WARNING = 100_000
TOKEN_LIMIT_CRITICAL = 200_000

# ANSI Colors
ANSI_RED = "\033[91m"
ANSI_YELLOW = "\033[93m"
ANSI_RESET = "\033[0m"

TEXT_EXTENSIONS = {
    ".md", ".txt", ".json", ".py", ".js", ".mjs", ".cjs",
    ".css", ".html", ".php", ".ps1", ".cmd", ".bat", ".yml", ".yaml",
}

TEXT_BASENAMES = {".gitignore", ".gitattributes", ".editorconfig", ".htaccess", ".gitkeep", "LICENSE"}

def rel_posix(*parts: str) -> str:
    return Path(*parts).as_posix()

def _canonical_json_bytes(payload: Any) -> bytes:
    return (json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")

def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _bucket_ordered(include_dirs: Sequence[str]) -> List[str]:
    # P.2 ordering rule
    preferred = ["LAW", "CAPABILITY", "NAVIGATION", "DIRECTION", "THOUGHT", "MEMORY", ".github"]
    present: set[str] = set()
    for d in include_dirs:
        try:
            present.add(Path(d).parts[-1])
        except Exception:
            continue
    return [b for b in preferred if b in present]

@contextmanager
def _override_cas_root(cas_root: Optional[Path]) -> Iterator[None]:
    if cas_root is None:
        yield
        return
    # Only used for deterministic tests; production uses default CAS root.
    from CAPABILITY.CAS import cas as cas_mod
    old = cas_mod._CAS_ROOT
    cas_mod._CAS_ROOT = Path(cas_root)
    try:
        yield
    finally:
        cas_mod._CAS_ROOT = old

def _git_repo_state(project_root: Path) -> Dict[str, str]:
    def run(args: List[str]) -> str:
        try:
            res = subprocess.run(args, cwd=str(project_root), capture_output=True, text=True, check=False)
            if res.returncode != 0:
                return ""
            return (res.stdout or "").strip()
        except Exception:
            return ""

    head = run(["git", "rev-parse", "HEAD"])
    branch = run(["git", "rev-parse", "--abbrev-ref", "HEAD"])
    out: Dict[str, str] = {}
    if head:
        out["commit"] = head
    if branch and branch != "HEAD":
        out["branch"] = branch
    return out

def _validate_artifact_ref(ref: str) -> str:
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", ref):
        raise ValueError(f"PACK_P2_INVALID_REF:{ref}")
    return ref

def _strip_sha256_prefix(ref: str) -> str:
    _validate_artifact_ref(ref)
    return ref.split(":", 1)[1]

def _write_run_roots(runs_dir: Path, *, roots: Sequence[str]) -> None:
    runs_dir.mkdir(parents=True, exist_ok=True)
    roots_sorted = sorted(set(roots))
    # Strict format: 64 lowercase hex
    for h in roots_sorted:
        if not re.fullmatch(r"[0-9a-f]{64}", h):
            raise ValueError(f"PACK_P2_INVALID_ROOT_HASH:{h}")
    (runs_dir / "RUN_ROOTS.json").write_text(json.dumps(roots_sorted, indent=2, sort_keys=True) + "\n", encoding="utf-8")

def _emit_p2_lite_artifacts(
    pack_dir: Path,
    *,
    project_root: Path,
    include_paths: Sequence[str],
    scope: PackScope,
    runs_dir: Path,
) -> Dict[str, str]:
    """
    P.2: CAS-addressed LITE manifest + run records + root-audit gating.

    Returns refs:
      - manifest_ref (sha256:...)
      - task_spec_ref (64hex)
      - output_hashes_ref (64hex)
      - status_ref (64hex)
    """
    from CAPABILITY.ARTIFACTS.store import store_file, store_bytes
    from CAPABILITY.RUNS.records import put_task_spec, put_output_hashes, put_status
    from CAPABILITY.AUDIT.root_audit import root_audit
    from CAPABILITY.CAS import cas as cas_mod

    lite_dir = pack_dir / "LITE"
    lite_dir.mkdir(parents=True, exist_ok=True)

    # Store each included payload into CAS and build deterministic entries.
    entries: List[Dict[str, Any]] = []
    payload_hashes: List[str] = []

    source_root = project_root / scope.source_root_rel
    for rel in sorted(set(include_paths)):
        src = source_root / rel
        if not src.exists() or not src.is_file():
            raise ValueError(f"PACK_P2_MISSING_SOURCE:{Path(rel).as_posix()}")
        ref = _validate_artifact_ref(store_file(str(src)))
        payload_hashes.append(_strip_sha256_prefix(ref))
        entries.append(
            {
                "path": Path(rel).as_posix(),
                "ref": ref,
                "bytes": int(src.stat().st_size),
                "ext": src.suffix.lower(),
                "kind": "FILE",
            }
        )

    entries.sort(key=lambda e: e["path"])
    # Dedup by path (fail-closed)
    seen: set[str] = set()
    for e in entries:
        if e["path"] in seen:
            raise ValueError(f"PACK_P2_DUPLICATE_MANIFEST_PATH:{e['path']}")
        seen.add(e["path"])

    manifest = {
        "version": P2_MANIFEST_VERSION,
        "scope": scope.key,
        "repo_state": _git_repo_state(project_root),
        "buckets": _bucket_ordered(scope.include_dirs),
        "entries": entries,
    }
    manifest_bytes = _canonical_json_bytes(manifest)
    (lite_dir / "PACK_MANIFEST.json").write_bytes(manifest_bytes)

    manifest_ref = _validate_artifact_ref(store_bytes(manifest_bytes))
    manifest_hash = _strip_sha256_prefix(manifest_ref)

    task_spec = {
        "scope": scope.key,
        "repo_state": _git_repo_state(project_root),
        "include_dirs": list(scope.include_dirs),
        "excluded_dir_parts": sorted(scope.excluded_dir_parts),
        "modes": ["FULL", "SPLIT", "LITE"],
        "manifest_version": P2_MANIFEST_VERSION,
        "grammar_version": GRAMMAR_VERSION,
    }
    task_spec_ref = put_task_spec(task_spec)

    required_hashes = [manifest_hash, *payload_hashes]
    output_hashes_ref = put_output_hashes(required_hashes)

    # First roots pass (no status_ref yet)
    roots_phase1 = sorted(set([task_spec_ref, output_hashes_ref, manifest_hash, *payload_hashes]))
    _write_run_roots(runs_dir, roots=roots_phase1)

    audit1 = root_audit(output_hashes_record=output_hashes_ref, dry_run=True, runs_dir=runs_dir, cas_root=cas_mod._CAS_ROOT)
    if audit1.get("verdict") != "PASS":
        status_payload = {
            "state": "FAILED",
            "verdict": "FAIL",
            "task_spec_ref": task_spec_ref,
            "output_hashes_ref": output_hashes_ref,
            "manifest_ref": manifest_ref,
            # Deterministic snapshot for this pack run (not global CAS state)
            "cas_snapshot_hash": _sha256_hex("\n".join(sorted(set(roots_phase1))).encode("utf-8")),
        }
        status_ref = put_status(status_payload)
        _write_run_roots(runs_dir, roots=sorted(set([*roots_phase1, status_ref])))
        audit2 = root_audit(output_hashes_record=output_hashes_ref, dry_run=True, runs_dir=runs_dir, cas_root=cas_mod._CAS_ROOT)
        raise ValueError(f"PACK_P2_ROOT_AUDIT_FAIL:{audit1.get('errors', [])}:{audit2.get('errors', [])}")

    status_payload = {
        "state": "COMPLETED",
        "verdict": "PASS",
        "task_spec_ref": task_spec_ref,
        "output_hashes_ref": output_hashes_ref,
        "manifest_ref": manifest_ref,
        "cas_snapshot_hash": _sha256_hex("\n".join(sorted(set(roots_phase1))).encode("utf-8")),
    }
    status_ref = put_status(status_payload)
    roots_final = sorted(set([*roots_phase1, status_ref]))
    _write_run_roots(runs_dir, roots=roots_final)
    audit_final = root_audit(output_hashes_record=output_hashes_ref, dry_run=True, runs_dir=runs_dir, cas_root=cas_mod._CAS_ROOT)
    if audit_final.get("verdict") != "PASS":
        raise ValueError(f"PACK_P2_ROOT_AUDIT_FAIL_FINAL:{audit_final.get('errors', [])}")

    run_refs = {
        "manifest_ref": manifest_ref,
        "task_spec_ref": task_spec_ref,
        "output_hashes_ref": output_hashes_ref,
        "status_ref": status_ref,
    }
    (lite_dir / "RUN_REFS.json").write_bytes(_canonical_json_bytes(run_refs))
    return run_refs


@dataclass(frozen=True)
class PackLimits:
    max_total_bytes: int
    max_entry_bytes: int
    max_entries: int
    allow_duplicate_hashes: Optional[bool]


@dataclass(frozen=True)
class PackScope:
    key: str
    title: str
    file_prefix: str
    include_dirs: Tuple[str, ...]
    root_files: Tuple[str, ...]
    anchors: Tuple[str, ...]
    excluded_dir_parts: frozenset[str]
    source_root_rel: str = "."


SCOPE_AGS = PackScope(
    key="ags",
    title="Agent Governance System (AGS)",
    file_prefix="AGS",
    include_dirs=("LAW", "CAPABILITY", "NAVIGATION", "DIRECTION", "THOUGHT", "MEMORY", ".github"),
    root_files=("README.md", "LICENSE", "AGENTS.md", ".gitignore", ".gitattributes", ".editorconfig"),
    anchors=(
        "AGENTS.md",
        "README.md",
        rel_posix("LAW", "CANON", "CONTRACT.md"),
        rel_posix("LAW", "CANON", "INVARIANTS.md"),
        rel_posix("LAW", "CANON", "VERSIONING.md"),
        rel_posix("NAVIGATION", "MAPS", "ENTRYPOINTS.md"),
        rel_posix("LAW", "CONTRACTS", "runner.py"),
        "MEMORY/LLM_PACKER/README.md",
    ),
    excluded_dir_parts=frozenset({
        ".git", "BUILD", "_runs", "_generated", "_packs",
        "LAB",
        "Original", "ORIGINAL", "research", "RESEARCH", "__pycache__", "node_modules",
    }),
    source_root_rel=".",
)

SCOPE_LAB = PackScope(
    key="lab",
    title="LAB (THOUGHT/LAB)",
    file_prefix="LAB",
    include_dirs=("THOUGHT/LAB",),
    root_files=(),
    anchors=(),
    excluded_dir_parts=frozenset({
        ".git", "BUILD", "_runs", "_generated", "_packs", "__pycache__", "node_modules",
    }),
    source_root_rel="THOUGHT/LAB",
)

SCOPES: Dict[str, PackScope] = {
    SCOPE_AGS.key: SCOPE_AGS,
    SCOPE_LAB.key: SCOPE_LAB,
}


def hash_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def estimate_tokens(text: str, model: str = "gpt-4o") -> int:
    return len(text) // CHARS_PER_TOKEN


def estimate_file_tokens(path: Path) -> int:
    try:
        return estimate_tokens(read_text(path))
    except Exception:
        return 0


def read_canon_version() -> str:
    if not CANON_VERSION_FILE.exists():
        return "unknown"
    text = read_text(CANON_VERSION_FILE)
    match = re.search(r"canon_version:\s*(\d+\.\d+\.\d+)", text)
    return match.group(1) if match else "unknown"


def is_text_path(path: Path) -> bool:
    ext = path.suffix.lower()
    if ext:
        return ext in TEXT_EXTENSIONS
    return path.name in TEXT_BASENAMES


def is_excluded_rel_path(rel_path: Path, *, excluded_dir_parts: frozenset[str]) -> bool:
    parts = set(rel_path.parts)
    if parts & excluded_dir_parts:
        return True
    # P.2: Roots are runtime artifacts and must never be packed (avoid self-reference cycles).
    if rel_path.name in {"RUN_ROOTS.json", "GC_PINS.json"}:
        return True
    if any(part.startswith(".") and part != ".github" for part in rel_path.parts):
        return True
    return False


def iter_repo_candidates(project_root: Path, *, scope: PackScope) -> Iterable[Path]:
    for directory in scope.include_dirs:
        base = project_root / directory
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            try:
                is_file = path.is_file()
            except OSError:
                is_file = False
            if not is_file:
                continue
            rel = path.relative_to(project_root)
            if is_excluded_rel_path(rel, excluded_dir_parts=scope.excluded_dir_parts):
                continue
            yield path

    for file_name in scope.root_files:
        path = project_root / file_name
        if path.exists() and path.is_file():
            yield path


def build_state_manifest(project_root: Path, *, scope: PackScope) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    canon_version = read_canon_version()
    files: List[Dict[str, Any]] = []
    omitted: List[Dict[str, Any]] = []

    source_root = project_root / scope.source_root_rel

    seen: set[str] = set()
    for abs_path in iter_repo_candidates(project_root, scope=scope):
        try:
            rel = abs_path.relative_to(source_root).as_posix()
        except ValueError:
            # Fallback for root files not inside source_root (unlikely with deep source roots unless explicitly included)
            # For CAT/LAB, root_files is empty, so this mostly applies to AGS where source_root is .
             rel = abs_path.relative_to(project_root).as_posix()

        if rel in seen:
            raise RuntimeError(f"PACK_DEDUP_DUPLICATE_PATH:{rel}")
        seen.add(rel)

        if not is_text_path(abs_path):
            omitted.append({
                "scope": "repo",
                "repoRelPath": rel,
                "bytes": abs_path.stat().st_size,
            })
            continue

        files.append({
            "path": rel,
            "hash": hash_file(abs_path),
            "size": abs_path.stat().st_size,
        })

    files.sort(key=lambda e: (e["path"], e["hash"]))
    manifest: Dict[str, Any] = {
        "canon_version": canon_version,
        "grammar_version": GRAMMAR_VERSION,
        "scope": scope.key,
        "files": files,
    }
    return manifest, omitted


def manifest_digest(manifest: Dict[str, Any]) -> str:
    hasher = hashlib.sha256()
    for entry in manifest.get("files", []):
        line = f"{entry['hash']} {entry['size']} {entry['path']}\n"
        hasher.update(line.encode("utf-8"))
    return hasher.hexdigest()


def baseline_path_for_scope(scope: PackScope) -> Path:
    if scope.key == SCOPE_AGS.key:
        return BASELINE_PATH
    return STATE_DIR / f"baseline-{scope.key}.json"


def load_baseline(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(read_text(path))
    except Exception:
        return None


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def ensure_under_packs_root(out_dir: Path) -> Path:
    packs_root = PACKS_ROOT.resolve()
    out_dir_resolved = out_dir.resolve()
    try:
        out_dir_resolved.relative_to(packs_root)
    except ValueError as exc:
        raise ValueError(f"OutDir must be under MEMORY/LLM_PACKER/_packs/. Received: {out_dir}") from exc
    return out_dir_resolved


def _is_valid_archive_zip(zip_path: Path) -> bool:
    if not zip_path.exists() or not zip_path.is_file():
        return False
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            # Ensure the zip isn't corrupted.
            if zf.testzip() is not None:
                return False
            names = zf.namelist()
    except Exception:
        return False

    has_meta = any(n.startswith("meta/") for n in names)
    has_repo = any(n.startswith("repo/") for n in names)
    return has_meta and has_repo


def _is_valid_external_archive_zip(zip_path: Path, *, expected_pack_name: str) -> bool:
    if not zip_path.exists() or not zip_path.is_file():
        return False
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            if zf.testzip() is not None:
                return False
            names = zf.namelist()
    except Exception:
        return False

    # Must contain internal archive zip and at least one split file for safety.
    internal_zip = f"{expected_pack_name}/archive/pack.zip"
    has_internal = internal_zip in set(names)
    has_split_index = any(n == f"{expected_pack_name}/SPLIT/AGS-00_INDEX.md" or n.endswith("/SPLIT/LAB-00_INDEX.md") for n in names)
    return has_internal and has_split_index


def _maybe_delete_previous_pack(*, current_pack_dir: Path, scope: "PackScope") -> None:
    """
    Delete the previous unzipped pack folder ONLY if it is safely zipped and archived.

    "Previous" is the most recently modified sibling pack dir matching the scope prefix, excluding the current pack.
    """
    if current_pack_dir.parent.resolve() != PACKS_ROOT.resolve():
        return

    prefixes: List[str] = []
    if scope.key == "ags":
        prefixes = ["ags-pack-", "llm-pack-ags-"]
    elif scope.key == "lab":
        prefixes = ["lab-pack-", "llm-pack-lab-"]
    else:
        prefixes = [f"{scope.key}-pack-", f"llm-pack-{scope.key}-"]

    candidates: List[Path] = []
    for p in PACKS_ROOT.iterdir():
        if not p.is_dir():
            continue
        if p.name in {"_system", "_archive", "_state", "archive"}:
            continue
        if p.resolve() == current_pack_dir.resolve():
            continue
        if not any(p.name.startswith(pref) for pref in prefixes):
            continue
        candidates.append(p)

    if not candidates:
        return

    previous = max(candidates, key=lambda d: d.stat().st_mtime)
    archived_zip = EXTERNAL_ARCHIVE_DIR / f"{previous.name}.zip"
    if not _is_valid_external_archive_zip(archived_zip, expected_pack_name=previous.name):
        return
    shutil.rmtree(previous)


def _migrate_system_archive() -> None:
    """
    Legacy: move `_packs/_system/archive/*` into `_packs/_archive/`.
    """
    legacy_dir = SYSTEM_DIR / "archive"
    if not legacy_dir.exists() or not legacy_dir.is_dir():
        return

    dest_dir = EXTERNAL_ARCHIVE_DIR
    dest_dir.mkdir(parents=True, exist_ok=True)

    moved_any = False
    for src in sorted(legacy_dir.iterdir()):
        if not src.is_file():
            continue
        dst = dest_dir / src.name

        # Be robust across filesystems: copy then unlink source (avoid "copy without delete" edge cases).
        if dst.exists():
            try:
                same_size = src.stat().st_size == dst.stat().st_size
                if same_size:
                    import hashlib

                    def _sha256(p: Path) -> str:
                        h = hashlib.sha256()
                        with p.open("rb") as f:
                            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                                h.update(chunk)
                        return h.hexdigest()

                    if _sha256(src) == _sha256(dst):
                        try:
                            src.unlink()
                            moved_any = True
                        except OSError:
                            pass
                        continue
            except OSError:
                pass

            # Preserve content without clobbering the existing external archive name.
            stem, suffix = src.stem, src.suffix
            i = 1
            while True:
                candidate = dest_dir / f"{stem}__legacy{i}{suffix}"
                if not candidate.exists():
                    dst = candidate
                    break
                i += 1

        shutil.copy2(src, dst)
        try:
            src.unlink()
        except OSError:
            # If we can't delete the legacy file, do not fail pack creation.
            pass
        moved_any = True

    if moved_any:
        # Best-effort cleanup.
        try:
            legacy_dir.rmdir()
        except OSError:
            pass


def enforce_included_repo_limits(entries: List[Dict[str, Any]], limits: PackLimits) -> Dict[str, Any]:
    total_bytes = sum(e["size"] for e in entries)
    if total_bytes > limits.max_total_bytes:
        raise ValueError(f"PACK_LIMIT_EXCEEDED:max_total_bytes ({total_bytes} > {limits.max_total_bytes})")
    
    if len(entries) > limits.max_entries:
        raise ValueError(f"PACK_LIMIT_EXCEEDED:max_entries ({len(entries)} > {limits.max_entries})")

    for e in entries:
        if e["size"] > limits.max_entry_bytes:
            raise ValueError(f"PACK_LIMIT_EXCEEDED:max_entry_bytes ({e['path']} {e['size']} > {limits.max_entry_bytes})")

    if limits.allow_duplicate_hashes is False:
        hashes = [e["hash"] for e in entries]
        if len(hashes) != len(set(hashes)):
            raise ValueError("PACK_LIMIT_EXCEEDED:duplicate_hashes")

    return {
        "repo_files": len(entries),
        "repo_bytes": total_bytes,
    }


def pack_dir_total_bytes(pack_dir: Path) -> int:
    return sum(f.stat().st_size for f in pack_dir.rglob("*") if f.is_file())


def copy_repo_files(pack_dir: Path, project_root: Path, included_paths: Sequence[str], scope: PackScope) -> None:
    source_root = project_root / scope.source_root_rel
    for rel in included_paths:
        # rel is already relative to source_root as per build_state_manifest
        src = source_root / rel
        if not src.exists() or not src.is_file():
             # Fallback: maybe it was relative to project root? (Should not happen if manifest was built consistent)
             src = project_root / rel
             if not src.exists():
                continue

        dst = pack_dir / "repo" / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(src.read_bytes())


# --- Document Generators (Sanitized) ---

def write_start_here(pack_dir: Path, *, scope: PackScope) -> None:
    if scope.key == SCOPE_AGS.key:
        canon_contract = rel_posix("LAW", "CANON", "CONTRACT.md")
        maps_entrypoints = rel_posix("NAVIGATION", "MAPS", "ENTRYPOINTS.md")
        contracts_runner = rel_posix("LAW", "CONTRACTS", "runner.py")
        text = "\n".join(
            [
                "# START HERE",
                "",
                "This snapshot is meant to be shared with any LLM to continue work on the Agent Governance System (AGS) repository.",
                "",
                "## Read order",
                "1) `repo/AGENTS.md`",
                "2) `repo/README.md`",
                f"3) `repo/{canon_contract}`",
                f"4) `repo/{maps_entrypoints}`",
                f"5) `repo/{contracts_runner}`",
                "6) `meta/ENTRYPOINTS.md`",
                "",
                "## Notes",
                "- `BUILD` contents excluded.",
                "- Use `FULL/` for single-file output or `SPLIT/` for sectioned reading.",
                "",
            ]
        )
    elif scope.key == SCOPE_LAB.key:
        text = "\n".join(
            [
                "# START HERE (LAB)",
                "",
                "This snapshot contains ALL research and experimental code under `THOUGHT/LAB`. It is volatile.",
                "",
                "## Read order",
                "1) `repo/THOUGHT/LAB/`",
                "",
                "## Notes",
                "- Use `FULL/` for single-file output or `SPLIT/` for sectioned reading.",
                "",
            ]
        )
    else:
        raise ValueError(f"Unsupported scope: {scope.key}")

    (pack_dir / "meta" / "START_HERE.md").write_text(text, encoding="utf-8")


def write_entrypoints(pack_dir: Path, *, scope: PackScope) -> None:
    if scope.key == SCOPE_AGS.key:
        canon_contract = rel_posix("LAW", "CANON", "CONTRACT.md")
        maps_entrypoints = rel_posix("NAVIGATION", "MAPS", "ENTRYPOINTS.md")
        skills_dir = rel_posix("CAPABILITY", "SKILLS")
        contracts_runner = rel_posix("LAW", "CONTRACTS", "runner.py")
        text = "\n".join(
            [
                "# Snapshot Entrypoints",
                "",
                "Key entrypoints for `AGS`:",
                "",
                "- `repo/AGENTS.md`",
                "- `repo/README.md`",
                f"- `repo/{canon_contract}`",
                f"- `repo/{maps_entrypoints}`",
                f"- `repo/{skills_dir}/`",
                f"- `repo/{contracts_runner}`",
                "",
                "Notes:",
                "- `FULL/` contains single-file bundles.",
                "- `SPLIT/` contains chunked sections.",
                "",
            ]
        )
    elif scope.key == SCOPE_LAB.key:
        text = "\n".join(
            [
                "# Snapshot Entrypoints",
                "",
                f"Key entrypoints for `{scope.title}`:",
                "",
                "- `repo/THOUGHT/LAB/`",
                "",
                "Notes:",
                "- `FULL/` contains single-file bundles.",
                "- `SPLIT/` contains chunked sections.",
                "",
            ]
        )
    else:
        raise ValueError(f"Unsupported scope for ENTRYPOINTS: {scope.key}")

    (pack_dir / "meta" / "ENTRYPOINTS.md").write_text(text, encoding="utf-8")


def write_build_tree(pack_dir: Path, project_root: Path) -> None:
    tree_path = pack_dir / "meta" / "BUILD_TREE.txt"
    tree_path.write_text("BUILD is excluded from packs by contract.\n", encoding="utf-8")


def write_pack_info(pack_dir: Path, scope: PackScope, stamp: str) -> None:
    info = {
        "scope": scope.key,
        "title": scope.title,
        "stamp": stamp,
        "version": read_canon_version(),
    }
    write_json(pack_dir / "meta" / "PACK_INFO.json", info)

def write_provenance(pack_dir: Path, scope: PackScope) -> None:
    import os

    prov = {
        "generator": "LLM_PACKER",
        # P.2: deterministic by default (no timestamps / machine identity)
        "scope": scope.key,
    }
    write_json(pack_dir / "meta" / "PROVENANCE.json", prov)

def write_omitted(pack_dir: Path, omitted: List[Dict[str, Any]]) -> None:
    # Always emit for determinism and fixture stability (empty list is meaningful).
    write_json(pack_dir / "meta" / "REPO_OMITTED_BINARIES.json", omitted)

def render_tree(paths: Sequence[str]) -> str:
    """Render a visual tree from a list of relative paths."""
    tree: Dict[str, Any] = {}
    for path in sorted(paths):
        # Normalize to forward slashes just in case
        parts = path.replace("\\", "/").split("/")
        node = tree
        for part in parts:
            if part not in node:
                node[part] = {}
            node = node[part]
            
    lines = ["."]
    
    def walk(node: Dict[str, Any], prefix: str = "") -> None:
        entries = sorted(node.keys())
        for i, entry in enumerate(entries):
            is_last = (i == len(entries) - 1)
            connector = "└── " if is_last else "├── "
            lines.append(f"{prefix}{connector}{entry}")
            
            children = node[entry]
            if children:
                extension = "    " if is_last else "│   "
                walk(children, prefix + extension)
                
    walk(tree)
    return "\n".join(lines)


def write_pack_file_tree_and_index(pack_dir: Path, *, scope: PackScope, stamp: str, combined: bool) -> None:
    all_files = [p for p in pack_dir.rglob("*") if p.is_file()]
    rel_paths = sorted(p.relative_to(pack_dir).as_posix() for p in all_files)

    # Generate visual tree including predicted treemap files if combined
    final_paths = list(rel_paths)
    tm_md = f"FULL/{scope.file_prefix}-FULL-TREEMAP-{stamp}.md"
    tm_txt = f"FULL/{scope.file_prefix}-FULL-TREEMAP-{stamp}.txt"
    
    if combined:
        if tm_md not in final_paths: final_paths.append(tm_md)
        if tm_txt not in final_paths: final_paths.append(tm_txt)

    tree_text = render_tree(final_paths)

    (pack_dir / "meta" / "FILE_TREE.txt").write_text(tree_text + "\n", encoding="utf-8")

    if combined:
        full_dir = pack_dir / "FULL"
        full_dir.mkdir(parents=True, exist_ok=True)
        
        md_content = f"# {scope.file_prefix} TREEMAP\n\n```text\n{tree_text}\n```\n"
        txt_content = f"{scope.file_prefix} TREEMAP\n\n{tree_text}\n"
        
        (full_dir / tm_md.replace("FULL/", "")).write_text(md_content, encoding="utf-8")
        # .txt treemap not allowed in FULL/ per req 5. Archive will generate sibling or use FILE_TREE.txt line 538 removal.

    file_index: List[Dict[str, Any]] = []
    # Use actual files for index (excluding treemaps if not written yet)
    for p in sorted(all_files, key=lambda x: x.relative_to(pack_dir).as_posix()):
        rel = p.relative_to(pack_dir).as_posix()
        size = p.stat().st_size
        file_index.append({"path": rel, "bytes": size, "sha256": hash_file(p)})
    file_index.sort(key=lambda e: (e["path"], e["sha256"]))
    write_json(pack_dir / "meta" / "FILE_INDEX.json", file_index)


# --- Full Output Generation ---

def build_combined_md_block(rel_path: str, text: str, byte_count: int) -> str:
    fence = "`````" if "````" in text else ("````" if "```" in text else "```")
    return "\n".join([f"## `{rel_path}` ({byte_count:,} bytes)", "", fence, text.rstrip(), fence, ""]) 

def build_combined_txt_block(rel_path: str, text: str, byte_count: int) -> str:
    limit = "-" * 80
    return "\n".join([limit, f"FILE: {rel_path} ({byte_count:,} bytes)", limit, text.rstrip(), ""])

def write_full_outputs(pack_dir: Path, *, stamp: str, scope: PackScope) -> None:
    full_dir = pack_dir / "FULL"
    full_dir.mkdir(parents=True, exist_ok=True)

    combined_md_rel = f"{scope.file_prefix}-FULL-{stamp}.md"
    combined_txt_rel = f"{scope.file_prefix}-FULL-{stamp}.txt"
    
    # We will compute the tree later and append it if needed, or write it separate
    # Roadmap says: FULL/ ...md, ...txt. 
    # Logic adapted from legacy but pointing to FULL_DIR
    
    combined_md_lines = [f"# {scope.file_prefix} FULL", ""]
    combined_txt_lines = [f"{scope.file_prefix} FULL", ""]

    base_paths = sorted(p.relative_to(pack_dir).as_posix() for p in pack_dir.rglob("*") if p.is_file())
    
    for rel in base_paths:
        # Exclude generated output dirs to avoid recursion/duplication
        if rel.startswith("FULL/") or rel.startswith("SPLIT/") or rel.startswith("LITE/"):
            continue

        abs_path = pack_dir / rel
        text = read_text(abs_path)
        size = abs_path.stat().st_size
        combined_md_lines.append(build_combined_md_block(rel, text, size))
        combined_txt_lines.append(build_combined_txt_block(rel, text, size))

    md_content = "\n".join(combined_md_lines).rstrip() + "\n"
    txt_content = "\n".join(combined_txt_lines).rstrip() + "\n"

    (full_dir / combined_md_rel).write_text(md_content, encoding="utf-8")
    # NO TXT output in FULL/ as per requirements
    # (full_dir / combined_txt_rel).write_text(txt_content, encoding="utf-8")


def verify_manifest(pack_dir: Path) -> Tuple[bool, List[str]]:
    manifest_path = pack_dir / "meta" / "REPO_STATE.json"
    if not manifest_path.exists():
        return False, ["Manifest missing: meta/REPO_STATE.json"]
    
    try:
        manifest = json.loads(read_text(manifest_path))
    except Exception as e:
        return False, [f"Manifest invalid JSON: {e}"]
        
    errors = []
    repo_dir = pack_dir / "repo"
    
    files = manifest.get("files", [])
    for entry in files:
        rel_path = entry.get("path")
        expected_hash = entry.get("hash")
        
        # Determine file path (handle potential subdirectory nesting)
        file_path = repo_dir.joinpath(rel_path)
        
        if not file_path.exists():
            errors.append(f"File missing: {rel_path}")
            continue
            
        computed = hash_file(file_path)
        if computed != expected_hash:
            errors.append(f"Hash mismatch for {rel_path}: expected {expected_hash}, got {computed}")
            
    return len(errors) == 0, errors


def make_pack(
    *,
    scope_key: str,
    mode: str,
    profile: str,
    split_lite: bool,
    out_dir: Optional[Path],
    combined: bool,
    stamp: Optional[str],
    zip_enabled: bool,
    max_total_bytes: int,
    max_entry_bytes: int,
    max_entries: int,
    allow_duplicate_hashes: Optional[bool],
    project_root: Optional[Path] = None,
    p2_runs_dir: Optional[Path] = None,
    p2_cas_root: Optional[Path] = None,
    skip_proofs: bool = False,
) -> Path:
    from .split import write_split_pack
    from .lite import write_split_pack_lite
    from .archive import write_pack_internal_archives, write_pack_external_archive
    from CAPABILITY.CAS import cas as cas_mod

    scope = SCOPES.get(scope_key)
    if not scope:
        raise ValueError(f"Unknown scope: {scope_key}")

    source_project_root = (project_root or PROJECT_ROOT).resolve()
    use_shared_baseline = source_project_root == PROJECT_ROOT.resolve()


    with _override_cas_root(p2_cas_root):
        _migrate_system_archive()

        # 0. Proof Refresh (Fail-closed)
        # Must happen BEFORE manifest build so new proofs are picked up.
        if scope.key == SCOPE_AGS.key and not skip_proofs:
            # We use a derived stamp for the proof run if one isn't provided yet.
            # However, core.py generates digest-based stamps later.
            # For proofs, we'll use a temp timestamp if stamp is None,
            # but the Pack ID will stick to the digest or user stamp.
            proof_stamp = stamp or datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")
            print(f"Refreshing proofs (stamp={proof_stamp})...")
            success, err = refresh_proofs(source_project_root, stamp=proof_stamp)
            if not success:
                raise RuntimeError(err)

        manifest, omitted = build_state_manifest(source_project_root, scope=scope)
        digest = manifest_digest(manifest)

        if out_dir is None:
            out_dir = PACKS_ROOT / f"llm-pack-{scope.key}-{digest[:12]}"
        out_dir = ensure_under_packs_root(out_dir)

        SYSTEM_DIR.mkdir(parents=True, exist_ok=True)
        EXTERNAL_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        FIXTURE_PACKS_DIR.mkdir(parents=True, exist_ok=True)
        STATE_DIR.mkdir(parents=True, exist_ok=True)

        baseline_path = baseline_path_for_scope(scope)
        baseline = load_baseline(baseline_path) if use_shared_baseline else None
        baseline_files_by_path = {f["path"]: f for f in (baseline or {}).get("files", [])}
        current_files_by_path = {f["path"]: f for f in manifest.get("files", [])}

        if allow_duplicate_hashes is None:
            allow_duplicate_hashes = True

        # validate_repo_state_manifest logic (simplified inline or stubbed)
        # We trust build_state_manifest for Phase 1 refactor

        anchors = scope.anchors if use_shared_baseline else ()

        if mode == "delta" and baseline is not None:
            changed = []
            for path, entry in current_files_by_path.items():
                prev = baseline_files_by_path.get(path)
                if prev is None or prev.get("hash") != entry.get("hash") or prev.get("size") != entry.get("size"):
                    changed.append(path)
            deleted = sorted(set(baseline_files_by_path.keys()) - set(current_files_by_path.keys()))
            include_paths = sorted(set(changed) | set(anchors))
        else:
            include_paths = sorted(set(current_files_by_path.keys()) | set(anchors))
            deleted = []

        limits = PackLimits(
            max_total_bytes=max_total_bytes,
            max_entry_bytes=max_entry_bytes,
            max_entries=max_entries,
            allow_duplicate_hashes=allow_duplicate_hashes,
        )
        included_entries = [current_files_by_path[p] for p in include_paths if p in current_files_by_path]
        included_stats = enforce_included_repo_limits(included_entries, limits=limits)

        if out_dir.exists():
            shutil.rmtree(out_dir)
        (out_dir / "meta").mkdir(parents=True, exist_ok=True)
        (out_dir / "repo").mkdir(parents=True, exist_ok=True)

        # 1. Copy Repo
        copy_repo_files(out_dir, source_project_root, include_paths, scope=scope)
        write_json(out_dir / "meta" / "REPO_STATE.json", manifest)
        write_build_tree(out_dir, source_project_root)

        # 2. Meta Docs
        write_start_here(out_dir, scope=scope)
        write_entrypoints(out_dir, scope=scope)
        write_pack_info(out_dir, scope=scope, stamp=stamp or digest[:12])
        write_provenance(out_dir, scope)
        write_omitted(out_dir, omitted)

        # 3. SPLIT Output (Strictly SPLIT/)
        repo_pack_paths = [f"repo/{p}" for p in include_paths]
        write_split_pack(out_dir, repo_pack_paths, scope=scope)

        # 4. FULL Output (Strictly FULL/) - if combined requested (renamed from legacy flag)
        # We respect the legacy flag '--combined' but map it to producing FULL/ output
        if combined:
            effective_stamp = stamp or digest[:12]
            write_full_outputs(out_dir, stamp=effective_stamp, scope=scope)

        # 5. LITE Output (Strictly LITE/) + P.2 CAS artifacts
        if split_lite or profile == "lite":
            write_split_pack_lite(out_dir, scope=scope, project_root=source_project_root)
            effective_runs_dir = p2_runs_dir or Path("CAPABILITY/RUNS")
            _emit_p2_lite_artifacts(
                out_dir,
                project_root=source_project_root,
                include_paths=include_paths,
                scope=scope,
                runs_dir=effective_runs_dir,
            )

        # 6. File Inventory
        # effective_stamp used here if combined, otherwise stamp or digest
        eff_stamp_for_tree = stamp or digest[:12]
        write_pack_file_tree_and_index(out_dir, scope=scope, stamp=eff_stamp_for_tree, combined=combined)

        # 7. Archives
        if zip_enabled:
            # Internal Archive lives inside the pack folder (archive/).
            write_pack_internal_archives(out_dir, scope=scope)
            
            # Cleanup root meta/ and repo/ (they are safely inside the Internal Archive zip).
            try:
                shutil.rmtree(out_dir / "meta")
                shutil.rmtree(out_dir / "repo")
            except Exception as exc:
                print(f"PACKER_WARNING: Failed to cleanup root folders: {exc}")

            # External Archive is a zip of the final pack folder under `_packs/_archive/`.
            write_pack_external_archive(out_dir, scope=scope)

            _maybe_delete_previous_pack(current_pack_dir=out_dir, scope=scope)

        # Update baseline
        if use_shared_baseline:
            write_json(baseline_path, manifest)

        return out_dir
`````

## `repo/MEMORY/LLM_PACKER/Engine/packer/lite.py`

```
"""
LITE output generation (Phase 1).

Output target: pack_dir/LITE/
FORBIDDEN: Any reference to COMBINED/ or SPLIT_LITE/ in output paths or documentation.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Sequence

import json
from .core import PackScope, SCOPE_AGS, SCOPE_LAB, read_text, PROJECT_ROOT
from .proofs import get_lite_proof_summary

def rel_posix(*parts: str) -> str:
    return Path(*parts).as_posix()

def write_split_pack_lite(pack_dir: Path, *, scope: PackScope, project_root: Path) -> None:
    """
    Write a discussion-first LITE index.

    P.2 contract: LITE must be manifest-only (no repo file bodies). This module
    only writes human-readable index stubs; manifests and CAS refs are generated
    in `core.py`.
    """
    lite_dir = pack_dir / "LITE"
    lite_dir.mkdir(parents=True, exist_ok=True)

    def write(path: Path, text: str) -> None:
        path.write_text(text.rstrip() + "\n", encoding="utf-8")

    if scope.key == SCOPE_AGS.key:
        canon_contract = rel_posix("LAW", "CANON", "CONTRACT.md")
        canon_invariants = rel_posix("LAW", "CANON", "INVARIANTS.md")
        canon_versioning = rel_posix("LAW", "CANON", "VERSIONING.md")
        contracts_runner = rel_posix("LAW", "CONTRACTS", "runner.py")
        maps_entrypoints = rel_posix("NAVIGATION", "MAPS", "ENTRYPOINTS.md")
        critic_tool = rel_posix("CAPABILITY", "TOOLS", "critic.py")
        skills_dir = rel_posix("CAPABILITY", "SKILLS")
        packer_readme = rel_posix("MEMORY", "LLM_PACKER", "README.md")
        write(
            lite_dir / "AGS-00_INDEX.md",
            "\n".join(
                [
                    "# AGS Pack Index (LITE)",
                    "",
                    "This directory contains a compressed, discussion-first map of the pack.",
                    "",
                    "## Read order",
                    "1) `repo/AGENTS.md`",
                    "2) `repo/README.md`",
                    f"3) `repo/{canon_contract}` and `repo/{canon_invariants}` and `repo/{canon_versioning}`",
                    f"4) `repo/{contracts_runner}`",
                    f"5) `repo/{maps_entrypoints}`",
                    f"6) `repo/{critic_tool}` and `repo/{skills_dir}/*/SKILL.md`",
                    "7) `repo/DIRECTION/` (roadmaps, if used)",
                    f"8) `repo/{packer_readme}`",
                    "9) `meta/PACK_INFO.json`",
                    "10) `meta/FILE_TREE.txt` and `meta/FILE_INDEX.json`",
                    "",
                ]
            ),
        )

        # LITE PROOFS Summary (AGS Only)
        lite_proofs = get_lite_proof_summary(project_root)
        (lite_dir / "PROOFS.json").write_text(json.dumps(lite_proofs, indent=2) + "\n", encoding="utf-8")

    elif scope.key == SCOPE_LAB.key:
        write(
            lite_dir / "LAB-00_INDEX.md",
            "\n".join(
                [
                    "# LAB Pack Index (LITE)",
                    "",
                    "This directory contains a compressed, discussion-first map of the pack.",
                    "",
                    "## Read order",
                    "1) `repo/THOUGHT/LAB/`",
                    "2) `meta/PACK_INFO.json`",
                    "3) `meta/FILE_TREE.txt` and `meta/FILE_INDEX.json`",
                    "",
                ]
            ),
        )

def write_lite_indexes(
    pack_dir: Path,
    *,
    project_root: Path,
    include_paths: Sequence[str],
    omitted_paths: Sequence[str],
    files_by_path: Dict[str, Dict[str, Any]],
) -> None:
    """Write lightweight indexes to LITE/."""
    # (Simplified from legacy packer, focused on LITE/ output)
    pass # Implementation deferred for rigorous ELO logic later; 
         # split_pack_lite handles the critical path for Phase 1.
```

## `repo/MEMORY/LLM_PACKER/Engine/packer/proofs.py`

```
#!/usr/bin/env python3
"""
Proof generation and refresh for LLM Packer.

Generates proof artifacts under NAVIGATION/PROOFS/_LATEST/ including:
- GREEN_STATE (git state, timestamps, command results)
- CATALYTIC proof outputs
- COMPRESSION proof outputs
- PROOF_MANIFEST (comprehensive manifest of all proof files)

All proofs are written atomically (temp dir + rename) and fail-closed.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Proof directories (relative to project root)
PROOFS_DIR = Path("NAVIGATION/PROOFS")
RUNS_DIR = PROOFS_DIR / "_RUNS"

# Proof suite config (optional)
PROOF_SUITE_CONFIG = PROOFS_DIR / "PROOF_SUITE.json"


def _sha256_file(path: Path) -> str:
    """Compute SHA256 hash of a file."""
    hasher = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def _sha256_bytes(data: bytes) -> str:
    """Compute SHA256 hash of bytes."""
    return hashlib.sha256(data).hexdigest()


def _run_command(
    cmd: List[str], *, cwd: Path, timeout: int = 300
) -> Tuple[int, bytes, bytes]:
    """
    Run a command and capture stdout/stderr.
    Returns (exit_code, stdout_bytes, stderr_bytes).
    """
    env = os.environ.copy()
    # Avoid pytest/capture tmpfile issues by forcing a stable temp root.
    try:
        tmp_root = (cwd / "LAW" / "CONTRACTS" / "_runs" / "pytest_tmp").resolve()
        tmp_root.mkdir(parents=True, exist_ok=True)
        env["TMPDIR"] = str(tmp_root)
        env["TMP"] = str(tmp_root)
        env["TEMP"] = str(tmp_root)
    except Exception:
        pass

    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as e:
        return -1, b"", f"Command timed out after {timeout}s".encode("utf-8")
    except Exception as e:
        return -1, b"", str(e).encode("utf-8")


def _get_git_state(project_root: Path) -> Dict[str, Any]:
    """Capture current git state."""
    
    def run_git(args: List[str]) -> str:
        try:
            result = subprocess.run(
                ["git"] + args,
                cwd=project_root,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10,
                check=False,
                text=True,
            )
            if result.returncode == 0:
                return result.stdout.strip()
            return ""
        except Exception:
            return ""
    
    commit = run_git(["rev-parse", "HEAD"])
    branch = run_git(["rev-parse", "--abbrev-ref", "HEAD"])
    status = run_git(["status", "--porcelain"])
    
    return {
        "repo_head_commit": commit or "unknown",
        "branch": branch or "unknown",
        "git_status": status if status else "clean",
        "is_clean": not bool(status),
    }


def _load_proof_suite(project_root: Path) -> List[List[str]]:
    """
    Load proof suite commands from PROOF_SUITE.json if it exists.
    Otherwise, return the minimal default suite.
    """
    config_path = project_root / PROOF_SUITE_CONFIG
    
    if config_path.exists():
        try:
            with config_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
                commands = data.get("commands", [])
                # Replace bare "python" with sys.executable
                normalized = []
                for cmd in commands:
                    if cmd and cmd[0] == "python":
                        normalized.append([sys.executable] + cmd[1:])
                    else:
                        normalized.append(cmd)
                return normalized
        except Exception:
            pass
    
    # Default minimal suite
    #
    # IMPORTANT: do NOT invoke pytest here by default. Proof refresh is called by the
    # packer during other tests/fixtures; invoking pytest here creates recursive/very
    # slow test runs (and can appear "stuck"). Opt into a stronger proof suite by
    # providing NAVIGATION/PROOFS/PROOF_SUITE.json.
    return [[sys.executable, "--version"]]


def _generate_green_state(
    project_root: Path,
    *,
    stamp: str,
    commands_executed: List[Dict[str, Any]],
    start_time: datetime,
    end_time: datetime,
) -> Tuple[Dict[str, Any], str]:
    """
    Generate GREEN_STATE.json and GREEN_STATE.md.
    Returns (json_data, markdown_content).
    """
    git_state = _get_git_state(project_root)
    duration = (end_time - start_time).total_seconds()
    
    json_data = {
        "stamp": stamp,
        "repo_head_commit": git_state["repo_head_commit"],
        "branch": git_state["branch"],
        "git_status": git_state["git_status"],
        "is_clean": git_state["is_clean"],
        "start_time": start_time.isoformat(),
        "end_time": end_time.isoformat(),
        "duration_seconds": duration,
        "commands": commands_executed,
    }
    
    # Generate markdown
    md_lines = [
        "# Green State Report",
        "",
        f"**Stamp:** `{stamp}`",
        f"**Commit:** `{git_state['repo_head_commit']}`",
        f"**Branch:** `{git_state['branch']}`",
        f"**Git Status:** {'clean' if git_state['is_clean'] else 'dirty'}",
        "",
        f"**Start Time:** {start_time.isoformat()}",
        f"**End Time:** {end_time.isoformat()}",
        f"**Duration:** {duration:.2f}s",
        "",
        "## Commands Executed",
        "",
    ]
    
    for i, cmd_info in enumerate(commands_executed, 1):
        md_lines.extend([
            f"### Command {i}",
            "",
            f"**Command:** `{' '.join(cmd_info['command'])}`",
            f"**Exit Code:** {cmd_info['exit_code']}",
            f"**Status:** {'PASS' if cmd_info['exit_code'] == 0 else 'FAIL'}",
            f"**Stdout SHA256:** `{cmd_info['stdout_sha256']}`",
            f"**Stderr SHA256:** `{cmd_info['stderr_sha256']}`",
            "",
        ])
    
    md_content = "\n".join(md_lines)
    return json_data, md_content


def _generate_catalytic_proof(
    project_root: Path, *, proof_dir: Path, commands: List[List[str]]
) -> Tuple[bool, List[Dict[str, Any]]]:
    """
    Run catalytic proof commands and generate outputs.
    Returns (success, commands_info).
    """
    catalytic_dir = proof_dir / "CATALYTIC"
    catalytic_dir.mkdir(parents=True, exist_ok=True)
    
    all_stdout = []
    all_stderr = []
    commands_info = []
    overall_success = True
    
    for cmd in commands:
        exit_code, stdout, stderr = _run_command(cmd, cwd=project_root)
        
        all_stdout.append(stdout)
        all_stderr.append(stderr)
        
        cmd_info = {
            "command": cmd,
            "exit_code": exit_code,
            "stdout_sha256": _sha256_bytes(stdout),
            "stderr_sha256": _sha256_bytes(stderr),
        }
        commands_info.append(cmd_info)
        
        if exit_code != 0:
            overall_success = False
    
    # Write combined log
    combined_log = b"\n".join(all_stdout + all_stderr)
    (catalytic_dir / "PROOF_LOG.txt").write_bytes(combined_log)
    
    # Write summary
    summary_lines = [
        "# Catalytic Proof Summary",
        "",
        f"**Overall Status:** {'PASS' if overall_success else 'FAIL'}",
        "",
        "## Commands",
        "",
    ]
    
    for i, cmd_info in enumerate(commands_info, 1):
        status = "✓ PASS" if cmd_info["exit_code"] == 0 else "✗ FAIL"
        summary_lines.append(f"{i}. `{' '.join(cmd_info['command'])}` — {status}")
    
    summary_lines.append("")
    (catalytic_dir / "PROOF_SUMMARY.md").write_text("\n".join(summary_lines), encoding="utf-8")
    
    return overall_success, commands_info


def _generate_compression_proof(
    project_root: Path, *, proof_dir: Path
) -> bool:
    """
    Generate compression proof outputs by copying existing compression proof artifacts.
    Returns True if successful.
    """
    compression_dir = proof_dir / "COMPRESSION"
    compression_dir.mkdir(parents=True, exist_ok=True)
    
    # Source compression proof directory
    source_compression = project_root / "NAVIGATION/PROOFS/COMPRESSION"
    
    if not source_compression.exists():
        # Create minimal placeholder
        (compression_dir / "COMPRESSION_PROOF_REPORT.md").write_text(
            "# Compression Proof\n\nNo compression proof artifacts found.\n",
            encoding="utf-8"
        )
        (compression_dir / "COMPRESSION_PROOF_DATA.json").write_text(
            json.dumps({"status": "not_available"}, indent=2),
            encoding="utf-8"
        )
        (compression_dir / "PROOF_LOG.txt").write_text("", encoding="utf-8")
        return True
    
    # Copy existing compression proof artifacts
    try:
        for artifact in ["COMPRESSION_PROOF_REPORT.md", "COMPRESSION_PROOF_DATA.json"]:
            src = source_compression / artifact
            if src.exists():
                shutil.copy2(src, compression_dir / artifact)
        
        # Create a log file (empty for now, as compression proof is pre-generated)
        (compression_dir / "PROOF_LOG.txt").write_text(
            "Compression proof artifacts copied from NAVIGATION/PROOFS/COMPRESSION/\n",
            encoding="utf-8"
        )
        return True
    except Exception:
        return False


def _generate_proof_manifest(
    proof_dir: Path,
    *,
    stamp: str,
    repo_head_commit: str,
    overall_status: str,
    executed_commands: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Generate PROOF_MANIFEST.json listing all files under proof_dir.
    """
    files = []
    for path in sorted(proof_dir.rglob("*")):
        if path.is_file():
            rel_path = path.relative_to(proof_dir).as_posix()
            files.append({
                "relative_path": rel_path,
                "sha256": _sha256_file(path),
                "size_bytes": path.stat().st_size,
            })
    
    manifest = {
        "stamp": stamp,
        "repo_head_commit": repo_head_commit,
        "overall_status": overall_status,
        "executed_commands": executed_commands,
        "files": files,
    }
    
    return manifest


def refresh_proofs(
    project_root: Path,
    *,
    stamp: str,
    save_run_history: bool = False,
) -> Tuple[bool, Optional[str]]:
    """
    Refresh proof artifacts under NAVIGATION/PROOFS/_LATEST/.
    
    Returns (success, error_message).
    
    Atomicity: writes to temp dir first, then atomically replaces _LATEST.
    Fail-closed: if ANY proof command fails, _LATEST is NOT updated.
    """
    start_time = datetime.now(timezone.utc)
    
    # Create temp directory for atomic write
    temp_dir = project_root / PROOFS_DIR / f"_LATEST.__tmp__{stamp}"
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Load proof suite
        commands = _load_proof_suite(project_root)
        
        # Generate catalytic proof
        catalytic_success, commands_info = _generate_catalytic_proof(
            project_root, proof_dir=temp_dir, commands=commands
        )
        
        if not catalytic_success:
            error_msg = "Catalytic proof failed: one or more commands returned non-zero exit code"
            return False, error_msg
        
        # Generate compression proof
        compression_success = _generate_compression_proof(
            project_root, proof_dir=temp_dir
        )
        
        if not compression_success:
            error_msg = "Compression proof generation failed"
            return False, error_msg
        
        end_time = datetime.now(timezone.utc)
        
        # Generate green state
        green_state_json, green_state_md = _generate_green_state(
            project_root,
            stamp=stamp,
            commands_executed=commands_info,
            start_time=start_time,
            end_time=end_time,
        )
        
        (temp_dir / "GREEN_STATE.json").write_text(
            json.dumps(green_state_json, indent=2, sort_keys=True) + "\n",
            encoding="utf-8"
        )
        (temp_dir / "GREEN_STATE.md").write_text(green_state_md, encoding="utf-8")
        
        # Generate proof manifest
        git_state = _get_git_state(project_root)
        manifest = _generate_proof_manifest(
            temp_dir,
            stamp=stamp,
            repo_head_commit=git_state["repo_head_commit"],
            overall_status="PASS",
            executed_commands=commands_info,
        )
        
        (temp_dir / "PROOF_MANIFEST.json").write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8"
        )
        
        
        # Deploy: clean up old _LATEST if exists (migration) and copy temp to dispersed locations
        latest_path = project_root / PROOFS_DIR / "_LATEST"
        if latest_path.exists():
            shutil.rmtree(latest_path)
            
        # Distribute artifacts to parent folders
        # 1. Root artifacts (GREEN_STATE*, PROOF_MANIFEST)
        for name in ["GREEN_STATE.json", "GREEN_STATE.md", "PROOF_MANIFEST.json"]:
            src = temp_dir / name
            dst = project_root / PROOFS_DIR / name
            if src.exists():
                shutil.copy2(src, dst)
                
        # 2. Subdirectories (CATALYTIC, COMPRESSION)
        for subdir in ["CATALYTIC", "COMPRESSION"]:
            src_sub = temp_dir / subdir
            dst_sub = project_root / PROOFS_DIR / subdir
            dst_sub.mkdir(parents=True, exist_ok=True)
            if src_sub.exists():
                # Copy/overwrite files
                for item in src_sub.iterdir():
                    if item.is_file():
                        shutil.copy2(item, dst_sub / item.name)
        
        # Optionally save to _RUNS history
        if save_run_history:
            runs_path = project_root / RUNS_DIR / stamp
            runs_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(temp_dir, runs_path)
            
        return True, None
        
    except Exception as e:
        # Cleanup temp dir on failure
        if temp_dir.exists():
            shutil.rmtree(temp_dir)
        return False, f"Proof generation failed: {e}"
    finally:
        # Always cleanup temp dir
        if temp_dir.exists():
            shutil.rmtree(temp_dir)


def get_lite_proof_summary(project_root: Path) -> Dict[str, Any]:
    """
    Generate a minimal PROOFS.json summary for LITE packs.
    Returns a small JSON object with key proof metadata.
    """
    proots_path = project_root / PROOFS_DIR
    
    manifest_path = proots_path / "PROOF_MANIFEST.json"
    green_state_path = proots_path / "GREEN_STATE.json"
    
    if not manifest_path.exists():
        return {
            "status": "not_available",
            "message": "No proof manifest found at NAVIGATION/PROOFS/PROOF_MANIFEST.json",
        }
    
    try:
        manifest = {}
        with manifest_path.open("r", encoding="utf-8") as f:
            manifest = json.load(f)
        
        green_state = {}
        if green_state_path.exists():
            with green_state_path.open("r", encoding="utf-8") as f:
                green_state = json.load(f)
        
        # Build minimal summary
        summary = {
            "overall_status": manifest.get("overall_status", "unknown"),
            "repo_head_commit": manifest.get("repo_head_commit", "unknown"),
            "stamp": manifest.get("stamp", "unknown"),
            "proof_files": {
                "green_state": _sha256_file(green_state_path) if green_state_path.exists() else None,
                "catalytic_summary": _sha256_file(proots_path / "CATALYTIC/PROOF_SUMMARY.md") if (proots_path / "CATALYTIC/PROOF_SUMMARY.md").exists() else None,
                "compression_report": _sha256_file(proots_path / "COMPRESSION/COMPRESSION_PROOF_REPORT.md") if (proots_path / "COMPRESSION/COMPRESSION_PROOF_REPORT.md").exists() else None,
                "manifest": _sha256_file(manifest_path) if manifest_path.exists() else None,
            },
        }
        
        return summary
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to read proof artifacts: {e}",
        }
```

## `repo/MEMORY/LLM_PACKER/Engine/packer/split.py`

`````
"""
SPLIT output generation (Phase 1).

Output target: pack_dir/SPLIT/ 
FORBIDDEN: Any reference to COMBINED/ in output paths or documentation.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Sequence

from .core import PackScope, SCOPE_AGS, SCOPE_LAB, read_text

def rel_posix(*parts: str) -> str:
    return Path(*parts).as_posix()

def choose_fence(text: str) -> str:
    """Choose a fence that doesn't conflict with existing fences in text."""
    if "````" in text:
        return "`````"
    if "```" in text:
        return "````"
    return "```"

def write_split_pack(pack_dir: Path, included_repo_paths: Sequence[str], *, scope: PackScope) -> None:
    """Dispatch split pack writing based on scope."""
    if scope.key == SCOPE_AGS.key:
        write_split_pack_ags(pack_dir, included_repo_paths)
    elif scope.key == SCOPE_LAB.key:
        write_split_pack_lab(pack_dir, included_repo_paths, scope=scope)
    else:
        raise ValueError(f"Unsupported scope for split pack: {scope.key}")

def write_split_pack_ags(pack_dir: Path, included_repo_paths: Sequence[str]) -> None:
    # Target: SPLIT/ directory
    split_dir = pack_dir / "SPLIT"
    split_dir.mkdir(parents=True, exist_ok=True)

    def section(paths: Sequence[str]) -> str:
        out_lines: List[str] = []
        for rel in paths:
            src = pack_dir / rel
            if not src.exists():
                continue
            text = read_text(src)
            fence = choose_fence(text)
            out_lines.append(f"## `{rel}`")
            out_lines.append("")
            out_lines.append(fence)
            out_lines.append(text.rstrip("\n"))
            out_lines.append(fence)
            out_lines.append("")
        return "\n".join(out_lines).rstrip() + "\n"

    # Group paths (6-bucket structure + optional root files + PROOFS)
    # Extract PROOFS from NAVIGATION
    navigation_all = [p for p in included_repo_paths if p.startswith("repo/NAVIGATION/")]
    proof_paths = [p for p in navigation_all if p.startswith("repo/NAVIGATION/PROOFS/")]
    navigation_paths = [p for p in navigation_all if not p.startswith("repo/NAVIGATION/PROOFS/")]

    law_paths = [p for p in included_repo_paths if p.startswith("repo/LAW/")]
    capability_paths = [p for p in included_repo_paths if p.startswith("repo/CAPABILITY/")]
    # navigation_paths defined above
    direction_paths = [p for p in included_repo_paths if p.startswith("repo/DIRECTION/")]
    thought_paths = [p for p in included_repo_paths if p.startswith("repo/THOUGHT/")]
    memory_paths = [p for p in included_repo_paths if p.startswith("repo/MEMORY/")]
    root_paths = [p for p in included_repo_paths if p.startswith("repo/") and p.count("/") == 1]
    github_paths = [p for p in included_repo_paths if p.startswith("repo/.github/")]

    meta_dir = pack_dir / "meta"
    meta_paths = sorted([f"meta/{p.name}" for p in meta_dir.iterdir() if p.is_file()]) if meta_dir.exists() else []

    canon_contract = rel_posix("LAW", "CANON", "CONTRACT.md")
    canon_invariants = rel_posix("LAW", "CANON", "INVARIANTS.md")
    canon_versioning = rel_posix("LAW", "CANON", "VERSIONING.md")
    maps_entrypoints = rel_posix("NAVIGATION", "MAPS", "ENTRYPOINTS.md")
    contracts_runner = rel_posix("LAW", "CONTRACTS", "runner.py")
    skills_dir = rel_posix("CAPABILITY", "SKILLS")
    cortex_dir = rel_posix("NAVIGATION", "CORTEX")
    tools_dir = rel_posix("CAPABILITY", "TOOLS")

    # Write Index (NO COMBINED references)
    (split_dir / "AGS-00_INDEX.md").write_text(
        "\n".join(
            [
                "# AGS Pack Index",
                "",
                "This directory contains a generated snapshot of the repository intended for LLM handoff.",
                "",
                "## Read order",
                "1) `repo/AGENTS.md`",
                "2) `repo/README.md`",
                f"3) `repo/{canon_contract}` and `repo/{canon_invariants}` and `repo/{canon_versioning}`",
                f"4) `repo/{maps_entrypoints}`",
                f"5) `repo/{contracts_runner}` and `repo/{skills_dir}/`",
                f"6) `repo/{cortex_dir}/` and `repo/{tools_dir}/`",
                "7) `meta/ENTRYPOINTS.md` and `meta/PACK_INFO.json` (Snapshot specific)",
                "",
                "## Notes",
                "- `BUILD` contents are excluded.",
                "- Single-file bundles available in `FULL/`.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    (split_dir / "AGS-01_LAW.md").write_text("# LAW\n\n" + section(law_paths), encoding="utf-8")
    (split_dir / "AGS-02_CAPABILITY.md").write_text("# CAPABILITY\n\n" + section(capability_paths), encoding="utf-8")
    (split_dir / "AGS-03_NAVIGATION.md").write_text("# NAVIGATION\n\n" + section(navigation_paths), encoding="utf-8")
    
    # AGS-04_PROOFS (New)
    (split_dir / "AGS-04_PROOFS.md").write_text("# PROOFS\n\n" + section(proof_paths), encoding="utf-8")

    # DIRECTION/THOUGHT are intentionally omitted from the AGS pack.
    # Keep SPLIT numbering contiguous.

    (split_dir / "AGS-05_MEMORY.md").write_text("# MEMORY\n\n" + section(memory_paths), encoding="utf-8")
    
    (split_dir / "AGS-06_ROOT_FILES.md").write_text(
        "# ROOT_FILES\n\n" + section([*root_paths, *github_paths, *meta_paths]),
        encoding="utf-8",
    )

def write_split_pack_lab(pack_dir: Path, included_repo_paths: Sequence[str], *, scope: PackScope) -> None:
    split_dir = pack_dir / "SPLIT"
    split_dir.mkdir(parents=True, exist_ok=True)

    def section(paths: Sequence[str]) -> str:
        out_lines: List[str] = []
        for rel in paths:
            src = pack_dir / rel
            if not src.exists():
                continue
            text = read_text(src)
            fence = choose_fence(text)
            out_lines.append(f"## `{rel}`")
            out_lines.append("")
            out_lines.append(fence)
            out_lines.append(text.rstrip("\n"))
            out_lines.append(fence)
            out_lines.append("")
        return "\n".join(out_lines).rstrip() + "\n"

    def is_lab(path: str) -> bool:
        return path.startswith("repo/THOUGHT/LAB/")

    meta_dir = pack_dir / "meta"
    meta_paths = sorted([f"meta/{p.name}" for p in meta_dir.iterdir() if p.is_file()]) if meta_dir.exists() else []

    lab_paths = [p for p in included_repo_paths if is_lab(p)]
    docs_paths = sorted([p for p in lab_paths if p.lower().endswith((".md", ".txt"))])
    system_paths = sorted([p for p in lab_paths if p not in set(docs_paths)])

    (split_dir / "LAB-00_INDEX.md").write_text(
        "\n".join(
            [
                "# LAB Pack Index",
                "",
                "This directory contains a generated snapshot intended for LLM handoff.",
                "",
                "## Read order",
                "1) `repo/THOUGHT/LAB/`",
                "2) `meta/ENTRYPOINTS.md` and `meta/PACK_INFO.json`",
                "",
                "## Notes",
                "- See `FULL/` for single-file bundles.",
                "- This scope is volatile and may change without notice.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    (split_dir / "LAB-01_DOCS.md").write_text("# Docs\n\n" + section(docs_paths), encoding="utf-8")
    (split_dir / "LAB-02_SYSTEM.md").write_text("# System\n\n" + section([*system_paths, *meta_paths]), encoding="utf-8")
`````

## `repo/MEMORY/LLM_PACKER/Engine/run_tests.cmd`

```
@echo off
setlocal
echo Running LLM Packer Smoke Tests...
python CAPABILITY/SKILLS/cortex/llm-packer-smoke/run.py CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/basic/input.json LAW/CONTRACTS/_runs/test_smoke/actual_basic.json
if %ERRORLEVEL% NEQ 0 goto :error
python CAPABILITY/SKILLS/cortex/llm-packer-smoke/validate.py LAW/CONTRACTS/_runs/test_smoke/actual_basic.json CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/basic/expected.json
if %ERRORLEVEL% NEQ 0 goto :error

echo Running Lite Profile Check...
python CAPABILITY/SKILLS/cortex/llm-packer-smoke/run.py CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/lite/input.json LAW/CONTRACTS/_runs/test_smoke/actual_lite.json
if %ERRORLEVEL% NEQ 0 goto :error
python CAPABILITY/SKILLS/cortex/llm-packer-smoke/validate.py LAW/CONTRACTS/_runs/test_smoke/actual_lite.json CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/lite/expected.json
if %ERRORLEVEL% NEQ 0 goto :error

echo ALL TESTS PASSED.
exit /b 0

:error
echo TESTS FAILED.
exit /b 1
```

## `repo/MEMORY/LLM_PACKER/README.md`

```
<!-- CONTENT_HASH: 4153d19ca4aba63f588ca9f4609f93dfecd40c10689797ff8e8af6352c7a6d98 -->

# LLM_PACKER

**Version:** 1.3.3

Utility to bundle repo content into a small, shareable snapshot for an LLM.

## Scopes

- `ags` (default): packs the full AGS repo (governance system), excluding `THOUGHT/LAB/**`
- `lab`: packs `THOUGHT/LAB/**` (volatile research)

## What it includes (FULL profile)

- Repo sources (text only): `LAW/`, `CAPABILITY/`, `NAVIGATION/`, `DIRECTION/`, `THOUGHT/`, `MEMORY/`, `.github/`
- Key root files (text): `AGENTS.md`, `README.md`, `LICENSE`, `.editorconfig`, `.gitattributes`, `.gitignore`
- Planning/history snapshots: `MEMORY/ARCHIVE/` (if present)
- Generated indices under `meta/` (start here, entrypoints, file tree, file index, BUILD inventory)
- Optional `FULL/` output for easy sharing:
  - `<PREFIX>-FULL-<stamp>.md`
  - `<PREFIX>-FULL-TREEMAP-<stamp>.md`
- `SPLIT/` output for LLM-friendly loading:
  - `<PREFIX>-00_INDEX.md` plus scope-specific section files
- Optional `LITE/` output for discussion-first loading (index + selected SPLIT chunks)

## Default behavior (LLM-PACK.cmd)

Double-clicking `1-AGS-PACK.cmd` produces a single pack folder with:

- `FULL/**`, `SPLIT/**`, and `LITE/**`
- An **Internal Archive** inside the pack at `<pack>/archive/pack.zip` (contains `meta/` + `repo/` only) plus scope-prefixed `.txt` siblings
- An **External Archive** at `MEMORY/LLM_PACKER/_packs/_archive/<pack_name>.zip` (zips the entire final pack folder)

## LITE profile (discussion-first)

The LITE profile produces a smaller, high-signal pack:

- Includes: `AGENTS.md`, `README.md`, `LAW/CANON/**`, `LAW/CONTRACTS/**`, `NAVIGATION/MAPS/**`, and the most relevant parts of `CAPABILITY/` and `MEMORY/LLM_PACKER/`.
- Excludes: most low-signal bulk content; always excludes `BUILD/`.

P.2 CAS-backed behavior (when `LITE/` is generated):
- Writes `LITE/PACK_MANIFEST.json` (path → `sha256:<hash>` refs; no raw repo bodies).
- Writes `LITE/RUN_REFS.json` (CAS record refs for `TASK_SPEC`, `OUTPUT_HASHES`, and final `STATUS`).
- Emits roots to `CAPABILITY/RUNS/RUN_ROOTS.json` and gates completion on `CAPABILITY/AUDIT/root_audit.py` Mode B.

## How to run

Double-click: `MEMORY/LLM_PACKER/Engine/1-AGS-PACK.cmd`

Double-click: `MEMORY/LLM_PACKER/Engine/2-LAB-PACK.cmd`

Or run in PowerShell:

`powershell -NoProfile -ExecutionPolicy Bypass -File MEMORY/LLM_PACKER/Engine/pack.ps1`

Or run cross-platform:

`python -m MEMORY.LLM_PACKER.Engine.packer --scope ags --mode full --combined --zip`

Optional arguments:

- `--scope ags` or `--scope lab`
- `--out-dir MEMORY/LLM_PACKER/_packs/<name>` (must be under `MEMORY/LLM_PACKER/_packs/`)
- `--mode full` or `--mode delta`
- `--profile full` or `--profile lite`
- `--stamp <stamp>` (used for timestamped FULL output filenames)
- `--split-lite` (write `LITE/**` alongside SPLIT)
- `--zip` (write both Internal + External archives; see “Default behavior”)

## Output

Creates a pack folder under:

`MEMORY/LLM_PACKER/_packs/` (default for user runs)

Fixture/smoke outputs should go under:

`MEMORY/LLM_PACKER/_packs/_system/fixtures/`

And optionally produces a `.zip` archived under:

`MEMORY/LLM_PACKER/_packs/_archive/<pack_name>.zip`

Baseline state used for delta packs is stored at:

`MEMORY/LLM_PACKER/_packs/_system/_state/baseline.json`

## Token Estimation

Token estimation is not emitted by the current Phase 1 modular packer.

## Changelog

See `MEMORY/LLM_PACKER/CHANGELOG.md`.
```

## `repo/MEMORY/MEMORY_STORE.md`

````
<!-- CONTENT_HASH: e7605ce8b44ac3dc4f67cd7051b722385246b36cd76dc66e94b3ec487dceeccb -->

# Memory Store

This document describes the persistent memory architecture for AGS agents.

## Overview

The memory system allows agents to persist state across sessions through a tiered storage model:

```
┌─────────────────────────────────────────────────────────────────┐
│                        MEMORY TIERS                              │
├─────────────────────────────────────────────────────────────────┤
│  Tier 1: Session Memory (ephemeral)                             │
│    - Current conversation context                                │
│    - Working state                                               │
│    - Lost when session ends                                      │
├─────────────────────────────────────────────────────────────────┤
│  Tier 2: Pack Memory (persistent, immutable)                    │
│    - LLM packs in MEMORY/LLM_PACKER/_packs/                 │
│    - Full repo snapshots                                         │
│    - Append-only: new packs created, old ones archived          │
├─────────────────────────────────────────────────────────────────┤
│  Tier 3: Context Memory (persistent, append-first)              │
│    - ADRs in CONTEXT/decisions/                                  │
│    - Rejected paths in CONTEXT/rejected/                         │
│    - Preferences in CONTEXT/preferences/                         │
│    - Editing existing records requires explicit instruction     │
└─────────────────────────────────────────────────────────────────┘
```

## Promotion Rules

| From | To | Trigger | Process |
|------|----|---------|---------| 
| Session → ADR | Significant decision made | Agent drafts ADR, user approves |
| Session → Pack | Session ending with valuable context | Run packer to snapshot |
| Pack → Summarized Pack | Pack too large for context | Run summarization skill |

## Mutability Rules

| Tier | Mutable? | Rules |
|------|----------|-------|
| Session | Yes | No restrictions during session |
| Packs | **Append-only** | Create new pack, never modify existing |
| Context/decisions | **Append-first** | New ADRs freely; edits require explicit instruction |
| Context/rejected | **Append-first** | Record rejections; edits require instruction |
| Context/preferences | **Append-first** | Add preferences; edits require instruction |

## Pack Lifecycle

1. **Creation**: `python MEMORY/packer.py --mode full` creates a new pack with timestamp
2. **Manifest**: Each pack includes `manifest.json` with file hashes for integrity
3. **Verification**: On load, compute hashes and compare to manifest
4. **Archival**: Old packs remain in `_packs/` for history

## Summarization Workflow

When pack size exceeds context limits:

1. Load full pack
2. Extract key decisions, file changes, and outcomes
3. Generate compressed summary maintaining essential context
4. Store summary pack alongside full pack

## Usage

```python
from MEMORY.packer import make_pack, build_state_manifest, verify_manifest

# Create a new pack
make_pack(mode="full", combined=True, stamp=None, zip_enabled=False)

# Build manifest for current state
manifest, omitted = build_state_manifest(PROJECT_ROOT)

# Verify pack integrity
is_valid = verify_manifest(pack_dir)
```
````

## `repo/MEMORY/PACKER_ROADMAP.md`

````
<!-- CONTENT_HASH: 989e618d2405bee643d4a04f67bf0ccf30ee24d49cf9bf6e274047b0a3ec231d -->

# LLM Packer Roadmap

## Target Pack Structure

```
pack/
 ├── FULL/                    # Combined single-file outputs (.md only)
 ├── SPLIT/                   # Chunked sections (INDEX, CANON, ROOT, MAPS, etc.)
 ├── LITE/                    # Compressed SPLIT with ELO tiers
 └── archive/
     ├── pack.zip             # Contains ONLY: meta/ + repo/
     ├── FULL.txt             # txt copies NEXT TO zip (not inside)
     ├── FULL-TREEMAP.txt
     ├── SPLIT-INDEX.txt
     ├── SPLIT-CANON.txt
     ├── LITE-INDEX.txt
     ├── <SCOPE>-FULL.txt     # txt copies NEXT TO zip (not inside); MUST be scope-prefixed (AGS-/CAT-/LAB-)
     ├── <SCOPE>-FULL-TREEMAP.txt
     ├── <SCOPE>-SPLIT-INDEX.txt
     ├── <SCOPE>-SPLIT-CANON.txt
     ├── <SCOPE>-LITE-INDEX.txt
     └── ...                  # etc for all md files
```

**Scopes (mutually exclusive):**
- AGS: excludes CAT and LAB
- CAT: excludes AGS and LAB
- LAB: excludes AGS and CAT

---

## LLM Packer Role in AGS

The **LLM Packer** is the **context compression engine** for AGS. It creates compressed "memory packs" that give LLMs a bounded view of the repository without loading everything into context.

### How It Fits with CAS and Cassette Network

```
┌─────────────────────────────────────────┐
│   LLM Packer (Compression Strategy)     │
│   "What should the LLM see?"            │
└─────────────────┬───────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│   CAS (Storage Layer)                   │
│   "How should we store it?"             │
│   - Deduplication (same hash = one blob)│
│   - Immutable (hash = content)          │
└─────────────────┬───────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│   Cassette Network (Discovery)          │
│   "How do we find what we need?"        │
│   - Semantic search (vectors)           │
│   - Symbol resolution (@Symbols)        │
└─────────────────────────────────────────┘
```

**Key Insight:** LLM Packer decides *what* to include (compression logic), CAS stores *how* (deduplicated blobs), and Cassette Network enables *discovery* (semantic search).

**Future Integration (Lane Z.2):** LITE packs will become manifests (pointers to CAS hashes) instead of storing full file bodies.

---

## Phase 0: 6-Bucket Migration (P0)

**Status:** ❌ **Not Started**  
**Blocker:** LLM Packer still references old paths (CANON/, CONTEXT/, etc.)

### Tasks
- [ ] Update `Engine/packer/core.py` to use new bucket paths:
  - `CANON/` → `LAW/CANON/`
  - `CONTEXT/` → `LAW/CONTEXT/` (decisions, preferences, rejected, open)
  - `CONTRACTS/` → `LAW/CONTRACTS/`
  - `SKILLS/` → `CAPABILITY/SKILLS/`
  - `TOOLS/` → `CAPABILITY/TOOLS/`
  - `MCP/` → `CAPABILITY/MCP/`
  - `PRIMITIVES/` → `CAPABILITY/PRIMITIVES/`
  - `CORTEX/` → `NAVIGATION/CORTEX/`
  - `MAPS/` → `NAVIGATION/MAPS/`
- [ ] Update `Engine/packer/split.py` to scan new bucket roots
- [ ] Update `Engine/packer/lite.py` to prioritize new bucket structure (HIGH ELO: LAW/CANON/, NAVIGATION/MAPS/)
- [ ] Update all scope configs (AGS, CAT, LAB) to reference new paths
- [ ] Update tests in `CONTRACTS/` to verify new bucket paths
- [ ] Update documentation (README, AGENTS.md) to reference new structure

### Exit Criteria
- Packer successfully generates packs using new bucket paths
- All tests pass with new structure
- No references to old paths (CANON/, CONTEXT/, etc.) in packer code

---

## Phase 1: Fix Output + Modularize Together

Do NOT fix code then modularize. Modularize AS you fix so we only do it once.

### Create Package Structure First

- [x] Create `Engine/packer/` directory
- [x] Create `Engine/packer/__init__.py` exporting: `make_pack`, `verify_manifest`, `PackScope`, `PROJECT_ROOT`
- [x] Create `Engine/packer/__main__.py` for canonical `python -m` entry point

### Modularize + Fix Duplication (core.py)

- [x] Create `Engine/packer/core.py` with:
  - `hash_file`, `read_text`, `estimate_tokens`
  - `build_state_manifest`, `manifest_digest`, `load_baseline`
  - `PackScope` dataclass
  - `render_tree` for deterministic visual file tree generation
  - `write_pack_file_tree_and_index` generating `meta/FILE_TREE.txt` and `FULL/*TREEMAP*`
- [x] Remove `FULL_COMBINED/` creation — outputs go to `FULL/` only
- [x] Remove `COMBINED/` folder — no longer exists
- [x] Remove mirroring logic (no duplicate SPLIT/, SPLIT_LITE/)
- [x] Restore treemap outputs: `meta/FILE_TREE.txt`, `FULL/{SCOPE}-TREEMAP-{stamp}.md/txt`

### Modularize + Fix Split (split.py)

- [x] Create `Engine/packer/split.py` with:
  - `write_split_pack`, `write_split_pack_ags`
  - `write_split_pack_catalytic_dpt`, `write_split_pack_catalytic_dpt_lab`
- [x] Output directly to `SPLIT/` (not `COMBINED/SPLIT/`)
- [x] Remove all "combined" references from generated markdown content

### Modularize + Fix Lite (lite.py) — Isolated

- [x] Create `Engine/packer/lite.py` with:
  - `write_split_pack_lite`, `write_lite_indexes`
- [x] Output directly to `LITE/` (not `COMBINED/SPLIT_LITE/` or `SPLIT_LITE/`)
- [x] Wrap imports in try/except so LITE failures don't break core packer

### Modularize + Fix Archive (archive.py)

- [x] Create `Engine/packer/archive.py` with:
  - `write_pack_internal_archives`, `_write_zip`, `_iter_files_under`
- [x] Create SINGLE `archive/pack.zip` containing ONLY:
  - `meta/` folder contents
  - `repo/` folder contents
- [x] Generate txt copies of all mds NEXT TO zip (not inside), flat files with clear names
    - [x] All archive sibling txt filenames MUST be prefixed with scope folder: AGS-, CAT-, LAB-
- [x] Remove separate `meta/` and `repo/` folders from pack root
- [x] Do NOT auto-prune archives

### Cleanup

- [x] Delete old `Engine/packer.py` after migration complete
- [x] Update `Engine/pack.ps1` to use canonical `python -m MEMORY.LLM_PACKER.Engine.packer` entry point
- [x] Update `Engine/verify_phase1.py` to verify treemap presence and COMBINED-free output
- [x] Update Launchers (`1-AGS-PACK.cmd`, `2-CAT-PACK.cmd`, `2-LAB-PACK.cmd`)
- [x] Refactor `lab` scope key and naming logic

---

## Phase 2: Update Governance References

Tests are in CONTRACTS and deeply embedded — we update them to match new output structure.

- [x] Create `scan_old_refs.py` script to find all files referencing FULL_COMBINED, COMBINED/SPLIT, SPLIT_LITE (and any other old paths)
- [x] Run scan script and update every file found that references old paths or files.
- [x] Update `SKILLS/llm-packer-smoke/` smoke tests for new structure (FULL/, SPLIT/, LITE/, archive/pack.zip)
- [x] Update `SKILLS/pack-validate/` to validate new structure
- [x] Ensure tests pass with new output structure

---

## Phase 3: Consolidate Documentation

No redundant files. Put everything in its right place.

### AGENTS.md or README.md (pick one for both humans and agents)

- [x] Decide: single file for humans + agents to minimize tokens
- [x] Include:
  - Pack structure spec (from AGI Compression.md)
  - Delta pack flow, baseline state, anchor files (from DELTA_PACKS.md)
  - Scope isolation rules
  - Usage commands (merge logic from SHIPPING.md)
  - Reference DETERMINISM.md (don't inline it)
- [x] Move changelog in README.md to CHANGELOG.md

### Keep Separate

- [x] DETERMINISM.md — technical spec, referenced from AGENTS/README

### Create New

- [x] `run_tests.cmd` — isolated test runner for packer work

### Delete After Content Moved

- [x] Delete `MEMORY/DELTA_PACKS.md`
- [x] Delete `MEMORY/AGI Compression.md`

---

## Phase 4: LITE ELO Implementation (Future)

Not implementing now. Research needed.

### ELO Tier System

- [ ] **HIGH ELO (inline with full integrity):** CANON/*, AGENTS.md, MAPS/*, core contracts — include completely
- [ ] **MEDIUM ELO (summarize):** SKILLS/*/SKILL.md, CONTEXT/decisions/* — show function signatures + one-line purpose, no code
- [ ] **LOW ELO (omit with pointer):** fixtures, logs, research, generated files — explain why removed, what to ask for

### LITE Output Requirements

- [ ] Include all HIGH ELO content with full integrity (no compression)
- [ ] Summarize MEDIUM ELO: function names, purpose, no code body
- [ ] For LOW ELO: list removed files, explain why, tell user how to request more info
- [ ] Check git history for when LITE was functioning correctly

---

## Phase 5: Modular Architecture Contract

- The packer is a package: `MEMORY/LLM_PACKER/Engine/packer/`
- Core utilities are scope-agnostic (hashing, manifests, deterministic IO).
- Scope-specific behavior is modularized so each scope can diverge safely:
  - Separate system/config modules per scope (AGS, CAT, LAB) for:
    - `source_root`
    - split generation mapping
    - lite strategy
    - meta emission differences
- **Rule:** Adding a new scope must not require editing existing scope logic (add new module + register it).

---

## Phase 6: CAS Integration (Future)

**Goal:** Integrate LLM Packer with Content-Addressed Storage (CAS) to enable deduplication and immutable artifact storage.

**Depends on:** Lane Z.2 (F3 / Content-Addressable Storage) must be complete.

### Tasks
- [ ] **Refactor LITE packs to use CAS references**
  - Instead of storing full file bodies, store CAS hashes
  - LITE pack manifest becomes: `{"file": "LAW/CANON/INTEGRITY.md", "hash": "sha256:abc123..."}`
  - File bodies stored in `.cas/` directory (deduplicated)
- [ ] **Update packer to write to CAS**
  - `write_split_pack()` → writes file bodies to CAS, returns hashes
  - `write_lite_pack()` → stores only manifest (pointers to CAS hashes)
- [ ] **Add CAS verification**
  - `verify_manifest()` → checks CAS hashes match file bodies
  - Fail-closed: missing CAS blob = verification failure
- [ ] **Implement garbage collection**
  - Track which CAS blobs are referenced by active packs
  - Prune unreferenced blobs (with safety margin)
- [ ] **Benchmark deduplication savings**
  - Measure storage reduction (same file across multiple packs = one CAS blob)
  - Measure pack generation speed (no need to re-hash identical files)

### Exit Criteria
- LITE packs are 80%+ smaller (manifests only, not full bodies)
- CAS deduplication works (same file = one blob)
- Verification passes (CAS hashes match file bodies)
- Garbage collection is safe (no accidental deletion of active blobs)

---

## Phase 7: Research (Future)

- [ ] **Context Indexing:** Include RAG or index like Cortex?
- [ ] **Competitive Analysis:** What are others doing that works?
- [ ] **Improvement:** How can we make it better?
- [ ] **Research Question:** Is this just RAG?

---

## Known Bugs (Tracked Separately)

- [x] Zip trying to run multiple times concurrently (Solved by strict scoped launchers)
- [x] Zip locking issues on Windows (Solved by write-to-tmp strategy)
- [x] Split for CAT needs verification (Verified)

---

## Do NOT Touch

- Exported packs already in `_packs/` (existing output)
- Already-created archives

## DO Update (Not Protected)

- Main governance tests in CONTRACTS — update to match new structure
- CANON files referencing packer
- Skills using packer output
````
