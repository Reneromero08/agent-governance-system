# ROOT_FILES

## `repo/.editorconfig`

```
root = true

[*]
charset = utf-8
indent_style = space
indent_size = 2
end_of_line = lf
insert_final_newline = true
trim_trailing_whitespace = true

[*.md]
max_line_length = off

[*.json]
indent_size = 2
```

## `repo/.gitattributes`

```
# Ensure consistent line endings
* text=auto eol=lf

# Treat schema files as JSON
*.schema.json linguist-language=JSON

# Preserve binary files
*.png binary
*.jpg binary
*.jpeg binary

*.py text eol=lf
```

## `repo/.gitignore`

```
BUILD/**
!BUILD/.gitkeep

LAW/CONTRACTS/_runs/**
!LAW/CONTRACTS/_runs/.gitkeep
!LAW/CONTRACTS/_runs/_demos/
!LAW/CONTRACTS/_runs/_demos/**
LAW/CONTRACTS/_runs/
LAW/CONTRACTS/_runs/_tmp/

# CAS runtime storage (never commit)
CAPABILITY/CAS/storage/

# Generated Cortex index
NAVIGATION/CORTEX/_generated/cortex.json
NAVIGATION/CORTEX/_generated/cortex.db
NAVIGATION/CORTEX/_generated/*.sqlite
NAVIGATION/CORTEX/_generated/SECTION_INDEX.json
NAVIGATION/CORTEX/_generated/SUMMARY_INDEX.json
NAVIGATION/CORTEX/_generated/summaries/
!NAVIGATION/CORTEX/_generated/.gitkeep

# Generated System1 DB (rebuilt in CI and by runner.py)
NAVIGATION/CORTEX/db/system1.db

# Generated Proof Artifacts (dispersed)
NAVIGATION/PROOFS/GREEN_STATE.json
NAVIGATION/PROOFS/GREEN_STATE.md
NAVIGATION/PROOFS/PROOF_MANIFEST.json
NAVIGATION/PROOFS/CATALYTIC/PROOF_LOG.txt
NAVIGATION/PROOFS/CATALYTIC/PROOF_SUMMARY.md
NAVIGATION/PROOFS/COMPRESSION/PROOF_LOG.txt
NAVIGATION/PROOFS/_RUNS/

# Local-only editor state (not governance-critical)
.claude/
.kilocode/

# Research Cache
LAW/CONTEXT/research/*.db
INBOX/research/*.db

# Legacy log locations (violate INV-006, moved to LAW/CONTRACTS/_runs/ per ADR-015)
LOGS/
CAPABILITY/MCP/logs/


MEMORY/LLM_PACKER/_packs/**
!MEMORY/LLM_PACKER/_packs/
!MEMORY/LLM_PACKER/_packs/.gitkeep
!MEMORY/LLM_PACKER/_packs/_state/
!MEMORY/LLM_PACKER/_packs/_state/.gitkeep
!MEMORY/LLM_PACKER/_packs/_archive/
!MEMORY/LLM_PACKER/_packs/_archive/.gitkeep
!MEMORY/LLM_PACKER/_packs/_archive/**

MEMORY/Original/

# Python Cache
__pycache__/
*.pyc
*.pyo
*.pyd
.pytest_cache/
.coverage
.venv/
env/
venv/
THOUGHT/LAB/CAT_CHAT/nul

# Misplaced Root Artifacts (Legacy paths, should be in LAW/ or NAVIGATION/)
/CONTRACTS/
/CORTEX/
/DIRECTION/
/MAPS/
/SKILLS/

# ------------------------------------
# Hygiene Protocol (Garbage to Ignore)
# ------------------------------------
*.log
*.tmp
*.bak
*.swp
*.swo
*_cache/
*_tmp/
.DS_Store
Thumbs.db
Desktop.ini
```

## `repo/AGENTS.md`

````
<!-- CONTENT_HASH: e0ba44e39e5812099582e5a276476b89ccb8a3d9cbb3dc9d2ede0b1f87440674 -->

# AGENTS.md

Agent Operating Contract for the Agent Governance System (AGS)

> **⛔ HARD PROHIBITION**: The **interactive terminal bridge** (VSCode terminal tabs) has been **AMPUTATED** from the system. The `launch-terminal` skill has been deleted. Agents are STRICTLY FORBIDDEN from attempting to spawn terminal windows or using interactive bridge tools. All work must be conducted via background processes and verified artifacts. The Swarm remains active for background task execution only.

This file defines how autonomous or semi-autonomous agents operate inside this
repository. It is procedural authority. If unclear, defer to CANON.

## 0. Initial Connection & Cortex Access

Before reading any rules, agents must establish a connection to the cortex (semantic indexing system) to access governance files and tools. This section provides the essential connection guidance that enables all subsequent operations.

### 0.1 Connection Methods

**Primary (Auto-start)**:
```bash
python LAW/CONTRACTS/ags_mcp_entrypoint.py
```
- **ADR-021 Compliant**: Automatically generates `session_id` (UUID) and logs all activity
- **Recommended**: Most reliable entry point with full audit logging

**Alternative**:
```bash
python CAPABILITY/MCP/server.py
```

**Test Connection**:
```bash
python LAW/CONTRACTS/ags_mcp_entrypoint.py --test
```

### 0.2 Essential Cortex Tools

Once connected via MCP, agents have access to these core tools:

- `cortex_query({"query": "term"})` - Search semantic index (logged with `session_id`)
- `canon_read({"file": "CONTRACT"})` - Read governance files (logged with `session_id`)
- `context_search({"type": "decisions"})` - Find ADRs and context records (logged with `session_id`)
- `session_info({})` - Get session information including `session_id` (ADR-021 compliance)

**Search Protocol (MANDATORY):**
- **MUST** use `semantic_search` for conceptual queries ("How does X work?")
- **MUST** use `grep_search` for exact string matches ("SPECTRUM-02", file paths)
- **SHOULD** try semantic search first for ambiguous queries
- **See:** `LAW/CANON/AGENT_SEARCH_PROTOCOL.md` for full decision tree

### 0.3 First Commands (Bootstrap Sequence)

1. **Read CONTRACT** via `canon_read({"file": "CONTRACT"})` - Establishes audit trail
2. **Read AGENTS.md** via `cortex_query({"query": "AGENTS.md"})` - Continues audit trail
3. **Check system status** - Verify ADR-021 compliance and connection health

### 0.4 ADR-021 Identity & Observability

**Session Identity**: The MCP server automatically generates a `session_id` (UUID) for each agent connection, fulfilling ADR-021 requirements.

**Essential Tool**: Use the `session_info` tool to discover your session_id:
```json
session_info({})  // Returns session_id, server info, and optional audit log entries
```

**Audit Compliance**: All cortex queries and tool calls are automatically logged to `LAW/CONTRACTS/_runs/mcp_logs/audit.jsonl` with your `session_id`, establishing traceable identity as required by ADR-021.

**Verification**: After connecting, immediately call `session_info({})` to obtain your `session_id` and verify ADR-021 compliance.

### 0.5 Troubleshooting

- **Python Check**: `python --version` (requires Python 3.8+)
- **Server Verification**: Run test command above
- **Log Inspection**: Check `LAW/CONTRACTS/_runs/mcp_logs/audit.jsonl` for connection errors
- **Session Tracking**: Verify `session_id` appears in audit logs (indicates ADR-021 compliance)

### 0.6 Connection Success Criteria

A successful connection is confirmed when:
1. MCP server starts without errors
2. Cortex tools respond to queries
3. Audit logs show entries with `session_id`
4. Agent can read CONTRACT.md via `canon_read`

**Only after establishing a successful cortex connection should agents proceed to Section 1.**

**Quick Reference**: For detailed tool usage and common query patterns, see `INBOX/reports/cortex-quick-reference.md`.

### 0.7 MCP-First Principle (Token Efficiency)

**🚨 CRITICAL: NO TOKEN WASTE 🚨**

Agents MUST use MCP tools for all cortex access and MUST NOT write custom database queries or manual file inspection code. This principle enforces catalytic computing token efficiency.

#### What is Token Waste?
Token waste occurs when an agent:
1. Writes Python SQLite snippets to inspect databases directly
2. Uses `open()` or `Path().read_text()` to read governance files
3. Creates custom scripts for tasks already covered by MCP tools
4. Analyzes database schemas instead of using semantic search tools

#### Examples of Token Waste vs. Correct Usage:

**❌ WRONG (Token Waste):**
```python
import sqlite3
conn = sqlite3.connect('NAVIGATION/CORTEX/db/system1.db')
cursor = conn.execute('SELECT * FROM symbols')
```

**✅ CORRECT (MCP-First):**
```json
cortex_query({"query": "symbols", "limit": 10})
```

**❌ WRONG (Token Waste):**
```python
open('LAW/CANON/CONTRACT.md').read()
```

**✅ CORRECT (MCP-First):**
```json
canon_read({"file": "CONTRACT"})
```

**❌ WRONG (Token Waste):**
```python
import os
for root, _, files in os.walk('LAW/CONTEXT/decisions'):
    for f in files:
        if 'catalytic' in open(f).read():
            print(f)
```

**✅ CORRECT (MCP-First):**
```json
context_search({"type": "decisions", "query": "catalytic"})
```

#### Enforcement
- The `mcp-access-validator` skill detects token waste and recommends MCP tools
- All agent actions are audited for token efficiency
- Violations are logged in `LAW/CONTRACTS/_runs/mcp_logs/token_waste.jsonl`

#### Token Savings
Using MCP tools provides:
- **95% savings** for database queries (vs. SQLite snippets)
- **90% savings** for file reading (vs. manual file ops)
- **85% savings** for context searches (vs. custom scripts)
- **100% governance compliance** (automatic audit logging)

#### The Rule
**If an MCP tool exists for a task, you MUST use it. Writing custom code for MCP-covered tasks is a governance violation.**

## 1. Required startup sequence (non-negotiable)

Before taking any action, an agent MUST:

1. **Connect to Cortex** using Section 0 guidelines
2. **Read essential governance documents** (via cortex tools):
   - LAW/CANON/CONTRACT.md - Core rules and authority gradient
   - LAW/CANON/INVARIANTS.md - Locked decisions that cannot change
   - LAW/CANON/VERSIONING.md - Version policy (identify current canon_version)
   - LAW/CANON/AGREEMENT.md - Constitutional agreement between human and system
   - LAW/CANON/STEWARDSHIP.md - Engineering practices and escalation paths
   - LAW/CANON/INBOX_POLICY.md - Document storage and content hash requirements
   - LAW/CANON/IMPLEMENTATION_REPORTS.md - Report format for all implementations
   - LAW/CANON/CRISIS.md - Emergency procedures and quarantine detection
3. **Read this file (AGENTS.md) in full**
4. **Identify the current canon_version** (found in LAW/CANON/VERSIONING.md)
5. **Identify whether the task is**:
   - governance change (requires ADR and ceremony)
   - skill implementation (requires SKILL.md, run.py, validate.py, fixtures)
   - build execution (outputs to BUILD/)
   - documentation only (must follow INBOX policy with content hash)
6. **Review relevant ADRs**:
   - ADR-021: Mandatory Agent Identity and Observability (session_id)
   - ADR-029: Headless Swarm Execution (terminal prohibition)
   - ADR-004: MCP Integration (connection protocol)
   - ADR-017: Skill Formalization (skill structure)
   - ADR-022: Why Flash Bypassed The Law (test requirement)
   - ADR-008: Composite Commit Approval (ceremony rules)
   - ADR-001: Build and Artifacts (output locations)
   - ADR-007: Constitutional Agreement (human-system relationship)
   - ADR-015: Logging Output Roots (audit log locations)
   - ADR-016: Context Edit Authority (mutation rules)
   - ADR-020: Admission Control Gate (governance enforcement)

7. **Note engineering standards** (from `LAW/CANON/STEWARDSHIP.md`):
   - No bare excepts, atomic writes, headless execution
   - Deterministic outputs, safety caps, proper database connections
   - Never bypass tests, cross-platform scripts, interface regression tests
   - Amend over pollute (clean commit history)

If any of the above steps are skipped, the agent must stop.

## 1C. Multi-agent workflow (worktrees)

When multiple agents are active in the same repo, each agent MUST use a separate Git worktree (or branch + worktree) to avoid shared working-tree conflicts that break governance checks.

Minimum practice:
- One agent = one worktree directory.
- Each agent updates `CHANGELOG.md` by adding a topmost entry, then rebases before push.
- Do not run tests or commit from a shared dirty worktree.
- Use `commit-queue` to enqueue and stage per-agent commit slices before the commit ceremony.

## 1A. Question-first gate (no-write)

If the user is asking questions, requesting analysis, or requesting a strategy without explicitly approving implementation, the agent MUST:

- answer first (no edits)
- avoid creating, modifying, deleting, or committing files
- avoid running commands that write artifacts
- ask for explicit approval before making changes (example: "Do you want me to implement this now?")

## 1B. Intent gate (canon and context)

Only change CANON or edit existing CONTEXT records when the task is explicitly about rules, governance, or memory updates. If intent is ambiguous, ask one clarifying question before touching CANON or existing CONTEXT records. Changes are reversible; if a change is wrong, revert it.

## 2. Authority gradient

If instructions conflict, obey in this order:

1. LAW/CANON/AGREEMENT.md
2. LAW/CANON/CONTRACT.md
3. LAW/CANON/INVARIANTS.md
4. LAW/CANON/VERSIONING.md
5. AGENTS.md
6. CONTEXT records (ADRs, rejections, preferences)
7. NAVIGATION/maps/*
8. User instructions
9. Implementation convenience

Never invert this order.

## 2A. Sovereign override interface (`MASTER_OVERRIDE`)

If a user prompt contains `MASTER_OVERRIDE`, treat it as an authorized Governance Interface directive (see `LAW/CANON/AGREEMENT.md`).

- It authorizes bypassing any repository governance rule for that prompt only (do not carry it across turns).
- Before taking an overridden action, append an audit entry to `LAW/CONTRACTS/_runs/override_logs/master_override.jsonl` (use the `master-override` skill).
- Do not read, quote, or summarize override logs unless the user prompt also contains `MASTER_OVERRIDE`.
- Do not echo the directive back to the user unless explicitly asked.

## 2B. Privacy boundary (no out-of-repo access)

- Default scope is the repository root only.
- Do not access, scan, or search outside the repo unless the user explicitly requests those paths in the same prompt.
- Avoid user profile and OS-level directories by default; if needed, ask before any out-of-repo access.

## 3. Mutation rules

Agents MAY:
- create or modify files under:
  - CAPABILITY/SKILLS/
  - LAW/CONTRACTS/
  - NAVIGATION/CORTEX/ (implementation), and `NAVIGATION/CORTEX/_generated/` (generated)
  - MEMORY/ (implementation), and `MEMORY/LLM_PACKER/_packs/` (generated)
  - BUILD/ (user build outputs only)
- append new records under LAW/CONTEXT/ (append-first; editing existing records requires explicit instruction)
- ignore THOUGHT/research unless the user explicitly requests it (non-binding)

Agents MAY NOT:
- modify LAW/CANON/* or edit existing LAW/CONTEXT records unless explicitly instructed or the task is explicitly about rules or memory updates
- delete authored content without explicit user instruction and confirmation (CANON rules must follow INV-010 archiving)
- rewrite history in LAW/CONTEXT/* without explicit instruction
- touch generated artifacts outside:
  - LAW/CONTRACTS/_runs/
  - NAVIGATION/CORTEX/_generated/
  - MEMORY/LLM_PACKER/_packs/

Generated files must be clearly marked as generated.

Research under THOUGHT/research is non-binding and ignored unless explicitly
requested. It must not be treated as canon.

## 4. Build output rules

System-generated artifacts MUST be written only to:

- LAW/CONTRACTS/_runs/
- NAVIGATION/CORTEX/_generated/
- MEMORY/LLM_PACKER/_packs/

`BUILD/` is reserved for user build outputs. It must not be used for system artifacts.

- BUILD/ is disposable
- BUILD/ is the dist equivalent
- BUILD/ may be wiped at any time
- No authored content belongs in BUILD/

If a task requires writing elsewhere, the agent must stop and ask.

## 5. Skills-first execution

Agents must not perform arbitrary actions.

All non-trivial work must be performed via a skill:

- If a suitable skill exists, use it.
- If no suitable skill exists:
  - propose a new skill
  - write SKILL.md first (manifest with metadata)
  - write run.py (implementation)
  - write validate.py (output validator)
  - define fixtures (test cases with input.json and expected.json)
  - then implement

Every skill must follow the contract defined in ADR-017:
- SKILL.md: manifest with metadata
- run.py: implementation script
- validate.py: output validator (accept two JSON file paths, return 0/1)
- fixtures/: test cases with input.json and expected.json

Direct ad-hoc scripting is forbidden.

## 6. Fixtures gate changes

If an agent changes behavior, it MUST:

1. Add or update fixtures
2. Run LAW/CONTRACTS/runner.py
3. Ensure all fixtures pass
4. Update CANON or CHANGELOG if behavior is user-visible

If fixtures fail, the change does not exist.

## 7. Uncertainty protocol

If any of the following are true, the agent must stop and ask:

- intent is ambiguous
- multiple canon interpretations exist
- change would affect invariants
- output location is unclear
- irreversible action is required

Guessing is forbidden.

## 8. Determinism requirement

Agent actions must be:

- deterministic
- reproducible
- explainable via canon and context

No randomness.
No hidden state.
No silent side effects.

## 9. Exit conditions

An agent should stop when:
- the requested task is complete
- fixtures pass
- outputs are written to the allowed artifact roots
- any blocking uncertainty appears

Agents must not continue "optimizing" beyond scope.

## 10. Commit ceremony (CRITICAL)

**Every single `git commit`, `git push`, and release publication requires explicit, per-instance user approval.**

This is the highest-priority governance rule for agent behavior.

### What does NOT authorize a commit
- "proceed"
- "let's move on to the next task"
- "continue"
- "yes" (unless in direct response to a commit ceremony prompt)

These authorize **implementation** only. They are **never** implicit commit approvals.

An explicit "commit" directive counts as approval to commit once checks pass and staged files are listed; no extra confirmation prompt is required.

### Explicit composite approvals
Explicit composite directives that include "commit", "push", and "release" (for example,
"commit, push, and release") count as approval for each action listed in that request.
This does not authorize additional commits beyond the current task.

### Ceremony confirmations
When checks have passed and staged files have been listed, short confirmations such as
"go on" count as approval for the listed actions.

### The anti-chaining rule
**One commit approval = one commit.** If the user approves a commit for Task A, and the agent then completes Task B, the agent MUST stop and request a new approval for Task B. Chaining commits under a single approval is forbidden.

### The ceremony
Before any Git command:
1. Run the required checks for the action:
   - **Before commit (fast):** `python CAPABILITY/TOOLS/governance/critic.py`
   - **Before push (full):** `python CAPABILITY/TOOLS/utilities/ci_local_gate.py --full` (mints the one-time `CI_OK` token used by `.githooks/pre-push`)
2. Stop all execution.
3. List every file in the staging area.
4. If the user already gave an explicit approval for commit (including a standalone "commit" directive or a composite approval), proceed without re-prompting.
5. Otherwise ask: "Ready for the Chunked Commit Ceremony? Shall I commit these [N] files?"
6. Wait for explicit user approval.

Violation of this ceremony is a **critical governance failure**.

See also: `LAW/CONTEXT/preferences/STYLE-001-commit-ceremony.md`

## 11. The Law (fast commit, full push)

**🚨 DO NOT PUSH WITHOUT FULL GATE PASSING 🚨**

This section exists to keep iteration fast (commit often) while keeping shared history safe (full verification at push time). See `LAW/CONTEXT/decisions/ADR-034-fast-commit-full-push-gate.md`.

### Before ANY push, agents MUST:

#### 11.1 Run the full CI-aligned gate and verify it passes
```bash
python CAPABILITY/TOOLS/utilities/ci_local_gate.py --full
```
**If it fails, DO NOT PUSH. Fix it first.**

#### 11.2 Read FULL test output
When tests fail:
- **DO NOT** assume what the error is
- **READ** the actual error message (look for `FAIL`, `ERROR`, `rc=`)
- **LOOK** for the root cause, not just the assertion message

#### 11.3 Never use `--no-verify` without:
- Running tests manually and confirming they PASS
- Documenting WHY you're bypassing hooks
- Getting explicit user approval
- Adding justification to the commit message

#### 11.4 Preflight failures are not logic bugs
If you see `FAIL preflight rc=2` with reasons like `DIRTY_TRACKED`:
- This is NOT a governance logic bug
- This is because the git repo has uncommitted changes
- Tests that call `ags run` will fail on dirty repos
- **FIX**: Test governance logic directly using:
  - `ags route` for routing/revocation checks
  - `catalytic pipeline verify` for verification checks

#### 11.5 The test output truncation trap
Test output in agent tools may be truncated. If you see partial output:
1. Redirect output to a file: `py -m pytest ... 2>&1 | Out-File test.txt`
2. Read the file to see the FULL error
3. Never assume the error from truncated output

**Violation of The Law is a critical governance failure.**
````

## `repo/LICENSE`

```
<!-- CONTENT_HASH: 3cf3cf666d23d368f1762a9ddba6ea577bc90b480203b7de06d3887aa13dfaa3 -->

CATALYTIC COMMONS LICENSE (CCL) v1.4
Non-Commercial, Attribution, Share-Alike, Anti-Extraction, No State/Police/Military/Intel Use, With Attestation-Gated Protected Artifacts

Copyright (c) 2026 Raúl René Romero Ramos
All rights reserved except as expressly granted below.

∞) No rights are granted to any entity exercising coercive authority or operating coercive infrastructure, whether directly or via contractors.

0) Core Rule
This License grants NO rights to any Prohibited Entity (defined below). Prohibited Entities have zero permission to use, copy, modify, distribute, or benefit from the Software. Any interaction by a Prohibited Entity is unlicensed.

1) Definitions
"Software" means the source code, documentation, data artifacts, schemas, prompts, proofs, indexes, embeddings, vectors, datasets, packs, and other materials distributed with this project, including any portion thereof.

"Use" means to run, execute, copy, modify, merge, publish, distribute, sublicense, make available, deploy, host, integrate, train on, or otherwise exploit the Software.

"Derivative" means any work based on or incorporating the Software, including modifications, forks, ports, translations, or substantial portions.

"Non-Commercial" means not primarily intended for or directed toward commercial advantage or monetary compensation.

"Commercial Use" means any Use that is not Non-Commercial, including any Use:
(a) by or for a for-profit entity,
(b) connected to revenue, fees, subscriptions, licensing, paid services, ads, sponsorships, or monetized distribution,
(c) to develop, improve, or operate products or services offered for a fee or other commercial benefit,
(d) for internal business purposes of a for-profit entity, even if not directly sold.

"Offering as a Service" means making the Software or any material functionality available to third parties over a network, API, hosted platform, or managed service.

"Extractive Use" means any Use that takes value from the Software while restricting others from comparable access to resulting improvements, and/or converting it into proprietary advantage, closed control, coercive power, surveillance, targeting, or repression.

"Protected Artifacts" means any subset of the Software that is distributed with access controls, including encrypted or keyed vector indexes, manifold state, CAS bundles, receipts, proofs, pack outputs, or any other artifact designated as protected (for example, under a directory name containing "_PROTECTED", "_SEALED", or similar).

"Access Controls" means cryptographic controls or protocol gates applied to Protected Artifacts, including encryption, keyed derivation, signatures, attestations, capability tokens, or any mechanism intended to restrict access to eligible users under this License.

"Compliance Attestation" means a signed statement (digital signature) by the requester asserting, at minimum:
(i) they are not a Prohibited Entity and are not acting on behalf of a Prohibited Entity,
(ii) they will Use the Software only as permitted by this License,
(iii) they will not perform any Prohibited Use (Section 3),
(iv) the attestation is made to obtain access to Protected Artifacts or key material, and is a material representation relied upon by the provider of such access.

"Digital Signature" means a cryptographic signature that binds the attestation text to a specific signer-controlled key, and that can be verified using the signer’s public key. Acceptable formats include, for example, OpenPGP (GPG) signatures, X.509/PKI signatures, or equivalent cryptographic signatures. A typed name, email-only confirmation, or unchecked checkbox is NOT a Digital Signature unless the Licensor explicitly permits it in writing.

"Acting on behalf of" means (a) acting under direction, contract, request, agency, employment, funding, deputization, partnership, tasking, or operational coordination with a Prohibited Entity, OR (b) acting with knowledge that the Use will directly or indirectly benefit a Prohibited Entity, OR (c) acting with reckless disregard as to whether the Use will directly or indirectly benefit a Prohibited Entity.

"Prohibited Entity" means any of the following, anywhere in the world, including any successor, affiliate, subsidiary, joint task force, partner, contractor, subcontractor, vendor, grantee, agent, intermediary, or any person or organization acting directly or indirectly on their behalf:

(A) State and Government
Any national, federal, state, provincial, municipal, local, tribal, or supranational governmental body, department, agency, court, legislature, regulator, or instrumentality.

(B) Military and Defense
Any armed forces, defense ministry/department, defense agency, defense contractor, weapons manufacturer, military R&D program, or any organization supporting military operations, targeting, weapons, or force projection.

(C) Intelligence and Security Services
Any intelligence, security, signals intelligence, cyber-intelligence, national security, covert operations, or surveillance organization, and any organization primarily engaged in intelligence collection or analysis for state actors.

(D) Law Enforcement and Carceral Systems
Any police, sheriff, constabulary, border enforcement, immigration enforcement, corrections, prisons, detention, probation, parole, or any law-enforcement or carceral body, including fusion centers and any surveillance or intelligence unit serving them.

(E) Surveillance and Social Control Contractors
Any organization that builds, sells, operates, or supports surveillance, tracking, biometric identification, predictive policing, mass data collection, targeting, propaganda, censorship, or coercive social control for any entity in (A) through (D).

2) License Grant (Non-Commercial, Non-Prohibited Only)
Subject to the terms of this License, the Licensor grants you a worldwide, royalty-free, non-exclusive license to Use the Software for Non-Commercial purposes only, provided that you are NOT a Prohibited Entity and are not acting on behalf of a Prohibited Entity, and provided you comply with Sections 3 and 4.

Access to Protected Artifacts is additionally conditioned under Section 4.4.

2.1 Safe Harbor for Accidental Violation (Non-Prohibited Only)
If you are not a Prohibited Entity and not acting on behalf of a Prohibited Entity, and you violate this License unintentionally, your license is reinstated if you (i) cease the violating activity promptly after discovery, (ii) remediate the violation to the extent practical, and (iii) provide written confirmation of cure upon request. This safe harbor does NOT apply to Sections 3.1 (Prohibited Entities), 3.6 (Circumvention), or 3.7 (False Attestation).

3) Prohibitions (Absolute)
You may NOT:

3.1 Prohibited Entities
Use the Software if you are a Prohibited Entity or acting on behalf of a Prohibited Entity, for any purpose, commercial or non-commercial, including research, evaluation, testing, procurement, training, deployment, or operations.

3.2 Commercial Use
Use the Software for any Commercial Use.

3.3 Offering as a Service
Offer the Software or any Derivative as a Service. Exception: a purely free public service may be permitted only with prior written permission from the Licensor.

3.4 Proprietary Model Training and Closed Exploitation
Use the Software (including prompts, corpora, artifacts, proofs, indexes, embeddings, vectors, or derived datasets) to train, fine-tune, align, or improve any proprietary or closed-access model, or any model whose outputs, weights, or access are commercially restricted.

3.5 No Rights Removal
Apply legal terms or technical measures that restrict recipients from exercising the rights granted by this License on any distributed copy of the Software or Derivative.

3.6 No Circumvention of Access Controls (Protected Artifacts)
You may NOT bypass, disable, defeat, tamper with, reverse, brute-force, or otherwise circumvent Access Controls protecting Protected Artifacts, nor assist others in doing so, nor distribute any tooling or instructions whose primary purpose is to circumvent Access Controls.
Any such act is unlicensed and terminates all rights under this License immediately.

3.7 No False Attestation
You may NOT submit, cause to be submitted, or rely upon any Compliance Attestation that is false, misleading, incomplete in a material way, or submitted on behalf of a Prohibited Entity.
A false Compliance Attestation is a material breach and terminates all rights under this License immediately.

4) Conditions (Attribution, Share-Alike, Source, Attestation for Protected Artifacts)
Your rights are conditioned on the following:

4.1 Attribution
You must preserve:
(a) this LICENSE text,
(b) copyright notices,
(c) a NOTICE file (or equivalent) that includes at minimum:
    - "Includes software from the agent-governance-system project by Raúl R. Romero, licensed under CCL v1.4."
    - a list of material modifications if you distribute a Derivative.

4.2 Share-Alike
If you distribute the Software or any Derivative, you must license the entire distributed work under this same License (CCL v1.4), without additional restrictions.

4.3 Source Availability on Distribution
If you distribute a Derivative in any form, you must make the complete corresponding source of that Derivative available to recipients under this License at no charge, in a reasonable and accessible way.

4.4 Protected Artifacts Access Condition (Cryptographic Handshake)
If any portion of the Software is distributed as Protected Artifacts, then access to those Protected Artifacts (including any decryption keys, capability tokens, or equivalent key material) is granted only to recipients who provide a Compliance Attestation containing a Digital Signature to the party providing such access.

If you distribute Protected Artifacts, you must:
(a) keep Access Controls intact,
(b) provide access (keys/tokens) only upon receipt of a Compliance Attestation that meets the Digital Signature requirement,
(c) treat a Compliance Attestation as a required condition of access under this License.

Nothing in this section obligates any person to provide access to Protected Artifacts. It defines the minimum conditions under which such access, if provided, is licensed.

5) Patent Grant (Non-Commercial, Non-Prohibited Only)
To the extent the Licensor holds patent rights that read on the Software, the Licensor grants you a non-exclusive, worldwide, royalty-free patent license solely for Non-Commercial use under this License, provided you are not a Prohibited Entity.
If you initiate patent litigation alleging the Software infringes a patent, your patent license terminates immediately.

6) No Warranty
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.

7) Limitation of Liability
IN NO EVENT SHALL THE LICENSOR OR CONTRIBUTORS BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM OR RELATED TO THE SOFTWARE OR ITS USE.

8) Termination
Any breach of Sections 2 through 4 terminates this License immediately.

9) Permissions
Any use outside this License requires prior written permission from the Licensor.

10) Miscellaneous (Governing Law; Venue)
This License is governed by the laws of the State of California, USA, excluding its conflict of laws rules.
Any dispute arising from or related to this License shall be brought exclusively in the state or federal courts located in Santa Clara County, California, and the parties consent to personal jurisdiction and venue there.
If any provision is held unenforceable, the remainder remains in effect. This License is the complete agreement regarding the Software’s licensing unless the Licensor provides separate written terms.
```

## `repo/README.md`

````
<!-- CONTENT_HASH: 82169ad2a1976e7041c636aeb9753816c946acd35754ceb3e84bb6d58f647a3f -->

# Agent Governance System (AGS)

The Agent Governance System (AGS) is a constitutional framework for durable, multi-agent intelligence.

This repository provides a language-driven operating system for AI-native projects. It treats text as law, code as consequence and fixtures as precedent. By enforcing a clear authority gradient and mechanical gates, AGS prevents drift, preserves intent and allows continuous evolution across model swaps and refactors.

## Starting a Session (Mandatory)

Every new agent session **must** begin with the Genesis Prompt to bootstrap the governance system correctly.

1. Read the full prompt from `LAW/CANON/GENESIS.md`.
2. Prepend it as the system message, pack header, or first instruction.
3. Agents are instructed to remind you if it is missing.

This solves the bootstrap paradox: the agent knows the governance structure exists *before* reading any other file.

## Project layout

The repository is organised into 6 authoritative buckets:

1. **LAW** (`LAW/`) - Constitution, decisions, and mechanical contracts.
    - `LAW/CANON/` - Constitutional rules (Genesis, Versioning, Glossary).
    - `LAW/CONTEXT/` - ADRs and preferences.
    - `LAW/CONTRACTS/` - Schemas and fixtures (precedent).
2. **CAPABILITY** (`CAPABILITY/`) - Skills, tools, and adapters.
    - `CAPABILITY/SKILLS/` - Atomic agent capabilities.
    - `CAPABILITY/MCP/` - Client integration and MCP server.
    - `CAPABILITY/TOOLS/` - Helper scripts (critics, linters).
3. **NAVIGATION** (`NAVIGATION/`) - Maps, invariants, and indices.
    - `NAVIGATION/MAPS/` - Entrypoints and ownership maps.
    - `NAVIGATION/CORTEX/` - Semantic index and search resources.
4. **DIRECTION** (`DIRECTION/`) - Roadmaps and forward plans (if used).
5. **THOUGHT** (`THOUGHT/`) - Experimental labs and prototypes.
6. **MEMORY** (`MEMORY/`) - Packers, archives, and durable state.

Non-bucket top-level directories (supporting, not authoritative): `INBOX/` (reports), `.github/`, and `BUILD/` (disposable build outputs).

## Semantic Core (Token Compression)

The `NAVIGATION/CORTEX/` layer includes a **Semantic Core** system that uses vector embeddings to enable massive token savings when dispatching tasks to smaller language models.

**How it works:**
- Big models (Opus) maintain semantic understanding via 384-dimensional vector embeddings in `NAVIGATION/CORTEX/`
- Small models (Haiku) receive compressed task specifications with @Symbols and vector context
- Achieves **96% token reduction** per task (50,000 → 2,000 tokens)

**Quick start:**
```bash
# Test the semantic adapter
python CAPABILITY/MCP/semantic_adapter.py --test

# Rebuild the semantic index
python NAVIGATION/CORTEX/semantic/vector_indexer.py --rebuild

# Search the codebase
python CAPABILITY/MCP/semantic_adapter.py search --query "how to add a skill"
```

**Documentation:**
- [Semantic Core Quick Start](./NAVIGATION/CORTEX/README.md)
- [ADR-030](./LAW/CONTEXT/decisions/ADR-030-semantic-core-architecture.md)
- [Final Report](./INBOX/reports/12-28-2025-12-00_PHASE1_TRIPLE_WRITE_IMPLEMENTATION.md)

**Status:** Phase 1 (Vector Foundation) complete. See [Final Report](./INBOX/reports/12-28-2025-12-00_PHASE1_TRIPLE_WRITE_IMPLEMENTATION.md) for details.

## MCP integration (external clients)

AGS exposes an MCP server for IDEs and desktop clients. Use the entrypoint wrapper
`LAW/CONTRACTS/ags_mcp_entrypoint.py` to keep audit logs under allowed output
roots (`LAW/CONTRACTS/_runs/mcp_logs/`). Verify with the `mcp-smoke` or
`mcp-extension-verify` skills. See `CAPABILITY/MCP/README.md` for client config examples.

## How to use

This repository is a template: most files are placeholders that illustrate the intended structure. To adapt the system for your own project, fill in the canon, add decisions and ADRs, implement skills and write fixtures.

Agents interacting with the system should follow the protocol described in `LAW/CANON/CONTRACT.md`. In brief:

1. Load the canon first and respect its authority.
2. Consult context records before making changes.
3. Use the maps to find the right entrypoints.
4. Execute work through skills rather than ad-hoc scripts.
5. Validate changes using the runner in `LAW/CONTRACTS`.
6. Update the canon and changelog in the same commit when rules change.
7. Default to repo-only access (see `LAW/CONTEXT/decisions/ADR-012-privacy-boundary.md`).

## How to extend AGS

- Add a skill: create `CAPABILITY/SKILLS/<skill-name>/` with `SKILL.md`, a run script, a validation script, and `fixtures/<case>/input.json` plus `expected.json`.
- Add fixtures: place skill fixtures under `CAPABILITY/SKILLS/<skill-name>/fixtures/` and governance fixtures under `LAW/CONTRACTS/fixtures/`.
- Add ADRs: create a new `LAW/CONTEXT/decisions/ADR-xxx-*.md` and reference it in `LAW/CONTEXT/INDEX.md`.
- Use `BUILD/` for your project's build outputs (dist). It is disposable and should not contain authored content. The template writes its own artifacts under `LAW/CONTRACTS/_runs/`, `NAVIGATION/CORTEX/_generated/`, and `MEMORY/LLM_PACKER/_packs/`.
- Planning snapshots (if present) live under `MEMORY/ARCHIVE/planning/`.

For more details, see individual files in the respective directories.
````

## `repo/.github/workflows/contracts.yml`

```
name: Contracts

on:
  pull_request:
    branches: [main]
  push:
    branches: [main]

jobs:
  governance:
    name: Governance Checks
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 2  # Need history for diff checks
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          python -m pip install -r requirements.txt
          python -m pip install pytest cryptography referencing
      
      - name: Test query module (pre-build gate)
        run: python NAVIGATION/CORTEX/tests/test_query.py
      
      - name: Build cortex index
        run: python NAVIGATION/CORTEX/db/cortex.build.py
      
      - name: Build system1 index
        run: python NAVIGATION/CORTEX/db/reset_system1.py
      
      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
      
      - name: Run canon governance checks
        run: node CAPABILITY/TOOLS/check-canon-governance.js
      
      - name: Run critic checks
        run: python CAPABILITY/TOOLS/governance/critic.py

      - name: Lint tokens
        run: python CAPABILITY/TOOLS/utilities/lint_tokens.py

      - name: Run contract fixtures
        run: python LAW/CONTRACTS/runner.py

      - name: Run pytest (bounded temp, no capture)
        env:
          TMPDIR: ${{ github.workspace }}/LAW/CONTRACTS/_runs/_tmp/pytest
          TEMP: ${{ github.workspace }}/LAW/CONTRACTS/_runs/_tmp/pytest
          TMP: ${{ github.workspace }}/LAW/CONTRACTS/_runs/_tmp/pytest
        run: |
          mkdir -p "$TMPDIR"
          python -m pytest -q -s --ignore=MEMORY/LLM_PACKER/_packs --ignore=CATALYTIC-DPT/LAB

      - name: CI strict verification (SPECTRUM-05)
        env:
          CI: "true"
        run: |
          python - <<'PY'
          import json
          import hashlib
          import subprocess
          from pathlib import Path
          
          from cryptography.hazmat.primitives.asymmetric import ed25519
          from cryptography.hazmat.primitives import serialization
          
          repo_root = Path.cwd()
          run_id = "ci-strict-bundle"
          run_dir = repo_root / "LAW" / "CONTRACTS" / "_runs" / run_id
          run_dir.mkdir(parents=True, exist_ok=True)
          
          # Deterministic output file within allowed roots.
          output_rel = "NAVIGATION/CORTEX/_generated/ci_strict_output.txt"
          output_abs = repo_root / output_rel
          output_abs.parent.mkdir(parents=True, exist_ok=True)
          output_bytes = b"ci-strict"
          output_abs.write_bytes(output_bytes)
          
          def canonical(obj) -> bytes:
            return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
          
          task_spec = {"task_id": run_id, "outputs": {"durable_paths": [output_rel]}}
          task_spec_bytes = json.dumps(task_spec, indent=2).encode("utf-8")
          (run_dir / "TASK_SPEC.json").write_bytes(task_spec_bytes)
          
          status = {"status": "success", "cmp01": "pass", "run_id": run_id}
          (run_dir / "STATUS.json").write_text(json.dumps(status, indent=2))
          
          output_hashes = {
            "validator_semver": "1.0.0",
            "validator_build_id": "ci",
            "hashes": {output_rel: "sha256:" + hashlib.sha256(output_bytes).hexdigest()},
          }
          (run_dir / "OUTPUT_HASHES.json").write_text(json.dumps(output_hashes, indent=2))
          
          proof = {"restoration_result": {"verified": True, "condition": "RESTORED_IDENTICAL"}}
          (run_dir / "PROOF.json").write_text(json.dumps(proof, indent=2))
          
          # SPECTRUM-04 identity + signing artifacts.
          private_key = ed25519.Ed25519PrivateKey.generate()
          public_key = private_key.public_key()
          public_key_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
          )
          public_key_hex = public_key_bytes.hex()
          validator_id = hashlib.sha256(public_key_bytes).hexdigest()
          
          identity = {"algorithm": "ed25519", "public_key": public_key_hex, "validator_id": validator_id}
          (run_dir / "VALIDATOR_IDENTITY.json").write_text(json.dumps(identity, indent=2))
          
          task_spec_hash = hashlib.sha256(task_spec_bytes).hexdigest()
          bundle_preimage = {"output_hashes": output_hashes["hashes"], "status": status, "task_spec_hash": task_spec_hash}
          bundle_root = hashlib.sha256(canonical(bundle_preimage)).hexdigest()
          
          signed_payload = {"bundle_root": bundle_root, "decision": "ACCEPT", "validator_id": validator_id}
          (run_dir / "SIGNED_PAYLOAD.json").write_text(json.dumps(signed_payload, indent=2))
          
          signature_message = b"CAT-DPT-SPECTRUM-04-v1:BUNDLE:" + canonical(signed_payload)
          signature = private_key.sign(signature_message).hex()
          sig_obj = {"payload_type": "BUNDLE", "signature": signature, "validator_id": validator_id}
          (run_dir / "SIGNATURE.json").write_text(json.dumps(sig_obj, indent=2))
          
          # Verify with strict mode (CI requires --strict).
          cmd = ["python", "CAPABILITY/TOOLS/catalytic/catalytic_verifier.py", "--run-dir", str(run_dir), "--strict", "--json"]
          res = subprocess.run(cmd, cwd=str(repo_root), capture_output=True, text=True)
          if res.returncode != 0:
            raise SystemExit(f"strict verifier failed: rc={res.returncode}\\nstdout={res.stdout}\\nstderr={res.stderr}")
          report = json.loads(res.stdout)
          if not report.get("ok"):
            raise SystemExit(f"strict verifier reported ok=false: {report}")
          PY
      
      - name: Run artifact escape hatch
        run: |
          python CAPABILITY/SKILLS/commit/artifact-escape-hatch/run.py CAPABILITY/SKILLS/commit/artifact-escape-hatch/fixtures/basic/input.json LAW/CONTRACTS/_runs/escape-check.json
          python CAPABILITY/SKILLS/commit/artifact-escape-hatch/validate.py LAW/CONTRACTS/_runs/escape-check.json CAPABILITY/SKILLS/commit/artifact-escape-hatch/fixtures/basic/expected.json
```

## `repo/.github/workflows/governance.yml`

```
# DEPRECATED: Merged into contracts.yml (single CI source of truth)
# See .github/workflows/contracts.yml for active governance checks

name: Governance [DEPRECATED]

on:
  pull_request:
    branches: [main]

jobs:
  deprecated_notice:
    runs-on: ubuntu-latest
    steps:
      - name: Notice
        run: |
          echo "This workflow is deprecated. See contracts.yml for active checks."
          exit 0
```

## `meta/BUILD_TREE.txt`

```
BUILD is excluded from packs by contract.
```

## `meta/ENTRYPOINTS.md`

```
# Snapshot Entrypoints

Key entrypoints for `AGS`:

- `repo/AGENTS.md`
- `repo/README.md`
- `repo/LAW/CANON/CONTRACT.md`
- `repo/NAVIGATION/MAPS/ENTRYPOINTS.md`
- `repo/CAPABILITY/SKILLS/`
- `repo/LAW/CONTRACTS/runner.py`

Notes:
- `FULL/` contains single-file bundles.
- `SPLIT/` contains chunked sections.
```

## `meta/PACK_INFO.json`

```
{
  "scope": "ags",
  "stamp": "2026-01-05_11-23-21",
  "title": "Agent Governance System (AGS)",
  "version": "3.0.0"
}
```

## `meta/PROVENANCE.json`

```
{
  "generator": "LLM_PACKER",
  "scope": "ags"
}
```

## `meta/REPO_OMITTED_BINARIES.json`

```
[
  {
    "bytes": 117725,
    "repoRelPath": "CAPABILITY/CAS/storage/0/04/004cb55a739c56918b53815cdc2e8090bf4aa25ed16e278d9686ef2ee6a9e0dc",
    "scope": "repo"
  },
  {
    "bytes": 6337,
    "repoRelPath": "CAPABILITY/CAS/storage/0/09/00977a26944e864fd22826de8c093b6009f36441da66c6c185836fcde5bdc89a",
    "scope": "repo"
  },
  {
    "bytes": 4689,
    "repoRelPath": "CAPABILITY/CAS/storage/0/09/0098f92bba33ac6eafc9aea7cb5b36ced2cb54af469cb526b369f2d94f87a13c",
    "scope": "repo"
  },
  {
    "bytes": 810,
    "repoRelPath": "CAPABILITY/CAS/storage/0/0d/00d2f0d702b99e4016416bce5a168f8f869b78b8e78059c7f106756688baed3f",
    "scope": "repo"
  },
  {
    "bytes": 7073,
    "repoRelPath": "CAPABILITY/CAS/storage/0/0e/00e354678240e6a7a2f305b199fa3d4df5ce864c9cf747c7bf3e2a94f26e9495",
    "scope": "repo"
  },
  {
    "bytes": 35082,
    "repoRelPath": "CAPABILITY/CAS/storage/0/0f/00fa8f26f8a2df60173061c7fb83e926e59efa611d380c3625aee7aa79831588",
    "scope": "repo"
  },
  {
    "bytes": 33,
    "repoRelPath": "CAPABILITY/CAS/storage/0/0f/00fb97950e506b233ceedd6d4dfdce4ee519b3ad8d1bfcc7a21d201a58436948",
    "scope": "repo"
  },
  {
    "bytes": 4655,
    "repoRelPath": "CAPABILITY/CAS/storage/0/13/01303deceda283473e1a1c430f25908032abae32196bd7db635dccefde40fd1e",
    "scope": "repo"
  },
  {
    "bytes": 40,
    "repoRelPath": "CAPABILITY/CAS/storage/0/13/0136f847f4d65eaab436f10981cf2c789a3105207f6cc73baaa211130453d61d",
    "scope": "repo"
  },
  {
    "bytes": 9,
    "repoRelPath": "CAPABILITY/CAS/storage/0/13/01374287b08854878940e270cfb7d84a643c3ba3e25bdf240b5095c31ea17666",
    "scope": "repo"
  },
  {
    "bytes": 117374,
    "repoRelPath": "CAPABILITY/CAS/storage/0/17/017e36a2cd95d916ca48bf58dd2c37cd3e938a4f9e82bfe6e4aeef63cc65752c",
    "scope": "repo"
  },
  {
    "bytes": 78,
    "repoRelPath": "CAPABILITY/CAS/storage/0/1e/01e4611d1ff125d0184b0bf7787d3b8b218325f7116e72383c4d7ec597d9fbec",
    "scope": "repo"
  },
  {
    "bytes": 8492,
    "repoRelPath": "CAPABILITY/CAS/storage/0/20/020c6a8a3e1e26bee0dbdfbd2e4471039e17083673421c4a093edb713cc6dd06",
    "scope": "repo"
  },
  {
    "bytes": 56,
    "repoRelPath": "CAPABILITY/CAS/storage/0/21/021a04492c3c3bc52a754c4dd76f4206c553a582299d418ec2f4d37c08994944",
    "scope": "repo"
  },
  {
    "bytes": 117721,
    "repoRelPath": "CAPABILITY/CAS/storage/0/28/028852a51a7d40e281f03745cb6d0dd1eb6d93c14a2b44aba52547c9c35f997f",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/0/2b/02b47ae3e440f2491118811e74e775a1d826bc5338f491736d47efb45f0b0f04",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/0/2b/02b91d1bb6a787fca0d5bd45b9e7e78b2186858a8f4c61f12cc3a3a94bca654f",
    "scope": "repo"
  },
  {
    "bytes": 354,
    "repoRelPath": "CAPABILITY/CAS/storage/0/32/0321476faa773652e4ea860357e2814c2e925432a69d2d5adbd928e81f2182ff",
    "scope": "repo"
  },
  {
    "bytes": 117725,
    "repoRelPath": "CAPABILITY/CAS/storage/0/32/032c76f2abd3bc48619bb6b2d0be5611216a4998409520f42be7b316fd8f67b7",
    "scope": "repo"
  },
  {
    "bytes": 27590,
    "repoRelPath": "CAPABILITY/CAS/storage/0/33/033a804c5a4dac0a8fa4278236ed86db93b3d18547601cb599bd9fa057ce9077",
    "scope": "repo"
  },
  {
    "bytes": 6730,
    "repoRelPath": "CAPABILITY/CAS/storage/0/35/03578531e16871d927d4f6e3bca794d8024b5dd6401f1cfdea51da720df64b2f",
    "scope": "repo"
  },
  {
    "bytes": 1643,
    "repoRelPath": "CAPABILITY/CAS/storage/0/35/035916467420dc2114bc4b3451516323db544aacb8ebdaf9d45acc21ccae3913",
    "scope": "repo"
  },
  {
    "bytes": 646,
    "repoRelPath": "CAPABILITY/CAS/storage/0/38/0384fe9dac4fd5b7e4651dbb795576f1a9f4608b216c5e062d5c8fc871a161f6",
    "scope": "repo"
  },
  {
    "bytes": 7889,
    "repoRelPath": "CAPABILITY/CAS/storage/0/39/0391b0e19a0ec0a99aa8adf40fcddd79fb4e3b2066418dc886ba798f6e9a030a",
    "scope": "repo"
  },
  {
    "bytes": 453,
    "repoRelPath": "CAPABILITY/CAS/storage/0/42/0420ea61de4e8ab07701811fc1eb3495003229cd3b2df33812df83a91fcadb17",
    "scope": "repo"
  },
  {
    "bytes": 157,
    "repoRelPath": "CAPABILITY/CAS/storage/0/46/0467bbc4970dc66c0ff19f5ddb8e2e48c43206e23f9417f971f6107224c128d8",
    "scope": "repo"
  },
  {
    "bytes": 14484,
    "repoRelPath": "CAPABILITY/CAS/storage/0/46/046b9638a9d51037c2c66f990b25303d7651fd849943896c03ac19c66f04577a",
    "scope": "repo"
  },
  {
    "bytes": 1555,
    "repoRelPath": "CAPABILITY/CAS/storage/0/48/04835078abddf99d9a4477fb39e09fcb77c647fd21a9f343036652ac6d046753",
    "scope": "repo"
  },
  {
    "bytes": 14478,
    "repoRelPath": "CAPABILITY/CAS/storage/0/48/04857c981a22174f172cc93e172376ed777b6d058f23aa9129e3a70eef691555",
    "scope": "repo"
  },
  {
    "bytes": 841,
    "repoRelPath": "CAPABILITY/CAS/storage/0/49/049d092ebdf76e61555f1b0b5e16d864d8f7f54dd75e2790673efc776bbeb0a0",
    "scope": "repo"
  },
  {
    "bytes": 183,
    "repoRelPath": "CAPABILITY/CAS/storage/0/4a/04ab9c107aaa8e05d0d014ac24679ea41789a8c460242912ca2484d96b1d4a90",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/0/53/053b0a139ccf1c2bd7abd87f0366985a424a2eaae5fac52223513353ee35a94f",
    "scope": "repo"
  },
  {
    "bytes": 135,
    "repoRelPath": "CAPABILITY/CAS/storage/0/55/055373d2d5916d7245990454c54ab62817bf787538ca4475c73a310b556aabef",
    "scope": "repo"
  },
  {
    "bytes": 33,
    "repoRelPath": "CAPABILITY/CAS/storage/0/56/0561cbc7f243ee1d2d8ce8e1bbc2461661d0cfc7cae6348d0ca70ae7b45bcd0f",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/0/58/058c7f3a23587a8995405ce2eb65979cf8b954cdace30b738bc6a86ffda590b4",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/0/5d/05de46de8af9918c1b42e187eb15f0a778a9ea0abf05ae7737e0c5201f32c7d0",
    "scope": "repo"
  },
  {
    "bytes": 125,
    "repoRelPath": "CAPABILITY/CAS/storage/0/62/062ae3c646a2a109fa2b19af91e1f5c063d2ef3bcf52e7acbc57b3b9f8682fe0",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/0/67/06770f1ada1a012401d09d4096d3b3327cf05e536d573aacaaa4d0af5008aa59",
    "scope": "repo"
  },
  {
    "bytes": 32898,
    "repoRelPath": "CAPABILITY/CAS/storage/0/68/06886c96cb3bce6cef93544aae242751be9a46f6cb8857bb42701200f1c16faf",
    "scope": "repo"
  },
  {
    "bytes": 3534,
    "repoRelPath": "CAPABILITY/CAS/storage/0/6a/06a6ea400e1d853ce68765711314031d320b66de13babf0a325e530bb47d00d5",
    "scope": "repo"
  },
  {
    "bytes": 14346,
    "repoRelPath": "CAPABILITY/CAS/storage/0/6f/06f5cd6e579ba91efd2682286a3c1b2c675b5f24b64ae529d1e631527a32ee2c",
    "scope": "repo"
  },
  {
    "bytes": 221,
    "repoRelPath": "CAPABILITY/CAS/storage/0/6f/06fadc8528c45eb5c13b125496dcf9de5e05500e146ba8bf0ec122be82128f4b",
    "scope": "repo"
  },
  {
    "bytes": 1407,
    "repoRelPath": "CAPABILITY/CAS/storage/0/71/071011f784011d1238c345a4093252ed410e9cfa832969beac1e6b30f2cafd91",
    "scope": "repo"
  },
  {
    "bytes": 8305,
    "repoRelPath": "CAPABILITY/CAS/storage/0/73/073c846d74e922cb33daaabe457a085bbea90c62fe56d43766012e15569559b1",
    "scope": "repo"
  },
  {
    "bytes": 6553,
    "repoRelPath": "CAPABILITY/CAS/storage/0/75/075fd55585caadd1ce69c981bd7ed4b8d0ebc0aef818158d173369d28a2b65a6",
    "scope": "repo"
  },
  {
    "bytes": 19899,
    "repoRelPath": "CAPABILITY/CAS/storage/0/76/0762d4aa9ee20f903259921ee6995fc964864b81f1e645d28fb2edf1981282c8",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/0/7a/07ac5742524c08c68d89f1062a44bf713e1f7ab61d8842b7bcf9d8c8b7cee1eb",
    "scope": "repo"
  },
  {
    "bytes": 1810,
    "repoRelPath": "CAPABILITY/CAS/storage/0/7b/07ba49382ab4b68f34d4eaa60d2e6183decad2f152b3e1c2dcef3d4b3b2cc15c",
    "scope": "repo"
  },
  {
    "bytes": 8955,
    "repoRelPath": "CAPABILITY/CAS/storage/0/82/0822d0d38260fc9eaff7c42b6cb9fc8c16fe58038af3206eb881138cfbb5a5fd",
    "scope": "repo"
  },
  {
    "bytes": 3165,
    "repoRelPath": "CAPABILITY/CAS/storage/0/84/084ce0d062c5583a6ce705f5b94795a0d56de37168b87bc00b588effa3aff020",
    "scope": "repo"
  },
  {
    "bytes": 1447,
    "repoRelPath": "CAPABILITY/CAS/storage/0/86/08601c32846458be0e67e3cf97e6b27062b004e38fc7f4414d38c1664903cff2",
    "scope": "repo"
  },
  {
    "bytes": 9909,
    "repoRelPath": "CAPABILITY/CAS/storage/0/88/0883f839e63e4216ecfe9981ed81889afb8e7e2416177e75d0d58b22393359db",
    "scope": "repo"
  },
  {
    "bytes": 20717,
    "repoRelPath": "CAPABILITY/CAS/storage/0/8e/08e774f07f0e56e0926252b5dee57bedcd67ee1ffcce013b60c2d84d0afe581b",
    "scope": "repo"
  },
  {
    "bytes": 851,
    "repoRelPath": "CAPABILITY/CAS/storage/0/93/093531739c3f8c7e5fce652657e6d8c8b17deb7ab3be9387fbeb0e7e9b668a71",
    "scope": "repo"
  },
  {
    "bytes": 1949,
    "repoRelPath": "CAPABILITY/CAS/storage/0/93/0937c4fa90725ff52e4fd22863629c27894efa49f5df26d849f274996a784143",
    "scope": "repo"
  },
  {
    "bytes": 8,
    "repoRelPath": "CAPABILITY/CAS/storage/0/96/096e929abe31157e5a522fecfe1333bb96b3252e9ee74923b6e9027206c4d068",
    "scope": "repo"
  },
  {
    "bytes": 17422,
    "repoRelPath": "CAPABILITY/CAS/storage/0/98/0987d58ae13158abff22e9dfb3fced75bdb2230f39e674ed0116d830eeef4cdb",
    "scope": "repo"
  },
  {
    "bytes": 216,
    "repoRelPath": "CAPABILITY/CAS/storage/0/99/0998393733486c3be1b01d65ab87f7ed0a03757028c80f7e945271dc3e3c2546",
    "scope": "repo"
  },
  {
    "bytes": 326,
    "repoRelPath": "CAPABILITY/CAS/storage/0/9b/09bf56ab148c2ee178611cafa54ef17a4398c0f019851b6349ccc249e0ef3d13",
    "scope": "repo"
  },
  {
    "bytes": 964,
    "repoRelPath": "CAPABILITY/CAS/storage/0/9d/09d87921aa4583c920716be4c72b49128ef931a25d0aea2dcb0ac36f120e115b",
    "scope": "repo"
  },
  {
    "bytes": 2305,
    "repoRelPath": "CAPABILITY/CAS/storage/0/9f/09f985cdc1486ae81fb033c3d28d8581ae82ba165bd6cf3748ffe950420dedf7",
    "scope": "repo"
  },
  {
    "bytes": 18,
    "repoRelPath": "CAPABILITY/CAS/storage/0/a5/0a5251aa4cb6de582dc54eec3a8bce8a3dd3b40074d7098709d32c1f0d7e2906",
    "scope": "repo"
  },
  {
    "bytes": 6994,
    "repoRelPath": "CAPABILITY/CAS/storage/0/a8/0a84c5c56b43de92db1ccc7ac66ed61ea3cf757db00b5810596fc5e98fef7be3",
    "scope": "repo"
  },
  {
    "bytes": 40,
    "repoRelPath": "CAPABILITY/CAS/storage/0/aa/0aacac3f9743e02194d0e51898a7977cdf1e9b41c572e191abd78df8c1a5ea28",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/0/ab/0ab2fd52fe1ca484c369bdbd64ced7a8256dcf418180dc98cda529ee69b3cb3c",
    "scope": "repo"
  },
  {
    "bytes": 11697,
    "repoRelPath": "CAPABILITY/CAS/storage/0/ab/0ab3aa8c6edf924d48dcb8ae309e49cb82467af15e3ab3eaf5cc83b7bff4c8e6",
    "scope": "repo"
  },
  {
    "bytes": 7775,
    "repoRelPath": "CAPABILITY/CAS/storage/0/ac/0acd825e0ec1ff754d0a98941d6329fc46fef33401fb648800f367df3f955916",
    "scope": "repo"
  },
  {
    "bytes": 1033,
    "repoRelPath": "CAPABILITY/CAS/storage/0/af/0afd0a4faab81fa072757fbc757f83e8151e57cbb5be80b349b77ac36c1c2a1c",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/0/b4/0b459c9e341c72b9c03d7b17193ea017f943176f3d077edb450e3e8ac8163cd4",
    "scope": "repo"
  },
  {
    "bytes": 35257,
    "repoRelPath": "CAPABILITY/CAS/storage/0/b5/0b5381e7aa14b4424a9107e2d0c3cb9872ad7d8a7a83d5107564be2ea32f3ff4",
    "scope": "repo"
  },
  {
    "bytes": 100,
    "repoRelPath": "CAPABILITY/CAS/storage/0/b6/0b6c8596c87642e751d35c404ed12823662ab1e21a284cdd6092c1738dc5a92a",
    "scope": "repo"
  },
  {
    "bytes": 4711,
    "repoRelPath": "CAPABILITY/CAS/storage/0/b7/0b7f566e2a70df66c0a22eb2776fdbc1362a4fafdb9910b1c696067ace8fb01d",
    "scope": "repo"
  },
  {
    "bytes": 33,
    "repoRelPath": "CAPABILITY/CAS/storage/0/b9/0b9461655a7fa4c5024ca5a143e89e26a8180d15385370c444769bfffa834ce9",
    "scope": "repo"
  },
  {
    "bytes": 10863,
    "repoRelPath": "CAPABILITY/CAS/storage/0/bb/0bba250b94caa4cb2b28b15dad26fdcf371aeda4c9797b8120e55c2e33e0c73c",
    "scope": "repo"
  },
  {
    "bytes": 5408,
    "repoRelPath": "CAPABILITY/CAS/storage/0/bc/0bc919dc117528731e2aab3adce3f96268d590f9db16b9487b9e4cba70fa2e25",
    "scope": "repo"
  },
  {
    "bytes": 5064,
    "repoRelPath": "CAPABILITY/CAS/storage/0/bc/0bce693b850264786762aa0aafb3a26b82706d8feb7682436a82d213eb19454b",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/0/be/0be80bae30b73b12849640e24afe8ebf1663873998b100f8720ecfd56cc01c94",
    "scope": "repo"
  },
  {
    "bytes": 1416077,
    "repoRelPath": "CAPABILITY/CAS/storage/0/c0/0c0e24118476ad1ba211ccb1459c25b866f83cd666b9cfb6f08262cb0ca66a04",
    "scope": "repo"
  },
  {
    "bytes": 2798,
    "repoRelPath": "CAPABILITY/CAS/storage/0/c4/0c43ac4f2001bbfb81cdcd7ce74ea60f3c2601a0b93180ab5cd29e00e00ad70a",
    "scope": "repo"
  },
  {
    "bytes": 677,
    "repoRelPath": "CAPABILITY/CAS/storage/0/ca/0ca1dbed6aeb09222ca6033428d1e964e63973f4ae03d29b1451fec350965a45",
    "scope": "repo"
  },
  {
    "bytes": 275,
    "repoRelPath": "CAPABILITY/CAS/storage/0/ca/0ca378eaa4298f1e78957ad945dfff6aac562471621ea0421f51b9ffbe17fddd",
    "scope": "repo"
  },
  {
    "bytes": 3184,
    "repoRelPath": "CAPABILITY/CAS/storage/0/cb/0cbaeead2743a5cfa2bf5a8ddfea5301910f5cbb010e2306054c0915997eb3dd",
    "scope": "repo"
  },
  {
    "bytes": 10408,
    "repoRelPath": "CAPABILITY/CAS/storage/0/d2/0d2770a470fd05cd8e78f067837e2661b0c01397d4f6082573501d82edb3eebf",
    "scope": "repo"
  },
  {
    "bytes": 25,
    "repoRelPath": "CAPABILITY/CAS/storage/0/d5/0d5375b01dd03c70ed6c226ef84c70e41ddb0b6b76b325c300cd303b5c18c99a",
    "scope": "repo"
  },
  {
    "bytes": 1741,
    "repoRelPath": "CAPABILITY/CAS/storage/0/d6/0d6ca48a8e41e4cb43203c0897cf94a2b183d5f8afcb6023c07f51ccb11e20e5",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/0/d7/0d7aac72d1af515418484c6f11544500b561a5eef7ef9f4f9ca3151b375802f5",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/0/d7/0d7d3f821b61d4f25d95aea5dc0f46223334aba8c338de7b8483c1122550175b",
    "scope": "repo"
  },
  {
    "bytes": 1585,
    "repoRelPath": "CAPABILITY/CAS/storage/0/d8/0d8a8b1b7e8bd74b820a8dc9c22d4797e38aac07580017281110fd8deefd1aed",
    "scope": "repo"
  },
  {
    "bytes": 596,
    "repoRelPath": "CAPABILITY/CAS/storage/0/dc/0dc7ca6d4fbedd0ec7e6b6fe79b00f941c1da93fa0692842851fcc3c3ed47a62",
    "scope": "repo"
  },
  {
    "bytes": 3043,
    "repoRelPath": "CAPABILITY/CAS/storage/0/dd/0dd838db73d4f94b04803cb2941293717f90493ce6fa7c094e6c2e777ecb5d27",
    "scope": "repo"
  },
  {
    "bytes": 11879,
    "repoRelPath": "CAPABILITY/CAS/storage/0/e3/0e3c30294e54c3f219cc1919509de7a2c526c775ab77416694b331922db6226c",
    "scope": "repo"
  },
  {
    "bytes": 1981,
    "repoRelPath": "CAPABILITY/CAS/storage/0/eb/0eb3b4d2e0cb40a634303905ba724c9f34f3a38a868fcf02b46277305a5ab773",
    "scope": "repo"
  },
  {
    "bytes": 1654,
    "repoRelPath": "CAPABILITY/CAS/storage/0/ec/0ecda9a6723ffef0006fdb1e049349b3251c2dee60a9f445de058e5ebe587ec7",
    "scope": "repo"
  },
  {
    "bytes": 3721,
    "repoRelPath": "CAPABILITY/CAS/storage/0/ee/0ee7f8a76476dc6ba0476505217293ac3b9a95ab610b0e254f54ae36063423a9",
    "scope": "repo"
  },
  {
    "bytes": 2014,
    "repoRelPath": "CAPABILITY/CAS/storage/0/f3/0f3077981a363dbe9ada12bfe03249c3ed742f5d733da5c5fbd7fe4ba382e460",
    "scope": "repo"
  },
  {
    "bytes": 3462,
    "repoRelPath": "CAPABILITY/CAS/storage/0/f5/0f5b836af209779f5af5e209aac84a3d38366b54dbbfd665a53a7dc03620360d",
    "scope": "repo"
  },
  {
    "bytes": 109351,
    "repoRelPath": "CAPABILITY/CAS/storage/0/f6/0f6351c0997d55e8dd57074da37e700bcb6dce43da7cc9e60c237e1bfc67b6eb",
    "scope": "repo"
  },
  {
    "bytes": 6181,
    "repoRelPath": "CAPABILITY/CAS/storage/0/fa/0fa79013174a7c3e42da05c64f8e31ee2632e3142ff6809a2eaf0b30c525a5cc",
    "scope": "repo"
  },
  {
    "bytes": 714,
    "repoRelPath": "CAPABILITY/CAS/storage/0/fa/0fa8b3a08d0ac4338a77ae9a2158d7047dce82e0c78388dc84b11b5653c10e53",
    "scope": "repo"
  },
  {
    "bytes": 1311,
    "repoRelPath": "CAPABILITY/CAS/storage/1/02/102b23f6bd4cb4bb81b1c69c21e468696dc72c0fa3ab85cf32146d14f0297b9f",
    "scope": "repo"
  },
  {
    "bytes": 33003,
    "repoRelPath": "CAPABILITY/CAS/storage/1/02/102e2ec746289e64179bc4b69c32514869308c5f87b3102621c23f5a01172687",
    "scope": "repo"
  },
  {
    "bytes": 485,
    "repoRelPath": "CAPABILITY/CAS/storage/1/14/11467e82995336790f12ee23911f0a308926449af1fb7fd2f5c60ae2089bd7c9",
    "scope": "repo"
  },
  {
    "bytes": 665,
    "repoRelPath": "CAPABILITY/CAS/storage/1/16/116b4ff0b7f9f6995c648106185697309fd380851197419d9d62275bb4906d87",
    "scope": "repo"
  },
  {
    "bytes": 290,
    "repoRelPath": "CAPABILITY/CAS/storage/1/17/117a6f30378ea14933ff4329f408e3a23d50782ba7fe5b5962816c261954dff6",
    "scope": "repo"
  },
  {
    "bytes": 262,
    "repoRelPath": "CAPABILITY/CAS/storage/1/17/117e3a6dda327a5c6e2aa17d6f644b4315b34044065eb4f9fa32ea472a5584df",
    "scope": "repo"
  },
  {
    "bytes": 116,
    "repoRelPath": "CAPABILITY/CAS/storage/1/20/1204d74d6ab19f1b3d17c64f9654782633a1cce1f1f243c6b1b96c296cfa62ab",
    "scope": "repo"
  },
  {
    "bytes": 549,
    "repoRelPath": "CAPABILITY/CAS/storage/1/20/120d4a44f06e0282ca6e9230fbbaccdd883cf8b4f9e3767fd4663c2e395896d2",
    "scope": "repo"
  },
  {
    "bytes": 3705,
    "repoRelPath": "CAPABILITY/CAS/storage/1/21/121ffcbd8d810cc7918ac3ff9e0d5dd7a87843d02481a44aa1d133eef6fd0b80",
    "scope": "repo"
  },
  {
    "bytes": 109187,
    "repoRelPath": "CAPABILITY/CAS/storage/1/26/126516edb437f7b7c7b472fa3d500098cf1d4ec63798fb71ddabf560eeca5d28",
    "scope": "repo"
  },
  {
    "bytes": 7360,
    "repoRelPath": "CAPABILITY/CAS/storage/1/2f/12f68403bf5c843597ec847d28f7f6838c9f1bec3a66a016bc31cdc1af5fe41b",
    "scope": "repo"
  },
  {
    "bytes": 4949,
    "repoRelPath": "CAPABILITY/CAS/storage/1/33/133ea5567ac729979ba5c86fc6914063fde9a10035d7fdfbb399d372144989d2",
    "scope": "repo"
  },
  {
    "bytes": 1109,
    "repoRelPath": "CAPABILITY/CAS/storage/1/39/1399c9dc754899501f24a5e56adeb1e0c4f1c2cd3a6ce2acf22ce4fb42f32fc1",
    "scope": "repo"
  },
  {
    "bytes": 77,
    "repoRelPath": "CAPABILITY/CAS/storage/1/3d/13dd01eda0eb9f22ce0acd541ebf06b0702c42d3b8568e6be0046dc2f46f3e4d",
    "scope": "repo"
  },
  {
    "bytes": 39866,
    "repoRelPath": "CAPABILITY/CAS/storage/1/43/14392c8f99b506f52a110fbb78aa8d78ac3118461c3c6a572c2b8a91b22fd4cd",
    "scope": "repo"
  },
  {
    "bytes": 38135,
    "repoRelPath": "CAPABILITY/CAS/storage/1/48/1483a12fd0eea34c08bb566bde41ea0c7b1ee33058d158198caba21304176df7",
    "scope": "repo"
  },
  {
    "bytes": 3248,
    "repoRelPath": "CAPABILITY/CAS/storage/1/49/149ce9439e62a483fd0a3ebc8434d9e1c21096ee06cf21234bab61754107979d",
    "scope": "repo"
  },
  {
    "bytes": 93,
    "repoRelPath": "CAPABILITY/CAS/storage/1/52/1522a0f0c64abf00f28da9ebb24ea61a1d64ceef7c9b3d9b0626a4a61848ec99",
    "scope": "repo"
  },
  {
    "bytes": 608,
    "repoRelPath": "CAPABILITY/CAS/storage/1/52/152937b8d75552543009aa32f8c1cccb2e44852276677387c9ecb692d483c5ef",
    "scope": "repo"
  },
  {
    "bytes": 5499,
    "repoRelPath": "CAPABILITY/CAS/storage/1/5a/15a1138d8a9de2f7722d284e3d0d7a39aec67849b832f14953a60b7779073495",
    "scope": "repo"
  },
  {
    "bytes": 187,
    "repoRelPath": "CAPABILITY/CAS/storage/1/5b/15bdfc68a0a0929bb2d4a624fb63df660ce5408fe0c24ebca160d283f7f85455",
    "scope": "repo"
  },
  {
    "bytes": 12773,
    "repoRelPath": "CAPABILITY/CAS/storage/1/5d/15ddc08431aa0a057124bed0c18091a44af1ad3196941523d66d592333e82580",
    "scope": "repo"
  },
  {
    "bytes": 109351,
    "repoRelPath": "CAPABILITY/CAS/storage/1/62/1624b9cf1dab9f8086fc34986c13688745d73af53bb275d5b5ed9f703d988c7f",
    "scope": "repo"
  },
  {
    "bytes": 21721,
    "repoRelPath": "CAPABILITY/CAS/storage/1/67/1671dc88f84dfc9ab1baea3e02ba91c741b96879f373970ec1ea7bdebfaa20eb",
    "scope": "repo"
  },
  {
    "bytes": 854,
    "repoRelPath": "CAPABILITY/CAS/storage/1/68/168e7c442c684c4fad9f7ead9671b1766f00e4745fe85693a4fc791564ea786e",
    "scope": "repo"
  },
  {
    "bytes": 1789,
    "repoRelPath": "CAPABILITY/CAS/storage/1/69/169fa93776460ebdeb1a3b15e2033ba9aa4aa0825165389a4b057ba1646c1765",
    "scope": "repo"
  },
  {
    "bytes": 805,
    "repoRelPath": "CAPABILITY/CAS/storage/1/70/17040364f513350f6f9a2ba2c02bfff5b5899a292a6f5db7b3abeec8a6fd3454",
    "scope": "repo"
  },
  {
    "bytes": 14,
    "repoRelPath": "CAPABILITY/CAS/storage/1/72/172dbe9607e5ab5576e2e5b6f1abf5350da9c3ff862681cb6801830bb4528400",
    "scope": "repo"
  },
  {
    "bytes": 368,
    "repoRelPath": "CAPABILITY/CAS/storage/1/77/177d392055dd0fd63dd799f4b559d9ddc09389dc17f282a444f2ec3d2def0d2c",
    "scope": "repo"
  },
  {
    "bytes": 1715,
    "repoRelPath": "CAPABILITY/CAS/storage/1/7c/17ca968f39b4245228b68aad06fa6d90fc5ac2f2e2c877008ce004ef3c8aacc3",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/1/7e/17eeae74efd0c16b5ca2c3ae0708361cdf2fb67fb59249e671ff7b41e8ab1340",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/1/82/182090e07fd02d97516a1dd68fad6e29d4bad0aeb9eb422c85cdb88f83946c1c",
    "scope": "repo"
  },
  {
    "bytes": 1774,
    "repoRelPath": "CAPABILITY/CAS/storage/1/8b/18b5d0ce51a337dda72c20921e19d0a2a568805a928943f3ab44cc4d103ef52d",
    "scope": "repo"
  },
  {
    "bytes": 30741,
    "repoRelPath": "CAPABILITY/CAS/storage/1/8e/18ec6c04a7bd0006fb59237d8de2a198540118f4dcabdfbba4ae145439c76bf8",
    "scope": "repo"
  },
  {
    "bytes": 5216,
    "repoRelPath": "CAPABILITY/CAS/storage/1/90/19067bb9b65e4a224ae5dc1ad036c70ad34bd8592d06cfe47fa338b7ca8d913a",
    "scope": "repo"
  },
  {
    "bytes": 12174,
    "repoRelPath": "CAPABILITY/CAS/storage/1/92/1921d4c8719bb29bddae687c4d87f792d6ab2587bd3a04511e29b980a7565d2a",
    "scope": "repo"
  },
  {
    "bytes": 25,
    "repoRelPath": "CAPABILITY/CAS/storage/1/95/1952540500994202247419d4329c9ef7beab40322762a1010cf470b49a5cf904",
    "scope": "repo"
  },
  {
    "bytes": 677,
    "repoRelPath": "CAPABILITY/CAS/storage/1/9a/19a1db57554d8503ed7568dcf3c39beaf54ca06bd1979ff53c39fe2707a1658a",
    "scope": "repo"
  },
  {
    "bytes": 738,
    "repoRelPath": "CAPABILITY/CAS/storage/1/9b/19bcf23c34d920dc6004ec897406dbc30381b3bdfc1b7847998c08de2fc8ad44",
    "scope": "repo"
  },
  {
    "bytes": 2521,
    "repoRelPath": "CAPABILITY/CAS/storage/1/9c/19c5c95b56fc19c67015a9a44e21284c296ffb14aa64a9bc8e640e889972181e",
    "scope": "repo"
  },
  {
    "bytes": 1043,
    "repoRelPath": "CAPABILITY/CAS/storage/1/9c/19cd6640a673e95a6c50d2cdf1298a6cd0243abeef967ca4ae15d237b10ab9e0",
    "scope": "repo"
  },
  {
    "bytes": 149,
    "repoRelPath": "CAPABILITY/CAS/storage/1/9e/19e5986992fdc90f6d44ed08daec6c56cb91f7a140b50c2c8fe92c5954263c83",
    "scope": "repo"
  },
  {
    "bytes": 10290,
    "repoRelPath": "CAPABILITY/CAS/storage/1/a3/1a3c66f4d21a66e22e85ea1f0688bf39f5bc52e8fd11bea64001f39e92a210c1",
    "scope": "repo"
  },
  {
    "bytes": 4481,
    "repoRelPath": "CAPABILITY/CAS/storage/1/a5/1a5eac2d0ef85e425702e1b9330f6b2ee567f3ec22e2f93e00e9687acbc6412b",
    "scope": "repo"
  },
  {
    "bytes": 32,
    "repoRelPath": "CAPABILITY/CAS/storage/1/a7/1a700403aab1bff3199a12ec4a8e4b5ac4bbd95b20d9b6f6ce5a1837b0a631d8",
    "scope": "repo"
  },
  {
    "bytes": 20,
    "repoRelPath": "CAPABILITY/CAS/storage/1/a8/1a87324c70faad94fdca78c5256460add4f1b30864cff0d08bf6be556519f41e",
    "scope": "repo"
  },
  {
    "bytes": 18195,
    "repoRelPath": "CAPABILITY/CAS/storage/1/af/1af98986ae69fda37cf31df40d18b496581cc7f483bab08ec0021166b58fa8b4",
    "scope": "repo"
  },
  {
    "bytes": 9010,
    "repoRelPath": "CAPABILITY/CAS/storage/1/b2/1b2cb7bdf7c5ac651b7b245bb92c5512abf414aec562eaeb51022d928fa093fa",
    "scope": "repo"
  },
  {
    "bytes": 48911,
    "repoRelPath": "CAPABILITY/CAS/storage/1/b6/1b6a9facaaeea63b43a48bed78d3a317ed547632e01571effa2ef89865186120",
    "scope": "repo"
  },
  {
    "bytes": 12170,
    "repoRelPath": "CAPABILITY/CAS/storage/1/ba/1bacbd7661b4da4032babcabf0b69359cc97d1672aa95f76153f31533f487050",
    "scope": "repo"
  },
  {
    "bytes": 169,
    "repoRelPath": "CAPABILITY/CAS/storage/1/bd/1bda59d2c5b9149cbf5884f50872d6f86a638cd2f7ed4b0525a817f59cdf087a",
    "scope": "repo"
  },
  {
    "bytes": 677,
    "repoRelPath": "CAPABILITY/CAS/storage/1/bf/1bfeaeb63eafb0a48d48fef28f56e3b75113c6e60df038f4f0e170180982c34b",
    "scope": "repo"
  },
  {
    "bytes": 765,
    "repoRelPath": "CAPABILITY/CAS/storage/1/c5/1c534608012927cc7fb7f3f73834a5ba7a389a6a52af9292b5a84e0b5c28cd6b",
    "scope": "repo"
  },
  {
    "bytes": 37551,
    "repoRelPath": "CAPABILITY/CAS/storage/1/c5/1c5c07d1879cbb2abc09a5293dfee9163d465be6cd2f40c4a30706ba3e058415",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/1/c7/1c7c7396b530d620429b37a0add33745882e2dfcda3d4a90e0dda2bd4d25a5fc",
    "scope": "repo"
  },
  {
    "bytes": 1820,
    "repoRelPath": "CAPABILITY/CAS/storage/1/ca/1ca2b9756119d76894bbe10b5819d7842489aa1ab8060e447059696ee8252ba6",
    "scope": "repo"
  },
  {
    "bytes": 6682,
    "repoRelPath": "CAPABILITY/CAS/storage/1/cc/1ccbd3f79b0b21b0d9ec35e8bb858ecf0001defd63f9a1b5e974dbfcf1db07de",
    "scope": "repo"
  },
  {
    "bytes": 6170,
    "repoRelPath": "CAPABILITY/CAS/storage/1/cd/1cdf05ca14183488c7d1894c88cfdabad526d261a57382c2ea004619137a6113",
    "scope": "repo"
  },
  {
    "bytes": 714,
    "repoRelPath": "CAPABILITY/CAS/storage/1/d2/1d2cf6185bd28733d96f43e630e33cefe944b72fcb5132bd51af0e1ad83616db",
    "scope": "repo"
  },
  {
    "bytes": 1123,
    "repoRelPath": "CAPABILITY/CAS/storage/1/d3/1d38a45ec76eda7cade512c05ff0d9dec71bd880bb6c28f7ba7c08707e66b9dd",
    "scope": "repo"
  },
  {
    "bytes": 7973,
    "repoRelPath": "CAPABILITY/CAS/storage/1/d3/1d3ca16300f0ac60a349623c22d2a32fffa15a0e5dfdc6b21057447c9f079ce6",
    "scope": "repo"
  },
  {
    "bytes": 2707,
    "repoRelPath": "CAPABILITY/CAS/storage/1/dc/1dcf61df2ca9e83a55afeaa08c83e5ec362100c2c68ef628ff39c9bbdb7bb7fa",
    "scope": "repo"
  },
  {
    "bytes": 626,
    "repoRelPath": "CAPABILITY/CAS/storage/1/dd/1dd83ddab03d37c580b0e881123a374b2d9444224b9c7c1003f16899515a58f1",
    "scope": "repo"
  },
  {
    "bytes": 3381,
    "repoRelPath": "CAPABILITY/CAS/storage/1/de/1ded4d6ffb0823deca417185681e0c5ea6b4dace3c5fd250201659d4bb269ad2",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/1/e3/1e328b215d324c46b9d915830726b905ffff0da2c37905d52128d0da5818d4b1",
    "scope": "repo"
  },
  {
    "bytes": 539,
    "repoRelPath": "CAPABILITY/CAS/storage/1/e5/1e5656122907879345148271195c65a8047f0ceacc9776eeee61b0d22d08ce20",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/1/eb/1eb4245b376a6f83ec527a538f71b14a8ef5f0ef4f01b338507ebed76d083f2c",
    "scope": "repo"
  },
  {
    "bytes": 1200,
    "repoRelPath": "CAPABILITY/CAS/storage/1/ed/1ed3f6d01a1870ecc0807a900fb5f12e392b63ff278dd72733ef23ae66720234",
    "scope": "repo"
  },
  {
    "bytes": 154,
    "repoRelPath": "CAPABILITY/CAS/storage/1/ef/1ef300421c27c67d9a7c44e48cae145aeb3412a4053f4f67340245cceee9f890",
    "scope": "repo"
  },
  {
    "bytes": 500,
    "repoRelPath": "CAPABILITY/CAS/storage/1/f4/1f43d0e9721df943bfaf20aecc757029991bc20900a0c74b799b60938ace586e",
    "scope": "repo"
  },
  {
    "bytes": 324,
    "repoRelPath": "CAPABILITY/CAS/storage/1/f6/1f6e8dac3065477bd5c8b729479349a277b272df2320cb3e96f91caa754748c7",
    "scope": "repo"
  },
  {
    "bytes": 149,
    "repoRelPath": "CAPABILITY/CAS/storage/1/f7/1f716033c10a46c685330f39e5d22adc23ec356053664f231890241231149753",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/1/fc/1fcbe293508237df6f7982236fc9b6342cd336757b185fae2328c6a37fffcdbb",
    "scope": "repo"
  },
  {
    "bytes": 62646,
    "repoRelPath": "CAPABILITY/CAS/storage/1/fd/1fd28b8b35fc4cb87e0bbb3931f41f3e4aef5b271e92bf01c4ed30d0b0387341",
    "scope": "repo"
  },
  {
    "bytes": 1416077,
    "repoRelPath": "CAPABILITY/CAS/storage/1/fd/1fd35c7cb3c2aaec966c38407247e082497ce48373e7f68f46886dbe18092f27",
    "scope": "repo"
  },
  {
    "bytes": 91,
    "repoRelPath": "CAPABILITY/CAS/storage/1/ff/1ffade5db29d9f3aa515605d7c920fb20b5121763b071335fe9e283af321bfcf",
    "scope": "repo"
  },
  {
    "bytes": 18,
    "repoRelPath": "CAPABILITY/CAS/storage/2/01/20171154c9f4a44db8eae68c34575e9bce5acf38532163254aaa39344737a528",
    "scope": "repo"
  },
  {
    "bytes": 805,
    "repoRelPath": "CAPABILITY/CAS/storage/2/04/2048b26b1365accf2d2ec8d1fd638e63e5b83312365f5d6794370ca6e3e26419",
    "scope": "repo"
  },
  {
    "bytes": 2190,
    "repoRelPath": "CAPABILITY/CAS/storage/2/04/204f15377315571967f2a70a3558a47019962f249e24063a80021b878a95436c",
    "scope": "repo"
  },
  {
    "bytes": 1741,
    "repoRelPath": "CAPABILITY/CAS/storage/2/08/208a9ca3f1a4c5a2acc38485f094e2b541e095d3c85e93ae39e6c9f0d75daf60",
    "scope": "repo"
  },
  {
    "bytes": 10663,
    "repoRelPath": "CAPABILITY/CAS/storage/2/0e/20eaf520a472d4003ae77f970db05e52133e7eb925bad8ffea4e8fa15971d544",
    "scope": "repo"
  },
  {
    "bytes": 6040,
    "repoRelPath": "CAPABILITY/CAS/storage/2/14/2149900d5a79932ea87d390cbe5c5e1cba8a667e3df03bfc4e43033ca39de634",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/2/17/217214a49257b15351d0461b62064f364de4880ff4004e43bd861df19eb6fbbc",
    "scope": "repo"
  },
  {
    "bytes": 457,
    "repoRelPath": "CAPABILITY/CAS/storage/2/1a/21a83ebe9a22b85f54fb99ea359a500e6d7cb274f1cf15a339bedf64d13e5ad8",
    "scope": "repo"
  },
  {
    "bytes": 1484208,
    "repoRelPath": "CAPABILITY/CAS/storage/2/1d/21d42d9985eed020ed35062cff75530aa7fa8f505d3b2e1243bd6c43f146c2f5",
    "scope": "repo"
  },
  {
    "bytes": 21753,
    "repoRelPath": "CAPABILITY/CAS/storage/2/1d/21dbb1ea1aa3fe1c7e551a38808051e16825dcb567845bfc883040d7b239a0a3",
    "scope": "repo"
  },
  {
    "bytes": 5015,
    "repoRelPath": "CAPABILITY/CAS/storage/2/21/221efc3add17b089d6c51691c28551ee9b0f2f082e0f8cf141202442a3cb9cf8",
    "scope": "repo"
  },
  {
    "bytes": 1435,
    "repoRelPath": "CAPABILITY/CAS/storage/2/28/2289dfc7e85ee5af1043983db3f1c5c63508d6693e4066aa57d0306a7f9bed4f",
    "scope": "repo"
  },
  {
    "bytes": 505,
    "repoRelPath": "CAPABILITY/CAS/storage/2/2a/22aaf126e2e8fb087fc659515738cee6bdb079248a3acbcaffd7f33f641e9295",
    "scope": "repo"
  },
  {
    "bytes": 825,
    "repoRelPath": "CAPABILITY/CAS/storage/2/2c/22c3c6781c40070b95898fa3b4b4d6fae4d508113f02505933ea459146b6969c",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/2/2e/22ee04d1f5be597f3e4e1ef047b28d0d9a9fdb9a91eca7de86ab1f34e5030b67",
    "scope": "repo"
  },
  {
    "bytes": 454,
    "repoRelPath": "CAPABILITY/CAS/storage/2/31/231a02f6baef0d0431beadd462489abe67b8e58919cf19b5b024547a9874b8ff",
    "scope": "repo"
  },
  {
    "bytes": 4058,
    "repoRelPath": "CAPABILITY/CAS/storage/2/32/23208501a5b2fc6421dfc91f4a29faecaf910e88b1eaadf91941f90418cf4d16",
    "scope": "repo"
  },
  {
    "bytes": 2505,
    "repoRelPath": "CAPABILITY/CAS/storage/2/32/232ea3e7faf64d7971757d37e46212ce67897905e5a68c4b78d72f0ff1f8438f",
    "scope": "repo"
  },
  {
    "bytes": 788,
    "repoRelPath": "CAPABILITY/CAS/storage/2/35/235cfc53350a56e1bc5c56a08aef262958dc2435209aa2c3deed740b67c91b89",
    "scope": "repo"
  },
  {
    "bytes": 7994,
    "repoRelPath": "CAPABILITY/CAS/storage/2/39/23975343ab96be17d1f0a23e9326cf931919fca3f30aba5b13ec21f3b2dd2574",
    "scope": "repo"
  },
  {
    "bytes": 14508,
    "repoRelPath": "CAPABILITY/CAS/storage/2/3a/23a0e012315a8f5a86256468b2b1629dd9cf166f1d3c5aec8e3403e96893a161",
    "scope": "repo"
  },
  {
    "bytes": 28,
    "repoRelPath": "CAPABILITY/CAS/storage/2/3a/23af6e082cff0fc018a8287c041c4039c4bb54c989edcc0785d1e12347915ec5",
    "scope": "repo"
  },
  {
    "bytes": 7576,
    "repoRelPath": "CAPABILITY/CAS/storage/2/43/243ac82657acb88f0363d347001787d8306b8daa81232089b522a2e001d4535b",
    "scope": "repo"
  },
  {
    "bytes": 6322,
    "repoRelPath": "CAPABILITY/CAS/storage/2/46/2462cf1429543ddd32c8444dd48457fd8f6bb87daf5046acc5c677dc4893e3c5",
    "scope": "repo"
  },
  {
    "bytes": 4060,
    "repoRelPath": "CAPABILITY/CAS/storage/2/47/24712329f0a040b09d48726bb3c0c89bab4561a3488fdc738121c3ace3ac449f",
    "scope": "repo"
  },
  {
    "bytes": 8294,
    "repoRelPath": "CAPABILITY/CAS/storage/2/48/24820a64afb5f9cfe3d27b03c4ca843c9051ffeb3f0628b07b6073377778076d",
    "scope": "repo"
  },
  {
    "bytes": 694,
    "repoRelPath": "CAPABILITY/CAS/storage/2/48/248b8b5c842de5593296529fc9e86ed9077e889c5eb921c74a2280cafe7504e5",
    "scope": "repo"
  },
  {
    "bytes": 3366,
    "repoRelPath": "CAPABILITY/CAS/storage/2/4b/24b5de07685d99eb8b6fe31c36902fec10dff6158359bc9b3184d2bd2b1dbfdb",
    "scope": "repo"
  },
  {
    "bytes": 20952,
    "repoRelPath": "CAPABILITY/CAS/storage/2/53/253c74a2fb645976aa767ca8307568363cdf6838eb51a821e45332355d43e464",
    "scope": "repo"
  },
  {
    "bytes": 19766,
    "repoRelPath": "CAPABILITY/CAS/storage/2/5c/25c63a1969039feed5f489e15174445745fa96cec618d42b1731abbd167fb170",
    "scope": "repo"
  },
  {
    "bytes": 2121,
    "repoRelPath": "CAPABILITY/CAS/storage/2/5d/25d4958da5385f895066a8c293b7fc81bcb9d8d01f06d68fd0e207b8f924eb8f",
    "scope": "repo"
  },
  {
    "bytes": 6589,
    "repoRelPath": "CAPABILITY/CAS/storage/2/5d/25d4ddd20b54a129fa878a27dda5051815682e45a3e28a398a6a2fcec57609a7",
    "scope": "repo"
  },
  {
    "bytes": 1265,
    "repoRelPath": "CAPABILITY/CAS/storage/2/64/2645836a803eddb30b1495f581c04d16f08f7f3794dbc4ae95a2a8ff2daba73d",
    "scope": "repo"
  },
  {
    "bytes": 2284,
    "repoRelPath": "CAPABILITY/CAS/storage/2/64/264dc79008c0deea1ceec1680078bf74c0c86331204a978f8e08057e520b129a",
    "scope": "repo"
  },
  {
    "bytes": 333,
    "repoRelPath": "CAPABILITY/CAS/storage/2/67/2675bf0f1c4741e036b34e539a8ec60ddfaf6e8a5a969e804e670e362f088aca",
    "scope": "repo"
  },
  {
    "bytes": 972,
    "repoRelPath": "CAPABILITY/CAS/storage/2/68/2683de5dad46800295979b0ecd418e76ffd14861935c921e48ba551f6590abd1",
    "scope": "repo"
  },
  {
    "bytes": 25189,
    "repoRelPath": "CAPABILITY/CAS/storage/2/68/26878b7983bfaa534859c65b405b209cfaf5e4c81144dc64a2e660a6d21e9d99",
    "scope": "repo"
  },
  {
    "bytes": 16403,
    "repoRelPath": "CAPABILITY/CAS/storage/2/68/268d3af8c7362243a44d3ab6398b45b90f031d9691a3f2cd077b4168bcb4e0c5",
    "scope": "repo"
  },
  {
    "bytes": 2558,
    "repoRelPath": "CAPABILITY/CAS/storage/2/6d/26d386296da81c945e060c253f57a8b2bd2daab899041173d5506619145d5957",
    "scope": "repo"
  },
  {
    "bytes": 6010,
    "repoRelPath": "CAPABILITY/CAS/storage/2/6d/26d8bd5bbf3bef8b70c74d9a463819495ae3f1e42d56db90c3d6389999d8f18c",
    "scope": "repo"
  },
  {
    "bytes": 4086,
    "repoRelPath": "CAPABILITY/CAS/storage/2/76/2764bae2de021461ecfe942723d5e769603b371990feb96780bdfad158023829",
    "scope": "repo"
  },
  {
    "bytes": 12747,
    "repoRelPath": "CAPABILITY/CAS/storage/2/76/276a78e832cc59f7a4e4a1fb7d539fded9d219ecd48d3c787a4aeddb1932bbf2",
    "scope": "repo"
  },
  {
    "bytes": 4432,
    "repoRelPath": "CAPABILITY/CAS/storage/2/87/28724ea4cf9939a8b23570d8f5e8484db3411a1017883db2e1d7ae8c38daf8f0",
    "scope": "repo"
  },
  {
    "bytes": 40,
    "repoRelPath": "CAPABILITY/CAS/storage/2/8a/28af725c40be97424aa61073ca9210b84338f89665f87440bd405200654f5f78",
    "scope": "repo"
  },
  {
    "bytes": 3231,
    "repoRelPath": "CAPABILITY/CAS/storage/2/8d/28d0833b469911ec65facc4952834306b8e73c7dc0b8e6faf5b7e9456c012ee8",
    "scope": "repo"
  },
  {
    "bytes": 1101,
    "repoRelPath": "CAPABILITY/CAS/storage/2/8d/28d8f925c326f006df9f43315a00f101ec4a85ef984b7503cd798827c86eb561",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/2/8d/28df9fe452f9d113607404188bf9f99728dc1a9c09f7beadd094b3230d510019",
    "scope": "repo"
  },
  {
    "bytes": 9629,
    "repoRelPath": "CAPABILITY/CAS/storage/2/90/290238a150212915d6168e9a2a0ac36ee57318413ee79c56fa95510b666b2f5f",
    "scope": "repo"
  },
  {
    "bytes": 2018,
    "repoRelPath": "CAPABILITY/CAS/storage/2/92/2926e552472b452ba03f7c985dd92bdd3a71d9589540d3e77409d18f66b0995d",
    "scope": "repo"
  },
  {
    "bytes": 924,
    "repoRelPath": "CAPABILITY/CAS/storage/2/93/29304e3c4a99691bda83d5861b62a7ecb0075300f689f793def4b60200e631b1",
    "scope": "repo"
  },
  {
    "bytes": 1036,
    "repoRelPath": "CAPABILITY/CAS/storage/2/94/2941604dd40be34186cfa31ac1f403f394b0cba875d3e09330c0062c5642ef3a",
    "scope": "repo"
  },
  {
    "bytes": 159,
    "repoRelPath": "CAPABILITY/CAS/storage/2/95/295a7446eddfee45ec4f0dcc1819cc30fe5ba6bc104474fbd22387f8fd95520e",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/2/98/298b2b7c52e934cf36e7dc1331d800df7fcbe98d15d5df478cc84a3511831539",
    "scope": "repo"
  },
  {
    "bytes": 92,
    "repoRelPath": "CAPABILITY/CAS/storage/2/9b/29b905d92a8466c5c62171f8bbaa61aba56bbef5f13647da7b6e19d0b3b23734",
    "scope": "repo"
  },
  {
    "bytes": 11344,
    "repoRelPath": "CAPABILITY/CAS/storage/2/9c/29c00e81d442ce72377c9ebdc8167a88c623ea067824641711c4041a9297c81f",
    "scope": "repo"
  },
  {
    "bytes": 5644,
    "repoRelPath": "CAPABILITY/CAS/storage/2/9d/29d2c86c0d131782ecff18f138a61d0064ded86a1a06406e771df3933d9c7186",
    "scope": "repo"
  },
  {
    "bytes": 9091,
    "repoRelPath": "CAPABILITY/CAS/storage/2/9e/29ed1cec0104314dea9bb5844e9fd7c15a162313ef7cc3a19e8b898d9cea2624",
    "scope": "repo"
  },
  {
    "bytes": 23,
    "repoRelPath": "CAPABILITY/CAS/storage/2/a9/2a97194361be750b88165e4520f345ac0ca64ec1bccaa9b2c10384ee7d2a2754",
    "scope": "repo"
  },
  {
    "bytes": 7300,
    "repoRelPath": "CAPABILITY/CAS/storage/2/ab/2ab029175292507b07f62ce0cac1dc3f4d7c9f97e3bd32a16d914dd14c175861",
    "scope": "repo"
  },
  {
    "bytes": 34,
    "repoRelPath": "CAPABILITY/CAS/storage/2/b0/2b00de8f948d16049a7df76dcf583387708c70883d783ed34c0674491750985c",
    "scope": "repo"
  },
  {
    "bytes": 37,
    "repoRelPath": "CAPABILITY/CAS/storage/2/b1/2b127c6ee6dd558fc268af89ffe9268959a7c8ee3b48e09c189109d81d051ec3",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/2/b1/2b14b930705de4e20eda3f5ef20e4254f5a328e6d5bd476b10cb8464c7dde5f8",
    "scope": "repo"
  },
  {
    "bytes": 7967,
    "repoRelPath": "CAPABILITY/CAS/storage/2/b2/2b21e2cb72b7ee43e7ebe70b775aac099533dc4de99bc5244fef0248176265bb",
    "scope": "repo"
  },
  {
    "bytes": 12473,
    "repoRelPath": "CAPABILITY/CAS/storage/2/b2/2b2d5793d1beb21f9f989a5c2f152fb750d41cbf1e4e6b8e54960660337d22ba",
    "scope": "repo"
  },
  {
    "bytes": 5737,
    "repoRelPath": "CAPABILITY/CAS/storage/2/b3/2b3f270a6d9ba149808cc8eafbcc8df4453a398e73dc342342dc6f8aa3fff4b1",
    "scope": "repo"
  },
  {
    "bytes": 135,
    "repoRelPath": "CAPABILITY/CAS/storage/2/ba/2ba3056e95d23c0c154eca683e330401c46e441d5074523e16349e29d7597a64",
    "scope": "repo"
  },
  {
    "bytes": 877,
    "repoRelPath": "CAPABILITY/CAS/storage/2/c6/2c659231316b8a35d1ecdb39b92ade801818c0506a40d73d8eadd0ffb6a66183",
    "scope": "repo"
  },
  {
    "bytes": 9408,
    "repoRelPath": "CAPABILITY/CAS/storage/2/c7/2c70f2320c57be43aef691d46c11a54c27cfda184dc655a0cb31d3d20938f60e",
    "scope": "repo"
  },
  {
    "bytes": 2577,
    "repoRelPath": "CAPABILITY/CAS/storage/2/c8/2c8459f8585007be5451eb297f12a964516f9686969f8da61db2abe05a8f418c",
    "scope": "repo"
  },
  {
    "bytes": 1391,
    "repoRelPath": "CAPABILITY/CAS/storage/2/d0/2d0362e062ffb5e7b27f88b0970087bc77764efa9de97a4f5e8711cf69cfdd45",
    "scope": "repo"
  },
  {
    "bytes": 19,
    "repoRelPath": "CAPABILITY/CAS/storage/2/d0/2d08bd5e833693c2079b52666317d962dd44506618c1078b8d663837fe1dbb9f",
    "scope": "repo"
  },
  {
    "bytes": 23,
    "repoRelPath": "CAPABILITY/CAS/storage/2/d5/2d51c84aeb8fb1b425062d71b3fdb7b03c8d9745151184d99d8e8586bf188aeb",
    "scope": "repo"
  },
  {
    "bytes": 489,
    "repoRelPath": "CAPABILITY/CAS/storage/2/d9/2d93720df591987fac877254338851124ea322f2805bcaf656e5fc6be11b1faf",
    "scope": "repo"
  },
  {
    "bytes": 570,
    "repoRelPath": "CAPABILITY/CAS/storage/2/da/2da9d6671c86c67da21c1b2f34723df4ef5103e4e0980ad0f6a8c0117d853604",
    "scope": "repo"
  },
  {
    "bytes": 11347,
    "repoRelPath": "CAPABILITY/CAS/storage/2/df/2df695b4e9ab5c8fff87be5ce0b8df219e3a0e53067383836088883475e0f6a4",
    "scope": "repo"
  },
  {
    "bytes": 263,
    "repoRelPath": "CAPABILITY/CAS/storage/2/ed/2ed02eb36a8ce195a7492daf425ff03f5f19ffb639e2d3e524df3aad497fa916",
    "scope": "repo"
  },
  {
    "bytes": 117724,
    "repoRelPath": "CAPABILITY/CAS/storage/2/ef/2efa6b771d35b4e7642e021ef905284fb13957fee15c032adce07010485f6848",
    "scope": "repo"
  },
  {
    "bytes": 302,
    "repoRelPath": "CAPABILITY/CAS/storage/2/f0/2f080ed7a0f48fbe6cfed536ae46fe5470b8b6a9f903b5a5d59f96b00198a220",
    "scope": "repo"
  },
  {
    "bytes": 36758,
    "repoRelPath": "CAPABILITY/CAS/storage/2/f1/2f136c92b888f9f4dd483ee7939ecd0c8d90de4da9a8757b250b6ee9d3d56157",
    "scope": "repo"
  },
  {
    "bytes": 21571,
    "repoRelPath": "CAPABILITY/CAS/storage/2/f1/2f15a2270649e1076efa5553eaba428540c5dd76ad36f7461e7f0e2bd8630eb9",
    "scope": "repo"
  },
  {
    "bytes": 135,
    "repoRelPath": "CAPABILITY/CAS/storage/2/f1/2f1fd17017ba5d19b884d529992901cbb2df784300e4af90506786831c22d139",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/2/f3/2f356780147980bc0adff73f4e1d5e9d4fb9576ba0360cbff981ee31fa09c9f2",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/2/f7/2f71b25879551f023e4c3f20d6a85e700a3c8372cd77607ea7eb59f2455df23b",
    "scope": "repo"
  },
  {
    "bytes": 17,
    "repoRelPath": "CAPABILITY/CAS/storage/2/fc/2fcbe025c1ac3f13a4d54330b477c39ca15200d9149328a0327b2df7e8a54c07",
    "scope": "repo"
  },
  {
    "bytes": 33156,
    "repoRelPath": "CAPABILITY/CAS/storage/2/fc/2fcc1e776943648c9f2c32da290df339ff069c215a5b4e0dac26db3b5d67d8a1",
    "scope": "repo"
  },
  {
    "bytes": 3116,
    "repoRelPath": "CAPABILITY/CAS/storage/2/fd/2fd0aeb9501016b2f00687d27e81947b2df85a9852268c1d72b14d674c3d9f2d",
    "scope": "repo"
  },
  {
    "bytes": 4217,
    "repoRelPath": "CAPABILITY/CAS/storage/2/fd/2fd88706d75f3d97adc5da75637f7b571269b82555665d76fcdf8129d76bdfda",
    "scope": "repo"
  },
  {
    "bytes": 805,
    "repoRelPath": "CAPABILITY/CAS/storage/3/03/303f22032204d752dd34d91cef7776eec6cbad3639efb67b3143e0bd57c94d0a",
    "scope": "repo"
  },
  {
    "bytes": 167,
    "repoRelPath": "CAPABILITY/CAS/storage/3/04/3048d06e746b7a6dc729d5936d4db00b7be06867bf96276e7df828b6f16b7a7e",
    "scope": "repo"
  },
  {
    "bytes": 30905,
    "repoRelPath": "CAPABILITY/CAS/storage/3/08/308148299e07342cadee9ba10dbeafa78b899bf4b7600278ec8877ede3704e85",
    "scope": "repo"
  },
  {
    "bytes": 5539,
    "repoRelPath": "CAPABILITY/CAS/storage/3/0a/30ad2da0ec071800cf1cd40f01b9f1528978c4942ba857b4ce0a6bf8bfbf219f",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/3/0d/30d20e34b32510796c4206404b2096288f6177bcb46856402eb62ed31c36e5d3",
    "scope": "repo"
  },
  {
    "bytes": 1797,
    "repoRelPath": "CAPABILITY/CAS/storage/3/18/318b72afcbe0331500e28291f7d0023d3bad4918392c8780dad189cce8a4fee7",
    "scope": "repo"
  },
  {
    "bytes": 2275,
    "repoRelPath": "CAPABILITY/CAS/storage/3/19/319252599b9cfb91ec6df7ba2008213b1406b81af157c3fcf40d7a2ad7da1310",
    "scope": "repo"
  },
  {
    "bytes": 2014,
    "repoRelPath": "CAPABILITY/CAS/storage/3/1b/31b087134049ea7d8aeb5cd3ae4732b8a41549b521ce539d4744824247ca4c3a",
    "scope": "repo"
  },
  {
    "bytes": 2964,
    "repoRelPath": "CAPABILITY/CAS/storage/3/22/322de6dce499a05c1b3b39962b42cab1dcc3324b08560b445435c2092ec7c844",
    "scope": "repo"
  },
  {
    "bytes": 1358,
    "repoRelPath": "CAPABILITY/CAS/storage/3/23/323798b3257e0631c53ed962ce08f8e3cccf5106fdbc2beed74a514c78d845ab",
    "scope": "repo"
  },
  {
    "bytes": 10295,
    "repoRelPath": "CAPABILITY/CAS/storage/3/24/3245fe4b5a7edce5924809fb277451abf5ab52563596c46bb4f466151e9a5bc5",
    "scope": "repo"
  },
  {
    "bytes": 1294,
    "repoRelPath": "CAPABILITY/CAS/storage/3/29/3299fbabb6b7ce12b73ea5f5f7c1a8216441294ec3d09a9aeae62a5626926d32",
    "scope": "repo"
  },
  {
    "bytes": 839,
    "repoRelPath": "CAPABILITY/CAS/storage/3/2a/32af56c078e693550ce03e75a55c649e2b56bf43980485e98610de8e0dc449f2",
    "scope": "repo"
  },
  {
    "bytes": 3220,
    "repoRelPath": "CAPABILITY/CAS/storage/3/2e/32ec660596646deb12f8b90b0c39a0eeb490f66cdc0b5048610d9b15b507fa36",
    "scope": "repo"
  },
  {
    "bytes": 11,
    "repoRelPath": "CAPABILITY/CAS/storage/3/30/3303b964cf5b6e436ca01f683760e0a17b2d44926c25c91f513a579a92c1187d",
    "scope": "repo"
  },
  {
    "bytes": 11467,
    "repoRelPath": "CAPABILITY/CAS/storage/3/31/331aaf5445af9ab09894f226b79c862249a12c83e65a7fc4335868bf8057fb2c",
    "scope": "repo"
  },
  {
    "bytes": 410,
    "repoRelPath": "CAPABILITY/CAS/storage/3/31/331cedc951ce666e7b4a98a3f91cd0bd818e5795cc436e2b568317dc321784ac",
    "scope": "repo"
  },
  {
    "bytes": 7039,
    "repoRelPath": "CAPABILITY/CAS/storage/3/37/3378a80c350e5f268e804c168dea1a134a47c3e9240fe47ffc186e04a4aa295f",
    "scope": "repo"
  },
  {
    "bytes": 7328,
    "repoRelPath": "CAPABILITY/CAS/storage/3/3a/33a48a01e413d74fd62a9a4192bd4c8e0dce189436922909cd24f3d841aaaa15",
    "scope": "repo"
  },
  {
    "bytes": 3592,
    "repoRelPath": "CAPABILITY/CAS/storage/3/3b/33b1190532889d10b3177ffb53a154b1d6a51d79e52fb5b94a4378eeb32e8c98",
    "scope": "repo"
  },
  {
    "bytes": 9851,
    "repoRelPath": "CAPABILITY/CAS/storage/3/3b/33bc6101af3404192f318e8a8078878346ca0611fd9e489261a651d486a69522",
    "scope": "repo"
  },
  {
    "bytes": 17,
    "repoRelPath": "CAPABILITY/CAS/storage/3/43/343f926cba12e625d430abdd2196e8888d2df781d4824f08556ea2adf2706fc9",
    "scope": "repo"
  },
  {
    "bytes": 16,
    "repoRelPath": "CAPABILITY/CAS/storage/3/44/3443c2beb8f548c062fb623d6c820958da40504c7719d7fd6582fdaaf0bb9dbf",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/3/44/34499ee4e7d56bfee01c4818d926a7b70ade5dd82117839d5b6745e4bc36249f",
    "scope": "repo"
  },
  {
    "bytes": 6680,
    "repoRelPath": "CAPABILITY/CAS/storage/3/46/34672cb7b2c74317ce16e5140ab3c0ca1f41921a386c779464556416cbffb960",
    "scope": "repo"
  },
  {
    "bytes": 7906,
    "repoRelPath": "CAPABILITY/CAS/storage/3/48/3481734a0e8355373702c8bf332c9f674a115f9b9f36282ceb106388efaa0314",
    "scope": "repo"
  },
  {
    "bytes": 1048576,
    "repoRelPath": "CAPABILITY/CAS/storage/3/4b/34bc6ad8178071438d388d4680bc6c236abeb0c88be1cee99a16f921d7d84999",
    "scope": "repo"
  },
  {
    "bytes": 666,
    "repoRelPath": "CAPABILITY/CAS/storage/3/4d/34d1cf1d62e0731f5a3747b8a90473295b2ae9c478f9835e5a0108c737991112",
    "scope": "repo"
  },
  {
    "bytes": 47,
    "repoRelPath": "CAPABILITY/CAS/storage/3/52/3528716e366bd7b4828e0f5ed753060ba6e2313866665f4bc0d4720d540831fe",
    "scope": "repo"
  },
  {
    "bytes": 4414,
    "repoRelPath": "CAPABILITY/CAS/storage/3/55/355aaf41ac809a55c35d3e63f2ac4639f7aa216bdd6bb2183d4958f1e395a9f0",
    "scope": "repo"
  },
  {
    "bytes": 3541,
    "repoRelPath": "CAPABILITY/CAS/storage/3/5d/35d1440dcfc9e045af84938e33e2c642d710c1b878ae1f9ee4e9e7ab79905d78",
    "scope": "repo"
  },
  {
    "bytes": 325,
    "repoRelPath": "CAPABILITY/CAS/storage/3/61/36131379ffbf85204962b880db1c05cf56fe197c4af70a5f22316ec98406dfaa",
    "scope": "repo"
  },
  {
    "bytes": 109351,
    "repoRelPath": "CAPABILITY/CAS/storage/3/64/364764cead12ed6afdfa90075d03e8e809685e5f63b0f467b0162ebe218d4ef7",
    "scope": "repo"
  },
  {
    "bytes": 411,
    "repoRelPath": "CAPABILITY/CAS/storage/3/76/37610678bd29e017d85fc62da14b7925476457334009a21b1741473d52d395d4",
    "scope": "repo"
  },
  {
    "bytes": 1361,
    "repoRelPath": "CAPABILITY/CAS/storage/3/78/3781b49297641553e63f81e59e04b0447f1d18cd201576795dea557f5c9f1142",
    "scope": "repo"
  },
  {
    "bytes": 1108,
    "repoRelPath": "CAPABILITY/CAS/storage/3/78/3788e471f507717e93561b726a44cfe39452d6a82b437b9ed483720b5c1438da",
    "scope": "repo"
  },
  {
    "bytes": 3962,
    "repoRelPath": "CAPABILITY/CAS/storage/3/81/381b9935d62347d5ae8137bda9484b61b587514875f8c504900a1e6adb408454",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/3/87/3870adb9ba83ac63d5739000b86284edddb2d133a9b1431260edd9077adc8a10",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/3/87/387a88f071124cd5a23dc167903bb22c8d8d59a9cf0cf96d8e10239b825e5b7e",
    "scope": "repo"
  },
  {
    "bytes": 25,
    "repoRelPath": "CAPABILITY/CAS/storage/3/88/388e152ac931fcdf635d0ed094a421401d956295019ec5ae32bb5f91b513e81b",
    "scope": "repo"
  },
  {
    "bytes": 1272604,
    "repoRelPath": "CAPABILITY/CAS/storage/3/8f/38f2d9de433808b73f1ca505a011fdc2adcc66db0e25398a7912910fc7e9f2bb",
    "scope": "repo"
  },
  {
    "bytes": 549,
    "repoRelPath": "CAPABILITY/CAS/storage/3/90/3906edadbee7166ba3876e90c7189b9964d1d0f7db494f843147d13295a29a9e",
    "scope": "repo"
  },
  {
    "bytes": 458,
    "repoRelPath": "CAPABILITY/CAS/storage/3/92/392ed7fec98cf6b9ac83a1158e47f45b54c7fb5ea4e71ba744c03186a4301481",
    "scope": "repo"
  },
  {
    "bytes": 1477,
    "repoRelPath": "CAPABILITY/CAS/storage/3/97/3972f5d42aa178c880c3f415b9c0bf003a5c8e5041d9b81f1736ad43038fa7e8",
    "scope": "repo"
  },
  {
    "bytes": 2351,
    "repoRelPath": "CAPABILITY/CAS/storage/3/99/399a649197c2ca2674f2fcdd9191e684ab11fa4c5f317bbf60bacc96adbb7c40",
    "scope": "repo"
  },
  {
    "bytes": 1317,
    "repoRelPath": "CAPABILITY/CAS/storage/3/9a/39ad6e0a11f0c96409e8295614a934c91c8ef6b1555146d9d6c4d9b4ba2d5d6f",
    "scope": "repo"
  },
  {
    "bytes": 8078,
    "repoRelPath": "CAPABILITY/CAS/storage/3/a1/3a145cefdbf6a7914abfc91e1bb1600e49a02e27893639bc9531d2650009360c",
    "scope": "repo"
  },
  {
    "bytes": 2490,
    "repoRelPath": "CAPABILITY/CAS/storage/3/a1/3a1e3363c806af3a3971867e5df21577e5c0a130cd019f4ff1f873e90ca146c1",
    "scope": "repo"
  },
  {
    "bytes": 439,
    "repoRelPath": "CAPABILITY/CAS/storage/3/a4/3a4799710aa7b5637ddfd03eacc72ecff3ba57f40cee7820846762bf08e6131e",
    "scope": "repo"
  },
  {
    "bytes": 4003,
    "repoRelPath": "CAPABILITY/CAS/storage/3/a6/3a6588ea46ca10b5a2882819808c43a2f7a745da75550588481a066f204712da",
    "scope": "repo"
  },
  {
    "bytes": 1500,
    "repoRelPath": "CAPABILITY/CAS/storage/3/af/3af0d7d320baf7110f7db5d87c7bad180116f2a971ab9b25c2a0331350d48e10",
    "scope": "repo"
  },
  {
    "bytes": 4757,
    "repoRelPath": "CAPABILITY/CAS/storage/3/af/3af7c91c256ee6c25b11ada9015c2e1e06902ffacbf127091857b7a199d229da",
    "scope": "repo"
  },
  {
    "bytes": 6096,
    "repoRelPath": "CAPABILITY/CAS/storage/3/b1/3b141f0f7b2a2914b3053e4c7028a0585f9f7e8e52cf4763b60102ec69f02435",
    "scope": "repo"
  },
  {
    "bytes": 7257,
    "repoRelPath": "CAPABILITY/CAS/storage/3/b1/3b17f35eccb370b69fec1df88f7a36d5fd3fdc7d0803b9e3ef9e185790add8c8",
    "scope": "repo"
  },
  {
    "bytes": 5444,
    "repoRelPath": "CAPABILITY/CAS/storage/3/bc/3bc5a9f962f008c5b5c7a57e3ab48ca50f960d5f50fa34810406b085a197f81f",
    "scope": "repo"
  },
  {
    "bytes": 1157,
    "repoRelPath": "CAPABILITY/CAS/storage/3/bd/3bd5f97bffd3fe32c2543556a46caf4138236b75d116eb030bfafa535ca891c7",
    "scope": "repo"
  },
  {
    "bytes": 2520,
    "repoRelPath": "CAPABILITY/CAS/storage/3/bf/3bf2a00ec793946add5911ed02e3dc279efc6d72e58f9be4821cdcc4defba5eb",
    "scope": "repo"
  },
  {
    "bytes": 8032,
    "repoRelPath": "CAPABILITY/CAS/storage/3/cf/3cf50d875828fcd54c5767232b1506f34b84055fcc810249b79d5e77eb71aa20",
    "scope": "repo"
  },
  {
    "bytes": 4460,
    "repoRelPath": "CAPABILITY/CAS/storage/3/d0/3d0c831936bbbaf6719234c2bf82f3e5ab0234efb17826b8073a24f0e6d23908",
    "scope": "repo"
  },
  {
    "bytes": 780,
    "repoRelPath": "CAPABILITY/CAS/storage/3/d2/3d2f3fa7360791548df98ad4bd9bc59925a0e7ccc53b00592779014d4c0c5dbb",
    "scope": "repo"
  },
  {
    "bytes": 3978,
    "repoRelPath": "CAPABILITY/CAS/storage/3/d6/3d68102255e8e3368f1605154afa68f7a9dc3d87230b76ac338075d76c8c895b",
    "scope": "repo"
  },
  {
    "bytes": 5531,
    "repoRelPath": "CAPABILITY/CAS/storage/3/d8/3d808494d4bfe79ec4d44c4098757e007fec9b82bf95e58dcbb2c295be69e408",
    "scope": "repo"
  },
  {
    "bytes": 5307,
    "repoRelPath": "CAPABILITY/CAS/storage/3/d9/3d9f8e198dfa1b690da264391b76882fbb8a9a7ad099a968e29c87fd9dffd52b",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/3/ec/3ecba386534fa7c2cf8a7dc943ef1ba648467cb3e7d7c02ac1c08a799575a547",
    "scope": "repo"
  },
  {
    "bytes": 1129,
    "repoRelPath": "CAPABILITY/CAS/storage/3/ee/3ee7d3960f1f766fe49344f664ec9b3f2d91ee9fbb4a1cb69f5e2e730bfb1de3",
    "scope": "repo"
  },
  {
    "bytes": 682,
    "repoRelPath": "CAPABILITY/CAS/storage/3/ef/3ef3449084701e0ad1b672da2d2fd28ec1693099d84de42c2458089a403167ef",
    "scope": "repo"
  },
  {
    "bytes": 43082,
    "repoRelPath": "CAPABILITY/CAS/storage/3/f0/3f0575856129519dc72ffa3d9e1d48f61fd88c459b677b8131250c964f484b08",
    "scope": "repo"
  },
  {
    "bytes": 134064,
    "repoRelPath": "CAPABILITY/CAS/storage/3/f7/3f7cf08c2f355ef63b0ce4ef2fb6498f2b0be47e790427221b27b725c00da7ab",
    "scope": "repo"
  },
  {
    "bytes": 310,
    "repoRelPath": "CAPABILITY/CAS/storage/3/fb/3fb3b01e949838f1c4a9e7084ad87f6d0008ed54de58385e4b56fb14baac9c94",
    "scope": "repo"
  },
  {
    "bytes": 8,
    "repoRelPath": "CAPABILITY/CAS/storage/4/00/400a936d0ac7637324413df9aaf2067ff68468e602a5446af1e454878b5bad1e",
    "scope": "repo"
  },
  {
    "bytes": 5538,
    "repoRelPath": "CAPABILITY/CAS/storage/4/01/401165536b2b69607783c7de794204d39939d9450017bb124e2eec927152e192",
    "scope": "repo"
  },
  {
    "bytes": 61,
    "repoRelPath": "CAPABILITY/CAS/storage/4/01/401b288014ba36d02960f9d8eb1a7ca4c8aa508ab4e9cd15cebc426a67b370f7",
    "scope": "repo"
  },
  {
    "bytes": 2276,
    "repoRelPath": "CAPABILITY/CAS/storage/4/01/401df585fca8cab1d0d06241a1fea550d1253d4d855b2179aea13a02a12614ae",
    "scope": "repo"
  },
  {
    "bytes": 256,
    "repoRelPath": "CAPABILITY/CAS/storage/4/0a/40aff2e9d2d8922e47afd4648e6967497158785fbd1da870e7110266bf944880",
    "scope": "repo"
  },
  {
    "bytes": 8313,
    "repoRelPath": "CAPABILITY/CAS/storage/4/0c/40cfe7d1ded4175bf05a57c76900a96907b4984b3d56be34e002af3e6e30a4a8",
    "scope": "repo"
  },
  {
    "bytes": 117725,
    "repoRelPath": "CAPABILITY/CAS/storage/4/12/412bc2cdd3cc1579997308b6cbada74ea753705c59bbaeb43b1e5ae79fe74eb8",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/4/1a/41a9e8619fb7e359083ff75ba190f5a46a1d5a3c82de5db9a82e20d04dfdf58d",
    "scope": "repo"
  },
  {
    "bytes": 1414,
    "repoRelPath": "CAPABILITY/CAS/storage/4/1d/41da286d4018ae72151ed319c6db3dc159ce27c9202253daeaaea458f6acac8c",
    "scope": "repo"
  },
  {
    "bytes": 323,
    "repoRelPath": "CAPABILITY/CAS/storage/4/2c/42c47aace52f9aaebe44a2332bf254b150bc58acc751f45c5130ca3c0a886706",
    "scope": "repo"
  },
  {
    "bytes": 27255,
    "repoRelPath": "CAPABILITY/CAS/storage/4/32/432e1593d6de7c861451e72cc39c425b707f19de0ae27d4d4952b4333e84d87a",
    "scope": "repo"
  },
  {
    "bytes": 672,
    "repoRelPath": "CAPABILITY/CAS/storage/4/36/436d850e0de0893ccb5445c098a53d8b6edc9c24a721adc9be82e2f7d393dd36",
    "scope": "repo"
  },
  {
    "bytes": 1179,
    "repoRelPath": "CAPABILITY/CAS/storage/4/36/436ea326e0728aca5a015527faaf420106f8dc23c3480ed25ab6fdb747d9eb4f",
    "scope": "repo"
  },
  {
    "bytes": 716,
    "repoRelPath": "CAPABILITY/CAS/storage/4/3b/43baf49f37baeb300de46c52ed335b1bf058615fb9cc450086e988a88e7b54a7",
    "scope": "repo"
  },
  {
    "bytes": 2,
    "repoRelPath": "CAPABILITY/CAS/storage/4/41/44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a",
    "scope": "repo"
  },
  {
    "bytes": 19842,
    "repoRelPath": "CAPABILITY/CAS/storage/4/43/443d6e8fa64a5c1d5f48892a1dfd8b8b2e4056efe9f15812b9802dbceb7f80a1",
    "scope": "repo"
  },
  {
    "bytes": 1740,
    "repoRelPath": "CAPABILITY/CAS/storage/4/47/447e594e4bf28a02bca3a42fdc92e346226cfa1d4fcc7e695958004b44e4adb5",
    "scope": "repo"
  },
  {
    "bytes": 109,
    "repoRelPath": "CAPABILITY/CAS/storage/4/49/4496639735d6316a12246617b4ff787e6e3046ee4c6768b7c2cae36f9fdbdb76",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/4/49/4499d123bf283de3d24601bbec7e9104fd953b22ed7ad843264c64b8a4f67527",
    "scope": "repo"
  },
  {
    "bytes": 33,
    "repoRelPath": "CAPABILITY/CAS/storage/4/4a/44ae1b1ba095c202e880f3a8a3194460ab7a398ab46231164b7fbfdaba4a4185",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/4/4e/44e4d765efe03e3855a4666843d287d14a060b8f3da3ad12d94780c95e9efb27",
    "scope": "repo"
  },
  {
    "bytes": 42881,
    "repoRelPath": "CAPABILITY/CAS/storage/4/4e/44e63223d5973b425d75833eb9661b634971e46683e0ac58e661b81dc345fbc3",
    "scope": "repo"
  },
  {
    "bytes": 25,
    "repoRelPath": "CAPABILITY/CAS/storage/4/50/4500c1fd188f313a849b431f8e66c6ea54cf1357231d5fb5a3ca3d21e0561191",
    "scope": "repo"
  },
  {
    "bytes": 4748,
    "repoRelPath": "CAPABILITY/CAS/storage/4/53/453eca920462f4e54c81bb48caa46ed0836325e740d3dc59c4104acfda06d501",
    "scope": "repo"
  },
  {
    "bytes": 868,
    "repoRelPath": "CAPABILITY/CAS/storage/4/55/45513ff716d59ebf1d6e48450c855cec612d4c3ae01584149ab56d18194d1292",
    "scope": "repo"
  },
  {
    "bytes": 358,
    "repoRelPath": "CAPABILITY/CAS/storage/4/59/459a64feb87b73cc8a8a56c531cbef6f3dfc0a4fa92379d1361789a4cbe00ac6",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/4/66/46681a2821f73ed21834bd7899bd561bb9cef46f0fe14c83bea795e956ec090d",
    "scope": "repo"
  },
  {
    "bytes": 1026,
    "repoRelPath": "CAPABILITY/CAS/storage/4/66/466b509e7f381e8bd05421e9c563967aa83cd1b665c0d14fea68d4998cd44ed1",
    "scope": "repo"
  },
  {
    "bytes": 8227,
    "repoRelPath": "CAPABILITY/CAS/storage/4/69/4693a0ba8a42705fcf802282f31eb2e7a24ee312980675d53924f1c4a0ead8a0",
    "scope": "repo"
  },
  {
    "bytes": 87,
    "repoRelPath": "CAPABILITY/CAS/storage/4/6c/46ca3ae3010168e0482625e1deef9600499405228a526823325e5a35d33f7640",
    "scope": "repo"
  },
  {
    "bytes": 37,
    "repoRelPath": "CAPABILITY/CAS/storage/4/6c/46ca96e4d51ab2614a0aff456d6bdabb7d46eac3ce81e5b7b2330ac63df5fed9",
    "scope": "repo"
  },
  {
    "bytes": 1326,
    "repoRelPath": "CAPABILITY/CAS/storage/4/6d/46d841186ad6098d6b09f33351408b204ed17d11a90f287cf25ba8b4075153be",
    "scope": "repo"
  },
  {
    "bytes": 13086,
    "repoRelPath": "CAPABILITY/CAS/storage/4/6e/46e241c65c973a803efb9a30c78d2a275959380a433b172c9f4d2198350acb18",
    "scope": "repo"
  },
  {
    "bytes": 2184,
    "repoRelPath": "CAPABILITY/CAS/storage/4/6f/46ff2d156f678b731d460aa7e60465b3ea19ac787da267d6292d6bdb8ce9abad",
    "scope": "repo"
  },
  {
    "bytes": 16,
    "repoRelPath": "CAPABILITY/CAS/storage/4/6f/46ffcfa0312379dbf5374a7bd1f0528cf2cd690893999aaf3c059053934c2dd8",
    "scope": "repo"
  },
  {
    "bytes": 2133,
    "repoRelPath": "CAPABILITY/CAS/storage/4/70/470e04ac4ccc7f6d0ca4589b5a881d2ef0007071a090f920eeff9e217eff5e47",
    "scope": "repo"
  },
  {
    "bytes": 7012,
    "repoRelPath": "CAPABILITY/CAS/storage/4/76/47611271380bcf0608afc483aea90c82d5836bb231ab2f4e18e923ac185fe100",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/4/76/4763c8c09331eb1f2ae65f6be579cffe99ea4ae74c2b8c7bf76776c51cbd5a77",
    "scope": "repo"
  },
  {
    "bytes": 597,
    "repoRelPath": "CAPABILITY/CAS/storage/4/79/479f2d0188b38495d8938bd1276bb5bccb92fe6c9476fb36fdc46aeae1710a1f",
    "scope": "repo"
  },
  {
    "bytes": 778,
    "repoRelPath": "CAPABILITY/CAS/storage/4/7b/47b0f1307ad967a7be5e7765cffb37e2a34ad364fed11dad4b7c328a3e2f631b",
    "scope": "repo"
  },
  {
    "bytes": 6896,
    "repoRelPath": "CAPABILITY/CAS/storage/4/7d/47d954b0f9868569759df910a778c9b8469f335d350787adc3462d36722bbac1",
    "scope": "repo"
  },
  {
    "bytes": 131,
    "repoRelPath": "CAPABILITY/CAS/storage/4/7e/47ea99c115890ab7af0e08c79c4a8e522bfa6ac93360116c0c335e35ee1e584b",
    "scope": "repo"
  },
  {
    "bytes": 70,
    "repoRelPath": "CAPABILITY/CAS/storage/4/7f/47f350149f8b4cb6c08f9e5639a2c0e1809b319d1388f6cb4efde17648705a1b",
    "scope": "repo"
  },
  {
    "bytes": 4628,
    "repoRelPath": "CAPABILITY/CAS/storage/4/82/482fde26ebbe9989489772c66a54e855a4124d79bb6ef22c238bab62356b7daf",
    "scope": "repo"
  },
  {
    "bytes": 917,
    "repoRelPath": "CAPABILITY/CAS/storage/4/86/486a38a91351d0220271e3d5c19d38e103ba513af447541f9eb261ac5032b1f2",
    "scope": "repo"
  },
  {
    "bytes": 492,
    "repoRelPath": "CAPABILITY/CAS/storage/4/87/48737002888a48493400fe67daaa813b97724af1369881e00c51d7486f030fa3",
    "scope": "repo"
  },
  {
    "bytes": 764,
    "repoRelPath": "CAPABILITY/CAS/storage/4/88/4889b1f7e7234b23729a52eca937d5a45d01c94bfd3ae38e7426c03bc67d8fd0",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/4/89/489e33686efe49719b0903447a0f08c9f47c1454391ed525d81cd3b5e4071481",
    "scope": "repo"
  },
  {
    "bytes": 1722,
    "repoRelPath": "CAPABILITY/CAS/storage/4/8c/48ca96402c66d54025a6e325b185b180eb9dc86fbbf67fc62d6ebee9f9558a6a",
    "scope": "repo"
  },
  {
    "bytes": 2724,
    "repoRelPath": "CAPABILITY/CAS/storage/4/8d/48d596622b6a5cde8570c5db4f83e398889d5e68b3418a959e2ba4119309e0a1",
    "scope": "repo"
  },
  {
    "bytes": 7148,
    "repoRelPath": "CAPABILITY/CAS/storage/4/8d/48dfb245145bd9f59d7a494b71ad9dc7079be58760885dcc2b2fd5c5ef1b50fd",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/4/91/4915b80b455eae10fbc48656b7d20736c3b76a1f466ca3acd5879af8f89778ad",
    "scope": "repo"
  },
  {
    "bytes": 16291,
    "repoRelPath": "CAPABILITY/CAS/storage/4/91/491c2416cb279e7acf0d378a01d74fa5e9d6207de6890eef368bdf9ca510c17a",
    "scope": "repo"
  },
  {
    "bytes": 2068,
    "repoRelPath": "CAPABILITY/CAS/storage/4/92/4926e444951af963e2f101213e30c44642b3fa64bc0ba900215977bd9f6ab422",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/4/92/492bc90829b32241fbc77c96f0b65511d915033c9f24444d22bae1c602d7efe2",
    "scope": "repo"
  },
  {
    "bytes": 7535,
    "repoRelPath": "CAPABILITY/CAS/storage/4/97/49705398ea4f4394e9d379168300c57316443834aceefb393fc82bb90da3f099",
    "scope": "repo"
  },
  {
    "bytes": 1635,
    "repoRelPath": "CAPABILITY/CAS/storage/4/98/498ee6ef0a9bd90a3ba937e21cacd7e1028657d80436c72cb09eafd350b87704",
    "scope": "repo"
  },
  {
    "bytes": 626,
    "repoRelPath": "CAPABILITY/CAS/storage/4/99/499ad03608376d33a1cf6508efeff34740b31163ce0592bd8bfee3778ece4364",
    "scope": "repo"
  },
  {
    "bytes": 1726,
    "repoRelPath": "CAPABILITY/CAS/storage/4/9a/49aa46af5b77a61ca7796070348a5e7b0fc3e1048b541219357eaeb443e1603d",
    "scope": "repo"
  },
  {
    "bytes": 5831,
    "repoRelPath": "CAPABILITY/CAS/storage/4/9f/49f6a9fb469e25bde4e4a882c8b6a258f1fa5e44a97e7ea0f25c6335f368fdce",
    "scope": "repo"
  },
  {
    "bytes": 747,
    "repoRelPath": "CAPABILITY/CAS/storage/4/a0/4a0357c3f6c8462933ef63b7cab5508b406434e4346e5103d3e66339a59859c1",
    "scope": "repo"
  },
  {
    "bytes": 2093,
    "repoRelPath": "CAPABILITY/CAS/storage/4/a1/4a1664457a5616567615d76283aefd199d06319c8dfb3e75dc791c5b69982640",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/4/a2/4a2ce97cefca05cc5f47cde3ee54c6961c7b2677814a17f15d928b312e871ddd",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/4/a6/4a6e2c0904cf9bf9808d2d4647074568936d203b2e086111e5d98ccb31180807",
    "scope": "repo"
  },
  {
    "bytes": 1150,
    "repoRelPath": "CAPABILITY/CAS/storage/4/a7/4a73e7fcb6cf2f993603f353cbf4a0439a8f97f8895e20e92263b09df3e9204a",
    "scope": "repo"
  },
  {
    "bytes": 36387,
    "repoRelPath": "CAPABILITY/CAS/storage/4/b2/4b244ce63ffb60e17aad2c03f71259d20456bafe585d72fd796446791e390d3e",
    "scope": "repo"
  },
  {
    "bytes": 10241,
    "repoRelPath": "CAPABILITY/CAS/storage/4/b4/4b4294df879ecfe5e437277f3c0f023d9ec2ed7be14d43eeab9dd2072637c4cd",
    "scope": "repo"
  },
  {
    "bytes": 792,
    "repoRelPath": "CAPABILITY/CAS/storage/4/b6/4b66faa33658fb4a412828a75d55f6840e04afa54726bd71ccfe301329d5fed6",
    "scope": "repo"
  },
  {
    "bytes": 7419,
    "repoRelPath": "CAPABILITY/CAS/storage/4/b7/4b731f5cf636e2d1b6df0c72da9605e0ed2cb789cb52a5dcdebf7ad3dc649834",
    "scope": "repo"
  },
  {
    "bytes": 1272781,
    "repoRelPath": "CAPABILITY/CAS/storage/4/bc/4bc634d11651c7a56f00540ee595e7070598629926cb7041d25c044d2803d2b8",
    "scope": "repo"
  },
  {
    "bytes": 1774,
    "repoRelPath": "CAPABILITY/CAS/storage/4/bd/4bde4b54332a5838f6498c32f0e6e860e21713290e583ef71fd1bfdaa087dd73",
    "scope": "repo"
  },
  {
    "bytes": 3533,
    "repoRelPath": "CAPABILITY/CAS/storage/4/be/4be1ff6af1498832f91ddb096533ae06dfcff53bb2569e9a965e0779388fc6c9",
    "scope": "repo"
  },
  {
    "bytes": 374,
    "repoRelPath": "CAPABILITY/CAS/storage/4/c0/4c02e676d4380062f04b078feca4a9f3d36735bb1c1ed971fc29c75de0d670ef",
    "scope": "repo"
  },
  {
    "bytes": 3989,
    "repoRelPath": "CAPABILITY/CAS/storage/4/c6/4c62d8313733388842c1b29d6ce8635cde7e53b2a897aa38c0a511b075c3047d",
    "scope": "repo"
  },
  {
    "bytes": 115,
    "repoRelPath": "CAPABILITY/CAS/storage/4/ca/4cabfa260fc6e4fae8450c803792cff2af05dce98b6735febc4e44f71b937dfd",
    "scope": "repo"
  },
  {
    "bytes": 2135,
    "repoRelPath": "CAPABILITY/CAS/storage/4/cb/4cb01e8c36942304d2f52a67bf4245b2c7deee8cb7d7b69a0625587144c05541",
    "scope": "repo"
  },
  {
    "bytes": 14915,
    "repoRelPath": "CAPABILITY/CAS/storage/4/cc/4cc941a82d642f4c8cbd9377db3c500c3f09a51a83ac416d27dd55d2a6fba17a",
    "scope": "repo"
  },
  {
    "bytes": 10193,
    "repoRelPath": "CAPABILITY/CAS/storage/4/cc/4ccb46076b9048973771cf7639d4916d7146187d184812ad1db6722ec2e104d0",
    "scope": "repo"
  },
  {
    "bytes": 2088,
    "repoRelPath": "CAPABILITY/CAS/storage/4/cf/4cf835aabf52b8bf42dbf7a890af9977a8d99cdfa3b6d1a26c0f356460184d55",
    "scope": "repo"
  },
  {
    "bytes": 183,
    "repoRelPath": "CAPABILITY/CAS/storage/4/d1/4d1335ce05ef98ab81ebefdbd72063313797e1b871f2bfd78f7d7f220f9e9755",
    "scope": "repo"
  },
  {
    "bytes": 7292,
    "repoRelPath": "CAPABILITY/CAS/storage/4/d2/4d2df70a2e3d1520a740993eb56d8c265871f32e746788e77d4863600de740e2",
    "scope": "repo"
  },
  {
    "bytes": 2446,
    "repoRelPath": "CAPABILITY/CAS/storage/4/d5/4d56cd430d813b7e8676fc3cebb105ad8c2ec46344b4ae88396ac1927f088f71",
    "scope": "repo"
  },
  {
    "bytes": 11473,
    "repoRelPath": "CAPABILITY/CAS/storage/4/d8/4d89676b10022dc31e11301821d2be0a45a55405f9ac1043d80b7d7a44327dd8",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/4/d8/4d8dffcc7872adfff63e2b34fd8832529c10c2e3ae83d9056b404971cd162189",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/4/e3/4e30d9e2880cd287eabb7745f4e1b11f5fa1b825326e399a63b578535b45bd3d",
    "scope": "repo"
  },
  {
    "bytes": 6344,
    "repoRelPath": "CAPABILITY/CAS/storage/4/ea/4ea8c2c3b42e047e6d7435f82dc8e8d6175a571b44ac02d7d2dba78ba4b8e0c4",
    "scope": "repo"
  },
  {
    "bytes": 2445,
    "repoRelPath": "CAPABILITY/CAS/storage/4/eb/4eb58a8c6bc69715de7236a24d36a55bd1ddcd487aa3ea95531ba2e075a29b34",
    "scope": "repo"
  },
  {
    "bytes": 34076,
    "repoRelPath": "CAPABILITY/CAS/storage/4/ed/4ed49da3870d953991a929f7af076e20423972b137228ff1f77e232f52e6c187",
    "scope": "repo"
  },
  {
    "bytes": 54000,
    "repoRelPath": "CAPABILITY/CAS/storage/4/ef/4ef8689a2066303428c99c3ea6816bc6ac924ef6f0635c18313c2bebdf354938",
    "scope": "repo"
  },
  {
    "bytes": 7766,
    "repoRelPath": "CAPABILITY/CAS/storage/4/f4/4f4e237bcd3ef4a013cfcd68aa6137c3325b37a9ff363fcc69be0bc008c1d18f",
    "scope": "repo"
  },
  {
    "bytes": 2,
    "repoRelPath": "CAPABILITY/CAS/storage/4/f5/4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945",
    "scope": "repo"
  },
  {
    "bytes": 269,
    "repoRelPath": "CAPABILITY/CAS/storage/4/f7/4f7de844a39363d5a0c94250606833d841e33e05827e8475c2447f825002770e",
    "scope": "repo"
  },
  {
    "bytes": 6467,
    "repoRelPath": "CAPABILITY/CAS/storage/4/f7/4f7eb709ccfe02f76af6499da5deb64afaa8cbf3af37226ef55b9be5ff1f8613",
    "scope": "repo"
  },
  {
    "bytes": 3189,
    "repoRelPath": "CAPABILITY/CAS/storage/5/00/500ca1b86fc0ea7ad040ded0847750c15cf25bc367bfbbef2933def410e11128",
    "scope": "repo"
  },
  {
    "bytes": 5117,
    "repoRelPath": "CAPABILITY/CAS/storage/5/05/50598af55b453adb45b8b0d8433300d166d6ae7fc49ce99f77817ba5a1afab76",
    "scope": "repo"
  },
  {
    "bytes": 2120,
    "repoRelPath": "CAPABILITY/CAS/storage/5/05/505d66a832305e78ba8f2636999932033628ba852cded04ff3f0247df20bd989",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/5/0c/50c033e139156db6ecf99804136bd7fd16b0194f119a93cb46f841e8b328f0a9",
    "scope": "repo"
  },
  {
    "bytes": 83,
    "repoRelPath": "CAPABILITY/CAS/storage/5/0c/50c2ef3a525c13757bc76a5acfddf639a34766f6df07d0776822b760b75433e5",
    "scope": "repo"
  },
  {
    "bytes": 2692,
    "repoRelPath": "CAPABILITY/CAS/storage/5/11/511150f89d0d3ccc3921cd70c8b15789089d06050ab9ca6d321638404944c0fe",
    "scope": "repo"
  },
  {
    "bytes": 19,
    "repoRelPath": "CAPABILITY/CAS/storage/5/17/5178562765cdad251ba34f215c2988936f53facbd77866bd9e690117ddda0b08",
    "scope": "repo"
  },
  {
    "bytes": 313,
    "repoRelPath": "CAPABILITY/CAS/storage/5/1d/51d33010d4a5540753edae2188097eea5b2a4ed2fa5655676ed0998f6536746a",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/5/23/5235181c2511408b198d5e31c81d94e5291b5d43f01b2f9eb88d848e9b79a3cc",
    "scope": "repo"
  },
  {
    "bytes": 458,
    "repoRelPath": "CAPABILITY/CAS/storage/5/28/528af24eacae7f4828e45a4f7e485577e27a2b14f782c7f7ee2d5635445307a1",
    "scope": "repo"
  },
  {
    "bytes": 118773,
    "repoRelPath": "CAPABILITY/CAS/storage/5/2a/52aba381a528f4f60194c0352762f8e86ffe7760fc4c9ef4b47d2679ca1adcb3",
    "scope": "repo"
  },
  {
    "bytes": 6239,
    "repoRelPath": "CAPABILITY/CAS/storage/5/38/538ea47315df4b0ddc86cfe6b3bebb9b7c4afb5873d4ef2a23fb2c8ecdacd58c",
    "scope": "repo"
  },
  {
    "bytes": 17,
    "repoRelPath": "CAPABILITY/CAS/storage/5/39/539755a3d3100bc6565b75201f9ca5d7b70ca931690fed76bcd495143233464a",
    "scope": "repo"
  },
  {
    "bytes": 20,
    "repoRelPath": "CAPABILITY/CAS/storage/5/39/5397ff0f50a6508b4d8a507e1e811595e135c8e7c4f60258d1f1d22a6c8c7f55",
    "scope": "repo"
  },
  {
    "bytes": 2311,
    "repoRelPath": "CAPABILITY/CAS/storage/5/3d/53d14fc8cb61410807b0be4ffd4056b17d814372ad2c42ad5bd897d192e87855",
    "scope": "repo"
  },
  {
    "bytes": 7744,
    "repoRelPath": "CAPABILITY/CAS/storage/5/3d/53d17921d9c7cccaceecc12fbbde64817378b193d8ac3f452c38dda8a790c05d",
    "scope": "repo"
  },
  {
    "bytes": 55,
    "repoRelPath": "CAPABILITY/CAS/storage/5/3d/53d80aa14e7f0d128a7438190b68e8fd62cec92b5fea13585bb76c47bc35e5fc",
    "scope": "repo"
  },
  {
    "bytes": 4119,
    "repoRelPath": "CAPABILITY/CAS/storage/5/3e/53e14fab70bd3c9a2543d989837358c630ed24910dff90970cba0cbfb6e7811e",
    "scope": "repo"
  },
  {
    "bytes": 7147,
    "repoRelPath": "CAPABILITY/CAS/storage/5/3f/53fa6a61315a6136d7b7c637fdf4948f4715845663d7f456f5f6af2e39aa0b01",
    "scope": "repo"
  },
  {
    "bytes": 405,
    "repoRelPath": "CAPABILITY/CAS/storage/5/40/540bfece331ff544ef12e168c91e8b9204588c2c112975037d192c36636f907c",
    "scope": "repo"
  },
  {
    "bytes": 5371,
    "repoRelPath": "CAPABILITY/CAS/storage/5/42/542e14a380820a28d7890ef0ee6b8bc73b81d1be9e2bc24c01db64bf82ad9ad7",
    "scope": "repo"
  },
  {
    "bytes": 1139,
    "repoRelPath": "CAPABILITY/CAS/storage/5/4a/54a97d76752ee906a085e406eaef075e0436111ab35261bad740e46dfdc5f23e",
    "scope": "repo"
  },
  {
    "bytes": 67,
    "repoRelPath": "CAPABILITY/CAS/storage/5/55/55525b3a0724227b0f862a53f731c330fe910a6d7638fff618a307076022ac3b",
    "scope": "repo"
  },
  {
    "bytes": 23,
    "repoRelPath": "CAPABILITY/CAS/storage/5/56/556395bea9906613097ff6723ea69c8b8f866344aad8aa07c3c1b72b832300e7",
    "scope": "repo"
  },
  {
    "bytes": 59,
    "repoRelPath": "CAPABILITY/CAS/storage/5/57/557fe3e88e0eb421c2191ba67b00bcb938257b9988751ab16cc0f284070c5dc7",
    "scope": "repo"
  },
  {
    "bytes": 4691,
    "repoRelPath": "CAPABILITY/CAS/storage/5/59/559e18b66f1c39628af96535869c8c7783879a1e31adcd07c8cbabaae70a6532",
    "scope": "repo"
  },
  {
    "bytes": 8497,
    "repoRelPath": "CAPABILITY/CAS/storage/5/5d/55d94a488ed1316a57617476e466644f77de11c7984ec6564760fc33202c1e07",
    "scope": "repo"
  },
  {
    "bytes": 217,
    "repoRelPath": "CAPABILITY/CAS/storage/5/5f/55f704c1cb8dcf24d354b55ccc8a7335891c1e76e7f9bf5423b4f4f679475e85",
    "scope": "repo"
  },
  {
    "bytes": 138,
    "repoRelPath": "CAPABILITY/CAS/storage/5/61/561d10f216c4301a91923c25502f8f173c80e323e2ac88d75bc2982dfe8dd40e",
    "scope": "repo"
  },
  {
    "bytes": 4371,
    "repoRelPath": "CAPABILITY/CAS/storage/5/66/5669b2e2974f2e7030cddd4469c78c13d75de8ce5c1b4e2853e9312bf37674da",
    "scope": "repo"
  },
  {
    "bytes": 17349,
    "repoRelPath": "CAPABILITY/CAS/storage/5/68/568604175669f8ded4cac5f1bdca2d9f01bbd79f01292267d5735f78f8359eb2",
    "scope": "repo"
  },
  {
    "bytes": 397,
    "repoRelPath": "CAPABILITY/CAS/storage/5/6e/56efa31075af3668076a22bcbfca5fc36b095ae69514f9cb1bd3a3efee988e1d",
    "scope": "repo"
  },
  {
    "bytes": 117725,
    "repoRelPath": "CAPABILITY/CAS/storage/5/78/578323b1b189078ef0bb690110c023e113646fde20a95005e2179d611b26d57c",
    "scope": "repo"
  },
  {
    "bytes": 30666,
    "repoRelPath": "CAPABILITY/CAS/storage/5/78/5789160ce850840eafe93f4a2d535fd4f317e50cd463da1144dcf2354b8ed0cd",
    "scope": "repo"
  },
  {
    "bytes": 28,
    "repoRelPath": "CAPABILITY/CAS/storage/5/7a/57ae64b6fcbb502c9c36f350780a672fbed363f533a2360230b49acaa9a36440",
    "scope": "repo"
  },
  {
    "bytes": 3057,
    "repoRelPath": "CAPABILITY/CAS/storage/5/7e/57e7116c8b7a5d40fe53b48f2b6c55169e1140b7f022a912a5ba8030db8f0682",
    "scope": "repo"
  },
  {
    "bytes": 6449,
    "repoRelPath": "CAPABILITY/CAS/storage/5/85/5854c504d03660f18d5e110db552676d8dbe412ff942e76fe028fb7b1e8d7802",
    "scope": "repo"
  },
  {
    "bytes": 4056,
    "repoRelPath": "CAPABILITY/CAS/storage/5/87/587f24ab1fe19900ee96c95ab799ab3aaa494ffce775cf39d06a324e5b496b06",
    "scope": "repo"
  },
  {
    "bytes": 11355,
    "repoRelPath": "CAPABILITY/CAS/storage/5/88/5882676091189064756c1e3df2e50a58e2127c7162039200e35636a7d21608f2",
    "scope": "repo"
  },
  {
    "bytes": 251,
    "repoRelPath": "CAPABILITY/CAS/storage/5/8e/58eb8716488520a33940bbbc2ea2a08827cb7fea6adc675569642792c1983542",
    "scope": "repo"
  },
  {
    "bytes": 3666,
    "repoRelPath": "CAPABILITY/CAS/storage/5/8f/58f5f08c2c7d666ddf7878cda90f5348af44eec356e5d32a12944924b86b788e",
    "scope": "repo"
  },
  {
    "bytes": 248,
    "repoRelPath": "CAPABILITY/CAS/storage/5/94/59488f6c84a5bb78209aaaf08fb2c71cd26b9c0e56b5ab638ff0a2e54b48f758",
    "scope": "repo"
  },
  {
    "bytes": 162,
    "repoRelPath": "CAPABILITY/CAS/storage/5/96/59637dc9a87e01e4adb05a5cd7990e6a97a3c564d3f140838733667310923089",
    "scope": "repo"
  },
  {
    "bytes": 53122,
    "repoRelPath": "CAPABILITY/CAS/storage/5/96/5968b29ba02fdbd88a1f4668ac15d1fd149ad6e8f67e3cf81f8ac149b11ae987",
    "scope": "repo"
  },
  {
    "bytes": 933,
    "repoRelPath": "CAPABILITY/CAS/storage/5/97/5971b6fa5dab5b801a4795d4c38be4a5d15ee07948ea82218ef65f946ebec56f",
    "scope": "repo"
  },
  {
    "bytes": 640,
    "repoRelPath": "CAPABILITY/CAS/storage/5/98/5989b96b224a73d8b85e91f4557254068fc2194dcc242e2566477cb54cc8903a",
    "scope": "repo"
  },
  {
    "bytes": 752,
    "repoRelPath": "CAPABILITY/CAS/storage/5/9b/59ba98b6555dec038ae3a9d5eae64bae2af8e07e1f61dcaddb23f58397a0ce1b",
    "scope": "repo"
  },
  {
    "bytes": 1395,
    "repoRelPath": "CAPABILITY/CAS/storage/5/9d/59d1a764b2d5612ab91704c5c3e900f6749683e9e9bf9595fd0e40492139cdb7",
    "scope": "repo"
  },
  {
    "bytes": 3678,
    "repoRelPath": "CAPABILITY/CAS/storage/5/9f/59f62d6b23842838e85afb90b819d149874dc3b83aa07c91f7032b53914cf71b",
    "scope": "repo"
  },
  {
    "bytes": 8895,
    "repoRelPath": "CAPABILITY/CAS/storage/5/a5/5a509a51d33c444d89447c18fad503c9f65ceab1afc5d627a3a07f3fa3119736",
    "scope": "repo"
  },
  {
    "bytes": 3400,
    "repoRelPath": "CAPABILITY/CAS/storage/5/ab/5ab4d9eb5d0c3bd21d0641c4f466c11ccc445ac391c1aa5748e2210dc3cecafb",
    "scope": "repo"
  },
  {
    "bytes": 10013,
    "repoRelPath": "CAPABILITY/CAS/storage/5/ac/5ac8770d047e687e93db6745a58b573aaf50c7ccc8e97340558f72c21b26fd4f",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/5/ad/5adb8c3d42601f14dc3c467830d23dcc75ffae17236d02c6bb26c6e31b1c3c8e",
    "scope": "repo"
  },
  {
    "bytes": 68942,
    "repoRelPath": "CAPABILITY/CAS/storage/5/af/5af0a0504c553b9e7ddac1bb46ecd1c178b9519721300338cef5811cde1143fa",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/5/b0/5b0e116e0647a4879dabbc2439dc519ac93a17778b1688276f03a014e0f5eed1",
    "scope": "repo"
  },
  {
    "bytes": 4405,
    "repoRelPath": "CAPABILITY/CAS/storage/5/b5/5b5e34ea332f613336153e5dcadbd4afd75b8c1d7c08bc6f9a51606775ee8ff5",
    "scope": "repo"
  },
  {
    "bytes": 1484003,
    "repoRelPath": "CAPABILITY/CAS/storage/5/b7/5b73dcfd05d73a27282b1841bfcde21e2626f8886fbde85984638b015b33e853",
    "scope": "repo"
  },
  {
    "bytes": 62646,
    "repoRelPath": "CAPABILITY/CAS/storage/5/ba/5ba31a92a4f62c0556337003a3cbfd00d3d5a6f42c6ef9b09e6e905d982fa581",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/5/bb/5bb8fa8c274ee3bfffe4bfb63a653e6d63dd716ee62a4372b7a68e6bde9ee53b",
    "scope": "repo"
  },
  {
    "bytes": 10842,
    "repoRelPath": "CAPABILITY/CAS/storage/5/bd/5bd63dfa7f7c51a0cc57f519468e3b40fe7451f6595a9d3543078088fd6aa900",
    "scope": "repo"
  },
  {
    "bytes": 35092,
    "repoRelPath": "CAPABILITY/CAS/storage/5/d5/5d543a8e1ece1264eee9efb996628351694942db0acf4422d137090d9f566c2c",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/5/d7/5d75c40aff5fd6975d8bcc8f7a62154ab666eb63e2ea83c438305c3ba511b59e",
    "scope": "repo"
  },
  {
    "bytes": 19766,
    "repoRelPath": "CAPABILITY/CAS/storage/5/dd/5dd88be673f5e1abe13c4bd5af0262d0e4cf1029d6e96ac12ed5f45f6df5a8cb",
    "scope": "repo"
  },
  {
    "bytes": 2323,
    "repoRelPath": "CAPABILITY/CAS/storage/5/df/5dfe371293ef1ca17c4912814bcdf3d65bb187e0670ffe5c39d9ecb5b8064b90",
    "scope": "repo"
  },
  {
    "bytes": 1158,
    "repoRelPath": "CAPABILITY/CAS/storage/5/e0/5e00d19dc542d3db158318eb1c79578adaf43287128dd8669c61102df56e7500",
    "scope": "repo"
  },
  {
    "bytes": 284,
    "repoRelPath": "CAPABILITY/CAS/storage/5/e4/5e458c912945f1f97a848c4fcec9b551a263ddf78a1c99072908ce39a3647edd",
    "scope": "repo"
  },
  {
    "bytes": 2227,
    "repoRelPath": "CAPABILITY/CAS/storage/5/e5/5e5891e27aa4c7b51b5d48f86f12e72a81c2ea77ee9a5536817437a7a51ad3fb",
    "scope": "repo"
  },
  {
    "bytes": 6974,
    "repoRelPath": "CAPABILITY/CAS/storage/5/e7/5e7934468019192681ff892cf9ae650fcda392fdd507abe9b647ebb779e78102",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/5/e8/5e85d4a1f6db1f8e34fbea0455fab08c319bc49b4ffc5eb13241710d8e5a5cf6",
    "scope": "repo"
  },
  {
    "bytes": 14624,
    "repoRelPath": "CAPABILITY/CAS/storage/5/eb/5eb3f8974bd70a461d33bc75e7ca640a006126306c7eb1cf50a95c26d89e4000",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/5/eb/5ebec1ba50998e95fd5ee525d45ca1c3589233a2598c8a036d3a762e0b8eecb6",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/5/f0/5f0085fa982665fa8d4fe3cef119d8a7db5978d641cf74fa8530be852e75d7fd",
    "scope": "repo"
  },
  {
    "bytes": 62871,
    "repoRelPath": "CAPABILITY/CAS/storage/5/f0/5f017767628074c58d4f293aae1d2923d140242613a9a30a33dd7c6fa4badeb9",
    "scope": "repo"
  },
  {
    "bytes": 2376,
    "repoRelPath": "CAPABILITY/CAS/storage/5/f2/5f29fc2efc27b7a44abea343e2a1577a6a6cdc569e44d9d16dc064a5e24c1363",
    "scope": "repo"
  },
  {
    "bytes": 5312,
    "repoRelPath": "CAPABILITY/CAS/storage/5/f4/5f427112df75711ed5a75fdacc25a753b00c023b66452b7b3877524dafc9bbad",
    "scope": "repo"
  },
  {
    "bytes": 22563,
    "repoRelPath": "CAPABILITY/CAS/storage/5/f7/5f74410131aed49fb6a20cd077e76a69629116f67c12451e10fd356a7e8d6763",
    "scope": "repo"
  },
  {
    "bytes": 2529,
    "repoRelPath": "CAPABILITY/CAS/storage/5/fc/5fc375699b780932946bb997d0a39879f96354c7671c8cdae8ee5d0035057e4b",
    "scope": "repo"
  },
  {
    "bytes": 1497,
    "repoRelPath": "CAPABILITY/CAS/storage/6/00/600169d046ffd63f28416ff4d50e395b1a2a244af89109d05501b13d324930ea",
    "scope": "repo"
  },
  {
    "bytes": 7402,
    "repoRelPath": "CAPABILITY/CAS/storage/6/01/601e4422cee86aba9a6c3437edd8ed831dbd6dbd531f845d77c9463be13be692",
    "scope": "repo"
  },
  {
    "bytes": 2912,
    "repoRelPath": "CAPABILITY/CAS/storage/6/07/6074e24d96996c0954bce96f1d687dc1a068d629e3a8a6c89e233b5b92a5b5d0",
    "scope": "repo"
  },
  {
    "bytes": 3048,
    "repoRelPath": "CAPABILITY/CAS/storage/6/0a/60a8f38f7125fc2b9be16923b78a17e21fd350ce3d1ea5746bb3ca639eb77f35",
    "scope": "repo"
  },
  {
    "bytes": 15,
    "repoRelPath": "CAPABILITY/CAS/storage/6/0c/60c48ddce35530a43716c40331da2e737fca5f9b2468c01396726ab7d4f351b2",
    "scope": "repo"
  },
  {
    "bytes": 2179,
    "repoRelPath": "CAPABILITY/CAS/storage/6/0e/60eb5f8bc0a798b0c280d57b9c08c6712c1f7935d6922ba6695e46a0d0f6e93b",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/6/13/613ff280ac23946616cd28743b3fbee4be3d48e23ac75feb15af78b996539296",
    "scope": "repo"
  },
  {
    "bytes": 3177,
    "repoRelPath": "CAPABILITY/CAS/storage/6/16/616760bf93df97c20380941c83d5ac32b154276d8f2afd2fda9c344bf4625350",
    "scope": "repo"
  },
  {
    "bytes": 16409,
    "repoRelPath": "CAPABILITY/CAS/storage/6/1a/61a12a50ddd3188bab3eb96f74938056736bc4bd67e39559ee0f1c22f96e80c0",
    "scope": "repo"
  },
  {
    "bytes": 798,
    "repoRelPath": "CAPABILITY/CAS/storage/6/25/6254443f0f8c135e8243404f107e90ec9383b75075ee56cfb2dbce1b362931bc",
    "scope": "repo"
  },
  {
    "bytes": 6909,
    "repoRelPath": "CAPABILITY/CAS/storage/6/25/625812eaab929ecb98b5142c2e0528dd6f4aa0d83caeb11f1c9cd0e4c84f510f",
    "scope": "repo"
  },
  {
    "bytes": 24308,
    "repoRelPath": "CAPABILITY/CAS/storage/6/25/625a1cd45d0db710ea8e595b0f338fda36a4aab1daf95deae38d1fd0ed991b96",
    "scope": "repo"
  },
  {
    "bytes": 4512,
    "repoRelPath": "CAPABILITY/CAS/storage/6/26/6265ea86542e922d885af91f529fcb0c4d58ebc8c36031d6b668502ceb75b4fd",
    "scope": "repo"
  },
  {
    "bytes": 3248,
    "repoRelPath": "CAPABILITY/CAS/storage/6/28/62802abb041af021d3bede91b45fecfc5583f4be1158c9c021df1faa3b01757f",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/6/2a/62a79986d245c6efaa0e2fe1d78e5287d808f667fedf00b8a8268bf369a4d15f",
    "scope": "repo"
  },
  {
    "bytes": 107,
    "repoRelPath": "CAPABILITY/CAS/storage/6/2b/62b19a25b333c501925a9936be946c92447247c640b3f80d7cba3645a43475e1",
    "scope": "repo"
  },
  {
    "bytes": 930,
    "repoRelPath": "CAPABILITY/CAS/storage/6/33/633f6c860d5501cceb99ab315cbe29b5b58e244da76893e4ea60b86e79fea524",
    "scope": "repo"
  },
  {
    "bytes": 83,
    "repoRelPath": "CAPABILITY/CAS/storage/6/36/63686f89023429c5e9d10e6359552d3960b9a49765e661bee7b4ab4fd55ee49d",
    "scope": "repo"
  },
  {
    "bytes": 2036,
    "repoRelPath": "CAPABILITY/CAS/storage/6/36/636fa9806d02c384d9864435e0163e17f87c7d35497455b039ddfd65f9717f15",
    "scope": "repo"
  },
  {
    "bytes": 1289,
    "repoRelPath": "CAPABILITY/CAS/storage/6/37/6373a6e7d286ce52670687c49dcb0fbc4a86ca4c544b7cfcccff247c9cef3ff1",
    "scope": "repo"
  },
  {
    "bytes": 2238,
    "repoRelPath": "CAPABILITY/CAS/storage/6/3a/63abfe7ecd1c53b74dad08f55aaa70b0ac38ae3138500e70df96950aedbb6c51",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/6/3c/63c8b0e4127bbaa73022bf46a3d99bd9d268745f4cfe9b09c91ccad1483bafd0",
    "scope": "repo"
  },
  {
    "bytes": 596,
    "repoRelPath": "CAPABILITY/CAS/storage/6/3f/63f0336731e0ddf5fec7693c1d46ac4783424f12bfb5aa7a0e1e3fe8a55a4d7e",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/6/3f/63fe8b8ebc969231ec55a5107521d63baa9d920cdf57a6cfe48455bafc743c72",
    "scope": "repo"
  },
  {
    "bytes": 3849,
    "repoRelPath": "CAPABILITY/CAS/storage/6/43/64353c6f23facdf85ceec36387e0f52f9f1d02b7dfd2ae1ec23c296ca021dede",
    "scope": "repo"
  },
  {
    "bytes": 6642,
    "repoRelPath": "CAPABILITY/CAS/storage/6/4c/64c4b4351d574efab30335ef5209ff9f3c04df3c8782a0432a16dd0522285f6b",
    "scope": "repo"
  },
  {
    "bytes": 4059,
    "repoRelPath": "CAPABILITY/CAS/storage/6/4e/64e111b826ccf6bc85e5e49f601faabf648b5e5b326c681c55aa572d6b3cd4a4",
    "scope": "repo"
  },
  {
    "bytes": 298,
    "repoRelPath": "CAPABILITY/CAS/storage/6/50/650833dc634e59bc819eefa86f1e3362de7c66025fd0dcbd68ea18e3951611b0",
    "scope": "repo"
  },
  {
    "bytes": 71,
    "repoRelPath": "CAPABILITY/CAS/storage/6/53/65386073f0affcec37a6e30e666c4d57d6f107e6974e3f2a4fdef373e4d7f7b8",
    "scope": "repo"
  },
  {
    "bytes": 1405,
    "repoRelPath": "CAPABILITY/CAS/storage/6/53/65392387b26f008a4d21e4e4373b7df22188131414ed11bb804464c78ed69e97",
    "scope": "repo"
  },
  {
    "bytes": 32,
    "repoRelPath": "CAPABILITY/CAS/storage/6/54/654e01427d28b453c988c06d6713d1843031efa35d6e162a586aae04e529f546",
    "scope": "repo"
  },
  {
    "bytes": 672,
    "repoRelPath": "CAPABILITY/CAS/storage/6/55/65520191217deb9d311df9dbe20dc11437ff567f299c22f5cbe8273914cf4d99",
    "scope": "repo"
  },
  {
    "bytes": 325,
    "repoRelPath": "CAPABILITY/CAS/storage/6/58/6582d55f816eda14f1bf2a663c3a5899c9d9e3c9a2f7610281e3df174f2e9b1a",
    "scope": "repo"
  },
  {
    "bytes": 7460,
    "repoRelPath": "CAPABILITY/CAS/storage/6/5b/65b12abc8ab240b8173ea378585940f02a999e3a6f719de8c264015124a53906",
    "scope": "repo"
  },
  {
    "bytes": 3836,
    "repoRelPath": "CAPABILITY/CAS/storage/6/5c/65cfd5c7ffe832798372867a17d80921d7d0c25a830457aa7d578148ddafeaf1",
    "scope": "repo"
  },
  {
    "bytes": 2495,
    "repoRelPath": "CAPABILITY/CAS/storage/6/5e/65e1d17be2147ce6e98955ee84c6a55384e45b116a9bc554e17930ca018b9383",
    "scope": "repo"
  },
  {
    "bytes": 6135,
    "repoRelPath": "CAPABILITY/CAS/storage/6/5e/65ec82c3a4e44788c8d7feb2baf4df271a59bda489a996d85e5195e4b13b935a",
    "scope": "repo"
  },
  {
    "bytes": 7677,
    "repoRelPath": "CAPABILITY/CAS/storage/6/5f/65fcfa283c2db768000f63d17486e4f200feb84083589b49c51bbb5b465f10af",
    "scope": "repo"
  },
  {
    "bytes": 801,
    "repoRelPath": "CAPABILITY/CAS/storage/6/62/6623270965a3c9439e85ad97473b76f93eb178a0beab31c7f9f3a1df5583a28e",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/6/64/6643754da2e71b50633f9fcc843027ce5b54bc0465750bc07b64795ded47c9e1",
    "scope": "repo"
  },
  {
    "bytes": 60,
    "repoRelPath": "CAPABILITY/CAS/storage/6/64/664b4588bab65d38c4b9209f6c9602be0bd6f1cadf24a1eeec2718776b103f21",
    "scope": "repo"
  },
  {
    "bytes": 907,
    "repoRelPath": "CAPABILITY/CAS/storage/6/65/665e022353d6060dbc103967710542afaeaa3cb181a60eb66e869cf194f4f111",
    "scope": "repo"
  },
  {
    "bytes": 138,
    "repoRelPath": "CAPABILITY/CAS/storage/6/6c/66cbe3401e700c6b9c1cc59dd472e40949d0dd2996d775cd21a8b5a5c6be931a",
    "scope": "repo"
  },
  {
    "bytes": 220,
    "repoRelPath": "CAPABILITY/CAS/storage/6/6d/66d851d3d27612030d9881f53ed9f8c3e260fd5af962ed9a4742f7b63b0a9fe2",
    "scope": "repo"
  },
  {
    "bytes": 24,
    "repoRelPath": "CAPABILITY/CAS/storage/6/6f/66fd4833a69c64d2292d4b432d0ebf621ffcc9114821b82ff38616af4c2aa574",
    "scope": "repo"
  },
  {
    "bytes": 325,
    "repoRelPath": "CAPABILITY/CAS/storage/6/70/67073e5d2a6d229f0f45b1b717d0925a6ce9b1d94fb2bc23a907332b1864cef4",
    "scope": "repo"
  },
  {
    "bytes": 21356,
    "repoRelPath": "CAPABILITY/CAS/storage/6/74/6740aebbb11a2f39c0073d7ea0e6437c47ecde6eb67b2bb98c11f895739cb6e0",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/6/79/679b3e8da3051bd20e39cc7ba08e1ba318a84f71c72b008bd89735b7ee196a79",
    "scope": "repo"
  },
  {
    "bytes": 6186,
    "repoRelPath": "CAPABILITY/CAS/storage/6/7c/67c1c0417da0aec3c78b88874cdf755e1974ac422474fa3a9f694acdfbe47c0d",
    "scope": "repo"
  },
  {
    "bytes": 1361,
    "repoRelPath": "CAPABILITY/CAS/storage/6/7f/67fda97da66c51db7e283ce3ba29201f390ce07ece250d12d170d4ce2a36f5f4",
    "scope": "repo"
  },
  {
    "bytes": 3579,
    "repoRelPath": "CAPABILITY/CAS/storage/6/84/68410da40ad10c58f1e4a26788b9701de638b3336ea86192d477519210703ce6",
    "scope": "repo"
  },
  {
    "bytes": 10545,
    "repoRelPath": "CAPABILITY/CAS/storage/6/84/684f6f400cfa5ffc26a465af99bf9c6811b945edb8377b5a7753b6ceee19e85c",
    "scope": "repo"
  },
  {
    "bytes": 1272780,
    "repoRelPath": "CAPABILITY/CAS/storage/6/8a/68a02d8838110dbd22a11630767ef4d63e2b32e6c3b5fcda3c3f93be546bcb61",
    "scope": "repo"
  },
  {
    "bytes": 3588,
    "repoRelPath": "CAPABILITY/CAS/storage/6/8b/68b4fbccf176c4afa62a26f762b27e29d530516755986d58fdf27e1316e5d33d",
    "scope": "repo"
  },
  {
    "bytes": 22,
    "repoRelPath": "CAPABILITY/CAS/storage/6/8c/68c3bae31438b7ea32c53c8f70cde7f6fc1f9f518eb0da255ffb33b336ac3751",
    "scope": "repo"
  },
  {
    "bytes": 2633,
    "repoRelPath": "CAPABILITY/CAS/storage/6/8d/68d2b7fb362abe34bf7c1ee51a655c872a1c5a2020436c6c564c859ab0fe4233",
    "scope": "repo"
  },
  {
    "bytes": 1328,
    "repoRelPath": "CAPABILITY/CAS/storage/6/93/693cecbb5c15e1e9187b465d2446fffcbb2f106c129c62578e33d5780ce4b101",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/6/94/694414da93eb159d349ae3e942c7e9d90dd30ff168188c10c13183918e938572",
    "scope": "repo"
  },
  {
    "bytes": 1902,
    "repoRelPath": "CAPABILITY/CAS/storage/6/98/698e81a4e865070e070292ef272aff393d69ec64054b27e2ad18d8f6f4e5b707",
    "scope": "repo"
  },
  {
    "bytes": 837,
    "repoRelPath": "CAPABILITY/CAS/storage/6/99/699886a49499fabffbf07251c4aa7289de6fdc1b8d6e2519f9c5b30204939408",
    "scope": "repo"
  },
  {
    "bytes": 14,
    "repoRelPath": "CAPABILITY/CAS/storage/6/9f/69f6245a92f0c902e45cfd6e99297cad3e536598237b6ef3d04fbb59c8a3b095",
    "scope": "repo"
  },
  {
    "bytes": 134061,
    "repoRelPath": "CAPABILITY/CAS/storage/6/9f/69fae7f2659260732c2283195b1b3298db61e8686b72ad6af4355dc4be5e57ef",
    "scope": "repo"
  },
  {
    "bytes": 1606,
    "repoRelPath": "CAPABILITY/CAS/storage/6/9f/69fd426b6fd0d76066e6bb28947ff6687b5f880902375445294be4b89860a128",
    "scope": "repo"
  },
  {
    "bytes": 293,
    "repoRelPath": "CAPABILITY/CAS/storage/6/a9/6a9451b5ccc394c4504c9650afd5ed7a59c8c1533f67bd43c4a941396c85affe",
    "scope": "repo"
  },
  {
    "bytes": 2287,
    "repoRelPath": "CAPABILITY/CAS/storage/6/aa/6aa4c2696dd60a1d418b5b46979e98b95e1da6e74a151073fb6269327786f76b",
    "scope": "repo"
  },
  {
    "bytes": 1981,
    "repoRelPath": "CAPABILITY/CAS/storage/6/aa/6aa922d2b0dec308ac492fd1f5072994bc036325b0cb7ab17555e3f1580b449c",
    "scope": "repo"
  },
  {
    "bytes": 8901,
    "repoRelPath": "CAPABILITY/CAS/storage/6/ac/6ac809f144684a0d79af9e03918fa7890a2e0e7972ad4876a5556a66a288d30f",
    "scope": "repo"
  },
  {
    "bytes": 692,
    "repoRelPath": "CAPABILITY/CAS/storage/6/b0/6b0e234afd048b5814c43cc5f51866a2f1d08a68f9e1f378c3c492fd6c025811",
    "scope": "repo"
  },
  {
    "bytes": 852,
    "repoRelPath": "CAPABILITY/CAS/storage/6/b4/6b404e0082d809e4570d9ccce706658dcd2ac27055feb35236e7afbc8939f1d9",
    "scope": "repo"
  },
  {
    "bytes": 80,
    "repoRelPath": "CAPABILITY/CAS/storage/6/b5/6b578aa92dc95324f9b9435198313ee53ee4d54804c90fd57135e9a0662ba80c",
    "scope": "repo"
  },
  {
    "bytes": 174,
    "repoRelPath": "CAPABILITY/CAS/storage/6/b7/6b724742de408b7486e8cfe4a16733b02d034a87705f6ea92da0823a80d8a5d9",
    "scope": "repo"
  },
  {
    "bytes": 7836,
    "repoRelPath": "CAPABILITY/CAS/storage/6/be/6bece0e04e4971781547d13e8500d445cf6939750b13cdf3560c42e5ba1522ed",
    "scope": "repo"
  },
  {
    "bytes": 7681,
    "repoRelPath": "CAPABILITY/CAS/storage/6/be/6befc3659dd13e536473e0069bb1933109c7803b7bfc14c243be27256c3d7d96",
    "scope": "repo"
  },
  {
    "bytes": 2346,
    "repoRelPath": "CAPABILITY/CAS/storage/6/c2/6c2daf56c28345682647fe14f53199babc4a462438434a2fe6975a9148ee39d5",
    "scope": "repo"
  },
  {
    "bytes": 3153,
    "repoRelPath": "CAPABILITY/CAS/storage/6/c4/6c4c391949b366eed8361a0f85cb54d044f0b1da21f3ba4efc4635757e45c5f6",
    "scope": "repo"
  },
  {
    "bytes": 9011,
    "repoRelPath": "CAPABILITY/CAS/storage/6/c7/6c70aae36bc2c0b0716e312f0b4b40c154768b37e0b98d6b5e0bdbcc338b1188",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/6/ca/6ca8c3c142c16101c294cb6b3d9fddab7fecc1a4ecade76fd8fb06f8016ed28f",
    "scope": "repo"
  },
  {
    "bytes": 6814,
    "repoRelPath": "CAPABILITY/CAS/storage/6/ca/6cad007334197503d6581a19bdedd63a2133ce188cdcac5f9d24d18ed629a0a2",
    "scope": "repo"
  },
  {
    "bytes": 6114,
    "repoRelPath": "CAPABILITY/CAS/storage/6/cc/6cca0f49f0a6f1d58d6b90bf75003e5926945cc3f75827573deeec40d96f4b83",
    "scope": "repo"
  },
  {
    "bytes": 943,
    "repoRelPath": "CAPABILITY/CAS/storage/6/cd/6cd833b2577548c40c45b6be10c78d95e83adf1afbe2a0ef083500c7c22beb80",
    "scope": "repo"
  },
  {
    "bytes": 76,
    "repoRelPath": "CAPABILITY/CAS/storage/6/d1/6d142ebb9f6c9655112f2805a2169c6994055f121f44d1b69da817c726cf0e3b",
    "scope": "repo"
  },
  {
    "bytes": 402,
    "repoRelPath": "CAPABILITY/CAS/storage/6/dd/6dd7513ede4e6027b7cb4fd4e17f33de8716337b78f8b3d1b80a9c7cca3bdcef",
    "scope": "repo"
  },
  {
    "bytes": 23823,
    "repoRelPath": "CAPABILITY/CAS/storage/6/df/6df8a4c35a32a3d917507741c91debb7d566e22ca21348386b57307f9c8a55e8",
    "scope": "repo"
  },
  {
    "bytes": 2660,
    "repoRelPath": "CAPABILITY/CAS/storage/6/ef/6ef19b210ee3853ee5c09a38f7ee00bfbbcd37cb0aac635abeb728d38a4889c9",
    "scope": "repo"
  },
  {
    "bytes": 48911,
    "repoRelPath": "CAPABILITY/CAS/storage/6/f0/6f09026b9dcbf82576a654ba9864fe8acb11d5bdfc8b85f474540987ac21ddf2",
    "scope": "repo"
  },
  {
    "bytes": 225,
    "repoRelPath": "CAPABILITY/CAS/storage/6/f4/6f43ad492738ff7e1518c7316f7390ddadcc8cfc0c835525f0d4bf4d7b5db028",
    "scope": "repo"
  },
  {
    "bytes": 1471,
    "repoRelPath": "CAPABILITY/CAS/storage/6/f5/6f56156cee22af73317554fee2c52812c88dd22effb24362c12f809695351065",
    "scope": "repo"
  },
  {
    "bytes": 59,
    "repoRelPath": "CAPABILITY/CAS/storage/6/f9/6f9f1bd2b8b23de0ec263976a0c4c2956d1cbd4d40adde3482ba58fbaefcb6e6",
    "scope": "repo"
  },
  {
    "bytes": 381,
    "repoRelPath": "CAPABILITY/CAS/storage/6/fc/6fc5c5b08a439701fd850f903d5e6045727d5a4b5d363a66a846f7b06d921d84",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/6/fe/6fe21324ae59891be642dbe330cc74bd28313a44ade23304d5f4d4f5b28f5de2",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/6/fe/6feb4f6a1eea33a71380e52ee6a56a1aa22f12d322a033d53597ad3ff2d8e582",
    "scope": "repo"
  },
  {
    "bytes": 5039,
    "repoRelPath": "CAPABILITY/CAS/storage/7/00/70022eda441e80518d3bdd4c48fad1194e9cc4abd887a2a893078752bb81fbc3",
    "scope": "repo"
  },
  {
    "bytes": 63,
    "repoRelPath": "CAPABILITY/CAS/storage/7/0a/70a53d01abbe37103e5dae3ded7b7e021ef284389ca2f28af7314dbc6de0303f",
    "scope": "repo"
  },
  {
    "bytes": 147,
    "repoRelPath": "CAPABILITY/CAS/storage/7/0b/70b914ec0e9d9cd5a5ee84e0e2ee0301660e6f1e735a95fea792a2951150ec48",
    "scope": "repo"
  },
  {
    "bytes": 1594,
    "repoRelPath": "CAPABILITY/CAS/storage/7/0c/70c678af4a1a8a138531fb0c36229c3d71d5cb88245641b65ce14fdaab6b0229",
    "scope": "repo"
  },
  {
    "bytes": 354,
    "repoRelPath": "CAPABILITY/CAS/storage/7/0c/70cbeff310db60936c45ed2c6ebd09d7f1d9336132961210333fb94a8c5dcc4c",
    "scope": "repo"
  },
  {
    "bytes": 19,
    "repoRelPath": "CAPABILITY/CAS/storage/7/0d/70d1ebc7a727a476f15f7b4436d65b0bca07718c03a0843fa008659badad79c7",
    "scope": "repo"
  },
  {
    "bytes": 174903,
    "repoRelPath": "CAPABILITY/CAS/storage/7/0d/70dba686114e990ecfa332ff5b00e78d1f6833ced08e2c9a825d8663447234f2",
    "scope": "repo"
  },
  {
    "bytes": 8241,
    "repoRelPath": "CAPABILITY/CAS/storage/7/10/71074e9f3455bb62c4f870f90ce9798e38c3f4e6068e344537e868f521496fc6",
    "scope": "repo"
  },
  {
    "bytes": 9196,
    "repoRelPath": "CAPABILITY/CAS/storage/7/11/71165335b7bc7bcccec3319c95b2d4b1db6cd080210aa996ebd8541ebc5188ab",
    "scope": "repo"
  },
  {
    "bytes": 13297,
    "repoRelPath": "CAPABILITY/CAS/storage/7/15/715b2bfa8f9a58cef3a55146c11804a6730575f736c13879724cf95a441da0a3",
    "scope": "repo"
  },
  {
    "bytes": 6259,
    "repoRelPath": "CAPABILITY/CAS/storage/7/18/718071fef8b27a9bb9d9dcf6afffad731ea8731902617e3140eabf00f1953419",
    "scope": "repo"
  },
  {
    "bytes": 1446,
    "repoRelPath": "CAPABILITY/CAS/storage/7/1b/71b1044a40940fb233ee3aeeaf85a54d8ac3a0614e06ac65f9c0451255b57790",
    "scope": "repo"
  },
  {
    "bytes": 73,
    "repoRelPath": "CAPABILITY/CAS/storage/7/1d/71da61fd98ba6f042563af222175940ec82cc841df8566958ccd92ab5143ebd1",
    "scope": "repo"
  },
  {
    "bytes": 2648,
    "repoRelPath": "CAPABILITY/CAS/storage/7/22/72272f0f80d60b3bfd0f2a08115245ca70521942e95aadb4c0f413c187fb756b",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/7/23/723806e8efb1baa6cd2b98df0636fc38bc61b4a1f85d6a849bd5e2e1b935f5c6",
    "scope": "repo"
  },
  {
    "bytes": 5816,
    "repoRelPath": "CAPABILITY/CAS/storage/7/24/7241b8e6b8d0e650e0da6d06bb193e4a3b91aa12e3acd416e5d0f86b1272b49a",
    "scope": "repo"
  },
  {
    "bytes": 46,
    "repoRelPath": "CAPABILITY/CAS/storage/7/24/7242b842211529b3b0c9935f920451e44aed87d8639a381ed1d71a1e1e6b8b61",
    "scope": "repo"
  },
  {
    "bytes": 7998,
    "repoRelPath": "CAPABILITY/CAS/storage/7/26/72692629dc98424d0bdfc7c77690014f8b9e47caf2791c359501029e733e28b8",
    "scope": "repo"
  },
  {
    "bytes": 2419,
    "repoRelPath": "CAPABILITY/CAS/storage/7/27/727a6b389deb1826c54eeb6937e010a802e00383e3fce36c08fa34d5b71fc93f",
    "scope": "repo"
  },
  {
    "bytes": 908,
    "repoRelPath": "CAPABILITY/CAS/storage/7/27/727cd289c360964910267dfe44c5b6e0e8b2a94768ac18cb718e917854590b2a",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/7/2a/72abc23f0bb54c410806e493863cecff1cbe5b6fc4d671c3ddf5181f080953a2",
    "scope": "repo"
  },
  {
    "bytes": 159,
    "repoRelPath": "CAPABILITY/CAS/storage/7/2a/72aca6d20307298fa4dc261858032ead079ca4fa9337ddd942e1fafa0db0fc64",
    "scope": "repo"
  },
  {
    "bytes": 155,
    "repoRelPath": "CAPABILITY/CAS/storage/7/2b/72b17c71832a51bbe0611ee06a45061abe340e0e485edb6ae5682a48a6d58074",
    "scope": "repo"
  },
  {
    "bytes": 8630,
    "repoRelPath": "CAPABILITY/CAS/storage/7/2c/72c8837f019c732598864474d0adddf8b2542c91f592f8847368af792dbcab78",
    "scope": "repo"
  },
  {
    "bytes": 12362,
    "repoRelPath": "CAPABILITY/CAS/storage/7/31/7312715023dc86684bcc596c2745c9330ebc8f308a18576a3e29bea33cfbee59",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/7/34/734beb1c003f845b1a20e94e6847a2261359c33297b05fd97f84e74bab31c3f1",
    "scope": "repo"
  },
  {
    "bytes": 724,
    "repoRelPath": "CAPABILITY/CAS/storage/7/35/7352a3b47558c9d0a8d984229552f633f4d6c1b43cc2823735052ab4f8377cb5",
    "scope": "repo"
  },
  {
    "bytes": 9056,
    "repoRelPath": "CAPABILITY/CAS/storage/7/36/736af19d732b68597a4fece71b8964ae05d816deaa7b2b44c398071117dfdac8",
    "scope": "repo"
  },
  {
    "bytes": 30,
    "repoRelPath": "CAPABILITY/CAS/storage/7/38/738a4ac9461d7fbe742060d3f06152729b34d0bec6d05dfd7053350306d9a18f",
    "scope": "repo"
  },
  {
    "bytes": 11807,
    "repoRelPath": "CAPABILITY/CAS/storage/7/46/746faf1c0b7f81680af594ffed41409fff5ea4f5153a7279ff20f2b323591617",
    "scope": "repo"
  },
  {
    "bytes": 3279,
    "repoRelPath": "CAPABILITY/CAS/storage/7/47/747e63b08b3cfac1e05e50f2176d4355e05dd86f10294eac54caabcd8b686a80",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/7/48/748fb8d82a20db7c22b76784bd2a3c7b17971c2d9caa965cd002730507361e53",
    "scope": "repo"
  },
  {
    "bytes": 3475,
    "repoRelPath": "CAPABILITY/CAS/storage/7/4d/74de984a7b1b4c6099104735179c62911505524b1735cd68d21855428c774e77",
    "scope": "repo"
  },
  {
    "bytes": 75261,
    "repoRelPath": "CAPABILITY/CAS/storage/7/4f/74f7b212f26300e853b6dfef8f28b8d035868b793ac0d8597008be7e08d6fc1a",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/7/51/751a5b50762fe6cf4d71bb2628a053da37b27c41e9d08f7a6eb45af675aa5fcb",
    "scope": "repo"
  },
  {
    "bytes": 5495,
    "repoRelPath": "CAPABILITY/CAS/storage/7/55/755a1b8a2cd0de276c68852f3db93c2d6a90902ab9c935981c9103cde70c8c5f",
    "scope": "repo"
  },
  {
    "bytes": 57,
    "repoRelPath": "CAPABILITY/CAS/storage/7/55/755c2088d092c41a50636dec21df68bb9f485738b4cea74b1eae3606ad9d7cca",
    "scope": "repo"
  },
  {
    "bytes": 109351,
    "repoRelPath": "CAPABILITY/CAS/storage/7/5b/75b1b5558af55f9f27ca817fd5d9ab3b03f83400de449af4b20ad1c67db490f8",
    "scope": "repo"
  },
  {
    "bytes": 7894,
    "repoRelPath": "CAPABILITY/CAS/storage/7/5b/75b4f673d88db7eb879ab81abcf6fc02326de9add39a3e241d909c3c5326dc29",
    "scope": "repo"
  },
  {
    "bytes": 858,
    "repoRelPath": "CAPABILITY/CAS/storage/7/5d/75d4f007d6f810c2c88473d56c07ec6a87a2c13b637e9594855e102482741924",
    "scope": "repo"
  },
  {
    "bytes": 1391,
    "repoRelPath": "CAPABILITY/CAS/storage/7/5e/75eba7b3fc52301344495a6614de7d14f16cc64a1bccd771e1a5df1ed0c59b16",
    "scope": "repo"
  },
  {
    "bytes": 1398,
    "repoRelPath": "CAPABILITY/CAS/storage/7/62/7624c5b3b43be9c9c4060fe23c8257e81053a05b543f60f101b45032f6ea370d",
    "scope": "repo"
  },
  {
    "bytes": 2127,
    "repoRelPath": "CAPABILITY/CAS/storage/7/64/7642fbb599ab749078f2ee70b34d84479168bbea2e6257af0c9ba9bfc3fee1fa",
    "scope": "repo"
  },
  {
    "bytes": 12908,
    "repoRelPath": "CAPABILITY/CAS/storage/7/68/76841b0e5aa30050120e386e801cc1afcc1706ab8d8efc5f80f84a048114642d",
    "scope": "repo"
  },
  {
    "bytes": 192,
    "repoRelPath": "CAPABILITY/CAS/storage/7/69/769f02d120c97da39581b15673e468395565ce91bc4d2f2a1dd41d172696cc2b",
    "scope": "repo"
  },
  {
    "bytes": 74400,
    "repoRelPath": "CAPABILITY/CAS/storage/7/6f/76f508072391fa75912aaa12a819ade5bc072bfeac412e8fe8eb0dc34a466622",
    "scope": "repo"
  },
  {
    "bytes": 4659,
    "repoRelPath": "CAPABILITY/CAS/storage/7/71/771778efab33cbbceafed62299cbb90c9fabdd6c48ec59792fc0708263fca848",
    "scope": "repo"
  },
  {
    "bytes": 134062,
    "repoRelPath": "CAPABILITY/CAS/storage/7/78/77868168a1b249781a4d6e59894556092cf2bcaed512aaa9130f6fb4a4393cba",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/7/78/7788650b24f11fe8daa98ddd47117b8256c3e62db8a2376cc1574df6561ab2f2",
    "scope": "repo"
  },
  {
    "bytes": 325,
    "repoRelPath": "CAPABILITY/CAS/storage/7/78/778e0979d1f135610ce455a9df2c8a14af58121d6d6996f6da6326f43a6a71a2",
    "scope": "repo"
  },
  {
    "bytes": 5960,
    "repoRelPath": "CAPABILITY/CAS/storage/7/7d/77df0b9785de174bdea9f300806f129e485ab152ee19837a36ee23d867f9a70b",
    "scope": "repo"
  },
  {
    "bytes": 294,
    "repoRelPath": "CAPABILITY/CAS/storage/7/7d/77df9fa0f549f1b779064f9ce80c3d4777c73a211216a33957b115f8a25d418f",
    "scope": "repo"
  },
  {
    "bytes": 671,
    "repoRelPath": "CAPABILITY/CAS/storage/7/84/784f1834b03364506db2c437b130abb90ab473264ad31d31ffcb5afb21b0b566",
    "scope": "repo"
  },
  {
    "bytes": 3829,
    "repoRelPath": "CAPABILITY/CAS/storage/7/85/78582669fe11c3782aa4fc37dec1afe115e21a2363bebbd6d07b0fd6702d0060",
    "scope": "repo"
  },
  {
    "bytes": 5195,
    "repoRelPath": "CAPABILITY/CAS/storage/7/89/789898b6fe61cfaa9e1d73227fc5ba5bd3068d2c74e900f7373376e27af4a162",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/7/8a/78a7cfd8edfd2ba74bac4ad5161520a0540dee8531c721f42755c70964c7e7c0",
    "scope": "repo"
  },
  {
    "bytes": 38783,
    "repoRelPath": "CAPABILITY/CAS/storage/7/8e/78e14bddb56e2d2480c756274d7867b118a15cef87b723159435a60ab808e715",
    "scope": "repo"
  },
  {
    "bytes": 824,
    "repoRelPath": "CAPABILITY/CAS/storage/7/91/7918e2248116cd2daa1c76c64ce5b31eadb9d597d9e5f12eac3f8cf86ba139d3",
    "scope": "repo"
  },
  {
    "bytes": 5731,
    "repoRelPath": "CAPABILITY/CAS/storage/7/92/79272e724be6bda82107ede578c1ffafb542d77e983768a57dbdd9e527816885",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/7/93/793658fc1fe7223e0aa004a3e543c40b24de5f15985a032a93130024bad9ce8b",
    "scope": "repo"
  },
  {
    "bytes": 174903,
    "repoRelPath": "CAPABILITY/CAS/storage/7/94/7942177af6123ce0aa9e1f070c19c9b5d25317b65db7c6910d41a05299794a1d",
    "scope": "repo"
  },
  {
    "bytes": 1136,
    "repoRelPath": "CAPABILITY/CAS/storage/7/94/7946e1e0e3c915cb299c56253fdf94b08f3e43054420ab6a5dee9be3f9f123e2",
    "scope": "repo"
  },
  {
    "bytes": 623,
    "repoRelPath": "CAPABILITY/CAS/storage/7/97/7974a6245560f49b7280407174beec494bbe1f8f3f569cab87b3f03db2727a6b",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/7/97/797ed95d4680422e4e68c9f04839d0a60d6797057ff3cc50d5830f89c5c18c47",
    "scope": "repo"
  },
  {
    "bytes": 17670,
    "repoRelPath": "CAPABILITY/CAS/storage/7/98/798c984191aaaf39ddfd506afe869ec3b497091cd74213c2f7d52ab08aeb10ec",
    "scope": "repo"
  },
  {
    "bytes": 174739,
    "repoRelPath": "CAPABILITY/CAS/storage/7/9c/79c38170f2845b1ffd44b0086b4e36155c8ec6efc104245800b433ec45068b94",
    "scope": "repo"
  },
  {
    "bytes": 4911,
    "repoRelPath": "CAPABILITY/CAS/storage/7/9f/79f96c84b163d92650a4f5053192701281100d62089d4f013086e2c59557e053",
    "scope": "repo"
  },
  {
    "bytes": 54000,
    "repoRelPath": "CAPABILITY/CAS/storage/7/a7/7a71ff98a123fccd89a33f441291529aeb067001f806caf53745b23ef39f72ea",
    "scope": "repo"
  },
  {
    "bytes": 13777,
    "repoRelPath": "CAPABILITY/CAS/storage/7/a7/7a79f5a5571550cfccbb575cf5d4046bd891a058f7ff8f2f5cabbe7b63d793a7",
    "scope": "repo"
  },
  {
    "bytes": 16223,
    "repoRelPath": "CAPABILITY/CAS/storage/7/a9/7a97a2078ce3c556eae406db576be47ae96e6876b81e4ea33eae41168aa62fe0",
    "scope": "repo"
  },
  {
    "bytes": 3523,
    "repoRelPath": "CAPABILITY/CAS/storage/7/ae/7aec840435e6b43be96eed9afb9ae9f84293d39d2d3996cbc7c5adb0b40a29d2",
    "scope": "repo"
  },
  {
    "bytes": 25569,
    "repoRelPath": "CAPABILITY/CAS/storage/7/b2/7b23de6fa0287d1cb469d654794805d32dc0f5ecb20143666a6e3e4410b4dbe2",
    "scope": "repo"
  },
  {
    "bytes": 6626,
    "repoRelPath": "CAPABILITY/CAS/storage/7/b5/7b5f66f000b5d4eba468983077af9b044264daf710ba9f5933f88fdb16f4d23b",
    "scope": "repo"
  },
  {
    "bytes": 2752,
    "repoRelPath": "CAPABILITY/CAS/storage/7/bb/7bbae12fd0e57280308ce07339cb5887741780c2a07b16d94c2fbec0240bc693",
    "scope": "repo"
  },
  {
    "bytes": 1674,
    "repoRelPath": "CAPABILITY/CAS/storage/7/bd/7bd0a87b772083c02d60f699f34143ad5551ae7f2e97e568066d77f9f07c13fd",
    "scope": "repo"
  },
  {
    "bytes": 135,
    "repoRelPath": "CAPABILITY/CAS/storage/7/bf/7bfffd4065d0a12a2d28c8d5d1129bce84fe2530a948e1c160a58772fef1a235",
    "scope": "repo"
  },
  {
    "bytes": 117724,
    "repoRelPath": "CAPABILITY/CAS/storage/7/c2/7c286e74e021c26aeda479c0586bddafb9ab885b16dbf53bed71fc1e102056c3",
    "scope": "repo"
  },
  {
    "bytes": 13,
    "repoRelPath": "CAPABILITY/CAS/storage/7/c5/7c5f79de167cbb6a6b9994f40c50be97256738392a2a10c4c4ede04b57ff3083",
    "scope": "repo"
  },
  {
    "bytes": 135,
    "repoRelPath": "CAPABILITY/CAS/storage/7/c6/7c64d32d15c0f38448c3672a26ebd528ac154f7415c60081f9aa31d02ae2f88d",
    "scope": "repo"
  },
  {
    "bytes": 10987,
    "repoRelPath": "CAPABILITY/CAS/storage/7/c7/7c74c23466f1c204294ab78340cec50d95dfb6a241819517aabce89dcd6116cb",
    "scope": "repo"
  },
  {
    "bytes": 441,
    "repoRelPath": "CAPABILITY/CAS/storage/7/ca/7ca54ed08611906ef21742df135156304e8b668dfcb2f34cd7d2476c8024b553",
    "scope": "repo"
  },
  {
    "bytes": 30,
    "repoRelPath": "CAPABILITY/CAS/storage/7/d1/7d1241b553c5d98340bb71c4aeff8d1c20a6afd4caee00a19424cd8af882a22c",
    "scope": "repo"
  },
  {
    "bytes": 11807,
    "repoRelPath": "CAPABILITY/CAS/storage/7/d3/7d3816ad605a9043ea3c0573ddc07109bba7e2f491f5a14fceab2a9f7621c7ce",
    "scope": "repo"
  },
  {
    "bytes": 60273,
    "repoRelPath": "CAPABILITY/CAS/storage/7/d7/7d70b3b2b43c8662eb67c6302b100ffca0a428efad54404b2c607e8b6941b3c7",
    "scope": "repo"
  },
  {
    "bytes": 4144,
    "repoRelPath": "CAPABILITY/CAS/storage/7/d7/7d770d7d84b24636bc82e994d19b8a351a835db8730bb37271b9cc3ce51ffcd3",
    "scope": "repo"
  },
  {
    "bytes": 8736,
    "repoRelPath": "CAPABILITY/CAS/storage/7/d9/7d96516ba057f2e5be34775d71283ff5240aa64d450a57d1002dd471433dade3",
    "scope": "repo"
  },
  {
    "bytes": 239,
    "repoRelPath": "CAPABILITY/CAS/storage/7/dc/7dcf58c6eb113f69df9147395dc11ee1f5f26eada61deddc1a13dfd667921b10",
    "scope": "repo"
  },
  {
    "bytes": 5167,
    "repoRelPath": "CAPABILITY/CAS/storage/7/e3/7e31c36b43ee11a6967bbd03ff2b76f103f0a7fdb0bf39052f311cae9f3bb04c",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/7/e5/7e5a2e170a8361a914b9e92484817ca65c0bbb45eb19179ad12c378ca579d8d5",
    "scope": "repo"
  },
  {
    "bytes": 3524,
    "repoRelPath": "CAPABILITY/CAS/storage/7/e9/7e90613552621f71b32737041b5f561040d49748096c2336208ed4c55fe9ca3b",
    "scope": "repo"
  },
  {
    "bytes": 9531,
    "repoRelPath": "CAPABILITY/CAS/storage/7/ea/7ea96abe09e4c937ada3f7d9784cc352baab31168c59cf099a0e1211d1d3f39e",
    "scope": "repo"
  },
  {
    "bytes": 325,
    "repoRelPath": "CAPABILITY/CAS/storage/7/ed/7edf647a4f95ff4cc906ff138545645843651a9962b96b13a296f64fc0a61c65",
    "scope": "repo"
  },
  {
    "bytes": 60,
    "repoRelPath": "CAPABILITY/CAS/storage/7/ee/7ee96b5ac8c0eee05c6a55926e41333b87498bcad47b7c8b224fe9416ff7c871",
    "scope": "repo"
  },
  {
    "bytes": 786,
    "repoRelPath": "CAPABILITY/CAS/storage/7/f2/7f238b8bd814d0bd770e09951087274dc2821f32d60c2635cf36660f96a97f44",
    "scope": "repo"
  },
  {
    "bytes": 30,
    "repoRelPath": "CAPABILITY/CAS/storage/7/f6/7f6cf0e7285778ac749bbd0977a391e2c9089b9e4dcb49850e6cf688acb8cd50",
    "scope": "repo"
  },
  {
    "bytes": 666,
    "repoRelPath": "CAPABILITY/CAS/storage/7/f7/7f7e3d1ecc41821055a792b1bb8db86418d38bd62ca91016de213c3c3f495ea9",
    "scope": "repo"
  },
  {
    "bytes": 596,
    "repoRelPath": "CAPABILITY/CAS/storage/7/f8/7f8baaf071c4ee846383b8c2762120cf6ce76a1aad76aa2215b03b4ee5f09243",
    "scope": "repo"
  },
  {
    "bytes": 7416,
    "repoRelPath": "CAPABILITY/CAS/storage/7/fb/7fb3517dc7ffd700b2b86dd647f1ddb42144863ef1163143485dba5418688a43",
    "scope": "repo"
  },
  {
    "bytes": 714,
    "repoRelPath": "CAPABILITY/CAS/storage/7/fd/7fd2372fbd5986e005bda68d81641efa782e5097eed5e8f51ee943cded6e564c",
    "scope": "repo"
  },
  {
    "bytes": 39866,
    "repoRelPath": "CAPABILITY/CAS/storage/7/fd/7fd8f49d359e8d254afec9cbd4e620badc12b53c1048f799ce063b1542f10dd7",
    "scope": "repo"
  },
  {
    "bytes": 118840,
    "repoRelPath": "CAPABILITY/CAS/storage/8/03/80386bd36ff542f05edcce81b6b191c03e4b438c9d31df29e827c5c5e3695ca2",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/8/07/8075f3f9137b451ecaf0ac6047a881e882d10e3b11d23c5bf971ddeb483f0592",
    "scope": "repo"
  },
  {
    "bytes": 6241,
    "repoRelPath": "CAPABILITY/CAS/storage/8/0e/80eb5985fea0b56964f6cd4e4e2c3e5ea694d2be97257f0e01355994ce954ddc",
    "scope": "repo"
  },
  {
    "bytes": 8,
    "repoRelPath": "CAPABILITY/CAS/storage/8/12/8126ea41a4016cf9c25fe27053b9b548f80316c5ee080bae0a0137a5bfded309",
    "scope": "repo"
  },
  {
    "bytes": 11222,
    "repoRelPath": "CAPABILITY/CAS/storage/8/14/814efefdfc4bcd272cf42222d0f7d6785f4a1d9c01b129ded7324849771dc035",
    "scope": "repo"
  },
  {
    "bytes": 3320,
    "repoRelPath": "CAPABILITY/CAS/storage/8/16/816ddd1c5400f5dd8b98a0b939b7915436f43635198d14f725c14cbcf9a2a585",
    "scope": "repo"
  },
  {
    "bytes": 363,
    "repoRelPath": "CAPABILITY/CAS/storage/8/26/8262ebe8188ad6636c16ca5d8a0fd0f7f166bde8fa7a999cd2d3442c9a6c8bdd",
    "scope": "repo"
  },
  {
    "bytes": 949,
    "repoRelPath": "CAPABILITY/CAS/storage/8/26/82644239207fee5a3837b869547b9252b540522941e7a2a1f2e638bc673ae9ad",
    "scope": "repo"
  },
  {
    "bytes": 2951,
    "repoRelPath": "CAPABILITY/CAS/storage/8/2b/82b5cdc6be55ddec55aedd979a7050a547d4e2a4881b46d3e8e1862c6b7bfe4c",
    "scope": "repo"
  },
  {
    "bytes": 1086,
    "repoRelPath": "CAPABILITY/CAS/storage/8/2d/82d543b614345385ce02cda288a232c67677c58003ebb10b70eb19174d41a2d5",
    "scope": "repo"
  },
  {
    "bytes": 9231,
    "repoRelPath": "CAPABILITY/CAS/storage/8/30/830080b8f2fd8df0c84eb0546f57ca4af17028f72d5f33741ff8678866064555",
    "scope": "repo"
  },
  {
    "bytes": 6986,
    "repoRelPath": "CAPABILITY/CAS/storage/8/39/8395e2cea21b28571731a4a916265f44a2db24f90aa231dcd4d6854daaef02fe",
    "scope": "repo"
  },
  {
    "bytes": 20411,
    "repoRelPath": "CAPABILITY/CAS/storage/8/39/8397437e876a06856f5dfa7c9b7e2fd4a3c14c98ec156488f2d519cf06e839b6",
    "scope": "repo"
  },
  {
    "bytes": 104,
    "repoRelPath": "CAPABILITY/CAS/storage/8/40/840408712c4a9a53c5d9640199244406ca0a73d5f5a74293260a786417bfe04f",
    "scope": "repo"
  },
  {
    "bytes": 1011,
    "repoRelPath": "CAPABILITY/CAS/storage/8/46/846740313b4b19285dd90036277a6f43e5dadb7aa6103d03933bab48130e2f03",
    "scope": "repo"
  },
  {
    "bytes": 1484207,
    "repoRelPath": "CAPABILITY/CAS/storage/8/49/84935af70b59eb1d45dd51583c938238715d258e9b7504863c1c93d59b4870d0",
    "scope": "repo"
  },
  {
    "bytes": 13870,
    "repoRelPath": "CAPABILITY/CAS/storage/8/49/849a08f97519a8f16b246340850996b1174b424d62c0ac6aab52aff2bd929065",
    "scope": "repo"
  },
  {
    "bytes": 2844,
    "repoRelPath": "CAPABILITY/CAS/storage/8/49/849c59c2c24bbc8627af9e7fc1f7c5a2345c309fdbef5a0b7956c40b5a7bbd2a",
    "scope": "repo"
  },
  {
    "bytes": 1216014,
    "repoRelPath": "CAPABILITY/CAS/storage/8/4e/84e0ef473eee0bb6482a7c38203277fbc98a05eb0bc5813663afdd5a89b6e0b8",
    "scope": "repo"
  },
  {
    "bytes": 117724,
    "repoRelPath": "CAPABILITY/CAS/storage/8/4e/84e24920bb045a5769d3d09396a5197c5be002553031f5b3609ab18a00b7b09c",
    "scope": "repo"
  },
  {
    "bytes": 6424,
    "repoRelPath": "CAPABILITY/CAS/storage/8/4f/84f30090d0a45c57aaf60eb026bc89d68f3116d86f4711ee40de816b84a8ba34",
    "scope": "repo"
  },
  {
    "bytes": 3205,
    "repoRelPath": "CAPABILITY/CAS/storage/8/51/8517810b4b7338eb4215c9d1863596855100ea3655b6b445c4c25564bd239c42",
    "scope": "repo"
  },
  {
    "bytes": 676,
    "repoRelPath": "CAPABILITY/CAS/storage/8/52/8528581d0e101cc2d18aee52b8f5910ffa526cfdc8b1867eef1dfbdacb6e06ee",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/8/54/85488653ed3a7cdc4110d02cda250847b81688536935646dd7ee97d38c418dfd",
    "scope": "repo"
  },
  {
    "bytes": 25,
    "repoRelPath": "CAPABILITY/CAS/storage/8/57/857c3621b39ce7de909c09de19f9993fb4343166075e8f005e5ea9da7b31f731",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/8/59/859ccfb2cbb6d6dae9fd057a33325af2d0cebb5741e114c4b504d9dc9ec97919",
    "scope": "repo"
  },
  {
    "bytes": 1492796,
    "repoRelPath": "CAPABILITY/CAS/storage/8/5b/85b3ca3165527afea1f6f66194784611677e9fd06add0b082a5d2480aeed884b",
    "scope": "repo"
  },
  {
    "bytes": 7595,
    "repoRelPath": "CAPABILITY/CAS/storage/8/5b/85bc78171225c4ff7a67826d953671cc031ff8e1420469f454df16ad8bd4c93f",
    "scope": "repo"
  },
  {
    "bytes": 5981,
    "repoRelPath": "CAPABILITY/CAS/storage/8/5d/85d0717d5b925047cb663ce559224435de6d88a604b7ee5f6d2b736344a143db",
    "scope": "repo"
  },
  {
    "bytes": 8445,
    "repoRelPath": "CAPABILITY/CAS/storage/8/62/862484ec74ea29192f87cd71a6e194c65e202327116ef9513895f8c4dd29016f",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/8/62/862842df5c87aa9d421f44588fea71ff42107091660bf9178e1399ee9fe1bcd8",
    "scope": "repo"
  },
  {
    "bytes": 28,
    "repoRelPath": "CAPABILITY/CAS/storage/8/62/862df3c721a2b1f6f38edc64fbdda18c672a62e9c3a322114ca4b6c7afd14bfe",
    "scope": "repo"
  },
  {
    "bytes": 4618,
    "repoRelPath": "CAPABILITY/CAS/storage/8/65/8650d1a7cd62df97960b91dcc3e0231666b56423e056d642ef83f1115e3ba525",
    "scope": "repo"
  },
  {
    "bytes": 652,
    "repoRelPath": "CAPABILITY/CAS/storage/8/68/86896f99304809b68f70f903a7d0f945f0e738a26abea64539a09584b286a770",
    "scope": "repo"
  },
  {
    "bytes": 2172,
    "repoRelPath": "CAPABILITY/CAS/storage/8/6b/86bbbea49295902dfc2e5a60270578ffcbb540bdc4e524bca0aaf4b521e4a97f",
    "scope": "repo"
  },
  {
    "bytes": 4787,
    "repoRelPath": "CAPABILITY/CAS/storage/8/72/872d93efc9d01d6d5b48469a931c9b38b843ce2c474b59cad4a7d9aacef33ea6",
    "scope": "repo"
  },
  {
    "bytes": 984,
    "repoRelPath": "CAPABILITY/CAS/storage/8/77/877d14f234fca31c1e601c1638a5ef01614c4b8ac83a20e0ec0641b38771518f",
    "scope": "repo"
  },
  {
    "bytes": 379,
    "repoRelPath": "CAPABILITY/CAS/storage/8/7b/87b9589552502732e17d8d4ae858ecf1ceb161db05838f144013d2636f98aeae",
    "scope": "repo"
  },
  {
    "bytes": 476,
    "repoRelPath": "CAPABILITY/CAS/storage/8/7c/87c01ad362254e77c23793bc48ac841578f57e46b1ded363a2cd1532574729e0",
    "scope": "repo"
  },
  {
    "bytes": 2484,
    "repoRelPath": "CAPABILITY/CAS/storage/8/7f/87f58c7a15ccaeb9739e47813563a88fb99ce5f2cfc98855536c29bc0b1be3d5",
    "scope": "repo"
  },
  {
    "bytes": 259,
    "repoRelPath": "CAPABILITY/CAS/storage/8/82/8821006f5b73f6b61612392e7a76ed04353b3fe478e409f554e4c40a667ade42",
    "scope": "repo"
  },
  {
    "bytes": 2158,
    "repoRelPath": "CAPABILITY/CAS/storage/8/89/889acba78bd43a997123ac34b3b7d9814d03913a71abe8fe61ab952c00f0ac4d",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/8/8b/88bc5ac00a2d7f625973df00b023ab32c96138c790ceba3a5053ea4bf677759a",
    "scope": "repo"
  },
  {
    "bytes": 1005,
    "repoRelPath": "CAPABILITY/CAS/storage/8/8b/88bf416e8ed52663bc8c8e1066c677c7f6cb70807014fe0dfb0b58e7551ea4e6",
    "scope": "repo"
  },
  {
    "bytes": 194,
    "repoRelPath": "CAPABILITY/CAS/storage/8/8d/88d1411d0a066ced56f204fecb7ea4d746da60b4df9661af0c76c7cae82c63a3",
    "scope": "repo"
  },
  {
    "bytes": 117725,
    "repoRelPath": "CAPABILITY/CAS/storage/8/8f/88f26e9ed4af65d06c8e9702eb3985c85d01dd5eb052a326a28009940cb56420",
    "scope": "repo"
  },
  {
    "bytes": 10192,
    "repoRelPath": "CAPABILITY/CAS/storage/8/8f/88fdb60184fae85de0f335ea8fda9bb023f67b5f9324090ccbd2e462f2ddd812",
    "scope": "repo"
  },
  {
    "bytes": 290,
    "repoRelPath": "CAPABILITY/CAS/storage/8/90/890e4391efeb9a2254f4e2d4c40af018517b211f8ff914775bdbe77eea9e5ff7",
    "scope": "repo"
  },
  {
    "bytes": 2201,
    "repoRelPath": "CAPABILITY/CAS/storage/8/92/89220d31ebca9b3945bcd0a8cc928e8cd2071c6baf2debf071a78f6dd11b33a0",
    "scope": "repo"
  },
  {
    "bytes": 11828,
    "repoRelPath": "CAPABILITY/CAS/storage/8/94/894586bd6bde897c25851e12dba019411fb4c0b6a1c46c7e5c89089b5c1a8afc",
    "scope": "repo"
  },
  {
    "bytes": 883,
    "repoRelPath": "CAPABILITY/CAS/storage/8/9a/89a047ade08194c2873302163d042b18ca34f7986c9051a2d678991a42652654",
    "scope": "repo"
  },
  {
    "bytes": 135,
    "repoRelPath": "CAPABILITY/CAS/storage/8/9a/89ae5cd4d8bdaa8921af9e18a7136905bec780e41c0dde1200b43ad40cd972b9",
    "scope": "repo"
  },
  {
    "bytes": 981,
    "repoRelPath": "CAPABILITY/CAS/storage/8/9b/89b2253e442691c5b649146e835884293cff9c4eacf6918b014bac8bdedc3d86",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/8/9c/89caffe58323a969715016e2af578ea1cf673598583d3f6c88577e709c6aa886",
    "scope": "repo"
  },
  {
    "bytes": 117725,
    "repoRelPath": "CAPABILITY/CAS/storage/8/9e/89e213821f1a4f1701024cf586ab42e3afdae1f23d29d082172437a025f3eb12",
    "scope": "repo"
  },
  {
    "bytes": 97,
    "repoRelPath": "CAPABILITY/CAS/storage/8/a3/8a3527227c1e5d59e69699bc64522c58631d280115ceb2c08b20e89e5d2c8a87",
    "scope": "repo"
  },
  {
    "bytes": 43,
    "repoRelPath": "CAPABILITY/CAS/storage/8/a4/8a44b619209764e3b71e560cb35efc02c217dbb52a6b4219df25abceb3c6517b",
    "scope": "repo"
  },
  {
    "bytes": 955,
    "repoRelPath": "CAPABILITY/CAS/storage/8/a8/8a895b0c4e7761e5508fa0678b36d3fd7e8e2c3dc7c3f79ec1874c9f12625802",
    "scope": "repo"
  },
  {
    "bytes": 402,
    "repoRelPath": "CAPABILITY/CAS/storage/8/af/8af045c29bea9ea54a0b66f51217bdc493945b092a43c015fdba3b32c4fd916f",
    "scope": "repo"
  },
  {
    "bytes": 238,
    "repoRelPath": "CAPABILITY/CAS/storage/8/b1/8b1d2b6f531cc860209516eecfc33f18609c7c5f83d52ba7d9fe877044d5d1db",
    "scope": "repo"
  },
  {
    "bytes": 18,
    "repoRelPath": "CAPABILITY/CAS/storage/8/b6/8b6c247cddac05b16da7052affd8629447f9ec927ac87c7aa794075b3dfb24d4",
    "scope": "repo"
  },
  {
    "bytes": 172,
    "repoRelPath": "CAPABILITY/CAS/storage/8/b9/8b98f8cd2e3e3e6bb626b8b9498edb87bbffae49a374374bdd4bb2d366784add",
    "scope": "repo"
  },
  {
    "bytes": 326,
    "repoRelPath": "CAPABILITY/CAS/storage/8/bb/8bbfa76e6ac2309b3a569a1838b8e32e390af26192e476881e33310652c8010a",
    "scope": "repo"
  },
  {
    "bytes": 1665,
    "repoRelPath": "CAPABILITY/CAS/storage/8/bd/8bd225cd1aa673e256b30876bd361cb959d687d7176bb55f5e19bdd20983dce0",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/8/c1/8c1d333f9150b4fd5fb7665f5c2a70bb2ee54875f194dd86cd5eec8c6e6ea38d",
    "scope": "repo"
  },
  {
    "bytes": 623,
    "repoRelPath": "CAPABILITY/CAS/storage/8/c3/8c3b5b3c2c3393bb1cf332c74e6046c027306f2f4f5ad897d5cad204cd5e8306",
    "scope": "repo"
  },
  {
    "bytes": 4422,
    "repoRelPath": "CAPABILITY/CAS/storage/8/c4/8c44c9da2bee823b08b61d023753093af17be1228b393f586c023e8edfbd0aa6",
    "scope": "repo"
  },
  {
    "bytes": 2645,
    "repoRelPath": "CAPABILITY/CAS/storage/8/cb/8cb015f86c0ed571afbedf9ab57b026802d8740131ba69b317d45267c31c81db",
    "scope": "repo"
  },
  {
    "bytes": 6575,
    "repoRelPath": "CAPABILITY/CAS/storage/8/cd/8cde3b2b54f329110916642cbc9c6eec3898256c0daba7e471197ff16c125e95",
    "scope": "repo"
  },
  {
    "bytes": 74,
    "repoRelPath": "CAPABILITY/CAS/storage/8/cf/8cf1497f6b1529deeb3969240ff3ad6aa8a139ed7de31c975f4b431b705cfbcc",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/8/d3/8d38801afbf775ad182ccc8e1c0d5ba53110ec14a5e104f93b418a19f22c44e0",
    "scope": "repo"
  },
  {
    "bytes": 10110,
    "repoRelPath": "CAPABILITY/CAS/storage/8/d8/8d8219e6048bda592c16d6e5c07a82d7f879fbcd6e04a06fe37afa87db551123",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/8/dd/8dd150d708e9240b1b47e60f4148f97e72aafe612aba49b12a4d13e56e2501ad",
    "scope": "repo"
  },
  {
    "bytes": 5340,
    "repoRelPath": "CAPABILITY/CAS/storage/8/e0/8e0c83102b9270fc1a9a9f31485cb7be6e80e0789410a715f0334be7466c07ba",
    "scope": "repo"
  },
  {
    "bytes": 6579,
    "repoRelPath": "CAPABILITY/CAS/storage/8/e3/8e337ed79f2ca49b2a128ceb02f886251039066dc74dcf70cdc42ad266e3e75b",
    "scope": "repo"
  },
  {
    "bytes": 522,
    "repoRelPath": "CAPABILITY/CAS/storage/8/e3/8e3efb8d4de8cc5a45101422437afe1fb3580067317267d8875b08bc1edd6593",
    "scope": "repo"
  },
  {
    "bytes": 8555,
    "repoRelPath": "CAPABILITY/CAS/storage/8/e4/8e40d30d326bc60439cbda7f90d687d0bfc1b373ccb4466f87ab9c8982c91787",
    "scope": "repo"
  },
  {
    "bytes": 7824,
    "repoRelPath": "CAPABILITY/CAS/storage/8/e5/8e50d690eadec6250358662bfebcb0984ac7127b84808b6232db9f05c60c75a5",
    "scope": "repo"
  },
  {
    "bytes": 3158,
    "repoRelPath": "CAPABILITY/CAS/storage/8/e8/8e84b5225f91db4ec94a78138268cc639b2c908b4bed1dfa81da995660154098",
    "scope": "repo"
  },
  {
    "bytes": 552,
    "repoRelPath": "CAPABILITY/CAS/storage/8/e8/8e88f2c17e5391f3624fdaefe3a51f71f3f8ef080de24a5d9e1fff5ecb80b37a",
    "scope": "repo"
  },
  {
    "bytes": 413,
    "repoRelPath": "CAPABILITY/CAS/storage/8/e8/8e8b316c1d60d6aa97a209bfc9453b79c7c83c591341f0f87f178962daf72895",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/8/eb/8eb19223d8d84c78b349adb7ac8c28f3aeba76c8c99ecbb6edfbc334a3570b65",
    "scope": "repo"
  },
  {
    "bytes": 184,
    "repoRelPath": "CAPABILITY/CAS/storage/8/eb/8ebecfb5ea3b40992ed79d63fd6df816555d97cc540bc309b3c2efd3ab75ff7f",
    "scope": "repo"
  },
  {
    "bytes": 3673,
    "repoRelPath": "CAPABILITY/CAS/storage/8/ec/8eca016e6f46eafbf9966c24600688261abb08eabb26084d846c742f06a5e7e4",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/8/ef/8ef6d95f86bdd19772e1608d3a9a426550263ae6fd8e194d4b2899b5c6e3429d",
    "scope": "repo"
  },
  {
    "bytes": 6404,
    "repoRelPath": "CAPABILITY/CAS/storage/8/f1/8f1cf5fa3bc36c2b7eb53e250c8e5429936ff7aaaf1d7b19569acdcbd3385731",
    "scope": "repo"
  },
  {
    "bytes": 259,
    "repoRelPath": "CAPABILITY/CAS/storage/8/f2/8f20084ce4aa86e21e5b3c81e753c96e4146d5b7add43288f2c119d634063a44",
    "scope": "repo"
  },
  {
    "bytes": 2557,
    "repoRelPath": "CAPABILITY/CAS/storage/8/f3/8f31e7e3e8a2672afb9252fe6daf6fd29dbd2e29d77e6c1d52349efd1f42d793",
    "scope": "repo"
  },
  {
    "bytes": 1068,
    "repoRelPath": "CAPABILITY/CAS/storage/8/f8/8f89fcf4e58617c6a650a1d30ffcf668e7436ce032d1949c1274ca28eb9db64c",
    "scope": "repo"
  },
  {
    "bytes": 7530,
    "repoRelPath": "CAPABILITY/CAS/storage/8/f8/8f8d3c75322cee99360f3fc861053dd5fd5517c8e5032bddb1d9e72050649f13",
    "scope": "repo"
  },
  {
    "bytes": 1048576,
    "repoRelPath": "CAPABILITY/CAS/storage/8/f9/8f990ba0b577b51cf009ea049368c16bbda1b21e1b93be07a824758bb253c39b",
    "scope": "repo"
  },
  {
    "bytes": 11000,
    "repoRelPath": "CAPABILITY/CAS/storage/8/fd/8fd73c2a72fa41a332bddda9fa07b8a9fa0cf2625296385f83c79b75199e6e04",
    "scope": "repo"
  },
  {
    "bytes": 4066,
    "repoRelPath": "CAPABILITY/CAS/storage/8/fd/8fdb1ea1508f42e5764fe7b9ecd7c1ff665cc6b204a19c411de000538f79a6d6",
    "scope": "repo"
  },
  {
    "bytes": 14047,
    "repoRelPath": "CAPABILITY/CAS/storage/8/ff/8ff455871c95721c6fc0b49b680b26668f2d82101db092bdb31fee33ba199d79",
    "scope": "repo"
  },
  {
    "bytes": 256,
    "repoRelPath": "CAPABILITY/CAS/storage/9/01/90115de2941bdbd5cddf1cdb07c60670ee1e97e78334c48ae617a8655f9651d3",
    "scope": "repo"
  },
  {
    "bytes": 6413,
    "repoRelPath": "CAPABILITY/CAS/storage/9/06/9068648aa5f8ecd111de19ed9c4bd1da1db1ed534345de5981f6e2b757e72d3a",
    "scope": "repo"
  },
  {
    "bytes": 5025,
    "repoRelPath": "CAPABILITY/CAS/storage/9/07/907850c000e4e3a12771f36551f3b747ab3d8ca1d4b816240fc8e2ae3eeb0667",
    "scope": "repo"
  },
  {
    "bytes": 3749,
    "repoRelPath": "CAPABILITY/CAS/storage/9/0b/90b7428fb48b33c548d797c0ef9c37614ee081f2159c4ef2eff34ec657760498",
    "scope": "repo"
  },
  {
    "bytes": 575,
    "repoRelPath": "CAPABILITY/CAS/storage/9/0e/90edc143b6f7d902661a7714816d4ec85eaa7d7d6dcddddc4748cbd2c2ccb0a9",
    "scope": "repo"
  },
  {
    "bytes": 2056,
    "repoRelPath": "CAPABILITY/CAS/storage/9/12/912f999ed4c0d529d7aedf78f014de9a5383cf09a4870c008f1823d5d1013ba4",
    "scope": "repo"
  },
  {
    "bytes": 1477,
    "repoRelPath": "CAPABILITY/CAS/storage/9/14/91499c1f357d50272de48ceffa85595afd52f94fd79760b96dae4f17b02222ee",
    "scope": "repo"
  },
  {
    "bytes": 9,
    "repoRelPath": "CAPABILITY/CAS/storage/9/16/916f0027a575074ce72a331777c3478d6513f786a591bd892da1a577bf2335f9",
    "scope": "repo"
  },
  {
    "bytes": 8169,
    "repoRelPath": "CAPABILITY/CAS/storage/9/1c/91cfb960c940acde1e89b79c787b370ce1137a48e3c817079b52f64b297012e3",
    "scope": "repo"
  },
  {
    "bytes": 14367,
    "repoRelPath": "CAPABILITY/CAS/storage/9/1f/91fece15fd8f1c5c015bb476b931b11d73b58f96b913371a2884653e9fa9060f",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/9/21/921bf1a963dceb09211bed0fd0fa1418927b942e07385c2d04d8e2940390e359",
    "scope": "repo"
  },
  {
    "bytes": 3980,
    "repoRelPath": "CAPABILITY/CAS/storage/9/23/9230f6e1cd2e30dd9c475e8c761b165c54d564cb5c1d01bb95e98de7e2128ca3",
    "scope": "repo"
  },
  {
    "bytes": 1774,
    "repoRelPath": "CAPABILITY/CAS/storage/9/24/9248c8e8a98d87aa619a99fa257a58968af5794db051b8b5a58c7d93e0667484",
    "scope": "repo"
  },
  {
    "bytes": 454,
    "repoRelPath": "CAPABILITY/CAS/storage/9/26/926ec2edabcc542e749ef124eb6f41a4044ba89f07eb801d12b8e1e5d5c4b3ca",
    "scope": "repo"
  },
  {
    "bytes": 5332,
    "repoRelPath": "CAPABILITY/CAS/storage/9/2a/92a1038ce8679ef799112764a52e101f3ec76a299beb55b05899fd9a020e2cdb",
    "scope": "repo"
  },
  {
    "bytes": 7156,
    "repoRelPath": "CAPABILITY/CAS/storage/9/2b/92b2338068b56e18fa46e123c0db4710f38f2c915bbc9a13513b441fa3b976e1",
    "scope": "repo"
  },
  {
    "bytes": 4240,
    "repoRelPath": "CAPABILITY/CAS/storage/9/2f/92f87b15f39047d1d7a3017a8d577e6c3da5d60316f23019a50cf2ac0f9947b4",
    "scope": "repo"
  },
  {
    "bytes": 6717,
    "repoRelPath": "CAPABILITY/CAS/storage/9/31/9311d95d57f1127a589dc609974e135a6d51a36fdf6d119db4eec7c1e034f7f1",
    "scope": "repo"
  },
  {
    "bytes": 64065,
    "repoRelPath": "CAPABILITY/CAS/storage/9/32/93210e6a1cb5bde806e5b7aeb45f8714076ada71b924659c550861cfb2ba56e5",
    "scope": "repo"
  },
  {
    "bytes": 39866,
    "repoRelPath": "CAPABILITY/CAS/storage/9/32/932e31fde94156679a9edd816a4ee64c98a3b865929175fa7307d2c79a19183d",
    "scope": "repo"
  },
  {
    "bytes": 295,
    "repoRelPath": "CAPABILITY/CAS/storage/9/33/9339973a1b681980ea902d9706a3fe241b764617160f7dd2771cb236c21fdd26",
    "scope": "repo"
  },
  {
    "bytes": 1177,
    "repoRelPath": "CAPABILITY/CAS/storage/9/36/936a0ad049d1ce9d7407af8c5254cb276cea5ac99677d3276e0d2025ff439612",
    "scope": "repo"
  },
  {
    "bytes": 257,
    "repoRelPath": "CAPABILITY/CAS/storage/9/3b/93bdcd24a9abd9718dbd1f55e6b2c5e84c09c10f02b4c6d399004488bb70c6ba",
    "scope": "repo"
  },
  {
    "bytes": 4542,
    "repoRelPath": "CAPABILITY/CAS/storage/9/3f/93f305c900a44ad04fccd6e079ec4bdee09e35c0011fff27757267a7bb15b14a",
    "scope": "repo"
  },
  {
    "bytes": 3920,
    "repoRelPath": "CAPABILITY/CAS/storage/9/46/94663b7e8085d5449906f9a0e2efc7b225ec0595f6ef95cb0e2dbc9285420acd",
    "scope": "repo"
  },
  {
    "bytes": 6535,
    "repoRelPath": "CAPABILITY/CAS/storage/9/48/948d6d46ecb5345d3835a515ad420959c11040313d9937bdadc7e99b710d9584",
    "scope": "repo"
  },
  {
    "bytes": 207,
    "repoRelPath": "CAPABILITY/CAS/storage/9/4a/94a0a2bbdd6731b585553930e6ea26c03f4ef7ac4f39241c65e216a076bb7958",
    "scope": "repo"
  },
  {
    "bytes": 14408,
    "repoRelPath": "CAPABILITY/CAS/storage/9/4a/94ae1081594790eca9e08ebd74dc8895e7d712f71dc65e303906e32885abb5d1",
    "scope": "repo"
  },
  {
    "bytes": 11300,
    "repoRelPath": "CAPABILITY/CAS/storage/9/4d/94d2f80f61d51593d504a3fef5aed46f0ba88307c8c807c65170c8cd484ca8d7",
    "scope": "repo"
  },
  {
    "bytes": 16056,
    "repoRelPath": "CAPABILITY/CAS/storage/9/50/950062205a7542a2af0e8bc0bfdb0c2ff40b20aee2fb35214d81917aacae88e8",
    "scope": "repo"
  },
  {
    "bytes": 20,
    "repoRelPath": "CAPABILITY/CAS/storage/9/50/950a08beb98585d6a3e12541646793e20014d6144e30a85c47db2839ca5201c4",
    "scope": "repo"
  },
  {
    "bytes": 137,
    "repoRelPath": "CAPABILITY/CAS/storage/9/54/954f8ec375bcb7de83f432b3fbff968cad6379234adb65ccb8c54c42e78d0c91",
    "scope": "repo"
  },
  {
    "bytes": 120,
    "repoRelPath": "CAPABILITY/CAS/storage/9/55/9555d6faf94236c7b483810faa656e9b5687c1a0de0b299d16a3e1b7333d66ba",
    "scope": "repo"
  },
  {
    "bytes": 62579,
    "repoRelPath": "CAPABILITY/CAS/storage/9/57/9579d77c1f7743ce0df37ba8f451c8a50caddcadb2abfb399953f78e549bb903",
    "scope": "repo"
  },
  {
    "bytes": 4677,
    "repoRelPath": "CAPABILITY/CAS/storage/9/59/9590f6a09aa11378d763769684b223f080f2f826f78bbff6eb6be980da76ca3c",
    "scope": "repo"
  },
  {
    "bytes": 5802,
    "repoRelPath": "CAPABILITY/CAS/storage/9/61/961087568db505e71310c5902ff0ccc93725d617af3cec7eed1e4706f1d90ac8",
    "scope": "repo"
  },
  {
    "bytes": 10959,
    "repoRelPath": "CAPABILITY/CAS/storage/9/63/9630dcdcb78efc84c13c8b9d3f140f23c7f15805c8935c6d2865bf7475c4394a",
    "scope": "repo"
  },
  {
    "bytes": 359,
    "repoRelPath": "CAPABILITY/CAS/storage/9/65/965576510f3ecf13de92c0ab7fdc0883edca8829ecb5159c749a8de35788d149",
    "scope": "repo"
  },
  {
    "bytes": 343,
    "repoRelPath": "CAPABILITY/CAS/storage/9/65/965ee570b0c46674732deb014a47a5f88d98bfe2897c0af61c3fc14502b2739c",
    "scope": "repo"
  },
  {
    "bytes": 2253,
    "repoRelPath": "CAPABILITY/CAS/storage/9/6a/96a37ceb1fed24f28ba00f762c642dcd5cf3204cf514ad96030548a569339b24",
    "scope": "repo"
  },
  {
    "bytes": 38853,
    "repoRelPath": "CAPABILITY/CAS/storage/9/6a/96af3655f8e5b3f48bba90d36253e4cc4070455348b2ef6cf921972c50004375",
    "scope": "repo"
  },
  {
    "bytes": 352,
    "repoRelPath": "CAPABILITY/CAS/storage/9/6d/96d7bb54473aaeaf0b401db3b3e0aa165eedb6eb44059e593c7e3cf79e761d0e",
    "scope": "repo"
  },
  {
    "bytes": 546,
    "repoRelPath": "CAPABILITY/CAS/storage/9/6d/96d985c6f292fdfdd3002071c116042c69d16746b68a3348080b65395c5b66ea",
    "scope": "repo"
  },
  {
    "bytes": 1216014,
    "repoRelPath": "CAPABILITY/CAS/storage/9/6f/96f33a90762de58cc3ce58b1dd527fe36dda8a65323d82b3c20be4c9a8666170",
    "scope": "repo"
  },
  {
    "bytes": 2808,
    "repoRelPath": "CAPABILITY/CAS/storage/9/71/971e35edcddce070c9ede342c8d49abc412ada925bb87764f6de8f4a7ab6b0b0",
    "scope": "repo"
  },
  {
    "bytes": 6851,
    "repoRelPath": "CAPABILITY/CAS/storage/9/72/9723b70ac67beace38edece2c4f03c4405ab8c58faaa3ec01c8901565fda28fc",
    "scope": "repo"
  },
  {
    "bytes": 8728,
    "repoRelPath": "CAPABILITY/CAS/storage/9/75/975182a9c5e732db5891d5243db6211239ec8878a6e1d1b7ecb2f2a752b4fee9",
    "scope": "repo"
  },
  {
    "bytes": 4939,
    "repoRelPath": "CAPABILITY/CAS/storage/9/78/97850d4e8df38900806c4a3ef44af0fe8708da74fa57e1212d0062288e5e4b73",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/9/7a/97a97f450c199bb3ea5e89d87443497a6e6615dec6018fdcc4b64118ce0a4bb4",
    "scope": "repo"
  },
  {
    "bytes": 15473,
    "repoRelPath": "CAPABILITY/CAS/storage/9/7c/97ce508957e44e7b72bfef37c2a7311a9f403dac26865b0f2179cda793657620",
    "scope": "repo"
  },
  {
    "bytes": 12,
    "repoRelPath": "CAPABILITY/CAS/storage/9/7c/97ce55589c7444a2491e9ac300ba78fa97c2c9cd5a0198c08f716f1604a46051",
    "scope": "repo"
  },
  {
    "bytes": 59,
    "repoRelPath": "CAPABILITY/CAS/storage/9/7e/97ef4603b14aa1858e0e9cbf57da9e7c839ddeaa763dd66ff74b0582a230802c",
    "scope": "repo"
  },
  {
    "bytes": 528,
    "repoRelPath": "CAPABILITY/CAS/storage/9/7f/97f1c105968feb11e341a7e7cfd26683a68fcc3b2cc86c421fef5f4419d67612",
    "scope": "repo"
  },
  {
    "bytes": 325,
    "repoRelPath": "CAPABILITY/CAS/storage/9/86/986d2188ac838ccd28238cda4f47680c2faa0551cf5a7a51eb64f35699bbe83c",
    "scope": "repo"
  },
  {
    "bytes": 805,
    "repoRelPath": "CAPABILITY/CAS/storage/9/8c/98cf63843961c0b3b385af66eb825554488984bee9477c3b80f3517cf9d93f0b",
    "scope": "repo"
  },
  {
    "bytes": 642,
    "repoRelPath": "CAPABILITY/CAS/storage/9/93/99309c9ac129f2168249efab61745de2f159cabcd5abdf0879b9864e59ec7cb4",
    "scope": "repo"
  },
  {
    "bytes": 4509,
    "repoRelPath": "CAPABILITY/CAS/storage/9/96/99668c46a7c469a647898b3dc8b8db914adc359c2789b3900ecb3664c943cd3e",
    "scope": "repo"
  },
  {
    "bytes": 6999,
    "repoRelPath": "CAPABILITY/CAS/storage/9/99/9997ad9d07d2e2f065568ba2412babe74960a961d3a32ac7f9179485e8cd3412",
    "scope": "repo"
  },
  {
    "bytes": 4247,
    "repoRelPath": "CAPABILITY/CAS/storage/9/9c/99c53495b67f86e5996ffa3afa34dd4f98290e581f38c28192aa277f8b2622f2",
    "scope": "repo"
  },
  {
    "bytes": 12,
    "repoRelPath": "CAPABILITY/CAS/storage/9/9c/99c6780f6f760fd705f59b0078b34e409268fa742a629c17201403edecc3e68f",
    "scope": "repo"
  },
  {
    "bytes": 7765,
    "repoRelPath": "CAPABILITY/CAS/storage/9/9d/99d0ede4ed7710767b90d37efd0ea9444ecb41d9c82ae38a79f0952dd25c22f3",
    "scope": "repo"
  },
  {
    "bytes": 12924,
    "repoRelPath": "CAPABILITY/CAS/storage/9/a4/9a44bb7ab7c321bd4aaa4f012cbc170a8ef719666983be98f2f2694071431d08",
    "scope": "repo"
  },
  {
    "bytes": 1884,
    "repoRelPath": "CAPABILITY/CAS/storage/9/a5/9a533360ab9b30ccfb720b0b85b8b0d22abe306ccac185e52060add5c7603e60",
    "scope": "repo"
  },
  {
    "bytes": 2014,
    "repoRelPath": "CAPABILITY/CAS/storage/9/a5/9a5b55e5276fc2cd74f248515258a42cd98a75a50aaa7a6db4807afad584c30a",
    "scope": "repo"
  },
  {
    "bytes": 32855,
    "repoRelPath": "CAPABILITY/CAS/storage/9/ac/9ac2bb0dc0b3cf654d63bd392817cead5f78d9349263fc3dca5af2e094f67bdc",
    "scope": "repo"
  },
  {
    "bytes": 3667,
    "repoRelPath": "CAPABILITY/CAS/storage/9/ac/9acc1b9772579720e3c8bc19a80a9a3908323b411c6d06d04952323668f4efe4",
    "scope": "repo"
  },
  {
    "bytes": 6979,
    "repoRelPath": "CAPABILITY/CAS/storage/9/ad/9ade0400cab4fecc0e0361c0e6bf3a97bf7fa53c499d6a9f371f94f90ce44e9d",
    "scope": "repo"
  },
  {
    "bytes": 1447,
    "repoRelPath": "CAPABILITY/CAS/storage/9/b0/9b06de9ea7dc450151f097da3d720c30c5feb18660c00c328026796ad250adc2",
    "scope": "repo"
  },
  {
    "bytes": 1361,
    "repoRelPath": "CAPABILITY/CAS/storage/9/b0/9b0f3936c48a01b1ed652e0c5fc0a94fa12d74007cefa7f0142b195a75f8aa9a",
    "scope": "repo"
  },
  {
    "bytes": 805,
    "repoRelPath": "CAPABILITY/CAS/storage/9/b3/9b32b5528c69f158d3b63a676f9e4edcf4a2691dc94909f27392ac0b6dbd9968",
    "scope": "repo"
  },
  {
    "bytes": 7759,
    "repoRelPath": "CAPABILITY/CAS/storage/9/b9/9b93869d5beba9af15c0c733f4cd46976b6b4fbdfcf0694a197490831790e800",
    "scope": "repo"
  },
  {
    "bytes": 235,
    "repoRelPath": "CAPABILITY/CAS/storage/9/c3/9c3035e3d548c341483a5cccffc706af6565a30a8c4d79ace9d64bef1bfe577b",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/9/c4/9c44558cf2909720d4a9bdc982bc0382ebded5e46d084572c2a9815d9305531a",
    "scope": "repo"
  },
  {
    "bytes": 1796,
    "repoRelPath": "CAPABILITY/CAS/storage/9/c8/9c80b3656a8306c08275c78c906fa2302bb8f8b3f8ed4bc111eb6c5b0741bc06",
    "scope": "repo"
  },
  {
    "bytes": 8,
    "repoRelPath": "CAPABILITY/CAS/storage/9/ca/9ca298d52a030032a083a8e31032417bbda4b71315cdf7268d0d2a73b637b623",
    "scope": "repo"
  },
  {
    "bytes": 20,
    "repoRelPath": "CAPABILITY/CAS/storage/9/cc/9ccd7d0cb2ff69d32dc7a30d5b5f78827acf19a850ca739e0175e253f69d9d71",
    "scope": "repo"
  },
  {
    "bytes": 4286,
    "repoRelPath": "CAPABILITY/CAS/storage/9/d1/9d16139b784f10f4d1a507ad02b84cb513c6b8f80268a20b5347ac2b55ddce08",
    "scope": "repo"
  },
  {
    "bytes": 13232,
    "repoRelPath": "CAPABILITY/CAS/storage/9/e0/9e021bc0156eb32871359fc926fc062eedf129a527bd764ba310073356fdb6b9",
    "scope": "repo"
  },
  {
    "bytes": 23376,
    "repoRelPath": "CAPABILITY/CAS/storage/9/e8/9e8428c2a2bd2213a8f9d539da8efc80fa227c702e9704c1fee0bc92fdfda56d",
    "scope": "repo"
  },
  {
    "bytes": 9337,
    "repoRelPath": "CAPABILITY/CAS/storage/9/e8/9e865074fa351084453200e79cf93a7df5a87081c3cf6d5efed99e5d2b169691",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/9/e8/9e892ee84871eff7afb61e11738ef397756abd135b41070ccabd0c2ab3419538",
    "scope": "repo"
  },
  {
    "bytes": 930,
    "repoRelPath": "CAPABILITY/CAS/storage/9/e8/9e8c6ca79329f6db88f136d6487ea216890e50c4251e570885d538a748d1e3f2",
    "scope": "repo"
  },
  {
    "bytes": 227,
    "repoRelPath": "CAPABILITY/CAS/storage/9/ee/9ee4fa50d2178bc3779f6fb9752521407e7a154102ff9e19baaac655983717cc",
    "scope": "repo"
  },
  {
    "bytes": 176,
    "repoRelPath": "CAPABILITY/CAS/storage/9/ee/9eebf32bd6946553becc1cc946fcc56288566d10203f3dd0394b47cb77d1e65e",
    "scope": "repo"
  },
  {
    "bytes": 1298,
    "repoRelPath": "CAPABILITY/CAS/storage/9/f1/9f19a652e02ac8c045cb26935bec0eadef5986fe884eacd4aa8727e81eb493a4",
    "scope": "repo"
  },
  {
    "bytes": 4,
    "repoRelPath": "CAPABILITY/CAS/storage/9/f8/9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/9/f8/9f8ace4143f6d48639e14ce2b2ca67136dc8032a1128104aa8920b48610034ea",
    "scope": "repo"
  },
  {
    "bytes": 3766,
    "repoRelPath": "CAPABILITY/CAS/storage/9/fa/9fabf27694f787cc7c998f193ece381378f8e97c2af6d245626871705d58b19f",
    "scope": "repo"
  },
  {
    "bytes": 7628,
    "repoRelPath": "CAPABILITY/CAS/storage/a/01/a01b4ad480da2778709a09ff3dbf33b4cc816ff08e95a835cab5c36e50671663",
    "scope": "repo"
  },
  {
    "bytes": 13,
    "repoRelPath": "CAPABILITY/CAS/storage/a/0a/a0a669dac52688c4d45318ef9f8c31cbb2620097a0b7e006c12c3f993431935e",
    "scope": "repo"
  },
  {
    "bytes": 39866,
    "repoRelPath": "CAPABILITY/CAS/storage/a/10/a10689941e552ab3600611864596223653ffb1f3db6a8e023dfb210c20cd7c6f",
    "scope": "repo"
  },
  {
    "bytes": 407,
    "repoRelPath": "CAPABILITY/CAS/storage/a/12/a1264289269667dcc463d38d5fffda26a601703dcae81c828afca33095391c08",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/a/1b/a1b93e4c095824efec3a2d5c5fe52d21f876ba16c57a13fd1b3931a7eb22a218",
    "scope": "repo"
  },
  {
    "bytes": 2951,
    "repoRelPath": "CAPABILITY/CAS/storage/a/1c/a1c36ea3cddd4f09f4df7cf5efad24d94bf8e58bad3f613806be32fff3f2fafc",
    "scope": "repo"
  },
  {
    "bytes": 9232,
    "repoRelPath": "CAPABILITY/CAS/storage/a/1e/a1e0d59d5f99e66826e15903c58f8f78dc13cba4f3007c8d5bbca843fc4dcfc1",
    "scope": "repo"
  },
  {
    "bytes": 6554,
    "repoRelPath": "CAPABILITY/CAS/storage/a/1e/a1eae3be70c724437aedb4db5890e365b27eb6913a0cf2cab47828db4beb58fc",
    "scope": "repo"
  },
  {
    "bytes": 22,
    "repoRelPath": "CAPABILITY/CAS/storage/a/22/a22b6d64000133b40224c36fc41c3d60bc920b80ddcf72a16fc7e7d316446fe8",
    "scope": "repo"
  },
  {
    "bytes": 241,
    "repoRelPath": "CAPABILITY/CAS/storage/a/26/a262fdbd84ce7fbb5081c8cca5af8340167c78684a42559c06417cb549750540",
    "scope": "repo"
  },
  {
    "bytes": 350,
    "repoRelPath": "CAPABILITY/CAS/storage/a/26/a26a8a3d859cecf554a6dbccd3f2c7b7ee3b9e5b2cc37f63b41cb445b0949dd1",
    "scope": "repo"
  },
  {
    "bytes": 8596,
    "repoRelPath": "CAPABILITY/CAS/storage/a/27/a27c71474f5308b67276297326b790de61b3231ce893e01b508bf7cd03bbf28e",
    "scope": "repo"
  },
  {
    "bytes": 89,
    "repoRelPath": "CAPABILITY/CAS/storage/a/28/a280f6fa0ee0b7184c55c75b647bdfd6f8490b57f9d131c189d82327a8a8941e",
    "scope": "repo"
  },
  {
    "bytes": 2847,
    "repoRelPath": "CAPABILITY/CAS/storage/a/2a/a2aeae3213f3d682ba15e5c63924094987d5cece5bced994caa91378f86c5087",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/a/31/a31918646dbdbca2a705b116fa95079a8c75968dad6eb4292b1424962b318c97",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/a/33/a33aab36bbdaeb9001dcc7a5237b05895ecb311cbd7f756919dad9c4ed792a82",
    "scope": "repo"
  },
  {
    "bytes": 7315,
    "repoRelPath": "CAPABILITY/CAS/storage/a/33/a33f73023ea210f1e5e1c81b100e7cdf77bc31bcf49bc95cd3a7b0d200541eed",
    "scope": "repo"
  },
  {
    "bytes": 8189,
    "repoRelPath": "CAPABILITY/CAS/storage/a/34/a3437835b224d5ff5806504e77e8f2fa27bf2605daa644ebd6b3e46b4abd1b9e",
    "scope": "repo"
  },
  {
    "bytes": 4887,
    "repoRelPath": "CAPABILITY/CAS/storage/a/3b/a3b446f261311b3c576e4730a045df9720adb985a4a2cab392a383417fc49fcf",
    "scope": "repo"
  },
  {
    "bytes": 1413,
    "repoRelPath": "CAPABILITY/CAS/storage/a/3b/a3bc9e0eb1817ba32ec02b31b86015a15a6e2fdf206f7bab096893e08ffaf0b8",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/a/3e/a3e9a05750d52fe7168bb71489884987f74a7e0ff0a70b437132829956a308b0",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/a/47/a47bd6c666f6b6296ad5041005b9ae0a23107e735348c8956e26bd438c834fcd",
    "scope": "repo"
  },
  {
    "bytes": 923,
    "repoRelPath": "CAPABILITY/CAS/storage/a/48/a488101bb48f862986d6c94c21d87704655af36bb0f99c21004f8ac2dd66835f",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/a/48/a48d7c5de947411bdbf0aedb73d80759924d3abc2134b346feaccbaede092aa5",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/a/4b/a4b4aa809465e38d15ab4a76cd9c759c87501ee1e8cc7c0c6bab33149f37cdfb",
    "scope": "repo"
  },
  {
    "bytes": 523,
    "repoRelPath": "CAPABILITY/CAS/storage/a/4e/a4eaf71cde500b4676219d6a2b91ef98dfa20315f17ab1604aa6e5f1d190ebc5",
    "scope": "repo"
  },
  {
    "bytes": 10188,
    "repoRelPath": "CAPABILITY/CAS/storage/a/50/a50dee1699b38e45b895e3fb342029d0df9e259a0f443892433f64021a9a254f",
    "scope": "repo"
  },
  {
    "bytes": 10733,
    "repoRelPath": "CAPABILITY/CAS/storage/a/53/a53819868540bc219c6d304017966eb1e7940a4ab41ad0b99a2f47b0a81b8193",
    "scope": "repo"
  },
  {
    "bytes": 623,
    "repoRelPath": "CAPABILITY/CAS/storage/a/55/a556ee605462ea7d4dd2196aa74e9a52eeb4b694c290f89a2d3dd80279e4cb90",
    "scope": "repo"
  },
  {
    "bytes": 1434,
    "repoRelPath": "CAPABILITY/CAS/storage/a/59/a599e94f9dd0177997dd02926d43f24fed11e3fbbd5486aaa0b4e81889ce3bb1",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/a/5c/a5c75aba71cdacb276e64447f93efa30ab781057ca33ee2afa2e330b8af3b1a9",
    "scope": "repo"
  },
  {
    "bytes": 4309,
    "repoRelPath": "CAPABILITY/CAS/storage/a/5c/a5cb018a360d73020940cf97d19b8535ed5cb9360592ec53610f80340f993c91",
    "scope": "repo"
  },
  {
    "bytes": 677,
    "repoRelPath": "CAPABILITY/CAS/storage/a/5e/a5e242e6597c199617d16fa3289e1ab82348300541f1e91b0775338a304221e9",
    "scope": "repo"
  },
  {
    "bytes": 590,
    "repoRelPath": "CAPABILITY/CAS/storage/a/60/a60fa8b1b3d236b134a6bf8a5b099a325ce8fb4544923c513ebe3d1607e46550",
    "scope": "repo"
  },
  {
    "bytes": 748,
    "repoRelPath": "CAPABILITY/CAS/storage/a/61/a613c7e34034effa2088d4d3f0934f753d9577a2fa2b9090926a67b4694666e5",
    "scope": "repo"
  },
  {
    "bytes": 6813,
    "repoRelPath": "CAPABILITY/CAS/storage/a/64/a647c3aa836993f647cd4435e3e5c18721a19ba2d8a0163b6573f01dc3ffdcc5",
    "scope": "repo"
  },
  {
    "bytes": 5922,
    "repoRelPath": "CAPABILITY/CAS/storage/a/65/a657f878ae81f3f0fdde1317a65d77896e061e0fc3afcb5f9ac970ecb65761ad",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/a/67/a6785cafe4ac3c9451b22275d058efa3c782e5c0d70f8e141062c74c914cc260",
    "scope": "repo"
  },
  {
    "bytes": 2009,
    "repoRelPath": "CAPABILITY/CAS/storage/a/6b/a6b36549c1404df1a85ef35a725f7555297af3610f4ec058ea1d1508b2da899c",
    "scope": "repo"
  },
  {
    "bytes": 2250,
    "repoRelPath": "CAPABILITY/CAS/storage/a/71/a712a05f6657057cd8d13651e14d99a7103ef283b1aba351350e36d1b9540a46",
    "scope": "repo"
  },
  {
    "bytes": 9767,
    "repoRelPath": "CAPABILITY/CAS/storage/a/76/a7660d15616598b78e504ff1c90f478f05f9b69eb4a07629c01f5614ec00949a",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/a/76/a76e12d7b3ff6e2fc5a47c801892b3837cf79470753d0d87aefd6c575f6d11d1",
    "scope": "repo"
  },
  {
    "bytes": 27,
    "repoRelPath": "CAPABILITY/CAS/storage/a/7c/a7c37f451324f2e7087279404c34fc11256422db448533c496ddacd115f5ad39",
    "scope": "repo"
  },
  {
    "bytes": 19766,
    "repoRelPath": "CAPABILITY/CAS/storage/a/7e/a7e3c2f8fae19caf494a4d44ea5f538bf1bf2eb32791925eb392600b9fbb6a60",
    "scope": "repo"
  },
  {
    "bytes": 9750,
    "repoRelPath": "CAPABILITY/CAS/storage/a/83/a838e8c6ab1128fb13b601e77b1a1c107fe7da87e798dbd4ea60ddc73b787782",
    "scope": "repo"
  },
  {
    "bytes": 596,
    "repoRelPath": "CAPABILITY/CAS/storage/a/84/a84152fa758de493506ec7e2056cfca1b7e94a6602d5d3f9a16ee95ef508d072",
    "scope": "repo"
  },
  {
    "bytes": 183,
    "repoRelPath": "CAPABILITY/CAS/storage/a/85/a853c5bc8f88e0f422f77b1fa37f890b5bed58f16e62ad1194847410a53b8f19",
    "scope": "repo"
  },
  {
    "bytes": 1484207,
    "repoRelPath": "CAPABILITY/CAS/storage/a/8a/a8a4191b72567bc9c10b9b8d098adae967f35e1c7c672da72995ba0c81e7be3c",
    "scope": "repo"
  },
  {
    "bytes": 2617,
    "repoRelPath": "CAPABILITY/CAS/storage/a/8a/a8aa8b3e8ea34d0e8dc61482b9daa53de18bff02edf12637a1f745cdddbc0981",
    "scope": "repo"
  },
  {
    "bytes": 178,
    "repoRelPath": "CAPABILITY/CAS/storage/a/8c/a8c56278975796ff6a7b3af4ce6adb4ca93762fc8de5bb9b2d0d6eafed04ecb2",
    "scope": "repo"
  },
  {
    "bytes": 3334,
    "repoRelPath": "CAPABILITY/CAS/storage/a/8c/a8cfc97d504e304548ba8554e07df68e1e54b073c15f2109207fac90ffef3d74",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/a/8d/a8df7b91bf7cad3948060931472b3f3de8d61216ab34c08bd73a79f1cfbb3c9a",
    "scope": "repo"
  },
  {
    "bytes": 810,
    "repoRelPath": "CAPABILITY/CAS/storage/a/94/a942600a7131ca66c487a2b2f250ad357deab1ab2842ecae65e0a8aed9f9dcdf",
    "scope": "repo"
  },
  {
    "bytes": 850,
    "repoRelPath": "CAPABILITY/CAS/storage/a/95/a95b7f08bf858ed41348fa676367df2b5472b2f0c05504064a4a6bd092776418",
    "scope": "repo"
  },
  {
    "bytes": 4576,
    "repoRelPath": "CAPABILITY/CAS/storage/a/95/a95bde53422c51061baf52c66165ca230789656b2776b67371b5c8f4b0996eb4",
    "scope": "repo"
  },
  {
    "bytes": 87,
    "repoRelPath": "CAPABILITY/CAS/storage/a/95/a95e11774a2e0fa01155c3611b7abf88c77fb934ffc3f1c8b33e243e98082bc8",
    "scope": "repo"
  },
  {
    "bytes": 575,
    "repoRelPath": "CAPABILITY/CAS/storage/a/98/a98b67e537e27929a35c5104c9565c4f26e6ccf2e4fbf2c2b8e2b7464e5b6000",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/a/9c/a9cc621e275dd043d77a58ff18180ce785b69f3c8874c4a54b481e453e7e6949",
    "scope": "repo"
  },
  {
    "bytes": 11252,
    "repoRelPath": "CAPABILITY/CAS/storage/a/9f/a9fb9f93a4b1b439b247bb38ad6c274f3d1f0b8fdf436c51630022d02fa5ebdf",
    "scope": "repo"
  },
  {
    "bytes": 1735,
    "repoRelPath": "CAPABILITY/CAS/storage/a/a4/aa45b347b73455ffcc775e8407ae592901d54aa039b2add8d73b6bb792b230d3",
    "scope": "repo"
  },
  {
    "bytes": 6583,
    "repoRelPath": "CAPABILITY/CAS/storage/a/a8/aa87c959e122fd137f3efd6ebaa3f1609db275bdef126550135403d4fd42878d",
    "scope": "repo"
  },
  {
    "bytes": 10,
    "repoRelPath": "CAPABILITY/CAS/storage/a/ac/aac04736ad22d2bc1e87a75e61b1866498c96a79be96cf0c5f3ecaf9e006c1c7",
    "scope": "repo"
  },
  {
    "bytes": 490,
    "repoRelPath": "CAPABILITY/CAS/storage/a/ad/aad22c3b08e6a82ddea3286b8ba9c59d2ada65c1bd66c3568fb49be4a63c730a",
    "scope": "repo"
  },
  {
    "bytes": 867,
    "repoRelPath": "CAPABILITY/CAS/storage/a/ae/aae2575f705e5d97f0d0f5db7c636b5c104a996533c590dc9ae90f7a3147337e",
    "scope": "repo"
  },
  {
    "bytes": 1294,
    "repoRelPath": "CAPABILITY/CAS/storage/a/b0/ab082bdf0f87c1f6c25033af4ec24d5514ec6e2b4cb0d293f1c590c569c0d90a",
    "scope": "repo"
  },
  {
    "bytes": 23754,
    "repoRelPath": "CAPABILITY/CAS/storage/a/b0/ab0d7de912ff247a822774eea05cfb5fbdbfccb5c662ff6413b5f54f98e95197",
    "scope": "repo"
  },
  {
    "bytes": 9551,
    "repoRelPath": "CAPABILITY/CAS/storage/a/b1/ab15dbeb4bc7a13d3b9a9f0056b0bfdf75cb46afa0adaeb827a1b4b52c40660f",
    "scope": "repo"
  },
  {
    "bytes": 2537,
    "repoRelPath": "CAPABILITY/CAS/storage/a/b8/ab8f604b54e2ae10f8e7ec3e7f8f903fd4bcb3b6088e52c2760f8c44244c5bef",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/a/b9/ab97a95bf460070a4d25fb5e4c2f4149f4b22dddbb45b5b20679e8e4c4fe35eb",
    "scope": "repo"
  },
  {
    "bytes": 13319,
    "repoRelPath": "CAPABILITY/CAS/storage/a/ba/abaada8ff48ea910734f6b1cd2abddc13400e545b7f575871810e0547c6b3bfa",
    "scope": "repo"
  },
  {
    "bytes": 5720,
    "repoRelPath": "CAPABILITY/CAS/storage/a/bb/abb230c98808c110d4de5d5f7256a3931696bf4dfd00112f15f478892a936197",
    "scope": "repo"
  },
  {
    "bytes": 8,
    "repoRelPath": "CAPABILITY/CAS/storage/a/bb/abb9243e962cc3e96ca2fb53c96c58222daafac219afffc34d2cff0d34a7c0b1",
    "scope": "repo"
  },
  {
    "bytes": 2563,
    "repoRelPath": "CAPABILITY/CAS/storage/a/bb/abbad738d261647bd3ec19bd99adf62de6c649b3ae750b2f46411d31e6f21b08",
    "scope": "repo"
  },
  {
    "bytes": 17291,
    "repoRelPath": "CAPABILITY/CAS/storage/a/bb/abbe34cf3621c0e56edfabdd230f70d7ab2a148bc2a64fcfdfd348fa1d2c9361",
    "scope": "repo"
  },
  {
    "bytes": 1296,
    "repoRelPath": "CAPABILITY/CAS/storage/a/c2/ac2eba6b99ed21174525c51d392a03309086e41ba8716468ac8b0e095edbe928",
    "scope": "repo"
  },
  {
    "bytes": 2005,
    "repoRelPath": "CAPABILITY/CAS/storage/a/c4/ac46c6f73c0d86b25b5fdfbb95116a35a4c3b3e11931cad5d3e2da238e76c0ea",
    "scope": "repo"
  },
  {
    "bytes": 117901,
    "repoRelPath": "CAPABILITY/CAS/storage/a/c8/ac8e74ccd8998721f3453b3611d594e9c4793316c3f47edef25db3c994a78af0",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/a/cb/acb72cbaa8c7a33b2641ad97968cae4e218d59178c57ae647b749867b7dd9fdd",
    "scope": "repo"
  },
  {
    "bytes": 4613,
    "repoRelPath": "CAPABILITY/CAS/storage/a/ce/acef691f5f28ec8f0d6b8fc437d1e9e02b8465b782c3b10b60eb31823adaabf4",
    "scope": "repo"
  },
  {
    "bytes": 530,
    "repoRelPath": "CAPABILITY/CAS/storage/a/d3/ad382ebb10a5fe58f38af7f265f52383636044c5fe57773bab5286f380a2ad78",
    "scope": "repo"
  },
  {
    "bytes": 5336,
    "repoRelPath": "CAPABILITY/CAS/storage/a/d8/ad8bc4b9f2c2da905cc105102d8e735e9b9e64ae745680857793fe77214edd21",
    "scope": "repo"
  },
  {
    "bytes": 1892,
    "repoRelPath": "CAPABILITY/CAS/storage/a/d9/ad9bd6587a4ca96d966ec9ae35b4112ea66bf12dc44a5656fb07307616def235",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/a/dc/adc31e325c4b1a1135854d455bfbdf5c94fa5c1801332b4327a5a14d9580929b",
    "scope": "repo"
  },
  {
    "bytes": 1646,
    "repoRelPath": "CAPABILITY/CAS/storage/a/dd/addb876ef3cf92b450a3fd784bec1843cea805978f22b0e7f01bab21927c206e",
    "scope": "repo"
  },
  {
    "bytes": 6526,
    "repoRelPath": "CAPABILITY/CAS/storage/a/de/ade6a2dbd043ec32b9b70855c9a16cc619de9bb736cf4cbc4bfbc59835636d5a",
    "scope": "repo"
  },
  {
    "bytes": 597,
    "repoRelPath": "CAPABILITY/CAS/storage/a/de/ade8a2e3bc19b1130866e0a1de93c84d426b90c47767dec04f38e9ef62482578",
    "scope": "repo"
  },
  {
    "bytes": 172,
    "repoRelPath": "CAPABILITY/CAS/storage/a/e3/ae31bcf8fbf72215e3afcdb20e08acbb12d5f6600fced258e94367b80ed4a186",
    "scope": "repo"
  },
  {
    "bytes": 73,
    "repoRelPath": "CAPABILITY/CAS/storage/a/e6/ae626bc5e73c9740bc9f9d948b296c931c1fc3a7c858e153610eccd4f0bb9e83",
    "scope": "repo"
  },
  {
    "bytes": 608,
    "repoRelPath": "CAPABILITY/CAS/storage/a/ef/aef232318e657e0e25f40a483b627dc55764a08323507d2bcca510f95c74a423",
    "scope": "repo"
  },
  {
    "bytes": 17,
    "repoRelPath": "CAPABILITY/CAS/storage/a/f0/af062acbe3e64aa039672b0bc0197abeb443bf0cc9685e7d96ea67d18afdb7d7",
    "scope": "repo"
  },
  {
    "bytes": 101,
    "repoRelPath": "CAPABILITY/CAS/storage/a/f0/af088fc86bc5168e36a522c9308b4a9ace812b1a1bc4b6ede8dd3f036ec81012",
    "scope": "repo"
  },
  {
    "bytes": 1080,
    "repoRelPath": "CAPABILITY/CAS/storage/a/fb/afb8c7004a10fba1944253f12c7ddbfdd75694b15dd24c948943e4d139bfbe71",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/a/ff/aff2733e8dddee139028a6fab2994615c82adbf8e6abec095653e36f5c960a3a",
    "scope": "repo"
  },
  {
    "bytes": 5317,
    "repoRelPath": "CAPABILITY/CAS/storage/b/00/b004458502a304dc759193bcfa6f02a74485e1ac12f2657d6393281fea89f6f8",
    "scope": "repo"
  },
  {
    "bytes": 6682,
    "repoRelPath": "CAPABILITY/CAS/storage/b/08/b08b14fc88ed116b33f78bd4f56fa76a51d222141eafb449db6567d1f74d2098",
    "scope": "repo"
  },
  {
    "bytes": 37383,
    "repoRelPath": "CAPABILITY/CAS/storage/b/0b/b0be47f20d4a190939719d8afa109cbe3082e96b123add3c0f4ec4881fc1eb6e",
    "scope": "repo"
  },
  {
    "bytes": 9305,
    "repoRelPath": "CAPABILITY/CAS/storage/b/0f/b0fc1857c89c5762bcb2a98fb0b8ff49fd69558fd10d8400cf8d88e458d3a425",
    "scope": "repo"
  },
  {
    "bytes": 6277,
    "repoRelPath": "CAPABILITY/CAS/storage/b/16/b161d451cf1d2208f228f071aebbf47670eca1bf18d89070524036b5a3668cfa",
    "scope": "repo"
  },
  {
    "bytes": 133,
    "repoRelPath": "CAPABILITY/CAS/storage/b/1c/b1caab67f4bc1dcf7208fd0d181d2ef1cb58cfc9f5ce3a5555d7b4dccdafa1bc",
    "scope": "repo"
  },
  {
    "bytes": 179,
    "repoRelPath": "CAPABILITY/CAS/storage/b/1f/b1f5d1abc27fea91835458041bcaa6b5bab1d6e315db83ce14c524055e22eef5",
    "scope": "repo"
  },
  {
    "bytes": 658,
    "repoRelPath": "CAPABILITY/CAS/storage/b/21/b21050f057754170138982c15e2d88ad03fffe6d7d3bb6bce7a7832b6b7f5471",
    "scope": "repo"
  },
  {
    "bytes": 9286,
    "repoRelPath": "CAPABILITY/CAS/storage/b/24/b24984a4f814f747f1538f7b001a90d6a2b2b3a108881b1f159357381107c526",
    "scope": "repo"
  },
  {
    "bytes": 1416077,
    "repoRelPath": "CAPABILITY/CAS/storage/b/26/b2655aeeb5cdea6a546a76edd36c622b10f15fd6c85124b1130ac1fe446ce878",
    "scope": "repo"
  },
  {
    "bytes": 684,
    "repoRelPath": "CAPABILITY/CAS/storage/b/29/b2952d64e94fc2c9f550b453e914b2dcad77493855815e591bb4cf09a1efaf95",
    "scope": "repo"
  },
  {
    "bytes": 31749,
    "repoRelPath": "CAPABILITY/CAS/storage/b/2a/b2a3ad5852d5cc8c7541a00bd8e29d2a8c91998bf51fc227c7fcfda2c9a688ab",
    "scope": "repo"
  },
  {
    "bytes": 21,
    "repoRelPath": "CAPABILITY/CAS/storage/b/2e/b2e24ba5dc21b0b2164eefeea1ee7d47f367aba3824eaaf6bf6ed3d779fc12ca",
    "scope": "repo"
  },
  {
    "bytes": 4368,
    "repoRelPath": "CAPABILITY/CAS/storage/b/30/b3089b4c240f0383bf43e4b9164ec9f1e9fa269438de634b0fcb56929bf56b6f",
    "scope": "repo"
  },
  {
    "bytes": 3551,
    "repoRelPath": "CAPABILITY/CAS/storage/b/31/b313ed07421dde6ca9403cfb12dc1bb8a021cb48da02467e2a86ac73c31f69f6",
    "scope": "repo"
  },
  {
    "bytes": 3288,
    "repoRelPath": "CAPABILITY/CAS/storage/b/31/b31fbcb3e362d5c5308e99255ff8e83cde3a513e0636953964a648494ca10931",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/b/32/b3226688bcaefa8e5e81bdac59521bcb8e3c3db0cecb8c4bd7893c30b8887224",
    "scope": "repo"
  },
  {
    "bytes": 3540,
    "repoRelPath": "CAPABILITY/CAS/storage/b/37/b376de5611b55c576f77c04aa0e2acd288db81f4ff842617898a2e174d4761da",
    "scope": "repo"
  },
  {
    "bytes": 89,
    "repoRelPath": "CAPABILITY/CAS/storage/b/38/b3821f0a8fbd6a615736dc57e7620b0fa0503cc973400e2963bc33bbf32431f2",
    "scope": "repo"
  },
  {
    "bytes": 57,
    "repoRelPath": "CAPABILITY/CAS/storage/b/3a/b3a0edb6f3ca10d9afc6384498dc545386a07d432b2e4295554f6de25d064ae6",
    "scope": "repo"
  },
  {
    "bytes": 109187,
    "repoRelPath": "CAPABILITY/CAS/storage/b/3c/b3c260ac6ab163ee073775c6d5a311828df9dac9b55a537023fa6f341e3f65e1",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/b/3d/b3ddf5d4e90bbe7e46c68a2040ac24271cbdd79e43d544a982d975251a3a80ab",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/b/3f/b3fedff472debfc592e143373825bb52c3aaf67b0010d1242f562adb6f7a315a",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/b/41/b41ad6e6a13d0fb5e72e19a435c47645fe130a090447515c020a7890b121a18c",
    "scope": "repo"
  },
  {
    "bytes": 10850,
    "repoRelPath": "CAPABILITY/CAS/storage/b/41/b41f587459ead549b0bcbd63097b51897fa442d65f2b4c223184bec2b2b1c81c",
    "scope": "repo"
  },
  {
    "bytes": 20,
    "repoRelPath": "CAPABILITY/CAS/storage/b/42/b42a06bdf0100cf88a866cc8eec08cea9b8f2f613ad0fc91d71020a261efb23f",
    "scope": "repo"
  },
  {
    "bytes": 3763,
    "repoRelPath": "CAPABILITY/CAS/storage/b/43/b435d3b392ea04913390396d5c0895e1d8b3f8ca5615b66afd4abe5fbda06bdf",
    "scope": "repo"
  },
  {
    "bytes": 513,
    "repoRelPath": "CAPABILITY/CAS/storage/b/43/b439d652ad3060001c8b402ade9c27d9e271c14bf53354d816ec4eeab44886e3",
    "scope": "repo"
  },
  {
    "bytes": 7150,
    "repoRelPath": "CAPABILITY/CAS/storage/b/43/b439e35b02675145d770d4d2ea3decff08c6732932de3d08a16f8ab2ec05a157",
    "scope": "repo"
  },
  {
    "bytes": 5537,
    "repoRelPath": "CAPABILITY/CAS/storage/b/46/b4639639f1f73dffed25e591e119726acf2523c3572874630cc2914a50c90d3f",
    "scope": "repo"
  },
  {
    "bytes": 36730,
    "repoRelPath": "CAPABILITY/CAS/storage/b/48/b481f774e334bb5e3ba22d9fc9e3459baff9757e05cc2a96047186ad08e1411d",
    "scope": "repo"
  },
  {
    "bytes": 7948,
    "repoRelPath": "CAPABILITY/CAS/storage/b/4a/b4a6fd13df57b8c8ead300114ba851b07efadbe85bd31e471506248dcb4ea75d",
    "scope": "repo"
  },
  {
    "bytes": 7721,
    "repoRelPath": "CAPABILITY/CAS/storage/b/4b/b4b04164d428fd6a6575e658c976d9271f67e172c3e4518e37caa9b6f0063a79",
    "scope": "repo"
  },
  {
    "bytes": 813,
    "repoRelPath": "CAPABILITY/CAS/storage/b/50/b501bd44c25f428e2d65a550659c0dbfe9d13ea43bc5e6b786cf18985eedaa7e",
    "scope": "repo"
  },
  {
    "bytes": 77,
    "repoRelPath": "CAPABILITY/CAS/storage/b/51/b51c4d31930251cf05d31c3efe37308ca276d8ded9d49d3b3e5543d280453fe8",
    "scope": "repo"
  },
  {
    "bytes": 810,
    "repoRelPath": "CAPABILITY/CAS/storage/b/51/b51dd1c9ff6e94727c15fc1c60599d999c7c1d29caa6f15e0be4ec1586ab3ce2",
    "scope": "repo"
  },
  {
    "bytes": 559,
    "repoRelPath": "CAPABILITY/CAS/storage/b/57/b578860e46711e6e1b205da0046110703dbf33d91e6135889dff3050c78e1c52",
    "scope": "repo"
  },
  {
    "bytes": 16915,
    "repoRelPath": "CAPABILITY/CAS/storage/b/5a/b5a3fccdf359d74cfe579fbfe759319fc763b1a3f2abcfc9baa3af083081f41b",
    "scope": "repo"
  },
  {
    "bytes": 103,
    "repoRelPath": "CAPABILITY/CAS/storage/b/5c/b5cfd9669ba701a554a70f61c187b75977632945a8055369cac44cd4ba7af756",
    "scope": "repo"
  },
  {
    "bytes": 3296,
    "repoRelPath": "CAPABILITY/CAS/storage/b/5e/b5eb3837775ab3c61b7cf66fc7be6d7ed27f2e3bf9b2bca5649e8a134ee840e4",
    "scope": "repo"
  },
  {
    "bytes": 8307,
    "repoRelPath": "CAPABILITY/CAS/storage/b/61/b610679bb77eb2e416d28ad6d7dc20f876ab7c82ca29abb93f9f0fc4087d7d75",
    "scope": "repo"
  },
  {
    "bytes": 924,
    "repoRelPath": "CAPABILITY/CAS/storage/b/62/b6254c726eca5094064e2826752c8da24824634ae7824a66d71c9a56c3306a0f",
    "scope": "repo"
  },
  {
    "bytes": 1280261,
    "repoRelPath": "CAPABILITY/CAS/storage/b/63/b63166665bd27b63183e549110832544250704ee039859368517b63922ae21dd",
    "scope": "repo"
  },
  {
    "bytes": 60,
    "repoRelPath": "CAPABILITY/CAS/storage/b/63/b63d8099b1ea37b2d0477d871128bf82003665677dbfdd38f7eb89d6a01245b2",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/b/66/b66e26c63465762915fe081eb211e869456b224d44da3a41196e6fc3af04bf59",
    "scope": "repo"
  },
  {
    "bytes": 43082,
    "repoRelPath": "CAPABILITY/CAS/storage/b/6a/b6a2da7aef902ed49eea0b58791f155cccf400d0ad20b3fd431c19d873135cb6",
    "scope": "repo"
  },
  {
    "bytes": 1003,
    "repoRelPath": "CAPABILITY/CAS/storage/b/70/b70c76337db06495519b9f43e8d01b19a5ea5820c9c9f523b7e70d2f9be98aa7",
    "scope": "repo"
  },
  {
    "bytes": 121,
    "repoRelPath": "CAPABILITY/CAS/storage/b/72/b72b0141143a0afdaa725a7cc61350cd8c66df1b07aa99ba30e66f711e3a61d2",
    "scope": "repo"
  },
  {
    "bytes": 39799,
    "repoRelPath": "CAPABILITY/CAS/storage/b/74/b744b72016c65fff74acd6611d88c1bdb4254db8a33db9267586d962d445853d",
    "scope": "repo"
  },
  {
    "bytes": 73,
    "repoRelPath": "CAPABILITY/CAS/storage/b/75/b7566197ff41b9a84bbc18cb1f3d5b6ac13d955941780f74481d5120c1add6a9",
    "scope": "repo"
  },
  {
    "bytes": 12050,
    "repoRelPath": "CAPABILITY/CAS/storage/b/78/b78265e666c43f4c6098df428a53dddaf99bc5bf2f9125555527b143760e0855",
    "scope": "repo"
  },
  {
    "bytes": 6144,
    "repoRelPath": "CAPABILITY/CAS/storage/b/79/b793c9e68714c1cfc642ec9c09de88aee58e0f061ab1ed3dab396521dabe1747",
    "scope": "repo"
  },
  {
    "bytes": 716,
    "repoRelPath": "CAPABILITY/CAS/storage/b/7a/b7a1fdf7567f62594840357a746ba87e522fa404ba29a58347627433f1b1cad2",
    "scope": "repo"
  },
  {
    "bytes": 3984,
    "repoRelPath": "CAPABILITY/CAS/storage/b/7f/b7fd361e0642689912414aff6f5ef65bd03ebd5f96349d299b0019e89f32c529",
    "scope": "repo"
  },
  {
    "bytes": 4774,
    "repoRelPath": "CAPABILITY/CAS/storage/b/80/b8084e0fa1f2d02e37ca1b19c5410b1fafbc6a51c6d779f3a796cea00022c83f",
    "scope": "repo"
  },
  {
    "bytes": 1950,
    "repoRelPath": "CAPABILITY/CAS/storage/b/82/b82fc4f12754859de45cc9f9fc5153c4b8d1a63359fead5191e4f1a8990f3dba",
    "scope": "repo"
  },
  {
    "bytes": 97,
    "repoRelPath": "CAPABILITY/CAS/storage/b/8a/b8a3e64ffd21f21e7d3ed09187eda08f587344a99cfd6b2905f8417b56008964",
    "scope": "repo"
  },
  {
    "bytes": 1589,
    "repoRelPath": "CAPABILITY/CAS/storage/b/8a/b8a7edcf1abed4ab9f461649fd6193b83c4aa13cadef895976b52104a142165f",
    "scope": "repo"
  },
  {
    "bytes": 724,
    "repoRelPath": "CAPABILITY/CAS/storage/b/8c/b8c5555700ce785cbe000e801824299ea1ba3fddcd13e5099e42d325afdcd8b5",
    "scope": "repo"
  },
  {
    "bytes": 117901,
    "repoRelPath": "CAPABILITY/CAS/storage/b/8c/b8c6d16972bb9114b0b44e24268a5dcfa6d6a8cebd8d6cbb3a817adbc4d4c335",
    "scope": "repo"
  },
  {
    "bytes": 117724,
    "repoRelPath": "CAPABILITY/CAS/storage/b/8c/b8ca1b8f20aa40f90f302de1a56f6c0ad7dc77628f8ad2fb97370bea76ee01dd",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/b/8f/b8f3122daef62c3da1d4e21f320a4ac09c308bc5a4023ea7138dc387b6875c96",
    "scope": "repo"
  },
  {
    "bytes": 167,
    "repoRelPath": "CAPABILITY/CAS/storage/b/92/b925cb19d8a6c388f8fa9ccdc62122b87d76114190fe3239bc2da564e3cfade5",
    "scope": "repo"
  },
  {
    "bytes": 1733,
    "repoRelPath": "CAPABILITY/CAS/storage/b/95/b95135d2d0482ecbdd94fe15f10baf01f238877606d39a800a6312a4ed83095e",
    "scope": "repo"
  },
  {
    "bytes": 737,
    "repoRelPath": "CAPABILITY/CAS/storage/b/95/b957f2f0f84f18a6b56b2ac722d8d89f402b11dfa47896e6089d9e20811a5eef",
    "scope": "repo"
  },
  {
    "bytes": 2350,
    "repoRelPath": "CAPABILITY/CAS/storage/b/96/b969477c329da7ea57219cdc80924ef6034ece7ba1112596046e096d8598a14f",
    "scope": "repo"
  },
  {
    "bytes": 1859,
    "repoRelPath": "CAPABILITY/CAS/storage/b/97/b979c40a6b7f2b239c4d843b3cb6be5fe3748699eb6229031170aa3f1434b2d7",
    "scope": "repo"
  },
  {
    "bytes": 921,
    "repoRelPath": "CAPABILITY/CAS/storage/b/9d/b9d8cb104349c922ea61ab94438c236cf39643f44d40231beb73a3e7a19eb159",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/b/a3/ba3c39316abe46360ff09a43cec70200c124b89a675ecb9a0184c76246d8d182",
    "scope": "repo"
  },
  {
    "bytes": 2833,
    "repoRelPath": "CAPABILITY/CAS/storage/b/a5/ba54cf4a076e8de989a714764454c9f6bcf5f5e1566af07610a79297eb80384d",
    "scope": "repo"
  },
  {
    "bytes": 9480,
    "repoRelPath": "CAPABILITY/CAS/storage/b/a7/ba7a1c876591845c0acb7e2a79f052265b17014fd596291eb689bfb2778ea818",
    "scope": "repo"
  },
  {
    "bytes": 26253,
    "repoRelPath": "CAPABILITY/CAS/storage/b/ae/bae5ce9455461b78594755629661dcd125afac0ac10445e53505fbdb054c1900",
    "scope": "repo"
  },
  {
    "bytes": 1129,
    "repoRelPath": "CAPABILITY/CAS/storage/b/b2/bb2d6876cfaa7c60169f79d2e464184ff998124ae09fdf951af006b129698882",
    "scope": "repo"
  },
  {
    "bytes": 28,
    "repoRelPath": "CAPABILITY/CAS/storage/b/b5/bb5a9fa2687b8ba4cc4a67635f5628544cf2eed7f3f0867a7a5dd4911b61b012",
    "scope": "repo"
  },
  {
    "bytes": 16651,
    "repoRelPath": "CAPABILITY/CAS/storage/b/ba/bbacc304d7db4352bc65ea1a631fd56549e333e3474d58adad02b4774f57a272",
    "scope": "repo"
  },
  {
    "bytes": 117724,
    "repoRelPath": "CAPABILITY/CAS/storage/b/bf/bbf3e009a72d1a80e14ba8b407d7e8b5b5aabdfe0debc6fb15ebf415079f4972",
    "scope": "repo"
  },
  {
    "bytes": 3567,
    "repoRelPath": "CAPABILITY/CAS/storage/b/c1/bc100e50deb168eb42bd3143b11ba1523672a78b676880c48d5cb75b04f3e9c2",
    "scope": "repo"
  },
  {
    "bytes": 2322,
    "repoRelPath": "CAPABILITY/CAS/storage/b/c5/bc52597daf5efa6a7baa39c80f112debe1caf2b245d22600c6efd0b61e4df0f8",
    "scope": "repo"
  },
  {
    "bytes": 3844,
    "repoRelPath": "CAPABILITY/CAS/storage/b/d0/bd02b1b4e523b0a52123d5e72cb8346705b4872279a61723be3f17f436ab084c",
    "scope": "repo"
  },
  {
    "bytes": 34427,
    "repoRelPath": "CAPABILITY/CAS/storage/b/d0/bd0c3508881dcb71dfc6d4c1e536feff75e44d3fa14d075ad7138da363f7b20b",
    "scope": "repo"
  },
  {
    "bytes": 31,
    "repoRelPath": "CAPABILITY/CAS/storage/b/d1/bd1e09d3ddc1aa6bdf575f40846aabfec2b95cd4de2df584d012eb98d71cbd62",
    "scope": "repo"
  },
  {
    "bytes": 682,
    "repoRelPath": "CAPABILITY/CAS/storage/b/d7/bd70ea97010b2e14c9c461d4403f175ea60c53180c01a8035f415ae35704fac1",
    "scope": "repo"
  },
  {
    "bytes": 618,
    "repoRelPath": "CAPABILITY/CAS/storage/b/df/bdf14ecca6da63ae57d10b29d5c6c9aa34deffddacecbf0def382c568f62d11b",
    "scope": "repo"
  },
  {
    "bytes": 327,
    "repoRelPath": "CAPABILITY/CAS/storage/b/e0/be07a3dc5598d470381d6c0fb530545ca5d5539836e0ff8d0172c934d17a05c7",
    "scope": "repo"
  },
  {
    "bytes": 54000,
    "repoRelPath": "CAPABILITY/CAS/storage/b/e1/be13bacbf3e4dc7fcf3a9307358b26ce9353a6189954f617e505b23260c15846",
    "scope": "repo"
  },
  {
    "bytes": 63507,
    "repoRelPath": "CAPABILITY/CAS/storage/b/e1/be18c10bb28cae98663a401fb4f21ea15dde8da94389e93d46f5bd443083d729",
    "scope": "repo"
  },
  {
    "bytes": 846,
    "repoRelPath": "CAPABILITY/CAS/storage/b/e7/be788d38e8e5a0d1c5a4848da9407bc0a750d6e3a8019cca4b9d415030eb5abb",
    "scope": "repo"
  },
  {
    "bytes": 340,
    "repoRelPath": "CAPABILITY/CAS/storage/b/e9/be9f23bdc79f83e1d9ff28444c9504630386f167f5855d3dbeef7a86c633f2eb",
    "scope": "repo"
  },
  {
    "bytes": 3374,
    "repoRelPath": "CAPABILITY/CAS/storage/b/ea/bea90f12d7b05fbb866e2358ef3d34af43d6ba02f968ef8705c2c2fc902cb26e",
    "scope": "repo"
  },
  {
    "bytes": 645,
    "repoRelPath": "CAPABILITY/CAS/storage/b/eb/beb6519ef4864e0fee68f4ecf1a647a5607daff997e0e9c37f6ff6aea8832a5a",
    "scope": "repo"
  },
  {
    "bytes": 1808,
    "repoRelPath": "CAPABILITY/CAS/storage/b/f0/bf00e4248f3408a3aa532d07644b211cf8662aa1b47550769bb4ce9a1889952e",
    "scope": "repo"
  },
  {
    "bytes": 4748,
    "repoRelPath": "CAPABILITY/CAS/storage/b/f1/bf13bd4ab0aa8f16509baa22a6b8865dda61f6ad9d4084a4ec74a63ae172ab7e",
    "scope": "repo"
  },
  {
    "bytes": 304,
    "repoRelPath": "CAPABILITY/CAS/storage/b/f3/bf3f035bebd6476b85109dd1cf533db14d5369a69481e037d80507463ce445c9",
    "scope": "repo"
  },
  {
    "bytes": 5919,
    "repoRelPath": "CAPABILITY/CAS/storage/b/f5/bf5ce76945b7d8b98bd55f9c7910ebed7d7ff9deb92e02428485d123fc8601fd",
    "scope": "repo"
  },
  {
    "bytes": 2490,
    "repoRelPath": "CAPABILITY/CAS/storage/b/f7/bf7019da38e5ff1d9696c64ba2c53312cad3e6de701d602b758ea40680fb9967",
    "scope": "repo"
  },
  {
    "bytes": 2398,
    "repoRelPath": "CAPABILITY/CAS/storage/b/f9/bf99975478f51a8172147f8a1f838b02fe1821e24a74812fba8cfc1702699456",
    "scope": "repo"
  },
  {
    "bytes": 4191,
    "repoRelPath": "CAPABILITY/CAS/storage/b/fe/bfe74c796ba738a9de208d7af79c210ca15f5fc8c56984fc7982f1cf46b632af",
    "scope": "repo"
  },
  {
    "bytes": 5731,
    "repoRelPath": "CAPABILITY/CAS/storage/c/03/c033bb6fb8021650a1fb77841f6426c37e904e4a5f22bf83bf0d298808efce5b",
    "scope": "repo"
  },
  {
    "bytes": 54000,
    "repoRelPath": "CAPABILITY/CAS/storage/c/03/c03505c9cc23ea23b968b40608111fb72c4ca8b678c0cb339a22e1ed6509e16a",
    "scope": "repo"
  },
  {
    "bytes": 10655,
    "repoRelPath": "CAPABILITY/CAS/storage/c/04/c04e234a8e6651357bcece2bee5ddfcb9059ffe5b7fc9bc77e948fbea82bc847",
    "scope": "repo"
  },
  {
    "bytes": 38853,
    "repoRelPath": "CAPABILITY/CAS/storage/c/05/c0556ce033396ca0b8055443fec70217b22154e1916d7ad71e4c383f3eb63cc3",
    "scope": "repo"
  },
  {
    "bytes": 17001,
    "repoRelPath": "CAPABILITY/CAS/storage/c/06/c06f478e8fbd7b484917cc4dca3f52e6e8c6c0e7329a94efa0891b8d9092aad7",
    "scope": "repo"
  },
  {
    "bytes": 4336,
    "repoRelPath": "CAPABILITY/CAS/storage/c/0a/c0a584ce2962a11541912a305aaa372441b4ad97e5468f51633d5d8d3a8f7214",
    "scope": "repo"
  },
  {
    "bytes": 9481,
    "repoRelPath": "CAPABILITY/CAS/storage/c/0b/c0b63c760f49aeef66d0622e87c76c104a40a00408270effb460f68759749db6",
    "scope": "repo"
  },
  {
    "bytes": 132,
    "repoRelPath": "CAPABILITY/CAS/storage/c/0c/c0cd5babca1f61fd2038f5ab29bdfed67be7044c965f91ee0e1947108868d904",
    "scope": "repo"
  },
  {
    "bytes": 155,
    "repoRelPath": "CAPABILITY/CAS/storage/c/0f/c0f68ef968655946b866d1a07a7769b12178b38027daefac4bf38a91f4c28c99",
    "scope": "repo"
  },
  {
    "bytes": 4578,
    "repoRelPath": "CAPABILITY/CAS/storage/c/0f/c0ff694eb4291f0ce0cb2576d0c7c16b217df6159eea1da573c5ef7d616e54a0",
    "scope": "repo"
  },
  {
    "bytes": 1405,
    "repoRelPath": "CAPABILITY/CAS/storage/c/16/c1632767d7537ad39e34a98949f62c4aec1c1cf842867a5d89af08ab41399a9a",
    "scope": "repo"
  },
  {
    "bytes": 20835,
    "repoRelPath": "CAPABILITY/CAS/storage/c/17/c1763732d121e1fc1856e0c1b4cd9cfe054cb123152539217c7e3f89ba835538",
    "scope": "repo"
  },
  {
    "bytes": 14745,
    "repoRelPath": "CAPABILITY/CAS/storage/c/17/c1794dede39f04dcab5cad4ef9d6382381b1b9a81a81167d0b7080cfc2827433",
    "scope": "repo"
  },
  {
    "bytes": 23,
    "repoRelPath": "CAPABILITY/CAS/storage/c/18/c18bb744313f37c7dae1f249e9bd70fc660d500c8a99a95d7d1c2f057b0dcc5f",
    "scope": "repo"
  },
  {
    "bytes": 920,
    "repoRelPath": "CAPABILITY/CAS/storage/c/19/c19d77e3eeec956a48137c539833512c4a8f64c32d0c81b55d0acb9c504b5396",
    "scope": "repo"
  },
  {
    "bytes": 3588,
    "repoRelPath": "CAPABILITY/CAS/storage/c/1a/c1abcdf93c495f80d4e09d46bc0bee6c10e79307cf8fb12f7030b6a40444df10",
    "scope": "repo"
  },
  {
    "bytes": 6405,
    "repoRelPath": "CAPABILITY/CAS/storage/c/1e/c1ee01b16e29e76a639d6415698539f9992da989c135bbe2179c3830c7f7f51f",
    "scope": "repo"
  },
  {
    "bytes": 4300,
    "repoRelPath": "CAPABILITY/CAS/storage/c/20/c202a2555d57a56352e4d4959657b391c4b64a22d1594b9027915d8f9ef5023a",
    "scope": "repo"
  },
  {
    "bytes": 852,
    "repoRelPath": "CAPABILITY/CAS/storage/c/25/c257cb969c1ea495dc66c135c024775c53ba37267fb56d62a4cb25e353f63b9a",
    "scope": "repo"
  },
  {
    "bytes": 6743,
    "repoRelPath": "CAPABILITY/CAS/storage/c/25/c25a15ab68d26fc2c7d02d8a6b15814c72756bfff1ec1d0443bcb193a86c23b3",
    "scope": "repo"
  },
  {
    "bytes": 1798,
    "repoRelPath": "CAPABILITY/CAS/storage/c/28/c28f2a167d740d6b6e57aef2acd87fb5ce5e2dd1763315f5282ed9db625408e0",
    "scope": "repo"
  },
  {
    "bytes": 1461,
    "repoRelPath": "CAPABILITY/CAS/storage/c/30/c309f082022a4342024ae0fbaddf25517c673fae43a8acc0d6caea54eec22ae5",
    "scope": "repo"
  },
  {
    "bytes": 457,
    "repoRelPath": "CAPABILITY/CAS/storage/c/39/c396a24f8a3b9796a696adec95f5de30751dbeeac40b704a889d0ea2811e6847",
    "scope": "repo"
  },
  {
    "bytes": 6743,
    "repoRelPath": "CAPABILITY/CAS/storage/c/3a/c3a1068da850655deba37d9a7b34c97110a0ca65a244e5b3360bcf244cfd3495",
    "scope": "repo"
  },
  {
    "bytes": 4134,
    "repoRelPath": "CAPABILITY/CAS/storage/c/3f/c3f7b9ea9fccb8be5599bff60008b98af728ce5677f4f3b8b823c384eec1157e",
    "scope": "repo"
  },
  {
    "bytes": 1216014,
    "repoRelPath": "CAPABILITY/CAS/storage/c/41/c41cffe6bb721d421161f87485c74e67a8363b984f1ad9f29698eb7780b3639d",
    "scope": "repo"
  },
  {
    "bytes": 11105,
    "repoRelPath": "CAPABILITY/CAS/storage/c/41/c41ef4afb6983bcc1142eb909e15afdd41076305baf18886a88aab65bfbaffa4",
    "scope": "repo"
  },
  {
    "bytes": 136,
    "repoRelPath": "CAPABILITY/CAS/storage/c/44/c4407ad5f803e6a3d9c187434d013db83b5abd32c287404fabc17ce2ce8c9a45",
    "scope": "repo"
  },
  {
    "bytes": 11332,
    "repoRelPath": "CAPABILITY/CAS/storage/c/46/c4603804b68d6e61161e1edf5662bf54e87fe29fecdbb59104a9c12e2e990177",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/c/4d/c4d5e0328c13e434db6028c9d70b6f915b13a7438c9e6d1e579e228c8d95533d",
    "scope": "repo"
  },
  {
    "bytes": 7164,
    "repoRelPath": "CAPABILITY/CAS/storage/c/4d/c4de7092b56c685e7fcdc3223ec394363bc06dc98983453c08937bd814b78c9e",
    "scope": "repo"
  },
  {
    "bytes": 11,
    "repoRelPath": "CAPABILITY/CAS/storage/c/4f/c4f3079e433eaeb4e02b25c94b16b5ffa833a7c0d1f7733a41a73080d10a4f1b",
    "scope": "repo"
  },
  {
    "bytes": 578,
    "repoRelPath": "CAPABILITY/CAS/storage/c/50/c507b9b3f44cbb1ea9fe7e5eb26a50eb68ffd0dda79a779c763d820cb6ecd0a9",
    "scope": "repo"
  },
  {
    "bytes": 1202,
    "repoRelPath": "CAPABILITY/CAS/storage/c/50/c50bc6f0b1190640eb8039c65534aa87ffd61a716f03979a136ca3ef55b2926b",
    "scope": "repo"
  },
  {
    "bytes": 3312,
    "repoRelPath": "CAPABILITY/CAS/storage/c/50/c50d5a3c7e132fb9fac5ca0c92c27d7782dac2af16495191e9752df0b0a8c237",
    "scope": "repo"
  },
  {
    "bytes": 1117,
    "repoRelPath": "CAPABILITY/CAS/storage/c/59/c59f2d343696f0045d2f50114a252250a8e2669cc2b4561edf8e9e04d4d54ed7",
    "scope": "repo"
  },
  {
    "bytes": 9081,
    "repoRelPath": "CAPABILITY/CAS/storage/c/5a/c5a11f3416b4033b7109a9774b4036e498a18b0d99a2022a8f7769c75baf8cc6",
    "scope": "repo"
  },
  {
    "bytes": 54,
    "repoRelPath": "CAPABILITY/CAS/storage/c/5c/c5cc24eda795844be002255984cab9bfc71897f76bffcd6c8b5897b1006c02f2",
    "scope": "repo"
  },
  {
    "bytes": 8761,
    "repoRelPath": "CAPABILITY/CAS/storage/c/5f/c5fa87b9e2eb940f43a895653abc4f80bbdc500dde582ec0e1807952651c0177",
    "scope": "repo"
  },
  {
    "bytes": 596,
    "repoRelPath": "CAPABILITY/CAS/storage/c/60/c60679b2b333c496a331442a2ca33f1eb209c053651bef7c13a91c006f5ce4dc",
    "scope": "repo"
  },
  {
    "bytes": 6606,
    "repoRelPath": "CAPABILITY/CAS/storage/c/60/c60af9889a8383ed2be0468a3b3a3ac5d9b887fb0873240402ffbde6f4158d40",
    "scope": "repo"
  },
  {
    "bytes": 2240,
    "repoRelPath": "CAPABILITY/CAS/storage/c/63/c63d17d2805709756581a73afb37e16cecffcbd4ee10ba18484fda1d2f2337b7",
    "scope": "repo"
  },
  {
    "bytes": 13202,
    "repoRelPath": "CAPABILITY/CAS/storage/c/66/c6625a8c20fbc66bf232384f456598f1d6f9eafdeb8c35a50d13b62e8224dd39",
    "scope": "repo"
  },
  {
    "bytes": 3305,
    "repoRelPath": "CAPABILITY/CAS/storage/c/6b/c6b9c460d60f67457bcf0366768c46b0babc450fe1f9370df3ea7fda6c6e95cd",
    "scope": "repo"
  },
  {
    "bytes": 4576,
    "repoRelPath": "CAPABILITY/CAS/storage/c/6c/c6c88f54dd27c2e7cac942b6d3383eebdd29185ab6365694250c759c5bd36f78",
    "scope": "repo"
  },
  {
    "bytes": 16740,
    "repoRelPath": "CAPABILITY/CAS/storage/c/6e/c6e3c0c767c93c872637a6dd03a707efe2369e861f512ad17bec2ff7236acfa4",
    "scope": "repo"
  },
  {
    "bytes": 900,
    "repoRelPath": "CAPABILITY/CAS/storage/c/70/c70747cb80080ad2ad0d1e0de0e97c0f2f5b20b625863dded8d06fc6c68af64a",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/c/73/c73e20239cea3b62c81a31b628583b130968bafaf2facac6fcfc6b400a0620ca",
    "scope": "repo"
  },
  {
    "bytes": 2945,
    "repoRelPath": "CAPABILITY/CAS/storage/c/79/c793df17f7199dcd025d3785b1e441116b4ff7e7fdeae6b0497ce841470d62e9",
    "scope": "repo"
  },
  {
    "bytes": 13316,
    "repoRelPath": "CAPABILITY/CAS/storage/c/7b/c7be8babcd8f292beddbe546e9c78dbe2e00b7c91fad2cfc8f840b922db0cc42",
    "scope": "repo"
  },
  {
    "bytes": 10560,
    "repoRelPath": "CAPABILITY/CAS/storage/c/7f/c7f902ac6cac8119c367e65dd526872f7c5517b5e2cdf7f2b5ed9ddf934033c0",
    "scope": "repo"
  },
  {
    "bytes": 309,
    "repoRelPath": "CAPABILITY/CAS/storage/c/80/c8087fb1c184e8a41b6316b50f00080ec1ab7a2cd67a4c864ff001197ce62ca6",
    "scope": "repo"
  },
  {
    "bytes": 1986,
    "repoRelPath": "CAPABILITY/CAS/storage/c/81/c81f84f26bce4050670fae5a447c2e90ada3c6a76eff72a1f36ace9015f2b549",
    "scope": "repo"
  },
  {
    "bytes": 3549,
    "repoRelPath": "CAPABILITY/CAS/storage/c/84/c8490b122802f074697eddf43dc04ee343a6fd17657fab762223a25d09d66f65",
    "scope": "repo"
  },
  {
    "bytes": 54000,
    "repoRelPath": "CAPABILITY/CAS/storage/c/84/c84fc529683ab1e3ea2394134fa951313dbe0689b91c9bb7413e54d546624703",
    "scope": "repo"
  },
  {
    "bytes": 4675,
    "repoRelPath": "CAPABILITY/CAS/storage/c/84/c84fe0a9b1b3f4ee2db6c7800351bd4a4d71fd604c6d1322f598c604034b27e4",
    "scope": "repo"
  },
  {
    "bytes": 18857,
    "repoRelPath": "CAPABILITY/CAS/storage/c/85/c851420622249212ca9c164b256eff6fe0c6d7cb1d49ed957c36f0eb3efb675b",
    "scope": "repo"
  },
  {
    "bytes": 289,
    "repoRelPath": "CAPABILITY/CAS/storage/c/8b/c8b77f39d9f08b976c5ae3bd13afadf8a71ad88ae4bb16b2e7847d465bb35dc6",
    "scope": "repo"
  },
  {
    "bytes": 1895,
    "repoRelPath": "CAPABILITY/CAS/storage/c/8d/c8d16a9d9830c128bc8807fd2e5f4cb822e8c4d9e9779fb8786b50a8d8443c4d",
    "scope": "repo"
  },
  {
    "bytes": 2438,
    "repoRelPath": "CAPABILITY/CAS/storage/c/8e/c8ee86efcb3a115630f3624d8baed339ca76527c7e219408bb93e8ab369bf8b4",
    "scope": "repo"
  },
  {
    "bytes": 1214,
    "repoRelPath": "CAPABILITY/CAS/storage/c/91/c91804da1d1c7483907a750db8af2e6485a325c3a0f068470bafc4dfdbcc5b6b",
    "scope": "repo"
  },
  {
    "bytes": 8259,
    "repoRelPath": "CAPABILITY/CAS/storage/c/93/c93b6600a62f2ad4f90fa8bcc3da0dc438a0ed82bd614e8ffd100e712e2f3388",
    "scope": "repo"
  },
  {
    "bytes": 1107,
    "repoRelPath": "CAPABILITY/CAS/storage/c/97/c973bdf293627994e02a234c856378a9f4386494f5b6d3f188dd6da0f4ca1ff0",
    "scope": "repo"
  },
  {
    "bytes": 8476,
    "repoRelPath": "CAPABILITY/CAS/storage/c/98/c98620e05f2bf137fbdfe57c523fc4feffff4310ff87fc7ae34dcccf9f4b5f4c",
    "scope": "repo"
  },
  {
    "bytes": 5371,
    "repoRelPath": "CAPABILITY/CAS/storage/c/9a/c9a032a367442bb63fdd29f6e1666766cb2fbd4321fcbdb7c7f3ccfea1bd3bfd",
    "scope": "repo"
  },
  {
    "bytes": 805,
    "repoRelPath": "CAPABILITY/CAS/storage/c/9a/c9a8ae61f10e85513f4928b0f4b0f19b28499b660f32bd5c66d6cfe654b4653b",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/c/9f/c9ffb872275b43d1a46ee874ac1af467876682d993f8baf9c98be92e79ab464c",
    "scope": "repo"
  },
  {
    "bytes": 3,
    "repoRelPath": "CAPABILITY/CAS/storage/c/a3/ca3d163bab055381827226140568f3bef7eaac187cebd76878e0b63e9e442356",
    "scope": "repo"
  },
  {
    "bytes": 805,
    "repoRelPath": "CAPABILITY/CAS/storage/c/a5/ca5a16a7c46238c9078a4dda4c2d902055e1f231626b90c9be796d8351195acf",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/c/a7/ca7811f02ae953c3e6f74b1e87df465fa9317346b15b1cbf8fd51cc235c2b9f5",
    "scope": "repo"
  },
  {
    "bytes": 1633,
    "repoRelPath": "CAPABILITY/CAS/storage/c/ab/cab415a2aac68aae6bd471ef5c078c81be72e72ac1d803d675d3aa52cdd914d9",
    "scope": "repo"
  },
  {
    "bytes": 7119,
    "repoRelPath": "CAPABILITY/CAS/storage/c/ab/cabe75228dff8c1920d87878464064c8774dee6ecfd30fa7d50455bc58707c66",
    "scope": "repo"
  },
  {
    "bytes": 889,
    "repoRelPath": "CAPABILITY/CAS/storage/c/ab/cabeda59a582eabf217a6b5464bc634c1aed858a8dea6f42fe3d48dcb91cd9b7",
    "scope": "repo"
  },
  {
    "bytes": 38853,
    "repoRelPath": "CAPABILITY/CAS/storage/c/b4/cb43832298a4043dfdc304a557265d80b4af2a1ba593d60e491d0be12fc46c01",
    "scope": "repo"
  },
  {
    "bytes": 19,
    "repoRelPath": "CAPABILITY/CAS/storage/c/b5/cb560d49e4f986086cf353911ac5fc009cb3ef4d9c8c48228f726d56e51721a4",
    "scope": "repo"
  },
  {
    "bytes": 3160,
    "repoRelPath": "CAPABILITY/CAS/storage/c/b5/cb5a4e7a3f959804c9ba16f634f8bbaac4f5dbc601002f8dc0850f20c201ca14",
    "scope": "repo"
  },
  {
    "bytes": 36093,
    "repoRelPath": "CAPABILITY/CAS/storage/c/b8/cb800fecc95a1ea60bb0636b978b11f6d2d5e96ebdf0e89ef4e47e2fdc36b707",
    "scope": "repo"
  },
  {
    "bytes": 5452,
    "repoRelPath": "CAPABILITY/CAS/storage/c/b8/cb849283e50a8710327371a8b9f0e0266b34a8611985d27bc65d966e161f6944",
    "scope": "repo"
  },
  {
    "bytes": 42645,
    "repoRelPath": "CAPABILITY/CAS/storage/c/bd/cbdfc2d3a25e9eb985473e48db5082007641c353465d6b792af831e1bebf0f35",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/c/be/cbe240af7df952aef0cedcf9c2d26ef43b659f93c098a46f0a28b8b59df0c32f",
    "scope": "repo"
  },
  {
    "bytes": 4512,
    "repoRelPath": "CAPABILITY/CAS/storage/c/c5/cc54830914d723a67e1cbc317afebb54135bb3a322443762d2fa486464edbc5f",
    "scope": "repo"
  },
  {
    "bytes": 2386,
    "repoRelPath": "CAPABILITY/CAS/storage/c/c5/cc56ab4dfa66d47babbcc6d7cbc2d9cb41941712e3da32bd9c4fb8265c145f7e",
    "scope": "repo"
  },
  {
    "bytes": 2027,
    "repoRelPath": "CAPABILITY/CAS/storage/c/c5/cc5a15dc8b88e861fb1bca7d7fc3e96f7b30bec721b8f4b7f57fdfb150a6f788",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/c/d0/cd0a3133ed49ccd3c67ef5f8daedd62cb1558e6e71de57d5af12745f154f2b8f",
    "scope": "repo"
  },
  {
    "bytes": 3201,
    "repoRelPath": "CAPABILITY/CAS/storage/c/d6/cd6789f8b9f749353717c1a7a15e90ee7ff1687fa1880210c1cd729f56e73191",
    "scope": "repo"
  },
  {
    "bytes": 11,
    "repoRelPath": "CAPABILITY/CAS/storage/c/da/cdaf242e2e139dd255fbb56a691a9d0943a916a3235ee8d3cd73810d9d0b1ea2",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/c/db/cdb245557ec794cfe75f5984c537bac23f0a4a747e7a3ef40b3e6a9725790d85",
    "scope": "repo"
  },
  {
    "bytes": 18148,
    "repoRelPath": "CAPABILITY/CAS/storage/c/dc/cdc64e795e009e718875f93ae881b3edffcae40bc88d68dc137234d5b0749927",
    "scope": "repo"
  },
  {
    "bytes": 4801,
    "repoRelPath": "CAPABILITY/CAS/storage/c/dc/cdcdd938e696bbde2ac6b1e9f771d21f396b0b15bfbd66fdfb29ccea38b5e350",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/c/dd/cddf7f72d6227dbbb7c13215906cdc00e202ac61451537db1e0ac741eadbee05",
    "scope": "repo"
  },
  {
    "bytes": 7558,
    "repoRelPath": "CAPABILITY/CAS/storage/c/de/cdea792d9b5e7078a5cec237e03ea121daf1cbe2cb1f6772e7504f4575cb053d",
    "scope": "repo"
  },
  {
    "bytes": 1324,
    "repoRelPath": "CAPABILITY/CAS/storage/c/e1/ce1f6a39a2abbfde66d89069c77c5179fef4e1bd129443d0c484afc1db6e2271",
    "scope": "repo"
  },
  {
    "bytes": 14701,
    "repoRelPath": "CAPABILITY/CAS/storage/c/e3/ce312329cfa81a038659928ae60ac37c7f52a0852a10e6a585f00cdf7c0438ad",
    "scope": "repo"
  },
  {
    "bytes": 7670,
    "repoRelPath": "CAPABILITY/CAS/storage/c/e6/ce6e772af83b72c76b5ae07fe7ada6ec5ff1f2b830d17073c2d33dffb66aa286",
    "scope": "repo"
  },
  {
    "bytes": 217,
    "repoRelPath": "CAPABILITY/CAS/storage/c/e7/ce745390b57755ff092fa30abdb17e852a34695131181b1fcacf586939543663",
    "scope": "repo"
  },
  {
    "bytes": 297,
    "repoRelPath": "CAPABILITY/CAS/storage/c/e8/ce829ea8f2fb15e5c93cecf6a34450ac09dcda3f72652329d2493d8073228f3f",
    "scope": "repo"
  },
  {
    "bytes": 5357,
    "repoRelPath": "CAPABILITY/CAS/storage/c/ec/cecbe28df3eb1bb75ea872af0ecb10bc594076c6548334d0d284fa029ec1c8f5",
    "scope": "repo"
  },
  {
    "bytes": 452,
    "repoRelPath": "CAPABILITY/CAS/storage/c/f0/cf0621fb22fdf27930a84b2e5891ad19aad9878bc5ee735f43136baa6cb882ea",
    "scope": "repo"
  },
  {
    "bytes": 157,
    "repoRelPath": "CAPABILITY/CAS/storage/c/f2/cf29ae660ed257d722a94f01affc3ac11057f9e5ce4417185b3aec3d5b3b4e8a",
    "scope": "repo"
  },
  {
    "bytes": 8081,
    "repoRelPath": "CAPABILITY/CAS/storage/c/f2/cf2af87f826e397896221690ad2f98c54a5413767e8d8991f35e34fccb473ffa",
    "scope": "repo"
  },
  {
    "bytes": 217,
    "repoRelPath": "CAPABILITY/CAS/storage/c/f3/cf33cf8e7e444b0a7121fee03b7f44a3b27589e223aad54685361c0f6706e37c",
    "scope": "repo"
  },
  {
    "bytes": 1068,
    "repoRelPath": "CAPABILITY/CAS/storage/c/f5/cf5df27501dfdd31e9e1e13c465302b5ff935dfa133cc4cf0551b92b6dd1211e",
    "scope": "repo"
  },
  {
    "bytes": 5280,
    "repoRelPath": "CAPABILITY/CAS/storage/c/f7/cf7f0ff4bcd3de6e2de99cebd8427167af19d09d8045ce03eae33a9f5b87d3f7",
    "scope": "repo"
  },
  {
    "bytes": 62,
    "repoRelPath": "CAPABILITY/CAS/storage/c/f9/cf97c2de42740eaf504735b139b632901440ade200919ac4fcafe2967b6a3866",
    "scope": "repo"
  },
  {
    "bytes": 8533,
    "repoRelPath": "CAPABILITY/CAS/storage/c/fb/cfba470159d2c2e0c6b860f838f9786a9002a8575d11818d36dc3c358170b012",
    "scope": "repo"
  },
  {
    "bytes": 5951,
    "repoRelPath": "CAPABILITY/CAS/storage/d/02/d020264cf8a2c172af55de1319acfa9058e3fb76a8eef678a42617e72f075acf",
    "scope": "repo"
  },
  {
    "bytes": 173,
    "repoRelPath": "CAPABILITY/CAS/storage/d/08/d086a4bd89b52575e0aa6b3dfdda970efce76f909674e53ec9253742be41faf9",
    "scope": "repo"
  },
  {
    "bytes": 5157,
    "repoRelPath": "CAPABILITY/CAS/storage/d/09/d0961897876ffa88c8a11cac72d6147f7b4f9ff7c29a3cdebec52e83135dcb95",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/d/0e/d0ecba278b457bddb0820787a1cfa4f49871fca189ee94f0a7f631f1a4350e76",
    "scope": "repo"
  },
  {
    "bytes": 1929,
    "repoRelPath": "CAPABILITY/CAS/storage/d/18/d180c2a0513230f089b984d45dc54f4e38d43f9de966e188194fb7b7476f27de",
    "scope": "repo"
  },
  {
    "bytes": 756,
    "repoRelPath": "CAPABILITY/CAS/storage/d/1b/d1b01f726a20815b92f6a2cae0931ffaec7b79c6b22d75968eb5143e64aca43c",
    "scope": "repo"
  },
  {
    "bytes": 113,
    "repoRelPath": "CAPABILITY/CAS/storage/d/1c/d1cddac099154105722ea466cf625efa4dfb3aeec6d1947fa30d046059e72abc",
    "scope": "repo"
  },
  {
    "bytes": 5633,
    "repoRelPath": "CAPABILITY/CAS/storage/d/1e/d1edd0ee14fac3ce51c0561936623248a81f4fbbe1d02db65a257b4ae99241ee",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/d/2d/d2d48fbb995c568c9ce90f14539f81c8692ef4d2274acbd5142a09d9466007f7",
    "scope": "repo"
  },
  {
    "bytes": 1669,
    "repoRelPath": "CAPABILITY/CAS/storage/d/2e/d2e6e3a80346651cba7f0fe6e9a4bc267d1e8a33ae181e486a5b0abec0a3b08a",
    "scope": "repo"
  },
  {
    "bytes": 599,
    "repoRelPath": "CAPABILITY/CAS/storage/d/37/d370c16d698491bc9fa78db776a3b124a2421fb9e76a638cca00e676d28a5295",
    "scope": "repo"
  },
  {
    "bytes": 21090,
    "repoRelPath": "CAPABILITY/CAS/storage/d/37/d3710d7adfda08cfa98ab3dcd4cb7a0225c31350bf2d247d2c5cd87c8e4722e2",
    "scope": "repo"
  },
  {
    "bytes": 607,
    "repoRelPath": "CAPABILITY/CAS/storage/d/3b/d3b050a80b0cf7e22d17fe733529ee7c06d1764a16d0262ff65598ac3f9c51ad",
    "scope": "repo"
  },
  {
    "bytes": 169,
    "repoRelPath": "CAPABILITY/CAS/storage/d/3c/d3c73f9cda9eb7b5be90261d2b9f3af49d8c976485fbf35320fe3c4ae6434045",
    "scope": "repo"
  },
  {
    "bytes": 149,
    "repoRelPath": "CAPABILITY/CAS/storage/d/3c/d3ce80bc839c885d2af78080dc3906adff8fdbbb6c5b1bd7f81720314a627bd4",
    "scope": "repo"
  },
  {
    "bytes": 28640,
    "repoRelPath": "CAPABILITY/CAS/storage/d/3d/d3d5c6ca3e24ef24ffeda76c72d171cf022f99cd95fcfea498b8115ed82d5e0e",
    "scope": "repo"
  },
  {
    "bytes": 308,
    "repoRelPath": "CAPABILITY/CAS/storage/d/41/d41b8f40b92a21923eeb95430d1fa55ca9a4cff19bbdd9287af1944e415f7337",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/d/4f/d4fe37d08d2d68b933227142ff83dde113bad4a6edc7d78d314df07d91216087",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/d/54/d542a177f73637c2836b1d34b9ce54207942e8c38f907aab3bd1c0aa2d1f6f65",
    "scope": "repo"
  },
  {
    "bytes": 469,
    "repoRelPath": "CAPABILITY/CAS/storage/d/57/d57e3be689b3f94a9e4e806bb596197dbd2b6172ccd7927b8d578553d3938687",
    "scope": "repo"
  },
  {
    "bytes": 4892,
    "repoRelPath": "CAPABILITY/CAS/storage/d/58/d58c51255a9ed6b1cf45650ade7ea9654523dfb0da3906b886a5fdf2fee50c4a",
    "scope": "repo"
  },
  {
    "bytes": 519,
    "repoRelPath": "CAPABILITY/CAS/storage/d/59/d59e9e0e541ac284fef8858b0c90956f75953ccb4794d3db8302b08e5c980d12",
    "scope": "repo"
  },
  {
    "bytes": 2449,
    "repoRelPath": "CAPABILITY/CAS/storage/d/5c/d5c886834bba13ab8c17562d260b50a99b6de7f37a0c2575f5f45f0336b9927c",
    "scope": "repo"
  },
  {
    "bytes": 29,
    "repoRelPath": "CAPABILITY/CAS/storage/d/5d/d5d7558b2368ecea9dfeed7d1fbc71ee9e0750bebd1282faa527d528a344c3c7",
    "scope": "repo"
  },
  {
    "bytes": 211,
    "repoRelPath": "CAPABILITY/CAS/storage/d/5e/d5e755ef93166a96422d09fd809c3d94d59e87dba6949b56cfc793e7ab78f68c",
    "scope": "repo"
  },
  {
    "bytes": 10359,
    "repoRelPath": "CAPABILITY/CAS/storage/d/62/d62eb087f5588db943478bc78feb2b9d3806e793829898f95ef877b679a5e232",
    "scope": "repo"
  },
  {
    "bytes": 4641,
    "repoRelPath": "CAPABILITY/CAS/storage/d/63/d63ea3c5ffd092be3bd53405dc77b15de1ec4880257c1f49ce83ba155734d239",
    "scope": "repo"
  },
  {
    "bytes": 27531,
    "repoRelPath": "CAPABILITY/CAS/storage/d/66/d66ef400018430961ff220568c7dcadba968451a73d8ec04e24b301a001d1bc0",
    "scope": "repo"
  },
  {
    "bytes": 3431,
    "repoRelPath": "CAPABILITY/CAS/storage/d/6e/d6e1d4a0e1a01da59625a5d5aa22415521df83375ca5229abe045472d446181b",
    "scope": "repo"
  },
  {
    "bytes": 19766,
    "repoRelPath": "CAPABILITY/CAS/storage/d/6f/d6f11a5186bb02f201538c2dd48f4cf953fc8f221168ab1de9f921d14d83e6a2",
    "scope": "repo"
  },
  {
    "bytes": 138,
    "repoRelPath": "CAPABILITY/CAS/storage/d/71/d71debb03da675ba6b820abb95836f59b1e1a73b1046b1ca7d50f18d591ac07f",
    "scope": "repo"
  },
  {
    "bytes": 55,
    "repoRelPath": "CAPABILITY/CAS/storage/d/72/d7263f01b3badf818a443f2380ecb4d54612539659f073cca041f04321ebdaf4",
    "scope": "repo"
  },
  {
    "bytes": 400,
    "repoRelPath": "CAPABILITY/CAS/storage/d/75/d75f2b44b533e3843c3a281d43beb15874f5379b087198a46aeec5f79420be13",
    "scope": "repo"
  },
  {
    "bytes": 23835,
    "repoRelPath": "CAPABILITY/CAS/storage/d/78/d78dbf02d1c6a8489a5a2251ff823f7bf47bfc88690da6c587b5a1f5d9fd65c3",
    "scope": "repo"
  },
  {
    "bytes": 1866,
    "repoRelPath": "CAPABILITY/CAS/storage/d/7a/d7a9d886e8f2fa1b3439a37cd4ed8ba23ae8c6dd35b03079db372f8e258a2929",
    "scope": "repo"
  },
  {
    "bytes": 2383,
    "repoRelPath": "CAPABILITY/CAS/storage/d/7d/d7daf95212e137880d8481a12d1df8fbb363c74811fb4e5edf27c32b03c5fba8",
    "scope": "repo"
  },
  {
    "bytes": 4415,
    "repoRelPath": "CAPABILITY/CAS/storage/d/7f/d7f3b95f257bf3244eef89f457c50c94f69a131d80f8d23222422e8ce737a524",
    "scope": "repo"
  },
  {
    "bytes": 90,
    "repoRelPath": "CAPABILITY/CAS/storage/d/82/d829d3a4d5b542886a356565c93abd516de4b2f5be9c80e00bb2ba1a0f107948",
    "scope": "repo"
  },
  {
    "bytes": 2959,
    "repoRelPath": "CAPABILITY/CAS/storage/d/87/d875635e76d4e1cfaa5672bb1fa1271908bce7af66d17fb938176d3bee5b6b49",
    "scope": "repo"
  },
  {
    "bytes": 9045,
    "repoRelPath": "CAPABILITY/CAS/storage/d/88/d881df1275b84340cbe14908eb1fea67287a2a948f728bd905686ada3466572c",
    "scope": "repo"
  },
  {
    "bytes": 35,
    "repoRelPath": "CAPABILITY/CAS/storage/d/89/d8908c0b0cbcf3e7c3a312085a60adc5d8e973ae3fe6d550048c8fd4e0ca008c",
    "scope": "repo"
  },
  {
    "bytes": 306,
    "repoRelPath": "CAPABILITY/CAS/storage/d/92/d92862ad677b6c32a0f3d479e3be2d762339a4461879dc3b20650383bac9de27",
    "scope": "repo"
  },
  {
    "bytes": 1425,
    "repoRelPath": "CAPABILITY/CAS/storage/d/9b/d9b84a585096e0ef72bb482c14103a1b47147ee16931f274ca4baa2ffb4187c5",
    "scope": "repo"
  },
  {
    "bytes": 2568,
    "repoRelPath": "CAPABILITY/CAS/storage/d/a1/da1305aeae051fc91b7bb9b870ac9e9333b66a3448ed47e88c132af347ee57bc",
    "scope": "repo"
  },
  {
    "bytes": 32,
    "repoRelPath": "CAPABILITY/CAS/storage/d/a1/da1bffe2c468e23f0050a434b78aae89740e55205b4f660b04a495ddb454f987",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/d/a4/da44a98dad38197cdb8a52ba3e1e4eefb32bc905a0d482826391c56d38264f2b",
    "scope": "repo"
  },
  {
    "bytes": 1876,
    "repoRelPath": "CAPABILITY/CAS/storage/d/a7/da74d530569e0f1fbb56c88d09789741c417fd7d3be7c3436fcf1b07dee7f9ff",
    "scope": "repo"
  },
  {
    "bytes": 16404,
    "repoRelPath": "CAPABILITY/CAS/storage/d/a9/da938012c52c7608c5f8c564e675fea025fc69ac3658351c268a6da7f70584e3",
    "scope": "repo"
  },
  {
    "bytes": 9757,
    "repoRelPath": "CAPABILITY/CAS/storage/d/ab/dab772750384e2572f6edf646da5b2f11088c750f9b921ebb4ec062c757bbf32",
    "scope": "repo"
  },
  {
    "bytes": 3573,
    "repoRelPath": "CAPABILITY/CAS/storage/d/b6/db66a6a916fd6421cb1e8fa94e40b4656e38f02f236bd3f448625b646754698e",
    "scope": "repo"
  },
  {
    "bytes": 2277,
    "repoRelPath": "CAPABILITY/CAS/storage/d/be/dbec046ddd16b578f5d9952f692b80bb9e82d274449322e772711d10a9504124",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/d/c4/dc4cb031f3777a1e6b4e567298edca4eeb979ebde1d7139d2836a0f3334318e1",
    "scope": "repo"
  },
  {
    "bytes": 303,
    "repoRelPath": "CAPABILITY/CAS/storage/d/c5/dc5070ffe69ea0d241e41e0cd7cb14ccbffb3fd9bf57aae528e40ad316b919be",
    "scope": "repo"
  },
  {
    "bytes": 1600,
    "repoRelPath": "CAPABILITY/CAS/storage/d/ce/dced41fa53de422fd6b29e6e3c1ba6cba0f99c93eef43a59cbcbf543420d850e",
    "scope": "repo"
  },
  {
    "bytes": 5891,
    "repoRelPath": "CAPABILITY/CAS/storage/d/d1/dd16285b90bd9f2229733cdc205516328aede151cf387026aaab6fe6f85553f3",
    "scope": "repo"
  },
  {
    "bytes": 5717,
    "repoRelPath": "CAPABILITY/CAS/storage/d/d3/dd36c953713e863020c5066a44ae2e944431c6840b0d4eeb08b765f76b570a7d",
    "scope": "repo"
  },
  {
    "bytes": 78,
    "repoRelPath": "CAPABILITY/CAS/storage/d/d8/dd83eff543e5f8b769daf465e7f5e4244883609ebc67f61348706e3d47ef1be3",
    "scope": "repo"
  },
  {
    "bytes": 4474,
    "repoRelPath": "CAPABILITY/CAS/storage/d/da/dda229b2ae6082daa36b8a1b16bd036ffda75d57f994725f5a3611a1a4966ba9",
    "scope": "repo"
  },
  {
    "bytes": 9001,
    "repoRelPath": "CAPABILITY/CAS/storage/d/de/ddeaab506db8964388a05f2e70900bfc0339579febc440c734daf0b044bde96a",
    "scope": "repo"
  },
  {
    "bytes": 10981,
    "repoRelPath": "CAPABILITY/CAS/storage/d/e9/de91e09e466b9f8616ca837d76cb9ef71481615ef9f8c213d63c1a6e4ac289ec",
    "scope": "repo"
  },
  {
    "bytes": 2183,
    "repoRelPath": "CAPABILITY/CAS/storage/d/eb/deb62eb74d388befd87baf91eaecf0f062fac6ca765002722e4a6de0e1611940",
    "scope": "repo"
  },
  {
    "bytes": 8450,
    "repoRelPath": "CAPABILITY/CAS/storage/d/ed/ded58a4a9dd92dafb37ba4f7d7d0a226b82cc718d42ec729f06b2cd00db4ed04",
    "scope": "repo"
  },
  {
    "bytes": 102,
    "repoRelPath": "CAPABILITY/CAS/storage/d/ee/dee6a67ff5b1ebaf6808afa97959dcded1da55793b9b62cdcd5a41c80db6466d",
    "scope": "repo"
  },
  {
    "bytes": 1016,
    "repoRelPath": "CAPABILITY/CAS/storage/d/ef/defd62398dc52586bfe8e88b250440577b1a757ba0d62b93df553ec615129594",
    "scope": "repo"
  },
  {
    "bytes": 682,
    "repoRelPath": "CAPABILITY/CAS/storage/d/f3/df321b58a58e1171e0a52c68be0b8c7bcc6cf195e452dabf6193c17f10619ab4",
    "scope": "repo"
  },
  {
    "bytes": 48911,
    "repoRelPath": "CAPABILITY/CAS/storage/d/fe/dfec04250735204f48985c945506718a44c0f4da97bc2c7ef8150edede08f3e7",
    "scope": "repo"
  },
  {
    "bytes": 5612,
    "repoRelPath": "CAPABILITY/CAS/storage/d/fe/dfeddf7b818e76a249379b6b36d47d32fedd48ed1f9e80ccb253d5ce19c4573f",
    "scope": "repo"
  },
  {
    "bytes": 13,
    "repoRelPath": "CAPABILITY/CAS/storage/d/ff/dffd6021bb2bd5b0af676290809ec3a53191dd81c7f70a4b28688a362182986f",
    "scope": "repo"
  },
  {
    "bytes": 1142,
    "repoRelPath": "CAPABILITY/CAS/storage/e/01/e0188e2ed2e38cf012cc1d2218234ab4fe867ba68f6b4364af5c35ff46207287",
    "scope": "repo"
  },
  {
    "bytes": 325,
    "repoRelPath": "CAPABILITY/CAS/storage/e/01/e019c3b23ededba82c9b2fa428273583b15e81084fd83b087aa2ba37bb943f56",
    "scope": "repo"
  },
  {
    "bytes": 6419,
    "repoRelPath": "CAPABILITY/CAS/storage/e/01/e01ee913a0ee3d2d2a781b799a9573cc798997d729ab09e9c156c93e58129925",
    "scope": "repo"
  },
  {
    "bytes": 2271,
    "repoRelPath": "CAPABILITY/CAS/storage/e/04/e04caba2f1683e32f2ea49290f45d86fd5b75364985034e6b8b141b9e6763543",
    "scope": "repo"
  },
  {
    "bytes": 927,
    "repoRelPath": "CAPABILITY/CAS/storage/e/06/e0689eacb3646b31dfdf7b952d885361bb9b2e1f51cb6f4a04788bd0aa64be12",
    "scope": "repo"
  },
  {
    "bytes": 542,
    "repoRelPath": "CAPABILITY/CAS/storage/e/07/e074240709d200f8793827b95158abc74d2d042ce5e1abe3449b7e557750ce2c",
    "scope": "repo"
  },
  {
    "bytes": 117901,
    "repoRelPath": "CAPABILITY/CAS/storage/e/08/e08dcc10aa534c440d4b04e1d94fad1bd31787517a9182c544efea5aa14be667",
    "scope": "repo"
  },
  {
    "bytes": 402,
    "repoRelPath": "CAPABILITY/CAS/storage/e/0f/e0f492c8ed33286abb5028751f9fddc3233296fbcf771a8e5186a908d7c2742a",
    "scope": "repo"
  },
  {
    "bytes": 37873,
    "repoRelPath": "CAPABILITY/CAS/storage/e/12/e1211cbd75e316703f646003d708d7390b267da21199fa4fd4424f826e1c0099",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/e/19/e194030ef12c980b494fa7e0199621c6b529ac9ed69f70566eb31b4aabdeb4ea",
    "scope": "repo"
  },
  {
    "bytes": 5374,
    "repoRelPath": "CAPABILITY/CAS/storage/e/21/e21373aaf8a5a94e9888ca51c2771e904050429bd1dafb7568a0c12ac31d3f99",
    "scope": "repo"
  },
  {
    "bytes": 1797,
    "repoRelPath": "CAPABILITY/CAS/storage/e/24/e2470f376ac734523cbb043b18083deb4c354d76e083efe47a6f7229d13ab847",
    "scope": "repo"
  },
  {
    "bytes": 21806,
    "repoRelPath": "CAPABILITY/CAS/storage/e/25/e25327199028da37b08293ba94e45eab0708e673a257a794fae4ca682c772100",
    "scope": "repo"
  },
  {
    "bytes": 10411,
    "repoRelPath": "CAPABILITY/CAS/storage/e/29/e294e1077ce4d7bda92704da823a2e7bf2234a873ebfe1774b1828021297dccc",
    "scope": "repo"
  },
  {
    "bytes": 2126,
    "repoRelPath": "CAPABILITY/CAS/storage/e/2a/e2aaf0c741cfd03fc72b51a62a33e64a1e1f1d4141bfde3298516b07174d7078",
    "scope": "repo"
  },
  {
    "bytes": 21114,
    "repoRelPath": "CAPABILITY/CAS/storage/e/2d/e2d6ed62523df4c6aa049b02237af932f1243ffc68226b980ece2468e6a06e39",
    "scope": "repo"
  },
  {
    "bytes": 1306,
    "repoRelPath": "CAPABILITY/CAS/storage/e/2f/e2f28c7218a138e79f2a12553b0ffe4a4adee9d29b319591c4993ea751bc503a",
    "scope": "repo"
  },
  {
    "bytes": 5293,
    "repoRelPath": "CAPABILITY/CAS/storage/e/33/e3318fe94b8a288c7b61a7424dc04e8999f938bd3c8a270527712a1ee321f7ef",
    "scope": "repo"
  },
  {
    "bytes": 175,
    "repoRelPath": "CAPABILITY/CAS/storage/e/33/e3325740f6253dbbc9b3f713aaa402a569795f220110a8b17a9d0ad963a8da4e",
    "scope": "repo"
  },
  {
    "bytes": 4418,
    "repoRelPath": "CAPABILITY/CAS/storage/e/33/e3344506eaa877aaecd2b2812e04bd459a1d9a51da86432e3f846359c2819d9a",
    "scope": "repo"
  },
  {
    "bytes": 215,
    "repoRelPath": "CAPABILITY/CAS/storage/e/35/e35e79eff7e634ef1d2facafd73edac0fca46caa251669ae863f0631c87a3728",
    "scope": "repo"
  },
  {
    "bytes": 1272780,
    "repoRelPath": "CAPABILITY/CAS/storage/e/39/e39580eb036abfe1b219e4e3b557a2860c4d8f81ad924a7d3e9a4711b1c3b7e5",
    "scope": "repo"
  },
  {
    "bytes": 0,
    "repoRelPath": "CAPABILITY/CAS/storage/e/3b/e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "scope": "repo"
  },
  {
    "bytes": 17499,
    "repoRelPath": "CAPABILITY/CAS/storage/e/3d/e3d1607cada76c06b1bc7a09118e9cab328c8242f8dcd1aede759626c4cb31ef",
    "scope": "repo"
  },
  {
    "bytes": 3316,
    "repoRelPath": "CAPABILITY/CAS/storage/e/3f/e3f5b474c94344e15ecd5f20c79d191551eb779d35ea50a16bdb2444cbcc3069",
    "scope": "repo"
  },
  {
    "bytes": 14,
    "repoRelPath": "CAPABILITY/CAS/storage/e/40/e40bca8f4071b6659550cf0663c37a0eba11e359927e3020185db8d0450e61b9",
    "scope": "repo"
  },
  {
    "bytes": 3077,
    "repoRelPath": "CAPABILITY/CAS/storage/e/42/e42a88e659b7f247b3f4e3acece6221624daf06aef18f947eb687450d7008362",
    "scope": "repo"
  },
  {
    "bytes": 2279,
    "repoRelPath": "CAPABILITY/CAS/storage/e/44/e44bec42504d71c5e471d92ef9de7e9148f1cc76c340f751375042325514e758",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/e/45/e45165025561f07ef4b66893ccd06f99a7fb0905a61b02fc4e937eedc2d85049",
    "scope": "repo"
  },
  {
    "bytes": 7897,
    "repoRelPath": "CAPABILITY/CAS/storage/e/48/e48801d7dbd5d202a3ddba94748a1cb20373c338327e8a57b42eeaeeae64ebab",
    "scope": "repo"
  },
  {
    "bytes": 7387,
    "repoRelPath": "CAPABILITY/CAS/storage/e/49/e492c1add989185fdfbb9b3464f07691e054ea2aff891a487aa5bfb187374734",
    "scope": "repo"
  },
  {
    "bytes": 10000,
    "repoRelPath": "CAPABILITY/CAS/storage/e/4e/e4ee97ec252749d2096447e849628d0d7734f51700416eefbb33574bf0b3ee75",
    "scope": "repo"
  },
  {
    "bytes": 38,
    "repoRelPath": "CAPABILITY/CAS/storage/e/53/e53f885257b076005741edf72c897e8f052e01c631fe4e6331c53b239f9478e8",
    "scope": "repo"
  },
  {
    "bytes": 435,
    "repoRelPath": "CAPABILITY/CAS/storage/e/54/e5405321a12367f63e8cdaa748660d8a766876991ff690369dc80631217e5b6b",
    "scope": "repo"
  },
  {
    "bytes": 8039,
    "repoRelPath": "CAPABILITY/CAS/storage/e/54/e54b502856b5fb0698474094832e7c6f5cd12258a9edb70cf727d9c9c8cf96ca",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/e/54/e54bf2e73d0e0074c1134dfbd48c10094f35d437b0bccb2928c4168705b5a739",
    "scope": "repo"
  },
  {
    "bytes": 16918,
    "repoRelPath": "CAPABILITY/CAS/storage/e/56/e56f23a74102caf6acf86c4ae3f50a57d4e40d112318dd2287f270b953e613a5",
    "scope": "repo"
  },
  {
    "bytes": 3197,
    "repoRelPath": "CAPABILITY/CAS/storage/e/57/e57e0133b14915be89ce3c436e4636ddc391df965f1ad2ea93622af614f93e3e",
    "scope": "repo"
  },
  {
    "bytes": 7031,
    "repoRelPath": "CAPABILITY/CAS/storage/e/5d/e5de9c06aae71f5b1200898ac963bdc9cbdf34d091aad72fccba85f8e14e6df5",
    "scope": "repo"
  },
  {
    "bytes": 5800,
    "repoRelPath": "CAPABILITY/CAS/storage/e/61/e612889768f979a0edf1eee0593955f9f00aa0077244b9504a45ad5508f9878c",
    "scope": "repo"
  },
  {
    "bytes": 1950,
    "repoRelPath": "CAPABILITY/CAS/storage/e/62/e623191f5869dd8dbb296950bfb7680711e46d2da76fe24830180f21f0c43aa6",
    "scope": "repo"
  },
  {
    "bytes": 262,
    "repoRelPath": "CAPABILITY/CAS/storage/e/65/e658cc4fe4c7be71dfddc6c3efb8676ead9be6d23dfa3f5b485b6603a360914e",
    "scope": "repo"
  },
  {
    "bytes": 264,
    "repoRelPath": "CAPABILITY/CAS/storage/e/67/e67970c3439dc2afc13a45cff44a77248851860b7a97852261b74a55406126e4",
    "scope": "repo"
  },
  {
    "bytes": 2780,
    "repoRelPath": "CAPABILITY/CAS/storage/e/6b/e6bdb054b369d7171e2ec8503461523f091b8d6429ae9eec76d4d684963641f8",
    "scope": "repo"
  },
  {
    "bytes": 33,
    "repoRelPath": "CAPABILITY/CAS/storage/e/70/e70ca4a1c466a037877df2080c76058730416c5cef9ee52bfb7c1d595bd58a30",
    "scope": "repo"
  },
  {
    "bytes": 1490,
    "repoRelPath": "CAPABILITY/CAS/storage/e/74/e741c8fb1346f4034e55e23404e337a4ff6f651bdf0dfeaf2ebc1ebf01f3b55c",
    "scope": "repo"
  },
  {
    "bytes": 325,
    "repoRelPath": "CAPABILITY/CAS/storage/e/77/e77c2e688a46e2685c54178a22234d1f5079c6af193ecd9e66a19fdfa64b66bb",
    "scope": "repo"
  },
  {
    "bytes": 3469,
    "repoRelPath": "CAPABILITY/CAS/storage/e/79/e79a9d9ce69e9e5611bc343ad1a1318e430de704849a80d4afd0b4e3f039355b",
    "scope": "repo"
  },
  {
    "bytes": 12989,
    "repoRelPath": "CAPABILITY/CAS/storage/e/7a/e7a0804831c8c8cc9e1adc37cc4c06f7417f6a52813bc2ef5cd41b00f73d96ae",
    "scope": "repo"
  },
  {
    "bytes": 1015,
    "repoRelPath": "CAPABILITY/CAS/storage/e/7a/e7a1813580b19c488fee625a75763da81d0304aac5c054f06eb46a7c5749c175",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/e/7b/e7b494a660063370190a467a0ef2a7833465ea50370a62e0842d12716116c8a6",
    "scope": "repo"
  },
  {
    "bytes": 12394,
    "repoRelPath": "CAPABILITY/CAS/storage/e/7d/e7ddf8b4b83669b7d8dd7947f3fd6927d5a3722e2684f4b4941b48ec9b156601",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/e/82/e820e34de3bc24e13b1e76a0d4cbef9ce5ac77b4ade121452a69cb91903d7fe7",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/e/82/e826aad70a2c469b4c415620c5266a30f30f3ab61c3d41ccaf5229d17d4bfcc8",
    "scope": "repo"
  },
  {
    "bytes": 316,
    "repoRelPath": "CAPABILITY/CAS/storage/e/83/e83148cd0dddcd22bd3d03099c489766ea163cf1ed5497c3c1d6e4c8667ffbf4",
    "scope": "repo"
  },
  {
    "bytes": 4787,
    "repoRelPath": "CAPABILITY/CAS/storage/e/87/e87e152c009cf91b4f5e7521af0c4e9788181555cd780919a74d90bb047346b9",
    "scope": "repo"
  },
  {
    "bytes": 8936,
    "repoRelPath": "CAPABILITY/CAS/storage/e/88/e8828fb7c485fd02b96462f0ee773c44f25fcbd2aaed627bdefe8035d407efac",
    "scope": "repo"
  },
  {
    "bytes": 500,
    "repoRelPath": "CAPABILITY/CAS/storage/e/97/e97f05f7e083779549ed157b14385b965784661e21f00c72f8afa2e15c481923",
    "scope": "repo"
  },
  {
    "bytes": 2242,
    "repoRelPath": "CAPABILITY/CAS/storage/e/99/e99132e819e15785cb3b552e38e642240014673f3e5285b39cc2d4db0198cbfd",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/e/a0/ea0dd30c392a694f38abf6d6d5b99f8a5c5a6367f198639ae27e9c149434260b",
    "scope": "repo"
  },
  {
    "bytes": 684,
    "repoRelPath": "CAPABILITY/CAS/storage/e/a1/ea13e88414df2ef6a1393dcc3ea8d9bf9ce9b549eedc3a32ff7b1adfe40305e6",
    "scope": "repo"
  },
  {
    "bytes": 72,
    "repoRelPath": "CAPABILITY/CAS/storage/e/a3/ea36f2464f13a3e021f183e5cdd44924dc17d5d1b30b80fcd1e440ee3d2f7f9c",
    "scope": "repo"
  },
  {
    "bytes": 33,
    "repoRelPath": "CAPABILITY/CAS/storage/e/a5/ea5f4bca21a02b3999429a3eee443d698773c257d3aa779a0535890ecc502d04",
    "scope": "repo"
  },
  {
    "bytes": 11905,
    "repoRelPath": "CAPABILITY/CAS/storage/e/aa/eaa99caed93b6f8583eabe4d5a4af082c065e7b61d27d3988fe2e1970775165d",
    "scope": "repo"
  },
  {
    "bytes": 30,
    "repoRelPath": "CAPABILITY/CAS/storage/e/ac/eac056af62f92f2449d84d84903ab32be5c2043312dcd6f48ba9ab5d07bb620f",
    "scope": "repo"
  },
  {
    "bytes": 62,
    "repoRelPath": "CAPABILITY/CAS/storage/e/ae/eae5538defef4e62f6af6d09258cdb8a7dcfac6b53bcd79a9ad173f5cd7ac8dc",
    "scope": "repo"
  },
  {
    "bytes": 50,
    "repoRelPath": "CAPABILITY/CAS/storage/e/af/eaf5dcb97dc64e9f1a6922e9999f381e197498acc07756c0b1dd75e7f04b6aed",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/e/b0/eb0863e225ed8a03cb4c85c378cbf224513d61ec47fd2385a9ef2a6453037cc7",
    "scope": "repo"
  },
  {
    "bytes": 25138,
    "repoRelPath": "CAPABILITY/CAS/storage/e/b3/eb3674497108a51630ba825081244b1d44b76fe904d4b6c31eb29d8400851f06",
    "scope": "repo"
  },
  {
    "bytes": 10779,
    "repoRelPath": "CAPABILITY/CAS/storage/e/b5/eb596b0b5ddb9d382b854909df7f01bb3e21375737e9f77047cdf6742243f20b",
    "scope": "repo"
  },
  {
    "bytes": 4810,
    "repoRelPath": "CAPABILITY/CAS/storage/e/b5/eb5a595179b641f0f08a6a5802c79406f01c1adda944f84b3f5cebd64d9650d8",
    "scope": "repo"
  },
  {
    "bytes": 842,
    "repoRelPath": "CAPABILITY/CAS/storage/e/b6/eb6e385a7797bc8d4e81dd1af7ed380e5aa4086e1e57f6a94310706ff5c6da01",
    "scope": "repo"
  },
  {
    "bytes": 3598,
    "repoRelPath": "CAPABILITY/CAS/storage/e/b8/eb8366d738eef2750196d17906b5c37d81963b71b43381efd6e7a73fe45659b0",
    "scope": "repo"
  },
  {
    "bytes": 78,
    "repoRelPath": "CAPABILITY/CAS/storage/e/bc/ebc791fdb9576204df81b72010289e6f70ecf7a2bfcaa9afaf79040c89f54236",
    "scope": "repo"
  },
  {
    "bytes": 1090,
    "repoRelPath": "CAPABILITY/CAS/storage/e/bc/ebca0da1dffab5bdd52673a21aa02db39b0f070ccd2c8e22357e05aa8259aa82",
    "scope": "repo"
  },
  {
    "bytes": 12691,
    "repoRelPath": "CAPABILITY/CAS/storage/e/bf/ebfcd444c7023ff82710ce46ba8cfc4f2cb88b604716f1eff0cd52db987b54aa",
    "scope": "repo"
  },
  {
    "bytes": 151,
    "repoRelPath": "CAPABILITY/CAS/storage/e/c0/ec08f3647647a8dae57dfbefddb4faaa28db22d75106c13864c976bc103b04bb",
    "scope": "repo"
  },
  {
    "bytes": 4267,
    "repoRelPath": "CAPABILITY/CAS/storage/e/cc/ecc12f3a6b341cbbf8192b4e4a342a76fbec4f944da7d9dc3e431b544dbd693f",
    "scope": "repo"
  },
  {
    "bytes": 814,
    "repoRelPath": "CAPABILITY/CAS/storage/e/cd/ecd4640a90d507c8a743494712170ff031c4c41a01c5e8de8c83b74da2bbe30f",
    "scope": "repo"
  },
  {
    "bytes": 343,
    "repoRelPath": "CAPABILITY/CAS/storage/e/cd/ecd8713ee19410aa557bd85e289ee09bda43ed7f0b5b6154e88fca1952dacdaa",
    "scope": "repo"
  },
  {
    "bytes": 60,
    "repoRelPath": "CAPABILITY/CAS/storage/e/ce/ece996d4d256f3442ded1b98794d4e6406b936b3f747b57fc4cef604b7c4e704",
    "scope": "repo"
  },
  {
    "bytes": 1403,
    "repoRelPath": "CAPABILITY/CAS/storage/e/ce/ecebd44c4c32e54fd0de29ed8558a747bcacbedc69fe78b061855b23423ad80c",
    "scope": "repo"
  },
  {
    "bytes": 5502,
    "repoRelPath": "CAPABILITY/CAS/storage/e/d0/ed0cc147d45494087cf0a628b77e7713459413ab45f1319e14bc1b28f5c42b0d",
    "scope": "repo"
  },
  {
    "bytes": 9703,
    "repoRelPath": "CAPABILITY/CAS/storage/e/d1/ed10c2d7d4f0b83512d9e039d5fcfa566ae6d7c7cd78ef857c757bbbb1f4a56d",
    "scope": "repo"
  },
  {
    "bytes": 8096,
    "repoRelPath": "CAPABILITY/CAS/storage/e/d7/ed7179aea8cfd420bbea0ab5c5390c198076ee48d54760f671b11575dab54bf2",
    "scope": "repo"
  },
  {
    "bytes": 4911,
    "repoRelPath": "CAPABILITY/CAS/storage/e/d7/ed76105310e6bf3c315ddf838a3a56cea29ca93c5aa2bc21b3dc7aa94fb44ff0",
    "scope": "repo"
  },
  {
    "bytes": 74,
    "repoRelPath": "CAPABILITY/CAS/storage/e/d9/ed99efeb329a6775540f48e2050813f3f84e26a18738a589e3f47a26d906ce22",
    "scope": "repo"
  },
  {
    "bytes": 18847,
    "repoRelPath": "CAPABILITY/CAS/storage/e/db/edb338f6eccb8cd3ee98db934306457435d63ed053fee4649d788b1233fbfc13",
    "scope": "repo"
  },
  {
    "bytes": 7206,
    "repoRelPath": "CAPABILITY/CAS/storage/e/db/edbd5d1c7109b2f12fd96f70d23d9f74a2311d2514100c848409b7fc5eba14aa",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/e/e0/ee07db678c0121e59fca0a762bc99fa5f7b544b8495df6721a170fc2374d2b7e",
    "scope": "repo"
  },
  {
    "bytes": 5609,
    "repoRelPath": "CAPABILITY/CAS/storage/e/e1/ee1453fa7545f068653c00133355e615acfff93e040d8029654940bc9402bc51",
    "scope": "repo"
  },
  {
    "bytes": 407,
    "repoRelPath": "CAPABILITY/CAS/storage/e/ea/eea433b1f188c6098fb0809b3485913a70a8e408dbc2d8b0951547979c7c71c7",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/e/f5/ef5b42d4008ccde241420c85c8d0ab235598096ca6e85585312410af44f0b974",
    "scope": "repo"
  },
  {
    "bytes": 273,
    "repoRelPath": "CAPABILITY/CAS/storage/e/fb/efba8598ba684833ceede3999eb5f00ef63706f7a39b2ee7427900acbb802e94",
    "scope": "repo"
  },
  {
    "bytes": 7612,
    "repoRelPath": "CAPABILITY/CAS/storage/e/fc/efc81d7525b4650aa77952f90a4bbd8c074eb88d02e10ccaf147c345611e51cc",
    "scope": "repo"
  },
  {
    "bytes": 17881,
    "repoRelPath": "CAPABILITY/CAS/storage/f/00/f00f36873d3232648f6795a8a8a7357807eadf550563f669cbd6c3e1c9b2e67e",
    "scope": "repo"
  },
  {
    "bytes": 2347,
    "repoRelPath": "CAPABILITY/CAS/storage/f/01/f01c28113b2d4c283be157b9bae6b9907369ab27ef0fc33513595f2140e046dd",
    "scope": "repo"
  },
  {
    "bytes": 20309,
    "repoRelPath": "CAPABILITY/CAS/storage/f/01/f01f8544a09807750b2862a9cbe5e0293f9019305f78b87e5695999aca90b577",
    "scope": "repo"
  },
  {
    "bytes": 9,
    "repoRelPath": "CAPABILITY/CAS/storage/f/05/f053976368a0f1e72b370de056ab94c2935eb22030694c0d9ea1c9649b71fb49",
    "scope": "repo"
  },
  {
    "bytes": 3720,
    "repoRelPath": "CAPABILITY/CAS/storage/f/08/f083295db88ef650c3517b807e7c281825cb4bfe555a77079dca71624371eb30",
    "scope": "repo"
  },
  {
    "bytes": 8,
    "repoRelPath": "CAPABILITY/CAS/storage/f/09/f0920e94fa1617e968b8235c5bf129312e6a54bea32f61e8b1eb47ea55a84855",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/f/12/f121663b175b2e1350de1aa8fd280685359eea7cee08bebb2f671cf661aa8186",
    "scope": "repo"
  },
  {
    "bytes": 5545,
    "repoRelPath": "CAPABILITY/CAS/storage/f/14/f144c8e4c8365171d0ee122ce6bac335c90b4e69946bace9ae8b2bbaccae3b66",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/f/14/f1463490861a4f47f57faf81ba471b6fe2e38622392bfdfb00b2e4526aac3573",
    "scope": "repo"
  },
  {
    "bytes": 182,
    "repoRelPath": "CAPABILITY/CAS/storage/f/19/f19c73301ce1d60279a7a10474ddf192844421aa9e29009aa3b5558ba7faafef",
    "scope": "repo"
  },
  {
    "bytes": 291,
    "repoRelPath": "CAPABILITY/CAS/storage/f/1a/f1a84733824ef0c58dae1ea29271fe8bcdc708c1afc61623431b0aca55190b5e",
    "scope": "repo"
  },
  {
    "bytes": 2747,
    "repoRelPath": "CAPABILITY/CAS/storage/f/1b/f1b3a7604141dd574f0bf778afb0c232ca8c086efade10e35c0a6a9a03a4f815",
    "scope": "repo"
  },
  {
    "bytes": 39799,
    "repoRelPath": "CAPABILITY/CAS/storage/f/1d/f1d7a6c2ffe46e3291d72d7ddca9cd55ce872f82071c9f60b09ed237cff1d543",
    "scope": "repo"
  },
  {
    "bytes": 13,
    "repoRelPath": "CAPABILITY/CAS/storage/f/20/f20cfa911775cac0c40949e055f28189e2a636e77f48787aaed56bb01ddacfeb",
    "scope": "repo"
  },
  {
    "bytes": 371,
    "repoRelPath": "CAPABILITY/CAS/storage/f/21/f2164376a721173ea93e003b9049677d8d4d3425b8fe13ba8a91e62ae40195ff",
    "scope": "repo"
  },
  {
    "bytes": 8528,
    "repoRelPath": "CAPABILITY/CAS/storage/f/21/f21cee4218b7252eb5c5609bce79e54b810a67029082b880927674fc15eb2911",
    "scope": "repo"
  },
  {
    "bytes": 1237,
    "repoRelPath": "CAPABILITY/CAS/storage/f/22/f2207033cc0bf409677a24dc4e6b46348f35c31dc69d2341fa3b120dd0b7ba44",
    "scope": "repo"
  },
  {
    "bytes": 32817,
    "repoRelPath": "CAPABILITY/CAS/storage/f/27/f277b80b8f9bdd9ac005511e317cce5190407c4ba13fd24a03f7cc822ae79adc",
    "scope": "repo"
  },
  {
    "bytes": 21,
    "repoRelPath": "CAPABILITY/CAS/storage/f/27/f279401bdcd31cdcd36de71219072abff4c6c2efc7e98fa04a3ead0d6d85d258",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/28/f283a4610305991f265a35e2da6a18206653503b8222f15338fc0dccddff19bd",
    "scope": "repo"
  },
  {
    "bytes": 3475,
    "repoRelPath": "CAPABILITY/CAS/storage/f/29/f293d297fa71531e942c5aff9b7361b6e1dbca7c7209cd7f4900d53e363a794d",
    "scope": "repo"
  },
  {
    "bytes": 4918,
    "repoRelPath": "CAPABILITY/CAS/storage/f/29/f2944fe08311cabfc8f66e04735be71eb081113cf1951ffc0874320e3790ee54",
    "scope": "repo"
  },
  {
    "bytes": 6701,
    "repoRelPath": "CAPABILITY/CAS/storage/f/2c/f2c8d7c6fca8ba46b1525426e9baaf22c27effbf7a238531d29a00eaa239cc5f",
    "scope": "repo"
  },
  {
    "bytes": 43082,
    "repoRelPath": "CAPABILITY/CAS/storage/f/31/f31621618b8fba70010f9f60df040d4a29ece94e413d5d3a00812b5139b1f960",
    "scope": "repo"
  },
  {
    "bytes": 21,
    "repoRelPath": "CAPABILITY/CAS/storage/f/33/f3391497677f3cf2db4ce695f85e4d5de199267f3a267d32dde5a6bd87d364d6",
    "scope": "repo"
  },
  {
    "bytes": 2287,
    "repoRelPath": "CAPABILITY/CAS/storage/f/34/f34182cea77b661f5291481b3531cc58e9e0b848d484d74747928fa9bbbda6ed",
    "scope": "repo"
  },
  {
    "bytes": 277,
    "repoRelPath": "CAPABILITY/CAS/storage/f/36/f36b3c32f0e9628f19cb63e75c1766deebf892ada196bc8918e41716a309a963",
    "scope": "repo"
  },
  {
    "bytes": 10621,
    "repoRelPath": "CAPABILITY/CAS/storage/f/37/f37b4de40159e90788f526308c102549cf3addb4cf7f75131c082419aa6f1655",
    "scope": "repo"
  },
  {
    "bytes": 265,
    "repoRelPath": "CAPABILITY/CAS/storage/f/39/f39f39afeabd3ce226555af7a39c4b813f4c33b23e81cb6beec0b1f122f36151",
    "scope": "repo"
  },
  {
    "bytes": 746,
    "repoRelPath": "CAPABILITY/CAS/storage/f/39/f39f9689e7b12b17f1407cfb7fab83738c539ee35a2463f1d5e7fc40362e46f5",
    "scope": "repo"
  },
  {
    "bytes": 458,
    "repoRelPath": "CAPABILITY/CAS/storage/f/3d/f3d865b8b5da09f0dd38715a88edce423ec9248d6b5d035a4f768901eaebbdfe",
    "scope": "repo"
  },
  {
    "bytes": 726,
    "repoRelPath": "CAPABILITY/CAS/storage/f/40/f40c58c0420f054c78807d1bb15bfc09d60a2511bde0744010bc0b8385178e6e",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/40/f40f5c55bf6b570b123690e3e4fab8e3a852ffb0cbb1638e98af84ff54a49e07",
    "scope": "repo"
  },
  {
    "bytes": 4775,
    "repoRelPath": "CAPABILITY/CAS/storage/f/43/f4390ccde746058a81ab8ea8f0d591cf119f0ac3ec702be17483d9446bf20274",
    "scope": "repo"
  },
  {
    "bytes": 4550,
    "repoRelPath": "CAPABILITY/CAS/storage/f/45/f45236c87ad0ea6a7b08db6da4a8cbda2c783480351ba1b89edd29f6a92783bf",
    "scope": "repo"
  },
  {
    "bytes": 30730,
    "repoRelPath": "CAPABILITY/CAS/storage/f/45/f4590f3f0520dfa6cf3fbf81e339587971a87e9f1a54cff76411ce449ac7593a",
    "scope": "repo"
  },
  {
    "bytes": 891,
    "repoRelPath": "CAPABILITY/CAS/storage/f/51/f513f3905ea166c4eb1694d15d74f67bd649a43a0d909d0b77a320946cc758be",
    "scope": "repo"
  },
  {
    "bytes": 1249891,
    "repoRelPath": "CAPABILITY/CAS/storage/f/52/f5239bc8e5796327c293bc719d0717511b3434d785ec76adf90509cd44700fba",
    "scope": "repo"
  },
  {
    "bytes": 2018,
    "repoRelPath": "CAPABILITY/CAS/storage/f/53/f53fde773948e7e87a86f7f34de68cc04cc6a2a8a7260c148d8fa8c9368cd378",
    "scope": "repo"
  },
  {
    "bytes": 2852,
    "repoRelPath": "CAPABILITY/CAS/storage/f/59/f59ce79aea9258157c19f71d80b502893e388c519942f5ec24399d2aed4f0465",
    "scope": "repo"
  },
  {
    "bytes": 8632,
    "repoRelPath": "CAPABILITY/CAS/storage/f/5d/f5d0b28fc62ef53d22a47ac3ab5547e525db0e494fd6f734234016f801dc07af",
    "scope": "repo"
  },
  {
    "bytes": 1456703,
    "repoRelPath": "CAPABILITY/CAS/storage/f/61/f618335159144101393a08f138f4f11995b7bff129e92e6f6f7b60afc3bc2f15",
    "scope": "repo"
  },
  {
    "bytes": 547,
    "repoRelPath": "CAPABILITY/CAS/storage/f/66/f667f92007321c254398fe9c1532f9fdad9417f04cd8af40bc1cfac71dad6eef",
    "scope": "repo"
  },
  {
    "bytes": 2888,
    "repoRelPath": "CAPABILITY/CAS/storage/f/6b/f6bd8787b1f3f0dd567678d7f587ae7341885b0faa4ec8ea5939a7564923295d",
    "scope": "repo"
  },
  {
    "bytes": 820,
    "repoRelPath": "CAPABILITY/CAS/storage/f/6f/f6fc2395ed8e9812b539b2f683df1bdd2a32ea906c48ebf10c37374e94da05e8",
    "scope": "repo"
  },
  {
    "bytes": 123,
    "repoRelPath": "CAPABILITY/CAS/storage/f/71/f7143d38eb0ecb38f90a868fe188f9696245061f2b593aaf112c093f2a6fdd81",
    "scope": "repo"
  },
  {
    "bytes": 2421,
    "repoRelPath": "CAPABILITY/CAS/storage/f/71/f71dc83fb42105bbe3d2a0cfcf1029d16ced2d0dcce74f6d5eff26a198ba326a",
    "scope": "repo"
  },
  {
    "bytes": 8055,
    "repoRelPath": "CAPABILITY/CAS/storage/f/73/f734de8f639f00a3e5edfb5052b95496ee41349e80295afade5a78cb33538cd2",
    "scope": "repo"
  },
  {
    "bytes": 38853,
    "repoRelPath": "CAPABILITY/CAS/storage/f/75/f753374b03f3afaad4ecac26a3d53dbfe8a73168c3a812e84d5931b3f9be917d",
    "scope": "repo"
  },
  {
    "bytes": 43015,
    "repoRelPath": "CAPABILITY/CAS/storage/f/75/f754754125db9f43aafd08f9e626b98c115c0d507c3810870f2997e283157303",
    "scope": "repo"
  },
  {
    "bytes": 6002,
    "repoRelPath": "CAPABILITY/CAS/storage/f/7b/f7b1ba619e0703c57829a8fa0768aab8411584268fcfecf0012bf7e364d84a4a",
    "scope": "repo"
  },
  {
    "bytes": 8419,
    "repoRelPath": "CAPABILITY/CAS/storage/f/7b/f7b5bdfdbfe44ac99647076cd8f0bd7b8fb9ddb49a58db43bbe3b4299a1b7791",
    "scope": "repo"
  },
  {
    "bytes": 314,
    "repoRelPath": "CAPABILITY/CAS/storage/f/7b/f7bea74d7674ca2f44896d7531e2d0d30462815b6cc38b9b9c35b30abe3a1ef4",
    "scope": "repo"
  },
  {
    "bytes": 21355,
    "repoRelPath": "CAPABILITY/CAS/storage/f/7b/f7bf1cbd16f85292094e9689733476cd7b931a824661d72789e21a250d30e992",
    "scope": "repo"
  },
  {
    "bytes": 2780,
    "repoRelPath": "CAPABILITY/CAS/storage/f/7d/f7dfe219c1ba5fe58b742099aa335bf9df0e33c99eb6f665c4593b0d5a98c92f",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/f/7f/f7f8d37b9d00f2778115b7f861e004980777fd31c57d8916ebd664f05e87e751",
    "scope": "repo"
  },
  {
    "bytes": 10618,
    "repoRelPath": "CAPABILITY/CAS/storage/f/82/f8283415040c4f372d90fd8972852bd4caafaa176c75ca754dfdce2519b9e12b",
    "scope": "repo"
  },
  {
    "bytes": 6349,
    "repoRelPath": "CAPABILITY/CAS/storage/f/84/f847317d903f6411effc9dd22513b9fa61162d11ad18388c15cc07c3538b04b1",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/84/f8475e324b0216d500181f915eef70abbecab25c0ac8d01822f2bb6c4882a7c1",
    "scope": "repo"
  },
  {
    "bytes": 32301,
    "repoRelPath": "CAPABILITY/CAS/storage/f/90/f90ec828cabdcf7f2b5d41015f827c7fd02a6ba0911b646f21f33cfa46c0a50e",
    "scope": "repo"
  },
  {
    "bytes": 36199,
    "repoRelPath": "CAPABILITY/CAS/storage/f/91/f91de16eaea5f1427befff565c89b9ca26eeaf32b2cc0ec4a8c7e21566376954",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/98/f98e64cfc121c3bb9ba67eaa1d0192cf6ebf69ddc97c2ccd01beb00ed50f4926",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/99/f99be8666fd318e3189672d4470706453184b63c22a74341368137a7027575cd",
    "scope": "repo"
  },
  {
    "bytes": 169,
    "repoRelPath": "CAPABILITY/CAS/storage/f/9f/f9f37892e0ee164b7f3026737d1ac39674b8f4450b27b0efd900dba5036ec56e",
    "scope": "repo"
  },
  {
    "bytes": 39239,
    "repoRelPath": "CAPABILITY/CAS/storage/f/a2/fa2515e55d94a082b4f7f79dbcd221c751b303c0eef4b7168b15955ed4800b18",
    "scope": "repo"
  },
  {
    "bytes": 4306,
    "repoRelPath": "CAPABILITY/CAS/storage/f/a3/fa31f91791b1e200f1bc97f1b55d617efa323a4e81f3a1d40dd4d56b0528c11e",
    "scope": "repo"
  },
  {
    "bytes": 417,
    "repoRelPath": "CAPABILITY/CAS/storage/f/a4/fa44cb4d66e72e17db3c7dd58f977a7b2e9c8be9ec4c9f3d165f14c3daf10166",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/a4/fa492a7eaefeaf494bb7420ae910763def76c2db7e18592e792e36820aea1a84",
    "scope": "repo"
  },
  {
    "bytes": 27012,
    "repoRelPath": "CAPABILITY/CAS/storage/f/a4/fa4c2aa6ca535b142784c0c6f49128703f0336168a188517c8c7fdff86e44e52",
    "scope": "repo"
  },
  {
    "bytes": 30741,
    "repoRelPath": "CAPABILITY/CAS/storage/f/a6/fa6974ea30b6c5599124b6435b7152e827a894360609df50498ddbaac38a49be",
    "scope": "repo"
  },
  {
    "bytes": 467,
    "repoRelPath": "CAPABILITY/CAS/storage/f/a8/fa8c69b1d2a11f9c5c94a92d5ced4bdd5876623b99bcc81b59f56a063f03b137",
    "scope": "repo"
  },
  {
    "bytes": 27097,
    "repoRelPath": "CAPABILITY/CAS/storage/f/a8/fa8e9df3bdd1f274eb895dce5d2ea611ebeb0eafba29c1cb4d97806bfdb5804e",
    "scope": "repo"
  },
  {
    "bytes": 9535,
    "repoRelPath": "CAPABILITY/CAS/storage/f/aa/faa3e8cbad3ce59f157bbf658b445a4070ee8a57d2fcb79a760cf0d480c96213",
    "scope": "repo"
  },
  {
    "bytes": 503,
    "repoRelPath": "CAPABILITY/CAS/storage/f/aa/faa667081997497d841535692d811bfac5f38e2b54e446b7634d018fb001ad0d",
    "scope": "repo"
  },
  {
    "bytes": 6926,
    "repoRelPath": "CAPABILITY/CAS/storage/f/ac/fac0fea50693eed501169f5129378ff666ef820bf52d6e0133b5a5431609402d",
    "scope": "repo"
  },
  {
    "bytes": 1707,
    "repoRelPath": "CAPABILITY/CAS/storage/f/ae/fae1ab027325d89ab0bc06ba866903d0469da2e90a445ea38028fdb06238c230",
    "scope": "repo"
  },
  {
    "bytes": 68,
    "repoRelPath": "CAPABILITY/CAS/storage/f/b2/fb2a1dc57aacb26b3557e96371a4d4562f8663205ad15d12d5df89870d6b0632",
    "scope": "repo"
  },
  {
    "bytes": 805,
    "repoRelPath": "CAPABILITY/CAS/storage/f/b6/fb618d5819dd8eb794c59e2d2ccb161d867f5e2d062fd011b48416fafba3de94",
    "scope": "repo"
  },
  {
    "bytes": 17180,
    "repoRelPath": "CAPABILITY/CAS/storage/f/be/fbe9b2ed610372cd5b56230683caac0224776f4a116e49cfc70c31a94af65614",
    "scope": "repo"
  },
  {
    "bytes": 3206,
    "repoRelPath": "CAPABILITY/CAS/storage/f/bf/fbf275039da9f64f09eae597b73c6312d06c1e08a34b08682b7677aabcde5e30",
    "scope": "repo"
  },
  {
    "bytes": 2261,
    "repoRelPath": "CAPABILITY/CAS/storage/f/c1/fc1f321ae3dfa097d1f22fa2af579faabfb774caa06600f8cc82f100323f289f",
    "scope": "repo"
  },
  {
    "bytes": 100,
    "repoRelPath": "CAPABILITY/CAS/storage/f/c3/fc34f2fd80db5c0b9ecbeb34bf2eb26ce953c9d00216c523b66f9751ec8fb326",
    "scope": "repo"
  },
  {
    "bytes": 160,
    "repoRelPath": "CAPABILITY/CAS/storage/f/c5/fc58bd8a3c911e345a8c8fc9df6c4f37b6638eaa6fd4fa0f5d265212040aec26",
    "scope": "repo"
  },
  {
    "bytes": 202,
    "repoRelPath": "CAPABILITY/CAS/storage/f/c9/fc9995a1fb79fa7877cda886a53698aab790338f9407c26d99d73963709ac59a",
    "scope": "repo"
  },
  {
    "bytes": 321,
    "repoRelPath": "CAPABILITY/CAS/storage/f/ca/fca40bfaa7ca0ee2964ee9cff2b33cc3c906656985d7af9554eaa274c91c776b",
    "scope": "repo"
  },
  {
    "bytes": 4937,
    "repoRelPath": "CAPABILITY/CAS/storage/f/cc/fcc11f81534ad9ff08c89e88c02782da0e1585c6bd3b02af101ed2336cbdf09e",
    "scope": "repo"
  },
  {
    "bytes": 8111,
    "repoRelPath": "CAPABILITY/CAS/storage/f/cc/fcc5bc567135600639a67f74e10138cd119e0cdca347f2f3fc730dda7675da25",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/cf/fcfeeb1d9444beb4d8afa8111477019b0685a54c0b6f0f7ab70fd5d11f2c7335",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/d9/fd91aee9df47688bf1bf1fc1eb253466ec114e0360a77b7fb41ebb2e0dd57d6a",
    "scope": "repo"
  },
  {
    "bytes": 6155,
    "repoRelPath": "CAPABILITY/CAS/storage/f/da/fda93e49ceeb9ea40b5986419f1fdc1b907dac9ec2dbabbcc7d209f2c38a63fa",
    "scope": "repo"
  },
  {
    "bytes": 4036,
    "repoRelPath": "CAPABILITY/CAS/storage/f/db/fdb4567b8c304c7f079ded2a5e7c4add13f097e5626bb9dae7e7439712f039e2",
    "scope": "repo"
  },
  {
    "bytes": 416,
    "repoRelPath": "CAPABILITY/CAS/storage/f/db/fdba86d9ec0bc71756ea87c52caaf7bdd73e3c6fe8b6f29e5f42400ac48d0b96",
    "scope": "repo"
  },
  {
    "bytes": 847,
    "repoRelPath": "CAPABILITY/CAS/storage/f/dd/fddc93a19ccfdef27b5bd0ffb9d7fef84253e11d8b1993d8534321b615a74d5e",
    "scope": "repo"
  },
  {
    "bytes": 72,
    "repoRelPath": "CAPABILITY/CAS/storage/f/de/fded354783af97c74cfa7283b94b17e96612fd88a2fa3a4022897f7c1dff2a0f",
    "scope": "repo"
  },
  {
    "bytes": 744,
    "repoRelPath": "CAPABILITY/CAS/storage/f/de/fdeec6b3f33bded7477c85fd1ec3cea75ac138c0f0c73fa689ff177a51a69da6",
    "scope": "repo"
  },
  {
    "bytes": 263,
    "repoRelPath": "CAPABILITY/CAS/storage/f/df/fdf978c01931d51d5fa8aa39e8d7c7704220e5c4757cd9d6257afca864d84529",
    "scope": "repo"
  },
  {
    "bytes": 7434,
    "repoRelPath": "CAPABILITY/CAS/storage/f/e1/fe1c5239001d0c15f3451202c9f5f27e877c468c73fdf468dfb75aca06bc1bf7",
    "scope": "repo"
  },
  {
    "bytes": 18,
    "repoRelPath": "CAPABILITY/CAS/storage/f/e2/fe24bce0b64a79aee2b1511494fc809da9f5951e7622889e3cc7f4f0bb689eb6",
    "scope": "repo"
  },
  {
    "bytes": 4472,
    "repoRelPath": "CAPABILITY/CAS/storage/f/e4/fe41e0e2b9b0fe167873bf19b8a05f5cb384cfadc2e1cacbb116018ad75beab6",
    "scope": "repo"
  },
  {
    "bytes": 547,
    "repoRelPath": "CAPABILITY/CAS/storage/f/e4/fe49dfee148d2710b1e97233b24679b6c5a669e787e568b8b3ca2a7e9259362a",
    "scope": "repo"
  },
  {
    "bytes": 4727,
    "repoRelPath": "CAPABILITY/CAS/storage/f/e4/fe4a22106c1a2bb6f5d67b11b1d53f3607dc9c11e7e193153caa567fa9baa538",
    "scope": "repo"
  },
  {
    "bytes": 2798,
    "repoRelPath": "CAPABILITY/CAS/storage/f/e7/fe76b8cc9fd59145c02f0f03eaa4c4c1feb3db0d7546b4f8d9f250c9dd59591e",
    "scope": "repo"
  },
  {
    "bytes": 18440,
    "repoRelPath": "CAPABILITY/CAS/storage/f/e9/fe9fe7fce1889d82452b70b8b48b937ad88ece577060a52e08983f48d4ab5928",
    "scope": "repo"
  },
  {
    "bytes": 3584,
    "repoRelPath": "CAPABILITY/CAS/storage/f/eb/feb6116a92f5f3b1a9742c166ef0da3fa26e05ef1ed9b47ea1acb9a95ee547f0",
    "scope": "repo"
  },
  {
    "bytes": 4947,
    "repoRelPath": "CAPABILITY/CAS/storage/f/ee/fee759fc40dbb9f3208d3824ab8a8255835ad736efe911d0c8ca87929e09f83c",
    "scope": "repo"
  },
  {
    "bytes": 19,
    "repoRelPath": "CAPABILITY/CAS/storage/f/f0/ff098afb1895400f9176429ee1bd56cd51a069c41df2b5fe9006b38954f8ac61",
    "scope": "repo"
  },
  {
    "bytes": 5943,
    "repoRelPath": "CAPABILITY/CAS/storage/f/f2/ff2612c05553a662e1d37421bd03a3c6e01d5eaf42bf018acc9a127672d61201",
    "scope": "repo"
  },
  {
    "bytes": 19766,
    "repoRelPath": "CAPABILITY/CAS/storage/f/f2/ff266f572324ecdaddf1522b96145729c07b602fb97b2bc0a8fecc6731e9ac00",
    "scope": "repo"
  },
  {
    "bytes": 384,
    "repoRelPath": "CAPABILITY/CAS/storage/f/f3/ff3f188379be12bbb0ef67885b26e215a40102fec42dfa3ba8b9165195acbc8d",
    "scope": "repo"
  },
  {
    "bytes": 837,
    "repoRelPath": "CAPABILITY/CAS/storage/f/f6/ff6253974f7da7cb396b9a8b72d38d4a38bf08df14f6c5808f19f4d2b5da00a5",
    "scope": "repo"
  },
  {
    "bytes": 142,
    "repoRelPath": "CAPABILITY/CAS/storage/f/f9/ff9c3226f84ca4398f784fd15114470c6bd80d95e82585a849c7bae7588d0016",
    "scope": "repo"
  },
  {
    "bytes": 512,
    "repoRelPath": "CAPABILITY/CAS/storage/f/fe/ffed3d76defed08305175410fc8dff75f78503555131ee0970314124a1d19dd5",
    "scope": "repo"
  },
  {
    "bytes": 1808,
    "repoRelPath": "CAPABILITY/CAS/storage/f/ff/fff291b4a08cb337c6ea78a26cbec36182b901f3469c03a91236c597e36c8769",
    "scope": "repo"
  },
  {
    "bytes": 5541,
    "repoRelPath": "CAPABILITY/CAS/storage/f/ff/fffebaade8f87842ec3b5902b4612d52056093f018504034af453383323ae428",
    "scope": "repo"
  },
  {
    "bytes": 178,
    "repoRelPath": "CAPABILITY/SKILLS/_TEMPLATE/run.sh",
    "scope": "repo"
  },
  {
    "bytes": 2346,
    "repoRelPath": "CAPABILITY/SKILLS/governance/canon-governance-check/scripts/pre-commit",
    "scope": "repo"
  },
  {
    "bytes": 272,
    "repoRelPath": "CAPABILITY/SKILLS/inbox/inbox-report-writer/post-commit-hook.sh",
    "scope": "repo"
  },
  {
    "bytes": 1194,
    "repoRelPath": "CAPABILITY/SKILLS/mcp/mcp-builder/scripts/example_evaluation.xml",
    "scope": "repo"
  },
  {
    "bytes": 323,
    "repoRelPath": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/pyproject.toml",
    "scope": "repo"
  },
  {
    "bytes": 4056,
    "repoRelPath": "CAPABILITY/TESTBENCH/core/test_cas_store.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 3512,
    "repoRelPath": "CAPABILITY/TESTBENCH/core/test_cas_store.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 1661,
    "repoRelPath": "CAPABILITY/TESTBENCH/integration/test_demo_memoization_hash_reuse.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 1552,
    "repoRelPath": "CAPABILITY/TESTBENCH/integration/test_demo_memoization_hash_reuse.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 3218,
    "repoRelPath": "CAPABILITY/TESTBENCH/integration/test_memoization.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 2303,
    "repoRelPath": "CAPABILITY/TESTBENCH/integration/test_packing_hygiene.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 2311,
    "repoRelPath": "CAPABILITY/TESTBENCH/integration/test_packing_hygiene.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 879,
    "repoRelPath": "CAPABILITY/TESTBENCH/integration/test_skills_registry.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 879,
    "repoRelPath": "CAPABILITY/TESTBENCH/integration/test_skills_registry.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 2873,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_bridge.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 2873,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_bridge.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 6131,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_capability_pins.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 4536,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_capability_revokes.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 4524,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_capability_revokes.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 4046,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_mcp_adapter_e2e.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 4127,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_registry_immutability.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 4915,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase7_swarm/test_phase7_acceptance.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 5669,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase7_swarm/test_swarm_reuse.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 5684,
    "repoRelPath": "CAPABILITY/TESTBENCH/phases/phase7_swarm/test_swarm_reuse.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 4674,
    "repoRelPath": "CAPABILITY/TESTBENCH/pipeline/test_canonical_artifacts.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 475,
    "repoRelPath": "CAPABILITY/TESTBENCH/pipeline/test_verifier_freeze.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 506,
    "repoRelPath": "CAPABILITY/TESTBENCH/spectrum/test_spectrum02_resume.py.prof_bak",
    "scope": "repo"
  },
  {
    "bytes": 575,
    "repoRelPath": "CAPABILITY/TESTBENCH/spectrum/test_spectrum02_resume.py.swarm_bak",
    "scope": "repo"
  },
  {
    "bytes": 11567,
    "repoRelPath": "CAPABILITY/TOOLS/linters/lint_prompt_pack.sh",
    "scope": "repo"
  },
  {
    "bytes": 3114,
    "repoRelPath": "CAPABILITY/TOOLS/linters/test_linter.sh",
    "scope": "repo"
  },
  {
    "bytes": 2021,
    "repoRelPath": "CAPABILITY/TOOLS/linters/validate_linter.sh",
    "scope": "repo"
  },
  {
    "bytes": 1944,
    "repoRelPath": "CAPABILITY/TOOLS/utilities/ensure_https_remote.sh",
    "scope": "repo"
  },
  {
    "bytes": 4177,
    "repoRelPath": "CAPABILITY/TOOLS/utilities/git_doctor.sh",
    "scope": "repo"
  },
  {
    "bytes": 1032,
    "repoRelPath": "CAPABILITY/TOOLS/utilities/push_main.sh",
    "scope": "repo"
  },
  {
    "bytes": 28487680,
    "repoRelPath": "NAVIGATION/CORTEX/db/codebase_full.db",
    "scope": "repo"
  },
  {
    "bytes": 57344,
    "repoRelPath": "NAVIGATION/CORTEX/db/instructions.db",
    "scope": "repo"
  },
  {
    "bytes": 1538,
    "repoRelPath": "NAVIGATION/CORTEX/db/schema/002_vectors.sql",
    "scope": "repo"
  },
  {
    "bytes": 855,
    "repoRelPath": "NAVIGATION/CORTEX/db/schema.sql",
    "scope": "repo"
  },
  {
    "bytes": 1925120,
    "repoRelPath": "NAVIGATION/CORTEX/db/swarm_instructions.db",
    "scope": "repo"
  },
  {
    "bytes": 4358144,
    "repoRelPath": "NAVIGATION/CORTEX/db/system1.db",
    "scope": "repo"
  },
  {
    "bytes": 28672,
    "repoRelPath": "NAVIGATION/CORTEX/db/system2.db",
    "scope": "repo"
  },
  {
    "bytes": 73728,
    "repoRelPath": "NAVIGATION/CORTEX/test_system1.db",
    "scope": "repo"
  },
  {
    "bytes": 133432,
    "repoRelPath": "NAVIGATION/PROMPTS.zip",
    "scope": "repo"
  },
  {
    "bytes": 1437,
    "repoRelPath": "MEMORY/LLM_PACKER/1-AGS-PACK.lnk",
    "scope": "repo"
  },
  {
    "bytes": 1437,
    "repoRelPath": "MEMORY/LLM_PACKER/2-LAB-PACK.lnk",
    "scope": "repo"
  },
  {
    "bytes": 3144,
    "repoRelPath": "MEMORY/LLM_PACKER/Engine/lab.ico",
    "scope": "repo"
  }
]
```

## `meta/REPO_STATE.json`

```
{
  "canon_version": "3.0.0",
  "files": [
    {
      "hash": "d4fe37d08d2d68b933227142ff83dde113bad4a6edc7d78d314df07d91216087",
      "path": ".editorconfig",
      "size": 202
    },
    {
      "hash": "05de46de8af9918c1b42e187eb15f0a778a9ea0abf05ae7737e0c5201f32c7d0",
      "path": ".gitattributes",
      "size": 202
    },
    {
      "hash": "84f30090d0a45c57aaf60eb026bc89d68f3116d86f4711ee40de816b84a8ba34",
      "path": ".github/workflows/contracts.yml",
      "size": 6424
    },
    {
      "hash": "331cedc951ce666e7b4a98a3f91cd0bd818e5795cc436e2b568317dc321784ac",
      "path": ".github/workflows/governance.yml",
      "size": 410
    },
    {
      "hash": "0937c4fa90725ff52e4fd22863629c27894efa49f5df26d849f274996a784143",
      "path": ".gitignore",
      "size": 1949
    },
    {
      "hash": "f00f36873d3232648f6795a8a8a7357807eadf550563f669cbd6c3e1c9b2e67e",
      "path": "AGENTS.md",
      "size": 17881
    },
    {
      "hash": "771778efab33cbbceafed62299cbb90c9fabdd6c48ec59792fc0708263fca848",
      "path": "CAPABILITY/ARTIFACTS/IMPLEMENTATION.md",
      "size": 4659
    },
    {
      "hash": "68410da40ad10c58f1e4a26788b9701de638b3336ea86192d477519210703ce6",
      "path": "CAPABILITY/ARTIFACTS/README.md",
      "size": 3579
    },
    {
      "hash": "ad382ebb10a5fe58f38af7f265f52383636044c5fe57773bab5286f380a2ad78",
      "path": "CAPABILITY/ARTIFACTS/__init__.py",
      "size": 530
    },
    {
      "hash": "6ac809f144684a0d79af9e03918fa7890a2e0e7972ad4876a5556a66a288d30f",
      "path": "CAPABILITY/ARTIFACTS/store.py",
      "size": 8901
    },
    {
      "hash": "d1edd0ee14fac3ce51c0561936623248a81f4fbbe1d02db65a257b4ae99241ee",
      "path": "CAPABILITY/AUDIT/IMPLEMENTATION.md",
      "size": 5633
    },
    {
      "hash": "7dcf58c6eb113f69df9147395dc11ee1f5f26eada61deddc1a13dfd667921b10",
      "path": "CAPABILITY/AUDIT/__init__.py",
      "size": 239
    },
    {
      "hash": "c06f478e8fbd7b484917cc4dca3f52e6e8c6c0e7329a94efa0891b8d9092aad7",
      "path": "CAPABILITY/AUDIT/root_audit.py",
      "size": 17001
    },
    {
      "hash": "bfe74c796ba738a9de208d7af79c210ca15f5fc8c56984fc7982f1cf46b632af",
      "path": "CAPABILITY/CAS/cas.py",
      "size": 4191
    },
    {
      "hash": "47611271380bcf0608afc483aea90c82d5836bb231ab2f4e18e923ac185fe100",
      "path": "CAPABILITY/GC/IMPLEMENTATION.md",
      "size": 7012
    },
    {
      "hash": "2f080ed7a0f48fbe6cfed536ae46fe5470b8b6a9f903b5a5d59f96b00198a220",
      "path": "CAPABILITY/GC/__init__.py",
      "size": 302
    },
    {
      "hash": "7a97a2078ce3c556eae406db576be47ae96e6876b81e4ea33eae41168aa62fe0",
      "path": "CAPABILITY/GC/gc.py",
      "size": 16223
    },
    {
      "hash": "50598af55b453adb45b8b0d8433300d166d6ae7fc49ce99f77817ba5a1afab76",
      "path": "CAPABILITY/MCP/MCP_SPEC.md",
      "size": 5117
    },
    {
      "hash": "3bf2a00ec793946add5911ed02e3dc279efc6d72e58f9be4821cdcc4defba5eb",
      "path": "CAPABILITY/MCP/QUICKSTART.md",
      "size": 2520
    },
    {
      "hash": "7241b8e6b8d0e650e0da6d06bb193e4a3b91aa12e3acd416e5d0f86b1272b49a",
      "path": "CAPABILITY/MCP/README.md",
      "size": 5816
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "CAPABILITY/MCP/__init__.py",
      "size": 0
    },
    {
      "hash": "55525b3a0724227b0f862a53f731c330fe910a6d7638fff618a307076022ac3b",
      "path": "CAPABILITY/MCP/board_roles.json",
      "size": 67
    },
    {
      "hash": "0384fe9dac4fd5b7e4651dbb795576f1a9f4608b216c5e062d5c8fc871a161f6",
      "path": "CAPABILITY/MCP/claude_desktop_config.json",
      "size": 646
    },
    {
      "hash": "221efc3add17b089d6c51691c28551ee9b0f2f082e0f8cf141202442a3cb9cf8",
      "path": "CAPABILITY/MCP/powershell_bridge.ps1",
      "size": 5015
    },
    {
      "hash": "a8c56278975796ff6a7b3af4ce6adb4ca93762fc8de5bb9b2d0d6eafed04ecb2",
      "path": "CAPABILITY/MCP/powershell_bridge_config.json",
      "size": 178
    },
    {
      "hash": "636fa9806d02c384d9864435e0163e17f87c7d35497455b039ddfd65f9717f15",
      "path": "CAPABILITY/MCP/schemas/governance/adr.schema.json",
      "size": 2036
    },
    {
      "hash": "8f89fcf4e58617c6a650a1d30ffcf668e7436ce032d1949c1274ca28eb9db64c",
      "path": "CAPABILITY/MCP/schemas/governance/skill.schema.json",
      "size": 1068
    },
    {
      "hash": "9b06de9ea7dc450151f097da3d720c30c5feb18660c00c328026796ad250adc2",
      "path": "CAPABILITY/MCP/schemas/governance/style.schema.json",
      "size": 1447
    },
    {
      "hash": "fbf275039da9f64f09eae597b73c6312d06c1e08a34b08682b7677aabcde5e30",
      "path": "CAPABILITY/MCP/schemas/resources.json",
      "size": 3206
    },
    {
      "hash": "625a1cd45d0db710ea8e595b0f338fda36a4aab1daf95deae38d1fd0ed991b96",
      "path": "CAPABILITY/MCP/schemas/tools.json",
      "size": 24308
    },
    {
      "hash": "0822d0d38260fc9eaff7c42b6cb9fc8c16fe58038af3206eb881138cfbb5a5fd",
      "path": "CAPABILITY/MCP/semantic_adapter.py",
      "size": 8955
    },
    {
      "hash": "80386bd36ff542f05edcce81b6b191c03e4b438c9d31df29e827c5c5e3695ca2",
      "path": "CAPABILITY/MCP/server.py",
      "size": 118840
    },
    {
      "hash": "94663b7e8085d5449906f9a0e2efc7b225ec0595f6ef95cb0e2dbc9285420acd",
      "path": "CAPABILITY/MCP/server_wrapper.py",
      "size": 3920
    },
    {
      "hash": "af088fc86bc5168e36a522c9308b4a9ace812b1a1bc4b6ede8dd3f036ec81012",
      "path": "CAPABILITY/MCP/start_simple.cmd",
      "size": 101
    },
    {
      "hash": "ad9bd6587a4ca96d966ec9ae35b4112ea66bf12dc44a5656fb07307616def235",
      "path": "CAPABILITY/MCP/verify_governance.py",
      "size": 1892
    },
    {
      "hash": "6befc3659dd13e536473e0069bb1933109c7803b7bfc14c243be27256c3d7d96",
      "path": "CAPABILITY/PIPELINES/pipeline_chain.py",
      "size": 7681
    },
    {
      "hash": "432e1593d6de7c861451e72cc39c425b707f19de0ae27d4d4952b4333e84d87a",
      "path": "CAPABILITY/PIPELINES/pipeline_dag.py",
      "size": 27255
    },
    {
      "hash": "253c74a2fb645976aa767ca8307568363cdf6838eb51a821e45332355d43e464",
      "path": "CAPABILITY/PIPELINES/pipeline_runtime.py",
      "size": 20952
    },
    {
      "hash": "0762d4aa9ee20f903259921ee6995fc964864b81f1e645d28fb2edf1981282c8",
      "path": "CAPABILITY/PIPELINES/pipeline_verify.py",
      "size": 19899
    },
    {
      "hash": "715b2bfa8f9a58cef3a55146c11804a6730575f736c13879724cf95a441da0a3",
      "path": "CAPABILITY/PIPELINES/swarm_runtime.py",
      "size": 13297
    },
    {
      "hash": "92a1038ce8679ef799112764a52e101f3ec76a299beb55b05899fd9a020e2cdb",
      "path": "CAPABILITY/PRIMITIVES/VERIFYING.md",
      "size": 5332
    },
    {
      "hash": "498ee6ef0a9bd90a3ba937e21cacd7e1028657d80436c72cb09eafd350b87704",
      "path": "CAPABILITY/PRIMITIVES/__init__.py",
      "size": 1635
    },
    {
      "hash": "c7f902ac6cac8119c367e65dd526872f7c5517b5e2cdf7f2b5ed9ddf934033c0",
      "path": "CAPABILITY/PRIMITIVES/cas_store.py",
      "size": 10560
    },
    {
      "hash": "9311d95d57f1127a589dc609974e135a6d51a36fdf6d119db4eec7c1e034f7f1",
      "path": "CAPABILITY/PRIMITIVES/fs_guard.py",
      "size": 6717
    },
    {
      "hash": "814efefdfc4bcd272cf42222d0f7d6785f4a1d9c01b129ded7324849771dc035",
      "path": "CAPABILITY/PRIMITIVES/hash_toolbelt.py",
      "size": 11222
    },
    {
      "hash": "e492c1add989185fdfbb9b3464f07691e054ea2aff891a487aa5bfb187374734",
      "path": "CAPABILITY/PRIMITIVES/ledger.py",
      "size": 7387
    },
    {
      "hash": "3b17f35eccb370b69fec1df88f7a36d5fd3fdc7d0803b9e3ef9e185790add8c8",
      "path": "CAPABILITY/PRIMITIVES/memo_cache.py",
      "size": 7257
    },
    {
      "hash": "8cb015f86c0ed571afbedf9ab57b026802d8740131ba69b317d45267c31c81db",
      "path": "CAPABILITY/PRIMITIVES/merkle.py",
      "size": 2645
    },
    {
      "hash": "f795ce907d934023b640112482aac19d8e5fb26927d5edc54eea88b89d40b4a8",
      "path": "CAPABILITY/PRIMITIVES/preflight.py",
      "size": 13341
    },
    {
      "hash": "830080b8f2fd8df0c84eb0546f57ca4af17028f72d5f33741ff8678866064555",
      "path": "CAPABILITY/PRIMITIVES/registry_validators.py",
      "size": 9231
    },
    {
      "hash": "ab15dbeb4bc7a13d3b9a9f0056b0bfdf75cb46afa0adaeb827a1b4b52c40660f",
      "path": "CAPABILITY/PRIMITIVES/restore_proof.py",
      "size": 9551
    },
    {
      "hash": "bae5ce9455461b78594755629661dcd125afac0ac10445e53505fbdb054c1900",
      "path": "CAPABILITY/PRIMITIVES/restore_runner.py",
      "size": 26253
    },
    {
      "hash": "204f15377315571967f2a70a3558a47019962f249e24063a80021b878a95436c",
      "path": "CAPABILITY/PRIMITIVES/scratch.py",
      "size": 2190
    },
    {
      "hash": "133ea5567ac729979ba5c86fc6914063fde9a10035d7fdfbb399d372144989d2",
      "path": "CAPABILITY/PRIMITIVES/skills.py",
      "size": 4949
    },
    {
      "hash": "bd0c3508881dcb71dfc6d4c1e536feff75e44d3fa14d075ad7138da363f7b20b",
      "path": "CAPABILITY/PRIMITIVES/verify_bundle.py",
      "size": 34427
    },
    {
      "hash": "f01f8544a09807750b2862a9cbe5e0293f9019305f78b87e5695999aca90b577",
      "path": "CAPABILITY/PRIMITIVES/verify_bundle_alt.py",
      "size": 20309
    },
    {
      "hash": "6b0e234afd048b5814c43cc5f51866a2f1d08a68f9e1f378c3c492fd6c025811",
      "path": "CAPABILITY/RUNS/__init__.py",
      "size": 692
    },
    {
      "hash": "2c62345f3bb20cf7f98de777bee54f9c46fe253a2db8ad03d8456a63866cf026",
      "path": "CAPABILITY/RUNS/bundles.py",
      "size": 12837
    },
    {
      "hash": "5bd63dfa7f7c51a0cc57f519468e3b40fe7451f6595a9d3543078088fd6aa900",
      "path": "CAPABILITY/RUNS/records.py",
      "size": 10842
    },
    {
      "hash": "82644239207fee5a3837b869547b9252b540522941e7a2a1f2e638bc673ae9ad",
      "path": "CAPABILITY/SKILLS/_TEMPLATE/SKILL.md",
      "size": 949
    },
    {
      "hash": "44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a",
      "path": "CAPABILITY/SKILLS/_TEMPLATE/fixtures/basic/expected.json",
      "size": 2
    },
    {
      "hash": "44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a",
      "path": "CAPABILITY/SKILLS/_TEMPLATE/fixtures/basic/input.json",
      "size": 2
    },
    {
      "hash": "1ed3f6d01a1870ecc0807a900fb5f12e392b63ff278dd72733ef23ae66720234",
      "path": "CAPABILITY/SKILLS/_TEMPLATE/run.py",
      "size": 1200
    },
    {
      "hash": "e0188e2ed2e38cf012cc1d2218234ab4fe867ba68f6b4364af5c35ff46207287",
      "path": "CAPABILITY/SKILLS/_TEMPLATE/validate.py",
      "size": 1142
    },
    {
      "hash": "defd62398dc52586bfe8e88b250440577b1a757ba0d62b93df553ec615129594",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/SKILL.md",
      "size": 1016
    },
    {
      "hash": "2da9d6671c86c67da21c1b2f34723df4ef5103e4e0980ad0f6a8c0117d853604",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/assets/code_adapt_task.json",
      "size": 570
    },
    {
      "hash": "19bcf23c34d920dc6004ec897406dbc30381b3bdfc1b7847998c08de2fc8ad44",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/assets/file_copy_task.json",
      "size": 738
    },
    {
      "hash": "8b98f8cd2e3e3e6bb626b8b9498edb87bbffae49a374374bdd4bb2d366784add",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/assets/research_task.json",
      "size": 172
    },
    {
      "hash": "24b5de07685d99eb8b6fe31c36902fec10dff6158359bc9b3184d2bd2b1dbfdb",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/assets/schema.json",
      "size": 3366
    },
    {
      "hash": "177d392055dd0fd63dd799f4b559d9ddc09389dc17f282a444f2ec3d2def0d2c",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/assets/validate_task.json",
      "size": 368
    },
    {
      "hash": "557fe3e88e0eb421c2191ba67b00bcb938257b9988751ab16cc0f284070c5dc7",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/fixtures/basic/expected.json",
      "size": 59
    },
    {
      "hash": "c0f68ef968655946b866d1a07a7769b12178b38027daefac4bf38a91f4c28c99",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/fixtures/basic/input.json",
      "size": 155
    },
    {
      "hash": "7624c5b3b43be9c9c4060fe23c8257e81053a05b543f60f101b45032f6ea370d",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/run.py",
      "size": 1398
    },
    {
      "hash": "f083295db88ef650c3517b807e7c281825cb4bfe555a77079dca71624371eb30",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/scripts/ant_agent.py",
      "size": 3720
    },
    {
      "hash": "f2207033cc0bf409677a24dc4e6b46348f35c31dc69d2341fa3b120dd0b7ba44",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/scripts/lfm2_runner.py",
      "size": 1237
    },
    {
      "hash": "c1763732d121e1fc1856e0c1b4cd9cfe054cb123152539217c7e3f89ba835538",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/scripts/run.py",
      "size": 20835
    },
    {
      "hash": "71165335b7bc7bcccec3319c95b2d4b1db6cd080210aa996ebd8541ebc5188ab",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/scripts/test_ant_worker.py",
      "size": 9196
    },
    {
      "hash": "b51dd1c9ff6e94727c15fc1c60599d999c7c1d29caa6f15e0be4ec1586ab3ce2",
      "path": "CAPABILITY/SKILLS/agents/ant-worker/validate.py",
      "size": 810
    },
    {
      "hash": "633f6c860d5501cceb99ab315cbe29b5b58e244da76893e4ea60b86e79fea524",
      "path": "CAPABILITY/SKILLS/commit/artifact-escape-hatch/SKILL.md",
      "size": 930
    },
    {
      "hash": "06fadc8528c45eb5c13b125496dcf9de5e05500e146ba8bf0ec122be82128f4b",
      "path": "CAPABILITY/SKILLS/commit/artifact-escape-hatch/fixtures/basic/expected.json",
      "size": 221
    },
    {
      "hash": "295a7446eddfee45ec4f0dcc1819cc30fe5ba6bc104474fbd22387f8fd95520e",
      "path": "CAPABILITY/SKILLS/commit/artifact-escape-hatch/fixtures/basic/input.json",
      "size": 159
    },
    {
      "hash": "bf5ce76945b7d8b98bd55f9c7910ebed7d7ff9deb92e02428485d123fc8601fd",
      "path": "CAPABILITY/SKILLS/commit/artifact-escape-hatch/run.py",
      "size": 5919
    },
    {
      "hash": "093531739c3f8c7e5fce652657e6d8c8b17deb7ab3be9387fbeb0e7e9b668a71",
      "path": "CAPABILITY/SKILLS/commit/artifact-escape-hatch/validate.py",
      "size": 851
    },
    {
      "hash": "17ca968f39b4245228b68aad06fa6d90fc5ac2f2e2c877008ce004ef3c8aacc3",
      "path": "CAPABILITY/SKILLS/commit/commit-queue/SKILL.md",
      "size": 1715
    },
    {
      "hash": "9eebf32bd6946553becc1cc946fcc56288566d10203f3dd0394b47cb77d1e65e",
      "path": "CAPABILITY/SKILLS/commit/commit-queue/fixtures/basic/expected.json",
      "size": 176
    },
    {
      "hash": "59488f6c84a5bb78209aaaf08fb2c71cd26b9c0e56b5ab638ff0a2e54b48f758",
      "path": "CAPABILITY/SKILLS/commit/commit-queue/fixtures/basic/input.json",
      "size": 248
    },
    {
      "hash": "65fcfa283c2db768000f63d17486e4f200feb84083589b49c51bbb5b465f10af",
      "path": "CAPABILITY/SKILLS/commit/commit-queue/run.py",
      "size": 7677
    },
    {
      "hash": "3d2f3fa7360791548df98ad4bd9bc59925a0e7ccc53b00592779014d4c0c5dbb",
      "path": "CAPABILITY/SKILLS/commit/commit-queue/validate.py",
      "size": 780
    },
    {
      "hash": "e3f5b474c94344e15ecd5f20c79d191551eb779d35ea50a16bdb2444cbcc3069",
      "path": "CAPABILITY/SKILLS/commit/commit-summary-log/SKILL.md",
      "size": 3316
    },
    {
      "hash": "b439d652ad3060001c8b402ade9c27d9e271c14bf53354d816ec4eeab44886e3",
      "path": "CAPABILITY/SKILLS/commit/commit-summary-log/fixtures/basic/expected.json",
      "size": 513
    },
    {
      "hash": "d59e9e0e541ac284fef8858b0c90956f75953ccb4794d3db8302b08e5c980d12",
      "path": "CAPABILITY/SKILLS/commit/commit-summary-log/fixtures/basic/input.json",
      "size": 519
    },
    {
      "hash": "840408712c4a9a53c5d9640199244406ca0a73d5f5a74293260a786417bfe04f",
      "path": "CAPABILITY/SKILLS/commit/commit-summary-log/fixtures/template_basic/expected.json",
      "size": 104
    },
    {
      "hash": "04ab9c107aaa8e05d0d014ac24679ea41789a8c460242912ca2484d96b1d4a90",
      "path": "CAPABILITY/SKILLS/commit/commit-summary-log/fixtures/template_basic/input.json",
      "size": 183
    },
    {
      "hash": "cabe75228dff8c1920d87878464064c8774dee6ecfd30fa7d50455bc58707c66",
      "path": "CAPABILITY/SKILLS/commit/commit-summary-log/run.py",
      "size": 7119
    },
    {
      "hash": "22c3c6781c40070b95898fa3b4b4d6fae4d508113f02505933ea459146b6969c",
      "path": "CAPABILITY/SKILLS/commit/commit-summary-log/validate.py",
      "size": 825
    },
    {
      "hash": "466b509e7f381e8bd05421e9c563967aa83cd1b665c0d14fea68d4998cd44ed1",
      "path": "CAPABILITY/SKILLS/cortex/cas-integrity-check/SKILL.md",
      "size": 1026
    },
    {
      "hash": "a7c37f451324f2e7087279404c34fc11256422db448533c496ddacd115f5ad39",
      "path": "CAPABILITY/SKILLS/cortex/cas-integrity-check/fixtures/missing_root/expected.json",
      "size": 27
    },
    {
      "hash": "97ef4603b14aa1858e0e9cbf57da9e7c839ddeaa763dd66ff74b0582a230802c",
      "path": "CAPABILITY/SKILLS/cortex/cas-integrity-check/fixtures/missing_root/input.json",
      "size": 59
    },
    {
      "hash": "82b5cdc6be55ddec55aedd979a7050a547d4e2a4881b46d3e8e1862c6b7bfe4c",
      "path": "CAPABILITY/SKILLS/cortex/cas-integrity-check/run.py",
      "size": 2951
    },
    {
      "hash": "248b8b5c842de5593296529fc9e86ed9077e889c5eb921c74a2280cafe7504e5",
      "path": "CAPABILITY/SKILLS/cortex/cas-integrity-check/validate.py",
      "size": 694
    },
    {
      "hash": "a488101bb48f862986d6c94c21d87704655af36bb0f99c21004f8ac2dd66835f",
      "path": "CAPABILITY/SKILLS/cortex/cortex-build/SKILL.md",
      "size": 923
    },
    {
      "hash": "19e5986992fdc90f6d44ed08daec6c56cb91f7a140b50c2c8fe92c5954263c83",
      "path": "CAPABILITY/SKILLS/cortex/cortex-build/fixtures/basic/expected.json",
      "size": 149
    },
    {
      "hash": "1204d74d6ab19f1b3d17c64f9654782633a1cce1f1f243c6b1b96c296cfa62ab",
      "path": "CAPABILITY/SKILLS/cortex/cortex-build/fixtures/basic/input.json",
      "size": 116
    },
    {
      "hash": "587f24ab1fe19900ee96c95ab799ab3aaa494ffce775cf39d06a324e5b496b06",
      "path": "CAPABILITY/SKILLS/cortex/cortex-build/run.py",
      "size": 4056
    },
    {
      "hash": "c19d77e3eeec956a48137c539833512c4a8f64c32d0c81b55d0acb9c504b5396",
      "path": "CAPABILITY/SKILLS/cortex/cortex-build/validate.py",
      "size": 920
    },
    {
      "hash": "c309f082022a4342024ae0fbaddf25517c673fae43a8acc0d6caea54eec22ae5",
      "path": "CAPABILITY/SKILLS/cortex/cortex-summaries/SKILL.md",
      "size": 1461
    },
    {
      "hash": "e074240709d200f8793827b95158abc74d2d042ce5e1abe3449b7e557750ce2c",
      "path": "CAPABILITY/SKILLS/cortex/cortex-summaries/fixtures/basic/expected.json",
      "size": 542
    },
    {
      "hash": "d3b050a80b0cf7e22d17fe733529ee7c06d1764a16d0262ff65598ac3f9c51ad",
      "path": "CAPABILITY/SKILLS/cortex/cortex-summaries/fixtures/basic/input.json",
      "size": 607
    },
    {
      "hash": "559e18b66f1c39628af96535869c8c7783879a1e31adcd07c8cbabaae70a6532",
      "path": "CAPABILITY/SKILLS/cortex/cortex-summaries/run.py",
      "size": 4691
    },
    {
      "hash": "7f7e3d1ecc41821055a792b1bb8db86418d38bd62ca91016de213c3c3f495ea9",
      "path": "CAPABILITY/SKILLS/cortex/cortex-summaries/validate.py",
      "size": 666
    },
    {
      "hash": "9f19a652e02ac8c045cb26935bec0eadef5986fe884eacd4aa8727e81eb493a4",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/SKILL.md",
      "size": 1298
    },
    {
      "hash": "df321b58a58e1171e0a52c68be0b8c7bcc6cf195e452dabf6193c17f10619ab4",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/basic/expected.json",
      "size": 682
    },
    {
      "hash": "117a6f30378ea14933ff4329f408e3a23d50782ba7fe5b5962816c261954dff6",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/basic/input.json",
      "size": 290
    },
    {
      "hash": "784f1834b03364506db2c437b130abb90ab473264ad31d31ffcb5afb21b0b566",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/catalytic-dpt-lab-split-lite/expected.json",
      "size": 671
    },
    {
      "hash": "459a64feb87b73cc8a8a56c531cbef6f3dfc0a4fa92379d1361789a4cbe00ac6",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/catalytic-dpt-lab-split-lite/input.json",
      "size": 358
    },
    {
      "hash": "a942600a7131ca66c487a2b2f250ad357deab1ab2842ecae65e0a8aed9f9dcdf",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/catalytic-dpt-split-lite/expected.json",
      "size": 810
    },
    {
      "hash": "a26a8a3d859cecf554a6dbccd3f2c7b7ee3b9e5b2cc37f63b41cb445b0949dd1",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/catalytic-dpt-split-lite/input.json",
      "size": 350
    },
    {
      "hash": "0fa8b3a08d0ac4338a77ae9a2158d7047dce82e0c78388dc84b11b5653c10e53",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/catalytic-dpt/expected.json",
      "size": 714
    },
    {
      "hash": "d92862ad677b6c32a0f3d479e3be2d762339a4461879dc3b20650383bac9de27",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/catalytic-dpt/input.json",
      "size": 306
    },
    {
      "hash": "152937b8d75552543009aa32f8c1cccb2e44852276677387c9ecb692d483c5ef",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/lite/expected.json",
      "size": 608
    },
    {
      "hash": "be9f23bdc79f83e1d9ff28444c9504630386f167f5855d3dbeef7a86c633f2eb",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/lite/input.json",
      "size": 340
    },
    {
      "hash": "65520191217deb9d311df9dbe20dc11437ff567f299c22f5cbe8273914cf4d99",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/split-lite/expected.json",
      "size": 672
    },
    {
      "hash": "4c02e676d4380062f04b078feca4a9f3d36735bb1c1ed971fc29c75de0d670ef",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/fixtures/split-lite/input.json",
      "size": 374
    },
    {
      "hash": "c25a15ab68d26fc2c7d02d8a6b15814c72756bfff1ec1d0443bcb193a86c23b3",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/run.py",
      "size": 6743
    },
    {
      "hash": "4a0357c3f6c8462933ef63b7cab5508b406434e4346e5103d3e66339a59859c1",
      "path": "CAPABILITY/SKILLS/cortex/llm-packer-smoke/validate.py",
      "size": 747
    },
    {
      "hash": "45513ff716d59ebf1d6e48450c855cec612d4c3ae01584149ab56d18194d1292",
      "path": "CAPABILITY/SKILLS/cortex/system1-verify/SKILL.md",
      "size": 868
    },
    {
      "hash": "021a04492c3c3bc52a754c4dd76f4206c553a582299d418ec2f4d37c08994944",
      "path": "CAPABILITY/SKILLS/cortex/system1-verify/fixtures/basic/expected.json",
      "size": 56
    },
    {
      "hash": "eac056af62f92f2449d84d84903ab32be5c2043312dcd6f48ba9ab5d07bb620f",
      "path": "CAPABILITY/SKILLS/cortex/system1-verify/fixtures/basic/input.json",
      "size": 30
    },
    {
      "hash": "f36b3c32f0e9628f19cb63e75c1766deebf892ada196bc8918e41716a309a963",
      "path": "CAPABILITY/SKILLS/cortex/system1-verify/manifest.json",
      "size": 277
    },
    {
      "hash": "907850c000e4e3a12771f36551f3b747ab3d8ca1d4b816240fc8e2ae3eeb0667",
      "path": "CAPABILITY/SKILLS/cortex/system1-verify/run.py",
      "size": 5025
    },
    {
      "hash": "486a38a91351d0220271e3d5c19d38e103ba513af447541f9eb261ac5032b1f2",
      "path": "CAPABILITY/SKILLS/governance/admission-control/SKILL.md",
      "size": 917
    },
    {
      "hash": "8b1d2b6f531cc860209516eecfc33f18609c7c5f83d52ba7d9fe877044d5d1db",
      "path": "CAPABILITY/SKILLS/governance/admission-control/fixtures/artifact_only_allow/expected.json",
      "size": 238
    },
    {
      "hash": "66cbe3401e700c6b9c1cc59dd472e40949d0dd2996d775cd21a8b5a5c6be931a",
      "path": "CAPABILITY/SKILLS/governance/admission-control/fixtures/artifact_only_allow/input.json",
      "size": 138
    },
    {
      "hash": "f1a84733824ef0c58dae1ea29271fe8bcdc708c1afc61623431b0aca55190b5e",
      "path": "CAPABILITY/SKILLS/governance/admission-control/fixtures/artifact_only_outside_block/expected.json",
      "size": 291
    },
    {
      "hash": "f7143d38eb0ecb38f90a868fe188f9696245061f2b593aaf112c093f2a6fdd81",
      "path": "CAPABILITY/SKILLS/governance/admission-control/fixtures/artifact_only_outside_block/input.json",
      "size": 123
    },
    {
      "hash": "9339973a1b681980ea902d9706a3fe241b764617160f7dd2771cb236c21fdd26",
      "path": "CAPABILITY/SKILLS/governance/admission-control/fixtures/read_only_write_block/expected.json",
      "size": 295
    },
    {
      "hash": "1ef300421c27c67d9a7c44e48cae145aeb3412a4053f4f67340245cceee9f890",
      "path": "CAPABILITY/SKILLS/governance/admission-control/fixtures/read_only_write_block/input.json",
      "size": 154
    },
    {
      "hash": "2ed02eb36a8ce195a7492daf425ff03f5f19ffb639e2d3e524df3aad497fa916",
      "path": "CAPABILITY/SKILLS/governance/admission-control/fixtures/repo_write_flag_required/expected.json",
      "size": 263
    },
    {
      "hash": "9555d6faf94236c7b483810faa656e9b5687c1a0de0b299d16a3e1b7333d66ba",
      "path": "CAPABILITY/SKILLS/governance/admission-control/fixtures/repo_write_flag_required/input.json",
      "size": 120
    },
    {
      "hash": "ce1f6a39a2abbfde66d89069c77c5179fef4e1bd129443d0c484afc1db6e2271",
      "path": "CAPABILITY/SKILLS/governance/admission-control/run.py",
      "size": 1324
    },
    {
      "hash": "34d1cf1d62e0731f5a3747b8a90473295b2ae9c478f9835e5a0108c737991112",
      "path": "CAPABILITY/SKILLS/governance/admission-control/validate.py",
      "size": 666
    },
    {
      "hash": "e44bec42504d71c5e471d92ef9de7e9148f1cc76c340f751375042325514e758",
      "path": "CAPABILITY/SKILLS/governance/canon-governance-check/CORTEX_INTEGRATION.md",
      "size": 2279
    },
    {
      "hash": "d0961897876ffa88c8a11cac72d6147f7b4f9ff7c29a3cdebec52e83135dcb95",
      "path": "CAPABILITY/SKILLS/governance/canon-governance-check/INTEGRATION_MAP.md",
      "size": 5157
    },
    {
      "hash": "dbec046ddd16b578f5d9952f692b80bb9e82d274449322e772711d10a9504124",
      "path": "CAPABILITY/SKILLS/governance/canon-governance-check/SKILL.md",
      "size": 2277
    },
    {
      "hash": "70a53d01abbe37103e5dae3ded7b7e021ef284389ca2f28af7314dbc6de0303f",
      "path": "CAPABILITY/SKILLS/governance/canon-governance-check/fixtures/basic/expected.json",
      "size": 63
    },
    {
      "hash": "2b127c6ee6dd558fc268af89ffe9268959a7c8ee3b48e09c189109d81d051ec3",
      "path": "CAPABILITY/SKILLS/governance/canon-governance-check/fixtures/basic/input.json",
      "size": 37
    },
    {
      "hash": "bea90f12d7b05fbb866e2358ef3d34af43d6ba02f968ef8705c2c2fc902cb26e",
      "path": "CAPABILITY/SKILLS/governance/canon-governance-check/run.py",
      "size": 3374
    },
    {
      "hash": "7352a3b47558c9d0a8d984229552f633f4d6c1b43cc2823735052ab4f8377cb5",
      "path": "CAPABILITY/SKILLS/governance/canon-governance-check/validate.py",
      "size": 724
    },
    {
      "hash": "447e594e4bf28a02bca3a42fdc92e346226cfa1d4fcc7e695958004b44e4adb5",
      "path": "CAPABILITY/SKILLS/governance/canon-migration/SKILL.md",
      "size": 1740
    },
    {
      "hash": "fdf978c01931d51d5fa8aa39e8d7c7704220e5c4757cd9d6257afca864d84529",
      "path": "CAPABILITY/SKILLS/governance/canon-migration/fixtures/basic/expected.json",
      "size": 263
    },
    {
      "hash": "1f716033c10a46c685330f39e5d22adc23ec356053664f231890241231149753",
      "path": "CAPABILITY/SKILLS/governance/canon-migration/fixtures/basic/input.json",
      "size": 149
    },
    {
      "hash": "6265ea86542e922d885af91f529fcb0c4d58ebc8c36031d6b668502ceb75b4fd",
      "path": "CAPABILITY/SKILLS/governance/canon-migration/run.py",
      "size": 4512
    },
    {
      "hash": "32af56c078e693550ce03e75a55c649e2b56bf43980485e98610de8e0dc449f2",
      "path": "CAPABILITY/SKILLS/governance/canon-migration/validate.py",
      "size": 839
    },
    {
      "hash": "965576510f3ecf13de92c0ab7fdc0883edca8829ecb5159c749a8de35788d149",
      "path": "CAPABILITY/SKILLS/governance/ci-trigger-policy/SKILL.md",
      "size": 359
    },
    {
      "hash": "13dd01eda0eb9f22ce0acd541ebf06b0702c42d3b8568e6be0046dc2f46f3e4d",
      "path": "CAPABILITY/SKILLS/governance/ci-trigger-policy/fixtures/basic/expected.json",
      "size": 77
    },
    {
      "hash": "0b6c8596c87642e751d35c404ed12823662ab1e21a284cdd6092c1738dc5a92a",
      "path": "CAPABILITY/SKILLS/governance/ci-trigger-policy/fixtures/basic/input.json",
      "size": 100
    },
    {
      "hash": "c50d5a3c7e132fb9fac5ca0c92c27d7782dac2af16495191e9752df0b0a8c237",
      "path": "CAPABILITY/SKILLS/governance/ci-trigger-policy/run.py",
      "size": 3312
    },
    {
      "hash": "699886a49499fabffbf07251c4aa7289de6fdc1b8d6e2519f9c5b30204939408",
      "path": "CAPABILITY/SKILLS/governance/intent-guard/SKILL.md",
      "size": 837
    },
    {
      "hash": "21a83ebe9a22b85f54fb99ea359a500e6d7cb274f1cf15a339bedf64d13e5ad8",
      "path": "CAPABILITY/SKILLS/governance/intent-guard/fixtures/artifact-only/expected.json",
      "size": 457
    },
    {
      "hash": "b1caab67f4bc1dcf7208fd0d181d2ef1cb58cfc9f5ce3a5555d7b4dccdafa1bc",
      "path": "CAPABILITY/SKILLS/governance/intent-guard/fixtures/artifact-only/input.json",
      "size": 133
    },
    {
      "hash": "0420ea61de4e8ab07701811fc1eb3495003229cd3b2df33812df83a91fcadb17",
      "path": "CAPABILITY/SKILLS/governance/intent-guard/fixtures/repo-write-allow/expected.json",
      "size": 453
    },
    {
      "hash": "47ea99c115890ab7af0e08c79c4a8e522bfa6ac93360116c0c335e35ee1e584b",
      "path": "CAPABILITY/SKILLS/governance/intent-guard/fixtures/repo-write-allow/input.json",
      "size": 131
    },
    {
      "hash": "231a02f6baef0d0431beadd462489abe67b8e58919cf19b5b024547a9874b8ff",
      "path": "CAPABILITY/SKILLS/governance/intent-guard/fixtures/repo-write-block/expected.json",
      "size": 454
    },
    {
      "hash": "c0cd5babca1f61fd2038f5ab29bdfed67be7044c965f91ee0e1947108868d904",
      "path": "CAPABILITY/SKILLS/governance/intent-guard/fixtures/repo-write-block/input.json",
      "size": 132
    },
    {
      "hash": "8517810b4b7338eb4215c9d1863596855100ea3655b6b445c4c25564bd239c42",
      "path": "CAPABILITY/SKILLS/governance/intent-guard/run.py",
      "size": 3205
    },
    {
      "hash": "8a895b0c4e7761e5508fa0678b36d3fd7e8e2c3dc7c3f79ec1874c9f12625802",
      "path": "CAPABILITY/SKILLS/governance/invariant-freeze/SKILL.md",
      "size": 955
    },
    {
      "hash": "59ba98b6555dec038ae3a9d5eae64bae2af8e07e1f61dcaddb23f58397a0ce1b",
      "path": "CAPABILITY/SKILLS/governance/invariant-freeze/fixtures/basic/expected.json",
      "size": 752
    },
    {
      "hash": "56efa31075af3668076a22bcbfca5fc36b095ae69514f9cb1bd3a3efee988e1d",
      "path": "CAPABILITY/SKILLS/governance/invariant-freeze/fixtures/basic/input.json",
      "size": 397
    },
    {
      "hash": "889acba78bd43a997123ac34b3b7d9814d03913a71abe8fe61ab952c00f0ac4d",
      "path": "CAPABILITY/SKILLS/governance/invariant-freeze/run.py",
      "size": 2158
    },
    {
      "hash": "f513f3905ea166c4eb1694d15d74f67bd649a43a0d909d0b77a320946cc758be",
      "path": "CAPABILITY/SKILLS/governance/invariant-freeze/validate.py",
      "size": 891
    },
    {
      "hash": "4a73e7fcb6cf2f993603f353cbf4a0439a8f97f8895e20e92263b09df3e9204a",
      "path": "CAPABILITY/SKILLS/governance/master-override/SKILL.md",
      "size": 1150
    },
    {
      "hash": "4496639735d6316a12246617b4ff787e6e3046ee4c6768b7c2cae36f9fdbdb76",
      "path": "CAPABILITY/SKILLS/governance/master-override/fixtures/basic/expected.json",
      "size": 109
    },
    {
      "hash": "71da61fd98ba6f042563af222175940ec82cc841df8566958ccd92ab5143ebd1",
      "path": "CAPABILITY/SKILLS/governance/master-override/fixtures/basic/input.json",
      "size": 73
    },
    {
      "hash": "561d10f216c4301a91923c25502f8f173c80e323e2ac88d75bc2982dfe8dd40e",
      "path": "CAPABILITY/SKILLS/governance/master-override/fixtures/unauthorized-read/expected.json",
      "size": 138
    },
    {
      "hash": "46ca96e4d51ab2614a0aff456d6bdabb7d46eac3ce81e5b7b2330ac63df5fed9",
      "path": "CAPABILITY/SKILLS/governance/master-override/fixtures/unauthorized-read/input.json",
      "size": 37
    },
    {
      "hash": "c202a2555d57a56352e4d4959657b391c4b64a22d1594b9027915d8f9ef5023a",
      "path": "CAPABILITY/SKILLS/governance/master-override/run.py",
      "size": 4300
    },
    {
      "hash": "fddc93a19ccfdef27b5bd0ffb9d7fef84253e11d8b1993d8534321b615a74d5e",
      "path": "CAPABILITY/SKILLS/governance/master-override/validate.py",
      "size": 847
    },
    {
      "hash": "319252599b9cfb91ec6df7ba2008213b1406b81af157c3fcf40d7a2ad7da1310",
      "path": "CAPABILITY/SKILLS/governance/repo-contract-alignment/SKILL.md",
      "size": 2275
    },
    {
      "hash": "29b905d92a8466c5c62171f8bbaa61aba56bbef5f13647da7b6e19d0b3b23734",
      "path": "CAPABILITY/SKILLS/governance/repo-contract-alignment/fixtures/basic/expected.json",
      "size": 92
    },
    {
      "hash": "f3391497677f3cf2db4ce695f85e4d5de199267f3a267d32dde5a6bd87d364d6",
      "path": "CAPABILITY/SKILLS/governance/repo-contract-alignment/fixtures/basic/input.json",
      "size": 21
    },
    {
      "hash": "3788e471f507717e93561b726a44cfe39452d6a82b437b9ed483720b5c1438da",
      "path": "CAPABILITY/SKILLS/governance/repo-contract-alignment/run.py",
      "size": 1108
    },
    {
      "hash": "a95b7f08bf858ed41348fa676367df2b5472b2f0c05504064a4a6bd092776418",
      "path": "CAPABILITY/SKILLS/governance/repo-contract-alignment/validate.py",
      "size": 850
    },
    {
      "hash": "3a6588ea46ca10b5a2882819808c43a2f7a745da75550588481a066f204712da",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/README.md",
      "size": 4003
    },
    {
      "hash": "6cd833b2577548c40c45b6be10c78d95e83adf1afbe2a0ef083500c7c22beb80",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/SKILL.md",
      "size": 943
    },
    {
      "hash": "0c43ac4f2001bbfb81cdcd7ce74ea60f3c2601a0b93180ab5cd29e00e00ad70a",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/check_inbox_hashes.py",
      "size": 2798
    },
    {
      "hash": "8ebecfb5ea3b40992ed79d63fd6df816555d97cc540bc309b3c2efd3ab75ff7f",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/fixtures/basic/expected.json",
      "size": 184
    },
    {
      "hash": "70b914ec0e9d9cd5a5ee84e0e2ee0301660e6f1e735a95fea792a2951150ec48",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/fixtures/basic/input.json",
      "size": 147
    },
    {
      "hash": "8e40d30d326bc60439cbda7f90d687d0bfc1b373ccb4466f87ab9c8982c91787",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/generate_inbox_ledger.py",
      "size": 8555
    },
    {
      "hash": "538ea47315df4b0ddc86cfe6b3bebb9b7c4afb5873d4ef2a23fb2c8ecdacd58c",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/hash_inbox_file.py",
      "size": 6239
    },
    {
      "hash": "948d6d46ecb5345d3835a515ad420959c11040313d9937bdadc7e99b710d9584",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/inbox_write_guard.py",
      "size": 6535
    },
    {
      "hash": "ecc12f3a6b341cbbf8192b4e4a342a76fbec4f944da7d9dc3e431b544dbd693f",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/run.py",
      "size": 4267
    },
    {
      "hash": "b4639639f1f73dffed25e591e119726acf2523c3572874630cc2914a50c90d3f",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/test_inbox_hash.py",
      "size": 5537
    },
    {
      "hash": "03578531e16871d927d4f6e3bca794d8024b5dd6401f1cfdea51da720df64b2f",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/update_inbox_index.py",
      "size": 6730
    },
    {
      "hash": "e0689eacb3646b31dfdf7b952d885361bb9b2e1f51cb6f4a04788bd0aa64be12",
      "path": "CAPABILITY/SKILLS/inbox/inbox-report-writer/validate.py",
      "size": 927
    },
    {
      "hash": "28724ea4cf9939a8b23570d8f5e8484db3411a1017883db2e1d7ae8c38daf8f0",
      "path": "CAPABILITY/SKILLS/mcp/mcp-access-validator/SKILL.md",
      "size": 4432
    },
    {
      "hash": "0afd0a4faab81fa072757fbc757f83e8151e57cbb5be80b349b77ac36c1c2a1c",
      "path": "CAPABILITY/SKILLS/mcp/mcp-access-validator/fixtures/manual-db-query/expected.json",
      "size": 1033
    },
    {
      "hash": "6dd7513ede4e6027b7cb4fd4e17f33de8716337b78f8b3d1b80a9c7cca3bdcef",
      "path": "CAPABILITY/SKILLS/mcp/mcp-access-validator/fixtures/manual-db-query/input.json",
      "size": 402
    },
    {
      "hash": "1c534608012927cc7fb7f3f73834a5ba7a389a6a52af9292b5a84e0b5c28cd6b",
      "path": "CAPABILITY/SKILLS/mcp/mcp-access-validator/fixtures/valid-mcp-usage/expected.json",
      "size": 765
    },
    {
      "hash": "e35e79eff7e634ef1d2facafd73edac0fca46caa251669ae863f0631c87a3728",
      "path": "CAPABILITY/SKILLS/mcp/mcp-access-validator/fixtures/valid-mcp-usage/input.json",
      "size": 215
    },
    {
      "hash": "88fdb60184fae85de0f335ea8fda9bb023f67b5f9324090ccbd2e462f2ddd812",
      "path": "CAPABILITY/SKILLS/mcp/mcp-access-validator/run.py",
      "size": 10192
    },
    {
      "hash": "59f62d6b23842838e85afb90b819d149874dc3b83aa07c91f7032b53914cf71b",
      "path": "CAPABILITY/SKILLS/mcp/mcp-access-validator/validate.py",
      "size": 3678
    },
    {
      "hash": "b8c5555700ce785cbe000e801824299ea1ba3fddcd13e5099e42d325afdcd8b5",
      "path": "CAPABILITY/SKILLS/mcp/mcp-adapter/SKILL.md",
      "size": 724
    },
    {
      "hash": "7242b842211529b3b0c9935f920451e44aed87d8639a381ed1d71a1e1e6b8b61",
      "path": "CAPABILITY/SKILLS/mcp/mcp-adapter/fixtures/basic/expected.json",
      "size": 46
    },
    {
      "hash": "eaf5dcb97dc64e9f1a6922e9999f381e197498acc07756c0b1dd75e7f04b6aed",
      "path": "CAPABILITY/SKILLS/mcp/mcp-adapter/fixtures/basic/input.json",
      "size": 50
    },
    {
      "hash": "c1632767d7537ad39e34a98949f62c4aec1c1cf842867a5d89af08ab41399a9a",
      "path": "CAPABILITY/SKILLS/mcp/mcp-adapter/run.py",
      "size": 1405
    },
    {
      "hash": "381b9935d62347d5ae8137bda9484b61b587514875f8c504900a1e6adb408454",
      "path": "CAPABILITY/SKILLS/mcp/mcp-adapter/scripts/wrapper.py",
      "size": 3962
    },
    {
      "hash": "e0188e2ed2e38cf012cc1d2218234ab4fe867ba68f6b4364af5c35ff46207287",
      "path": "CAPABILITY/SKILLS/mcp/mcp-adapter/validate.py",
      "size": 1142
    },
    {
      "hash": "a1e0d59d5f99e66826e15903c58f8f78dc13cba4f3007c8d5bbca843fc4dcfc1",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/SKILL.md",
      "size": 9232
    },
    {
      "hash": "7242b842211529b3b0c9935f920451e44aed87d8639a381ed1d71a1e1e6b8b61",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/fixtures/basic/expected.json",
      "size": 46
    },
    {
      "hash": "eaf5dcb97dc64e9f1a6922e9999f381e197498acc07756c0b1dd75e7f04b6aed",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/fixtures/basic/input.json",
      "size": 50
    },
    {
      "hash": "21dbb1ea1aa3fe1c7e551a38808051e16825dcb567845bfc883040d7b239a0a3",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/reference/evaluation.md",
      "size": 21753
    },
    {
      "hash": "4b731f5cf636e2d1b6df0c72da9605e0ed2cb789cb52a5dcdebf7ad3dc649834",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/reference/mcp_best_practices.md",
      "size": 7419
    },
    {
      "hash": "d3d5c6ca3e24ef24ffeda76c72d171cf022f99cd95fcfea498b8115ed82d5e0e",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/reference/node_mcp_server.md",
      "size": 28640
    },
    {
      "hash": "26878b7983bfaa534859c65b405b209cfaf5e4c81144dc64a2e660a6d21e9d99",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/reference/python_mcp_server.md",
      "size": 25189
    },
    {
      "hash": "65392387b26f008a4d21e4e4373b7df22188131414ed11bb804464c78ed69e97",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/run.py",
      "size": 1405
    },
    {
      "hash": "ed76105310e6bf3c315ddf838a3a56cea29ca93c5aa2bc21b3dc7aa94fb44ff0",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/scripts/connections.py",
      "size": 4911
    },
    {
      "hash": "e7a0804831c8c8cc9e1adc37cc4c06f7417f6a52813bc2ef5cd41b00f73d96ae",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/scripts/evaluation.py",
      "size": 12989
    },
    {
      "hash": "d5d7558b2368ecea9dfeed7d1fbc71ee9e0750bebd1282faa527d528a344c3c7",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/scripts/requirements.txt",
      "size": 29
    },
    {
      "hash": "e0188e2ed2e38cf012cc1d2218234ab4fe867ba68f6b4364af5c35ff46207287",
      "path": "CAPABILITY/SKILLS/mcp/mcp-builder/validate.py",
      "size": 1142
    },
    {
      "hash": "bb2d6876cfaa7c60169f79d2e464184ff998124ae09fdf951af006b129698882",
      "path": "CAPABILITY/SKILLS/mcp/mcp-extension-verify/SKILL.md",
      "size": 1129
    },
    {
      "hash": "926ec2edabcc542e749ef124eb6f41a4044ba89f07eb801d12b8e1e5d5c4b3ca",
      "path": "CAPABILITY/SKILLS/mcp/mcp-extension-verify/fixtures/basic/expected.json",
      "size": 454
    },
    {
      "hash": "d1cddac099154105722ea466cf625efa4dfb3aeec6d1947fa30d046059e72abc",
      "path": "CAPABILITY/SKILLS/mcp/mcp-extension-verify/fixtures/basic/input.json",
      "size": 113
    },
    {
      "hash": "4ea8c2c3b42e047e6d7435f82dc8e8d6175a571b44ac02d7d2dba78ba4b8e0c4",
      "path": "CAPABILITY/SKILLS/mcp/mcp-extension-verify/run.py",
      "size": 6344
    },
    {
      "hash": "c257cb969c1ea495dc66c135c024775c53ba37267fb56d62a4cb25e353f63b9a",
      "path": "CAPABILITY/SKILLS/mcp/mcp-extension-verify/validate.py",
      "size": 852
    },
    {
      "hash": "0ecda9a6723ffef0006fdb1e049349b3251c2dee60a9f445de058e5ebe587ec7",
      "path": "CAPABILITY/SKILLS/mcp/mcp-message-board/SKILL.md",
      "size": 1654
    },
    {
      "hash": "72aca6d20307298fa4dc261858032ead079ca4fa9337ddd942e1fafa0db0fc64",
      "path": "CAPABILITY/SKILLS/mcp/mcp-message-board/fixtures/basic/expected.json",
      "size": 159
    },
    {
      "hash": "7f6cf0e7285778ac749bbd0977a391e2c9089b9e4dcb49850e6cf688acb8cd50",
      "path": "CAPABILITY/SKILLS/mcp/mcp-message-board/fixtures/basic/input.json",
      "size": 30
    },
    {
      "hash": "436ea326e0728aca5a015527faaf420106f8dc23c3480ed25ab6fdb747d9eb4f",
      "path": "CAPABILITY/SKILLS/mcp/mcp-message-board/run.py",
      "size": 1179
    },
    {
      "hash": "47b0f1307ad967a7be5e7765cffb37e2a34ad364fed11dad4b7c328a3e2f631b",
      "path": "CAPABILITY/SKILLS/mcp/mcp-message-board/validate.py",
      "size": 778
    },
    {
      "hash": "9c80b3656a8306c08275c78c906fa2302bb8f8b3f8ed4bc111eb6c5b0741bc06",
      "path": "CAPABILITY/SKILLS/mcp/mcp-precommit-check/SKILL.md",
      "size": 1796
    },
    {
      "hash": "bf3f035bebd6476b85109dd1cf533db14d5369a69481e037d80507463ce445c9",
      "path": "CAPABILITY/SKILLS/mcp/mcp-precommit-check/fixtures/basic/expected.json",
      "size": 304
    },
    {
      "hash": "68c3bae31438b7ea32c53c8f70cde7f6fc1f9f518eb0da255ffb33b336ac3751",
      "path": "CAPABILITY/SKILLS/mcp/mcp-precommit-check/fixtures/basic/input.json",
      "size": 22
    },
    {
      "hash": "c41ef4afb6983bcc1142eb909e15afdd41076305baf18886a88aab65bfbaffa4",
      "path": "CAPABILITY/SKILLS/mcp/mcp-precommit-check/run.py",
      "size": 11105
    },
    {
      "hash": "4889b1f7e7234b23729a52eca937d5a45d01c94bfd3ae38e7426c03bc67d8fd0",
      "path": "CAPABILITY/SKILLS/mcp/mcp-precommit-check/validate.py",
      "size": 764
    },
    {
      "hash": "3af0d7d320baf7110f7db5d87c7bad180116f2a971ab9b25c2a0331350d48e10",
      "path": "CAPABILITY/SKILLS/mcp/mcp-smoke/SKILL.md",
      "size": 1500
    },
    {
      "hash": "e3325740f6253dbbc9b3f713aaa402a569795f220110a8b17a9d0ad963a8da4e",
      "path": "CAPABILITY/SKILLS/mcp/mcp-smoke/fixtures/basic/expected.json",
      "size": 175
    },
    {
      "hash": "c4407ad5f803e6a3d9c187434d013db83b5abd32c287404fabc17ce2ce8c9a45",
      "path": "CAPABILITY/SKILLS/mcp/mcp-smoke/fixtures/basic/input.json",
      "size": 136
    },
    {
      "hash": "4f4e237bcd3ef4a013cfcd68aa6137c3325b37a9ff363fcc69be0bc008c1d18f",
      "path": "CAPABILITY/SKILLS/mcp/mcp-smoke/run.py",
      "size": 7766
    },
    {
      "hash": "049d092ebdf76e61555f1b0b5e16d864d8f7f54dd75e2790673efc776bbeb0a0",
      "path": "CAPABILITY/SKILLS/mcp/mcp-smoke/validate.py",
      "size": 841
    },
    {
      "hash": "2683de5dad46800295979b0ecd418e76ffd14861935c921e48ba551f6590abd1",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-receipts/SKILL.md",
      "size": 972
    },
    {
      "hash": "954f8ec375bcb7de83f432b3fbff968cad6379234adb65ccb8c54c42e78d0c91",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-receipts/fixtures/basic_ok/expected.json",
      "size": 137
    },
    {
      "hash": "fded354783af97c74cfa7283b94b17e96612fd88a2fa3a4022897f7c1dff2a0f",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-receipts/fixtures/basic_ok/input.json",
      "size": 72
    },
    {
      "hash": "954f8ec375bcb7de83f432b3fbff968cad6379234adb65ccb8c54c42e78d0c91",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-receipts/fixtures/tamper_reject/expected.json",
      "size": 137
    },
    {
      "hash": "fded354783af97c74cfa7283b94b17e96612fd88a2fa3a4022897f7c1dff2a0f",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-receipts/fixtures/tamper_reject/input.json",
      "size": 72
    },
    {
      "hash": "5e00d19dc542d3db158318eb1c79578adaf43287128dd8669c61102df56e7500",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-receipts/run.py",
      "size": 1158
    },
    {
      "hash": "a4eaf71cde500b4676219d6a2b91ef98dfa20315f17ab1604aa6e5f1d190ebc5",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-receipts/validate.py",
      "size": 523
    },
    {
      "hash": "cf5df27501dfdd31e9e1e13c465302b5ff935dfa133cc4cf0551b92b6dd1211e",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-restore/SKILL.md",
      "size": 1068
    },
    {
      "hash": "954f8ec375bcb7de83f432b3fbff968cad6379234adb65ccb8c54c42e78d0c91",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-restore/fixtures/basic_ok/expected.json",
      "size": 137
    },
    {
      "hash": "2fcbe025c1ac3f13a4d54330b477c39ca15200d9149328a0327b2df7e8a54c07",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-restore/fixtures/basic_ok/input.json",
      "size": 17
    },
    {
      "hash": "954f8ec375bcb7de83f432b3fbff968cad6379234adb65ccb8c54c42e78d0c91",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-restore/fixtures/tamper_reject/expected.json",
      "size": 137
    },
    {
      "hash": "0a5251aa4cb6de582dc54eec3a8bce8a3dd3b40074d7098709d32c1f0d7e2906",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-restore/fixtures/tamper_reject/input.json",
      "size": 18
    },
    {
      "hash": "3bd5f97bffd3fe32c2543556a46caf4138236b75d116eb030bfafa535ca891c7",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-restore/run.py",
      "size": 1157
    },
    {
      "hash": "8e3efb8d4de8cc5a45101422437afe1fb3580067317267d8875b08bc1edd6593",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-restore/validate.py",
      "size": 522
    },
    {
      "hash": "2d0362e062ffb5e7b27f88b0970087bc77764efa9de97a4f5e8711cf69cfdd45",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-scheduler/SKILL.md",
      "size": 1391
    },
    {
      "hash": "954f8ec375bcb7de83f432b3fbff968cad6379234adb65ccb8c54c42e78d0c91",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-scheduler/fixtures/basic_ok/expected.json",
      "size": 137
    },
    {
      "hash": "fded354783af97c74cfa7283b94b17e96612fd88a2fa3a4022897f7c1dff2a0f",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-scheduler/fixtures/basic_ok/input.json",
      "size": 72
    },
    {
      "hash": "954f8ec375bcb7de83f432b3fbff968cad6379234adb65ccb8c54c42e78d0c91",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-scheduler/fixtures/cycle_reject/expected.json",
      "size": 137
    },
    {
      "hash": "fded354783af97c74cfa7283b94b17e96612fd88a2fa3a4022897f7c1dff2a0f",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-scheduler/fixtures/cycle_reject/input.json",
      "size": 72
    },
    {
      "hash": "3781b49297641553e63f81e59e04b0447f1d18cd201576795dea557f5c9f1142",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-scheduler/run.py",
      "size": 1361
    },
    {
      "hash": "a4eaf71cde500b4676219d6a2b91ef98dfa20315f17ab1604aa6e5f1d190ebc5",
      "path": "CAPABILITY/SKILLS/pipeline/pipeline-dag-scheduler/validate.py",
      "size": 523
    },
    {
      "hash": "c851420622249212ca9c164b256eff6fe0c6d7cb1d49ed957c36f0eb3efb675b",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/README.md",
      "size": 18857
    },
    {
      "hash": "9e8c6ca79329f6db88f136d6487ea216890e50c4251e570885d538a748d1e3f2",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/SKILL.md",
      "size": 930
    },
    {
      "hash": "3528716e366bd7b4828e0f5ed753060ba6e2313866665f4bc0d4720d540831fe",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/doc_merge_batch/__init__.py",
      "size": 47
    },
    {
      "hash": "d71debb03da675ba6b820abb95836f59b1e1a73b1046b1ca7d50f18d591ac07f",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/doc_merge_batch/__main__.py",
      "size": 138
    },
    {
      "hash": "4926e444951af963e2f101213e30c44642b3fa64bc0ba900215977bd9f6ab422",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/doc_merge_batch/blocks.py",
      "size": 2068
    },
    {
      "hash": "b8084e0fa1f2d02e37ca1b19c5410b1fafbc6a51c6d779f3a796cea00022c83f",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/doc_merge_batch/cli.py",
      "size": 4774
    },
    {
      "hash": "6740aebbb11a2f39c0073d7ea0e6437c47ecde6eb67b2bb98c11f895739cb6e0",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/doc_merge_batch/core.py",
      "size": 21356
    },
    {
      "hash": "39ad6e0a11f0c96409e8295614a934c91c8ef6b1555146d9d6c4d9b4ba2d5d6f",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/doc_merge_batch/diffing.py",
      "size": 1317
    },
    {
      "hash": "511150f89d0d3ccc3921cd70c8b15789089d06050ab9ca6d321638404944c0fe",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/doc_merge_batch/planner.py",
      "size": 2692
    },
    {
      "hash": "19067bb9b65e4a224ae5dc1ad036c70ad34bd8592d06cfe47fa338b7ca8d913a",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/doc_merge_batch/utils.py",
      "size": 5216
    },
    {
      "hash": "664b4588bab65d38c4b9209f6c9602be0bd6f1cadf24a1eeec2718776b103f21",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/fixtures/basic/a.md",
      "size": 60
    },
    {
      "hash": "b63d8099b1ea37b2d0477d871128bf82003665677dbfdd38f7eb89d6a01245b2",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/fixtures/basic/b.md",
      "size": 60
    },
    {
      "hash": "540bfece331ff544ef12e168c91e8b9204588c2c112975037d192c36636f907c",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/fixtures/basic/expected.json",
      "size": 405
    },
    {
      "hash": "650833dc634e59bc819eefa86f1e3362de7c66025fd0dcbd68ea18e3951611b0",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/fixtures/basic/input.json",
      "size": 298
    },
    {
      "hash": "e42a88e659b7f247b3f4e3acece6221624daf06aef18f947eb687450d7008362",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/run.py",
      "size": 3077
    },
    {
      "hash": "65cfd5c7ffe832798372867a17d80921d7d0c25a830457aa7d578148ddafeaf1",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/schemas/doc_merge_batch.input.schema.json",
      "size": 3836
    },
    {
      "hash": "19cd6640a673e95a6c50d2cdf1298a6cd0243abeef967ca4ae15d237b10ab9e0",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/schemas/doc_merge_batch.output.schema.json",
      "size": 1043
    },
    {
      "hash": "29304e3c4a99691bda83d5861b62a7ecb0075300f689f793def4b60200e631b1",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/tests/test_doc_merge_batch.py",
      "size": 924
    },
    {
      "hash": "665e022353d6060dbc103967710542afaeaa3cb181a60eb66e869cf194f4f111",
      "path": "CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/validate.py",
      "size": 907
    },
    {
      "hash": "53d14fc8cb61410807b0be4ffd4056b17d814372ad2c42ad5bd897d192e87855",
      "path": "CAPABILITY/SKILLS/utilities/doc-update/SKILL.md",
      "size": 2311
    },
    {
      "hash": "be788d38e8e5a0d1c5a4848da9407bc0a750d6e3a8019cca4b9d415030eb5abb",
      "path": "CAPABILITY/SKILLS/utilities/doc-update/fixtures/basic/expected.json",
      "size": 846
    },
    {
      "hash": "ae626bc5e73c9740bc9f9d948b296c931c1fc3a7c858e153610eccd4f0bb9e83",
      "path": "CAPABILITY/SKILLS/utilities/doc-update/fixtures/basic/input.json",
      "size": 73
    },
    {
      "hash": "89220d31ebca9b3945bcd0a8cc928e8cd2071c6baf2debf071a78f6dd11b33a0",
      "path": "CAPABILITY/SKILLS/utilities/doc-update/run.py",
      "size": 2201
    },
    {
      "hash": "eb6e385a7797bc8d4e81dd1af7ed380e5aa4086e1e57f6a94310706ff5c6da01",
      "path": "CAPABILITY/SKILLS/utilities/doc-update/validate.py",
      "size": 842
    },
    {
      "hash": "1d2cf6185bd28733d96f43e630e33cefe944b72fcb5132bd51af0e1ad83616db",
      "path": "CAPABILITY/SKILLS/utilities/example-echo/SKILL.md",
      "size": 714
    },
    {
      "hash": "388e152ac931fcdf635d0ed094a421401d956295019ec5ae32bb5f91b513e81b",
      "path": "CAPABILITY/SKILLS/utilities/example-echo/fixtures/basic/expected.json",
      "size": 25
    },
    {
      "hash": "388e152ac931fcdf635d0ed094a421401d956295019ec5ae32bb5f91b513e81b",
      "path": "CAPABILITY/SKILLS/utilities/example-echo/fixtures/basic/input.json",
      "size": 25
    },
    {
      "hash": "b6254c726eca5094064e2826752c8da24824634ae7824a66d71c9a56c3306a0f",
      "path": "CAPABILITY/SKILLS/utilities/example-echo/run.py",
      "size": 924
    },
    {
      "hash": "f39f9689e7b12b17f1407cfb7fab83738c539ee35a2463f1d5e7fc40362e46f5",
      "path": "CAPABILITY/SKILLS/utilities/example-echo/validate.py",
      "size": 746
    },
    {
      "hash": "75d4f007d6f810c2c88473d56c07ec6a87a2c13b637e9594855e102482741924",
      "path": "CAPABILITY/SKILLS/utilities/file-analyzer/SKILL.md",
      "size": 858
    },
    {
      "hash": "7242b842211529b3b0c9935f920451e44aed87d8639a381ed1d71a1e1e6b8b61",
      "path": "CAPABILITY/SKILLS/utilities/file-analyzer/fixtures/basic/expected.json",
      "size": 46
    },
    {
      "hash": "eaf5dcb97dc64e9f1a6922e9999f381e197498acc07756c0b1dd75e7f04b6aed",
      "path": "CAPABILITY/SKILLS/utilities/file-analyzer/fixtures/basic/input.json",
      "size": 50
    },
    {
      "hash": "a3bc9e0eb1817ba32ec02b31b86015a15a6e2fdf206f7bab096893e08ffaf0b8",
      "path": "CAPABILITY/SKILLS/utilities/file-analyzer/run.py",
      "size": 1413
    },
    {
      "hash": "b793c9e68714c1cfc642ec9c09de88aee58e0f061ab1ed3dab396521dabe1747",
      "path": "CAPABILITY/SKILLS/utilities/file-analyzer/scripts/run.py",
      "size": 6144
    },
    {
      "hash": "e0188e2ed2e38cf012cc1d2218234ab4fe867ba68f6b4364af5c35ff46207287",
      "path": "CAPABILITY/SKILLS/utilities/file-analyzer/validate.py",
      "size": 1142
    },
    {
      "hash": "54a97d76752ee906a085e406eaef075e0436111ab35261bad740e46dfdc5f23e",
      "path": "CAPABILITY/SKILLS/utilities/pack-validate/SKILL.md",
      "size": 1139
    },
    {
      "hash": "88d1411d0a066ced56f204fecb7ea4d746da60b4df9661af0c76c7cae82c63a3",
      "path": "CAPABILITY/SKILLS/utilities/pack-validate/fixtures/basic/expected.json",
      "size": 194
    },
    {
      "hash": "a95e11774a2e0fa01155c3611b7abf88c77fb934ffc3f1c8b33e243e98082bc8",
      "path": "CAPABILITY/SKILLS/utilities/pack-validate/fixtures/basic/input.json",
      "size": 87
    },
    {
      "hash": "9590f6a09aa11378d763769684b223f080f2f826f78bbff6eb6be980da76ca3c",
      "path": "CAPABILITY/SKILLS/utilities/pack-validate/run.py",
      "size": 4677
    },
    {
      "hash": "ff6253974f7da7cb396b9a8b72d38d4a38bf08df14f6c5808f19f4d2b5da00a5",
      "path": "CAPABILITY/SKILLS/utilities/pack-validate/validate.py",
      "size": 837
    },
    {
      "hash": "6623270965a3c9439e85ad97473b76f93eb178a0beab31c7f9f3a1df5583a28e",
      "path": "CAPABILITY/SKILLS/utilities/powershell-bridge/SKILL.md",
      "size": 801
    },
    {
      "hash": "fa8c69b1d2a11f9c5c94a92d5ced4bdd5876623b99bcc81b59f56a063f03b137",
      "path": "CAPABILITY/SKILLS/utilities/powershell-bridge/fixtures/basic/expected.json",
      "size": 467
    },
    {
      "hash": "ca3d163bab055381827226140568f3bef7eaac187cebd76878e0b63e9e442356",
      "path": "CAPABILITY/SKILLS/utilities/powershell-bridge/fixtures/basic/input.json",
      "size": 3
    },
    {
      "hash": "dced41fa53de422fd6b29e6e3c1ba6cba0f99c93eef43a59cbcbf543420d850e",
      "path": "CAPABILITY/SKILLS/utilities/powershell-bridge/run.py",
      "size": 1600
    },
    {
      "hash": "beb6519ef4864e0fee68f4ecf1a647a5607daff997e0e9c37f6ff6aea8832a5a",
      "path": "CAPABILITY/SKILLS/utilities/powershell-bridge/validate.py",
      "size": 645
    },
    {
      "hash": "d7daf95212e137880d8481a12d1df8fbb363c74811fb4e5edf27c32b03c5fba8",
      "path": "CAPABILITY/SKILLS/utilities/prompt-runner/SKILL.md",
      "size": 2383
    },
    {
      "hash": "d9b84a585096e0ef72bb482c14103a1b47147ee16931f274ca4baa2ffb4187c5",
      "path": "CAPABILITY/SKILLS/utilities/prompt-runner/fixtures/expected.json",
      "size": 1425
    },
    {
      "hash": "90115de2941bdbd5cddf1cdb07c60670ee1e97e78334c48ae617a8655f9651d3",
      "path": "CAPABILITY/SKILLS/utilities/prompt-runner/fixtures/input.json",
      "size": 256
    },
    {
      "hash": "ab082bdf0f87c1f6c25033af4ec24d5514ec6e2b4cb0d293f1c590c569c0d90a",
      "path": "CAPABILITY/SKILLS/utilities/prompt-runner/fixtures/sample_prompt.md",
      "size": 1294
    },
    {
      "hash": "033a804c5a4dac0a8fa4278236ed86db93b3d18547601cb599bd9fa057ce9077",
      "path": "CAPABILITY/SKILLS/utilities/prompt-runner/run.py",
      "size": 27590
    },
    {
      "hash": "b9d8cb104349c922ea61ab94438c236cf39643f44d40231beb73a3e7a19eb159",
      "path": "CAPABILITY/SKILLS/utilities/prompt-runner/validate.py",
      "size": 921
    },
    {
      "hash": "cdc64e795e009e718875f93ae881b3edffcae40bc88d68dc137234d5b0749927",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/SKILL.md",
      "size": 18148
    },
    {
      "hash": "7242b842211529b3b0c9935f920451e44aed87d8639a381ed1d71a1e1e6b8b61",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/fixtures/basic/expected.json",
      "size": 46
    },
    {
      "hash": "eaf5dcb97dc64e9f1a6922e9999f381e197498acc07756c0b1dd75e7f04b6aed",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/fixtures/basic/input.json",
      "size": 50
    },
    {
      "hash": "698e81a4e865070e070292ef272aff393d69ec64054b27e2ad18d8f6f4e5b707",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/references/output-patterns.md",
      "size": 1902
    },
    {
      "hash": "727cd289c360964910267dfe44c5b6e0e8b2a94768ac18cb718e917854590b2a",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/references/workflows.md",
      "size": 908
    },
    {
      "hash": "41da286d4018ae72151ed319c6db3dc159ce27c9202253daeaaea458f6acac8c",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/run.py",
      "size": 1414
    },
    {
      "hash": "0bba250b94caa4cb2b28b15dad26fdcf371aeda4c9797b8120e55c2e33e0c73c",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/scripts/init_skill.py",
      "size": 10863
    },
    {
      "hash": "b31fbcb3e362d5c5308e99255ff8e83cde3a513e0636953964a648494ca10931",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/scripts/package_skill.py",
      "size": 3288
    },
    {
      "hash": "7e90613552621f71b32737041b5f561040d49748096c2336208ed4c55fe9ca3b",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/scripts/quick_validate.py",
      "size": 3524
    },
    {
      "hash": "e0188e2ed2e38cf012cc1d2218234ab4fe867ba68f6b4364af5c35ff46207287",
      "path": "CAPABILITY/SKILLS/utilities/skill-creator/validate.py",
      "size": 1142
    },
    {
      "hash": "de91e09e466b9f8616ca837d76cb9ef71481615ef9f8c213d63c1a6e4ac289ec",
      "path": "CAPABILITY/TESTBENCH/TESTBENCH.md",
      "size": 10981
    },
    {
      "hash": "d875635e76d4e1cfaa5672bb1fa1271908bce7af66d17fb938176d3bee5b6b49",
      "path": "CAPABILITY/TESTBENCH/adversarial/test_adversarial_cas.py",
      "size": 2959
    },
    {
      "hash": "65e1d17be2147ce6e98955ee84c6a55384e45b116a9bc554e17930ca018b9383",
      "path": "CAPABILITY/TESTBENCH/adversarial/test_adversarial_ledger.py",
      "size": 2495
    },
    {
      "hash": "46d841186ad6098d6b09f33351408b204ed17d11a90f287cf25ba8b4075153be",
      "path": "CAPABILITY/TESTBENCH/adversarial/test_adversarial_paths.py",
      "size": 1326
    },
    {
      "hash": "93bdcd24a9abd9718dbd1f55e6b2c5e84c09c10f02b4c6d399004488bb70c6ba",
      "path": "CAPABILITY/TESTBENCH/adversarial/test_adversarial_pipeline_resume.py",
      "size": 257
    },
    {
      "hash": "fe41e0e2b9b0fe167873bf19b8a05f5cb384cfadc2e1cacbb116018ad75beab6",
      "path": "CAPABILITY/TESTBENCH/adversarial/test_adversarial_proof_tamper.py",
      "size": 4472
    },
    {
      "hash": "e8828fb7c485fd02b96462f0ee773c44f25fcbd2aaed627bdefe8035d407efac",
      "path": "CAPABILITY/TESTBENCH/artifacts/test_artifact_dedup.py",
      "size": 8936
    },
    {
      "hash": "23a0e012315a8f5a86256468b2b1629dd9cf166f1d3c5aec8e3403e96893a161",
      "path": "CAPABILITY/TESTBENCH/artifacts/test_artifact_store.py",
      "size": 14508
    },
    {
      "hash": "6d142ebb9f6c9655112f2805a2169c6994055f121f44d1b69da817c726cf0e3b",
      "path": "CAPABILITY/TESTBENCH/audit/__init__.py",
      "size": 76
    },
    {
      "hash": "6df8a4c35a32a3d917507741c91debb7d566e22ca21348386b57307f9c8a55e8",
      "path": "CAPABILITY/TESTBENCH/audit/test_root_audit.py",
      "size": 23823
    },
    {
      "hash": "6564ce2915caa89dd00c7665aae0e593c48176733d429ff6a15817d8c5715b7a",
      "path": "CAPABILITY/TESTBENCH/benchmarks/p2_dedup_benchmark.py",
      "size": 9539
    },
    {
      "hash": "fee759fc40dbb9f3208d3824ab8a8255835ad736efe911d0c8ca87929e09f83c",
      "path": "CAPABILITY/TESTBENCH/cas/test_cas.py",
      "size": 4947
    },
    {
      "hash": "cecbe28df3eb1bb75ea872af0ecb10bc594076c6548334d0d284fa029ec1c8f5",
      "path": "CAPABILITY/TESTBENCH/cas/test_cas_dedup.py",
      "size": 5357
    },
    {
      "hash": "24712329f0a040b09d48726bb3c0c89bab4561a3488fdc738121c3ace3ac449f",
      "path": "CAPABILITY/TESTBENCH/core/test_cas_store.py",
      "size": 4060
    },
    {
      "hash": "fa8e9df3bdd1f274eb895dce5d2ea611ebeb0eafba29c1cb4d97806bfdb5804e",
      "path": "CAPABILITY/TESTBENCH/core/test_cmp01_validator.py",
      "size": 27097
    },
    {
      "hash": "09d87921aa4583c920716be4c72b49128ef931a25d0aea2dcb0ac36f120e115b",
      "path": "CAPABILITY/TESTBENCH/core/test_foundational_dirs_exist.py",
      "size": 964
    },
    {
      "hash": "e7a1813580b19c488fee625a75763da81d0304aac5c054f06eb46a7c5749c175",
      "path": "CAPABILITY/TESTBENCH/core/test_hash_toolbelt.py",
      "size": 1015
    },
    {
      "hash": "f71dc83fb42105bbe3d2a0cfcf1029d16ced2d0dcce74f6d5eff26a198ba326a",
      "path": "CAPABILITY/TESTBENCH/core/test_merkle.py",
      "size": 2421
    },
    {
      "hash": "02a523cbb6d2d1032833d2c1f10253726c2bdb4a3bb2223549f8a46aec11bd72",
      "path": "CAPABILITY/TESTBENCH/core/test_model_router.py",
      "size": 13665
    },
    {
      "hash": "72272f0f80d60b3bfd0f2a08115245ca70521942e95aadb4c0f413c187fb756b",
      "path": "CAPABILITY/TESTBENCH/core/test_schemas.py",
      "size": 2648
    },
    {
      "hash": "deb62eb74d388befd87baf91eaecf0f062fac6ca765002722e4a6de0e1611940",
      "path": "CAPABILITY/TESTBENCH/core/test_scratch.py",
      "size": 2183
    },
    {
      "hash": "91fece15fd8f1c5c015bb476b931b11d73b58f96b913371a2884653e9fa9060f",
      "path": "CAPABILITY/TESTBENCH/core/test_skill_runtime_cmp01.py",
      "size": 14367
    },
    {
      "hash": "d3c73f9cda9eb7b5be90261d2b9f3af49d8c976485fbf35320fe3c4ae6434045",
      "path": "CAPABILITY/TESTBENCH/fixtures/dummy_mcp.py",
      "size": 169
    },
    {
      "hash": "5e458c912945f1f97a848c4fcec9b551a263ddf78a1c99072908ce39a3647edd",
      "path": "CAPABILITY/TESTBENCH/fixtures/packer_p2_repo/LAW/CANON/CONTRACT.md",
      "size": 284
    },
    {
      "hash": "66d851d3d27612030d9881f53ed9f8c3e260fd5af962ed9a4742f7b63b0a9fe2",
      "path": "CAPABILITY/TESTBENCH/fixtures/packer_p2_repo/README.md",
      "size": 220
    },
    {
      "hash": "edb338f6eccb8cd3ee98db934306457435d63ed053fee4649d788b1233fbfc13",
      "path": "CAPABILITY/TESTBENCH/gc/test_gc_collect.py",
      "size": 18847
    },
    {
      "hash": "76841b0e5aa30050120e386e801cc1afcc1706ab8d8efc5f80f84a048114642d",
      "path": "CAPABILITY/TESTBENCH/integration/test_catlab_restoration.py",
      "size": 12908
    },
    {
      "hash": "85d0717d5b925047cb663ce559224435de6d88a604b7ee5f6d2b736344a143db",
      "path": "CAPABILITY/TESTBENCH/integration/test_cortex_integration.py",
      "size": 5981
    },
    {
      "hash": "04835078abddf99d9a4477fb39e09fcb77c647fd21a9f343036652ac6d046753",
      "path": "CAPABILITY/TESTBENCH/integration/test_demo_memoization_hash_reuse.py",
      "size": 1555
    },
    {
      "hash": "3d808494d4bfe79ec4d44c4098757e007fec9b82bf95e58dcbb2c295be69e408",
      "path": "CAPABILITY/TESTBENCH/integration/test_deref_logging.py",
      "size": 5531
    },
    {
      "hash": "e67970c3439dc2afc13a45cff44a77248851860b7a97852261b74a55406126e4",
      "path": "CAPABILITY/TESTBENCH/integration/test_governance_coverage.py",
      "size": 264
    },
    {
      "hash": "816ddd1c5400f5dd8b98a0b939b7915436f43635198d14f725c14cbcf9a2a585",
      "path": "CAPABILITY/TESTBENCH/integration/test_memoization.py",
      "size": 3320
    },
    {
      "hash": "c5fa87b9e2eb940f43a895653abc4f80bbdc500dde582ec0e1807952651c0177",
      "path": "CAPABILITY/TESTBENCH/integration/test_p2_cas_packer_integration.py",
      "size": 8761
    },
    {
      "hash": "946ae0f39cb12a1724bd02522275437c9e1a031307bb438c2729d908412624d8",
      "path": "CAPABILITY/TESTBENCH/integration/test_p2_gc_safety.py",
      "size": 7042
    },
    {
      "hash": "2bdde1ccd20b5dd0f4d54c3e255627ec21f4fdaa85caceaa228116eb19c1afc3",
      "path": "CAPABILITY/TESTBENCH/integration/test_pack_consumer.py",
      "size": 12275
    },
    {
      "hash": "b161d451cf1d2208f228f071aebbf47670eca1bf18d89070524036b5a3668cfa",
      "path": "CAPABILITY/TESTBENCH/integration/test_packer_proofs.py",
      "size": 6277
    },
    {
      "hash": "e04caba2f1683e32f2ea49290f45d86fd5b75364985034e6b8b141b9e6763543",
      "path": "CAPABILITY/TESTBENCH/integration/test_packing_hygiene.py",
      "size": 2271
    },
    {
      "hash": "e3c0cf799a752a00c801b717f7a6f2b609260653bc330e80d783f9c5a19cae93",
      "path": "CAPABILITY/TESTBENCH/integration/test_preflight.py",
      "size": 11420
    },
    {
      "hash": "168e7c442c684c4fad9f7ead9671b1766f00e4745fe85693a4fc791564ea786e",
      "path": "CAPABILITY/TESTBENCH/integration/test_skills_registry.py",
      "size": 854
    },
    {
      "hash": "505d66a832305e78ba8f2636999932033628ba852cded04ff3f0247df20bd989",
      "path": "CAPABILITY/TESTBENCH/integration/test_spectrum_04_05_enforcement.py",
      "size": 2120
    },
    {
      "hash": "121c52f6178e4a2c2d9bbb8aaac0928116ab5b14a86ce30d3af2fbda3ad4c2e3",
      "path": "CAPABILITY/TESTBENCH/integration/test_task_4_1_catalytic_snapshot_restore.py",
      "size": 13782
    },
    {
      "hash": "fda93e49ceeb9ea40b5986419f1fdc1b907dac9ec2dbabbcc7d209f2c38a63fa",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_adapter_contract.py",
      "size": 6155
    },
    {
      "hash": "26d386296da81c945e060c253f57a8b2bd2daab899041173d5506619145d5957",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_bridge.py",
      "size": 2558
    },
    {
      "hash": "c033bb6fb8021650a1fb77841f6426c37e904e4a5f22bf83bf0d298808efce5b",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_capability_pins.py",
      "size": 5731
    },
    {
      "hash": "3b141f0f7b2a2914b3053e4c7028a0585f9f7e8e52cf4763b60102ec69f02435",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_capability_registry.py",
      "size": 6096
    },
    {
      "hash": "ad8bc4b9f2c2da905cc105102d8e735e9b9e64ae745680857793fe77214edd21",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_capability_revokes.py",
      "size": 5336
    },
    {
      "hash": "8c1d333f9150b4fd5fb7665f5c2a70bb2ee54875f194dd86cd5eec8c6e6ea38d",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_capability_versioning_semantics.py",
      "size": 308
    },
    {
      "hash": "64e111b826ccf6bc85e5e49f601faabf648b5e5b326c681c55aa572d6b3cd4a4",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_mcp_adapter_e2e.py",
      "size": 4059
    },
    {
      "hash": "a2aeae3213f3d682ba15e5c63924094987d5cece5bced994caa91378f86c5087",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_registry_immutability.py",
      "size": 2847
    },
    {
      "hash": "90edc143b6f7d902661a7714816d4ec85eaa7d7d6dcddddc4748cbd2c2ccb0a9",
      "path": "CAPABILITY/TESTBENCH/phases/phase6_governance/test_ags_phase6_router_slot.py",
      "size": 575
    },
    {
      "hash": "e3318fe94b8a288c7b61a7424dc04e8999f938bd3c8a270527712a1ee321f7ef",
      "path": "CAPABILITY/TESTBENCH/phases/phase7_swarm/test_phase7_acceptance.py",
      "size": 5293
    },
    {
      "hash": "79272e724be6bda82107ede578c1ffafb542d77e983768a57dbdd9e527816885",
      "path": "CAPABILITY/TESTBENCH/phases/phase7_swarm/test_swarm_reuse.py",
      "size": 5731
    },
    {
      "hash": "a3b446f261311b3c576e4730a045df9720adb985a4a2cab392a383417fc49fcf",
      "path": "CAPABILITY/TESTBENCH/phases/phase7_swarm/test_swarm_runtime.py",
      "size": 4887
    },
    {
      "hash": "f01c28113b2d4c283be157b9bae6b9907369ab27ef0fc33513595f2140e046dd",
      "path": "CAPABILITY/TESTBENCH/phases/phase8_router/test_ags_phase8_model_binding.py",
      "size": 2347
    },
    {
      "hash": "d180c2a0513230f089b984d45dc54f4e38d43f9de966e188194fb7b7476f27de",
      "path": "CAPABILITY/TESTBENCH/phases/phase8_router/test_phase8_router_receipts.py",
      "size": 1929
    },
    {
      "hash": "121ffcbd8d810cc7918ac3ff9e0d5dd7a87843d02481a44aa1d133eef6fd0b80",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_canonical_artifacts.py",
      "size": 3705
    },
    {
      "hash": "fe76b8cc9fd59145c02f0f03eaa4c4c1feb3db0d7546b4f8d9f250c9dd59591e",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_ledger.py",
      "size": 2798
    },
    {
      "hash": "efc81d7525b4650aa77952f90a4bbd8c074eb88d02e10ccaf147c345611e51cc",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_pipeline_chain.py",
      "size": 7612
    },
    {
      "hash": "4cb01e8c36942304d2f52a67bf4245b2c7deee8cb7d7b69a0625587144c05541",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_pipeline_dag.py",
      "size": 2135
    },
    {
      "hash": "f5d0b28fc62ef53d22a47ac3ab5547e525db0e494fd6f734234016f801dc07af",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_pipeline_verify_cli.py",
      "size": 8632
    },
    {
      "hash": "dd16285b90bd9f2229733cdc205516328aede151cf387026aaab6fe6f85553f3",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_pipelines.py",
      "size": 5891
    },
    {
      "hash": "abb230c98808c110d4de5d5f7256a3931696bf4dfd00112f15f478892a936197",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_proof_gating.py",
      "size": 5720
    },
    {
      "hash": "6cca0f49f0a6f1d58d6b90bf75003e5926945cc3f75827573deeec40d96f4b83",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_proof_wiring.py",
      "size": 6114
    },
    {
      "hash": "b501bd44c25f428e2d65a550659c0dbfe9d13ea43bc5e6b786cf18985eedaa7e",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_restore_proof.py",
      "size": 813
    },
    {
      "hash": "9ade0400cab4fecc0e0361c0e6bf3a97bf7fa53c499d6a9f371f94f90ce44e9d",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_restore_runner.py",
      "size": 6979
    },
    {
      "hash": "0acd825e0ec1ff754d0a98941d6329fc46fef33401fb648800f367df3f955916",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_runtime_guard.py",
      "size": 7775
    },
    {
      "hash": "87c01ad362254e77c23793bc48ac841578f57e46b1ded363a2cd1532574729e0",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_verifier_freeze.py",
      "size": 476
    },
    {
      "hash": "aa87c959e122fd137f3efd6ebaa3f1609db275bdef126550135403d4fd42878d",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_verifier_interop.py",
      "size": 6583
    },
    {
      "hash": "b376de5611b55c576f77c04aa0e2acd288db81f4ff842617898a2e174d4761da",
      "path": "CAPABILITY/TESTBENCH/pipeline/test_verify_bundle.py",
      "size": 3540
    },
    {
      "hash": "0561cbc7f243ee1d2d8ce8e1bbc2461661d0cfc7cae6348d0ca70ae7b45bcd0f",
      "path": "CAPABILITY/TESTBENCH/runs/__init__.py",
      "size": 33
    },
    {
      "hash": "b10934188bc428c0b2be50723d6fd975ff625e37420d002fe620d940f38874cf",
      "path": "CAPABILITY/TESTBENCH/runs/test_bundles.py",
      "size": 17448
    },
    {
      "hash": "ab0d7de912ff247a822774eea05cfb5fbdbfccb5c662ff6413b5f54f98e95197",
      "path": "CAPABILITY/TESTBENCH/runs/test_run_records.py",
      "size": 23754
    },
    {
      "hash": "5ab4d9eb5d0c3bd21d0641c4f466c11ccc445ac391c1aa5748e2210dc3cecafb",
      "path": "CAPABILITY/TESTBENCH/spectrum/test_spectrum02_emission.py",
      "size": 3400
    },
    {
      "hash": "c50bc6f0b1190640eb8039c65534aa87ffd61a716f03979a136ca3ef55b2926b",
      "path": "CAPABILITY/TESTBENCH/spectrum/test_spectrum02_resume.py",
      "size": 1202
    },
    {
      "hash": "25d4958da5385f895066a8c293b7fc81bcb9d8d01f06d68fd0e207b8f924eb8f",
      "path": "CAPABILITY/TESTBENCH/spectrum/test_spectrum03_chain.py",
      "size": 2121
    },
    {
      "hash": "94d2f80f61d51593d504a3fef5aed46f0ba88307c8c807c65170c8cd484ca8d7",
      "path": "CAPABILITY/TESTBENCH/spectrum/test_validator_version_integrity.py",
      "size": 11300
    },
    {
      "hash": "cb849283e50a8710327371a8b9f0e0266b34a8611985d27bc65d966e161f6944",
      "path": "CAPABILITY/TESTBENCH/v3_test_results/SYSTEM_FAILURE_PROTOCOL_1.md",
      "size": 5452
    },
    {
      "hash": "62802abb041af021d3bede91b45fecfc5583f4be1158c9c021df1faa3b01757f",
      "path": "CAPABILITY/TESTBENCH/v3_test_results/SYSTEM_FAILURE_PROTOCOL_2.md",
      "size": 3248
    },
    {
      "hash": "fe9fe7fce1889d82452b70b8b48b937ad88ece577060a52e08983f48d4ab5928",
      "path": "CAPABILITY/TESTBENCH/v3_test_results/SYSTEM_FAILURE_PROTOCOL_3.md",
      "size": 18440
    },
    {
      "hash": "c6b9c460d60f67457bcf0366768c46b0babc450fe1f9370df3ea7fda6c6e95cd",
      "path": "CAPABILITY/TESTBENCH/v3_test_results/SYSTEM_FAILURE_PROTOCOL_4.md",
      "size": 3305
    },
    {
      "hash": "bc100e50deb168eb42bd3143b11ba1523672a78b676880c48d5cb75b04f3e9c2",
      "path": "CAPABILITY/TESTBENCH/v3_test_results/SYSTEM_FAILURE_PROTOCOL_FINAL.md",
      "size": 3567
    },
    {
      "hash": "32ec660596646deb12f8b90b0c39a0eeb490f66cdc0b5048610d9b15b507fa36",
      "path": "CAPABILITY/TESTBENCH/v3_test_results/V3_STABILIZATION_REPORT.md",
      "size": 3220
    },
    {
      "hash": "bb5a9fa2687b8ba4cc4a67635f5628544cf2eed7f3f0867a7a5dd4911b61b012",
      "path": "CAPABILITY/TOOLS/__init__.py",
      "size": 28
    },
    {
      "hash": "ddeaab506db8964388a05f2e70900bfc0339579febc440c734daf0b044bde96a",
      "path": "CAPABILITY/TOOLS/agents/Z_1_6_IMPLEMENTATION_SUMMARY.md",
      "size": 9001
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "CAPABILITY/TOOLS/agents/__init__.py",
      "size": 0
    },
    {
      "hash": "e2d6ed62523df4c6aa049b02237af932f1243ffc68226b980ece2468e6a06e39",
      "path": "CAPABILITY/TOOLS/agents/skill_runtime.py",
      "size": 21114
    },
    {
      "hash": "5d543a8e1ece1264eee9efb996628351694942db0acf4422d137090d9f566c2c",
      "path": "CAPABILITY/TOOLS/ags.py",
      "size": 35092
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "CAPABILITY/TOOLS/catalytic/__init__.py",
      "size": 0
    },
    {
      "hash": "b8a3e64ffd21f21e7d3ed09187eda08f587344a99cfd6b2905f8417b56008964",
      "path": "CAPABILITY/TOOLS/catalytic/__main__.py",
      "size": 97
    },
    {
      "hash": "268d3af8c7362243a44d3ab6398b45b90f031d9691a3f2cd077b4168bcb4e0c5",
      "path": "CAPABILITY/TOOLS/catalytic/catalytic.py",
      "size": 16403
    },
    {
      "hash": "63abfe7ecd1c53b74dad08f55aaa70b0ac38ae3138500e70df96950aedbb6c51",
      "path": "CAPABILITY/TOOLS/catalytic/catalytic_restore.py",
      "size": 2238
    },
    {
      "hash": "102e2ec746289e64179bc4b69c32514869308c5f87b3102621c23f5a01172687",
      "path": "CAPABILITY/TOOLS/catalytic/catalytic_runtime.py",
      "size": 33003
    },
    {
      "hash": "c04e234a8e6651357bcece2bee5ddfcb9059ffe5b7fc9bc77e948fbea82bc847",
      "path": "CAPABILITY/TOOLS/catalytic/catalytic_validator.py",
      "size": 10655
    },
    {
      "hash": "29c00e81d442ce72377c9ebdc8167a88c623ea067824641711c4041a9297c81f",
      "path": "CAPABILITY/TOOLS/catalytic/catalytic_verifier.py",
      "size": 11344
    },
    {
      "hash": "04857c981a22174f172cc93e172376ed777b6d058f23aa9129e3a70eef691555",
      "path": "CAPABILITY/TOOLS/catalytic/provenance.py",
      "size": 14478
    },
    {
      "hash": "ed7179aea8cfd420bbea0ab5c5390c198076ee48d54760f671b11575dab54bf2",
      "path": "CAPABILITY/TOOLS/check-canon-governance.js",
      "size": 8096
    },
    {
      "hash": "30ad2da0ec071800cf1cd40f01b9f1528978c4942ba857b4ce0a6bf8bfbf219f",
      "path": "CAPABILITY/TOOLS/cleanup.py",
      "size": 5539
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "CAPABILITY/TOOLS/cortex/__init__.py",
      "size": 0
    },
    {
      "hash": "8ff455871c95721c6fc0b49b680b26668f2d82101db092bdb31fee33ba199d79",
      "path": "CAPABILITY/TOOLS/cortex/codebook_build.py",
      "size": 14047
    },
    {
      "hash": "7aec840435e6b43be96eed9afb9ae9f84293d39d2d3996cbc7c5adb0b40a29d2",
      "path": "CAPABILITY/TOOLS/cortex/codebook_lookup.py",
      "size": 3523
    },
    {
      "hash": "61a12a50ddd3188bab3eb96f74938056736bc4bd67e39559ee0f1c22f96e80c0",
      "path": "CAPABILITY/TOOLS/cortex/cortex.py",
      "size": 16409
    },
    {
      "hash": "5dfe371293ef1ca17c4912814bcdf3d65bb187e0670ffe5c39d9ecb5b8064b90",
      "path": "CAPABILITY/TOOLS/cortex/cortex_refresh.py",
      "size": 2323
    },
    {
      "hash": "48d596622b6a5cde8570c5db4f83e398889d5e68b3418a959e2ba4119309e0a1",
      "path": "CAPABILITY/TOOLS/cortex/export_semantic.py",
      "size": 2724
    },
    {
      "hash": "5854c504d03660f18d5e110db552676d8dbe412ff942e76fe028fb7b1e8d7802",
      "path": "CAPABILITY/TOOLS/cortex/semantic_bridge.py",
      "size": 6449
    },
    {
      "hash": "a27c71474f5308b67276297326b790de61b3231ce893e01b508bf7cd03bbf28e",
      "path": "CAPABILITY/TOOLS/cortex/semantic_network.py",
      "size": 8596
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "CAPABILITY/TOOLS/governance/__init__.py",
      "size": 0
    },
    {
      "hash": "f144c8e4c8365171d0ee122ce6bac335c90b4e69946bace9ae8b2bbaccae3b66",
      "path": "CAPABILITY/TOOLS/governance/admission.py",
      "size": 5545
    },
    {
      "hash": "c0a584ce2962a11541912a305aaa372441b4ad97e5468f51633d5d8d3a8f7214",
      "path": "CAPABILITY/TOOLS/governance/check_canon_governance.py",
      "size": 4336
    },
    {
      "hash": "8650d1a7cd62df97960b91dcc3e0231666b56423e056d642ef83f1115e3ba525",
      "path": "CAPABILITY/TOOLS/governance/check_inbox_policy.py",
      "size": 4618
    },
    {
      "hash": "4cc941a82d642f4c8cbd9377db3c500c3f09a51a83ac416d27dd55d2a6fba17a",
      "path": "CAPABILITY/TOOLS/governance/critic.py",
      "size": 14915
    },
    {
      "hash": "ee1453fa7545f068653c00133355e615acfff93e040d8029654940bc9402bc51",
      "path": "CAPABILITY/TOOLS/governance/integrity_stack.py",
      "size": 5609
    },
    {
      "hash": "12f68403bf5c843597ec847d28f7f6838c9f1bec3a66a016bc31cdc1af5fe41b",
      "path": "CAPABILITY/TOOLS/governance/preflight.py",
      "size": 7360
    },
    {
      "hash": "8f1cf5fa3bc36c2b7eb53e250c8e5429936ff7aaaf1d7b19569acdcbd3385731",
      "path": "CAPABILITY/TOOLS/governance/schema_validator.py",
      "size": 6404
    },
    {
      "hash": "8a3527227c1e5d59e69699bc64522c58631d280115ceb2c08b20e89e5d2c8a87",
      "path": "CAPABILITY/TOOLS/intent/fixture-artifact/intent.json",
      "size": 97
    },
    {
      "hash": "d020264cf8a2c172af55de1319acfa9058e3fb76a8eef678a42617e72f075acf",
      "path": "CAPABILITY/TOOLS/linters/LINT_IMPLEMENTATION_SUMMARY.md",
      "size": 5951
    },
    {
      "hash": "401165536b2b69607783c7de794204d39939d9450017bb124e2eec927152e192",
      "path": "CAPABILITY/TOOLS/linters/LINT_PROMPT_PACK_README.md",
      "size": 5538
    },
    {
      "hash": "68d2b7fb362abe34bf7c1ee51a655c872a1c5a2020436c6c564c859ab0fe4233",
      "path": "CAPABILITY/TOOLS/linters/LINT_QUICK_REFERENCE.md",
      "size": 2633
    },
    {
      "hash": "e741c8fb1346f4034e55e23404e337a4ff6f651bdf0dfeaf2ebc1ebf01f3b55c",
      "path": "CAPABILITY/TOOLS/linters/fix_canon_hashes.py",
      "size": 1490
    },
    {
      "hash": "70c678af4a1a8a138531fb0c36229c3d71d5cb88245641b65ce14fdaab6b0229",
      "path": "CAPABILITY/TOOLS/linters/update_canon_hashes.py",
      "size": 1594
    },
    {
      "hash": "6373a6e7d286ce52670687c49dcb0fbc4a86ca4c544b7cfcccff247c9cef3ff1",
      "path": "CAPABILITY/TOOLS/linters/update_hashes.py",
      "size": 1289
    },
    {
      "hash": "c81f84f26bce4050670fae5a447c2e90ada3c6a76eff72a1f36ace9015f2b549",
      "path": "CAPABILITY/TOOLS/linters/update_manifest.py",
      "size": 1986
    },
    {
      "hash": "da74d530569e0f1fbb56c88d09789741c417fd7d3be7c3436fcf1b07dee7f9ff",
      "path": "CAPABILITY/TOOLS/linters/verify_canon_hashes.py",
      "size": 1876
    },
    {
      "hash": "c83a60fcaf6c2fb0ac7514cd585aaf57a559eabd331105a5ffc1cc660b629a97",
      "path": "CAPABILITY/TOOLS/model_router.py",
      "size": 8963
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "CAPABILITY/TOOLS/utilities/__init__.py",
      "size": 0
    },
    {
      "hash": "e57e0133b14915be89ce3c436e4636ddc391df965f1ad2ea93622af614f93e3e",
      "path": "CAPABILITY/TOOLS/utilities/add_hash.py",
      "size": 3197
    },
    {
      "hash": "cc56ab4dfa66d47babbcc6d7cbc2d9cb41941712e3da32bd9c4fb8265c145f7e",
      "path": "CAPABILITY/TOOLS/utilities/audit_lost_files.py",
      "size": 2386
    },
    {
      "hash": "f847317d903f6411effc9dd22513b9fa61162d11ad18388c15cc07c3538b04b1",
      "path": "CAPABILITY/TOOLS/utilities/ci_local_gate.py",
      "size": 6349
    },
    {
      "hash": "1b2cb7bdf7c5ac651b7b245bb92c5512abf414aec562eaeb51022d928fa093fa",
      "path": "CAPABILITY/TOOLS/utilities/compress.py",
      "size": 9010
    },
    {
      "hash": "264dc79008c0deea1ceec1680078bf74c0c86331204a978f8e08057e520b129a",
      "path": "CAPABILITY/TOOLS/utilities/economy_report.py",
      "size": 2284
    },
    {
      "hash": "5882676091189064756c1e3df2e50a58e2127c7162039200e35636a7d21608f2",
      "path": "CAPABILITY/TOOLS/utilities/emergency.py",
      "size": 11355
    },
    {
      "hash": "a6b36549c1404df1a85ef35a725f7555297af3610f4ec058ea1d1508b2da899c",
      "path": "CAPABILITY/TOOLS/utilities/fix_depths.py",
      "size": 2009
    },
    {
      "hash": "c91804da1d1c7483907a750db8af2e6485a325c3a0f068470bafc4dfdbcc5b6b",
      "path": "CAPABILITY/TOOLS/utilities/force_fix.py",
      "size": 1214
    },
    {
      "hash": "3906edadbee7166ba3876e90c7189b9964d1d0f7db494f843147d13295a29a9e",
      "path": "CAPABILITY/TOOLS/utilities/freeze.py",
      "size": 549
    },
    {
      "hash": "60a8f38f7125fc2b9be16923b78a17e21fd350ce3d1ea5746bb3ca639eb77f35",
      "path": "CAPABILITY/TOOLS/utilities/intent.py",
      "size": 3048
    },
    {
      "hash": "355aaf41ac809a55c35d3e63f2ac4639f7aa216bdd6bb2183d4958f1e395a9f0",
      "path": "CAPABILITY/TOOLS/utilities/lint_tokens.py",
      "size": 4414
    },
    {
      "hash": "96a37ceb1fed24f28ba00f762c642dcd5cf3204cf514ad96030548a569339b24",
      "path": "CAPABILITY/TOOLS/utilities/refactor_imports.py",
      "size": 2253
    },
    {
      "hash": "cb5a4e7a3f959804c9ba16f634f8bbaac4f5dbc601002f8dc0850f20c201ca14",
      "path": "CAPABILITY/TOOLS/utilities/rename_canon.py",
      "size": 3160
    },
    {
      "hash": "3af7c91c256ee6c25b11ada9015c2e1e06902ffacbf127091857b7a199d229da",
      "path": "CAPABILITY/TOOLS/utilities/research_cache.py",
      "size": 4757
    },
    {
      "hash": "2c70f2320c57be43aef691d46c11a54c27cfda184dc655a0cb31d3d20938f60e",
      "path": "CAPABILITY/TOOLS/utilities/review_context.py",
      "size": 9408
    },
    {
      "hash": "f40c58c0420f054c78807d1bb15bfc09d60a2511bde0744010bc0b8385178e6e",
      "path": "CAPABILITY/TOOLS/utilities/setup_git_hooks.py",
      "size": 726
    },
    {
      "hash": "6074e24d96996c0954bce96f1d687dc1a068d629e3a8a6c89e233b5b92a5b5d0",
      "path": "CAPABILITY/TOOLS/utilities/terminal_hunter.py",
      "size": 2912
    },
    {
      "hash": "e612889768f979a0edf1eee0593955f9f00aa0077244b9504a45ad5508f9878c",
      "path": "CAPABILITY/TOOLS/utilities/tokenizer_harness.py",
      "size": 5800
    },
    {
      "hash": "936a0ad049d1ce9d7407af8c5254cb276cea5ac99677d3276e0d2025ff439612",
      "path": "CAPABILITY/TOOLS/utilities/verify_f3.py",
      "size": 1177
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "CAPABILITY/__init__.py",
      "size": 0
    },
    {
      "hash": "dfeddf7b818e76a249379b6b36d47d32fedd48ed1f9e80ccb253d5ce19c4573f",
      "path": "LAW/CANON/AGENT_SEARCH_PROTOCOL.md",
      "size": 5612
    },
    {
      "hash": "ac46c6f73c0d86b25b5fdfbb95116a35a4c3b3e11931cad5d3e2da238e76c0ea",
      "path": "LAW/CANON/AGREEMENT.md",
      "size": 2005
    },
    {
      "hash": "3d68102255e8e3368f1605154afa68f7a9dc3d87230b76ac338075d76c8c895b",
      "path": "LAW/CANON/ARBITRATION.md",
      "size": 3978
    },
    {
      "hash": "600169d046ffd63f28416ff4d50e395b1a2a244af89109d05501b13d324930ea",
      "path": "LAW/CANON/CAPABILITIES.json",
      "size": 1497
    },
    {
      "hash": "4d1335ce05ef98ab81ebefdbd72063313797e1b871f2bfd78f7d7f220f9e9755",
      "path": "LAW/CANON/CAPABILITY_PINS.json",
      "size": 183
    },
    {
      "hash": "c5cc24eda795844be002255984cab9bfc71897f76bffcd6c8b5897b1006c02f2",
      "path": "LAW/CANON/CAPABILITY_REVOKES.json",
      "size": 54
    },
    {
      "hash": "e01ee913a0ee3d2d2a781b799a9573cc798997d729ab09e9c156c93e58129925",
      "path": "LAW/CANON/CATALYTIC_COMPUTING.md",
      "size": 6419
    },
    {
      "hash": "0883f839e63e4216ecfe9981ed81889afb8e7e2416177e75d0d58b22393359db",
      "path": "LAW/CANON/CODEBOOK.md",
      "size": 9909
    },
    {
      "hash": "cdea792d9b5e7078a5cec237e03ea121daf1cbe2cb1f6772e7504f4575cb053d",
      "path": "LAW/CANON/CONTRACT.md",
      "size": 7558
    },
    {
      "hash": "8e0c83102b9270fc1a9a9f31485cb7be6e80e0789410a715f0334be7466c07ba",
      "path": "LAW/CANON/CRISIS.md",
      "size": 5340
    },
    {
      "hash": "33b1190532889d10b3177ffb53a154b1d6a51d79e52fb5b94a4378eeb32e8c98",
      "path": "LAW/CANON/DEPRECATION.md",
      "size": 3592
    },
    {
      "hash": "85bc78171225c4ff7a67826d953671cc031ff8e1420469f454df16ad8bd4c93f",
      "path": "LAW/CANON/FORMULA.md",
      "size": 7595
    },
    {
      "hash": "57e7116c8b7a5d40fe53b48f2b6c55169e1140b7f022a912a5ba8030db8f0682",
      "path": "LAW/CANON/GENESIS.md",
      "size": 3057
    },
    {
      "hash": "08601c32846458be0e67e3cf97e6b27062b004e38fc7f4414d38c1664903cff2",
      "path": "LAW/CANON/GENESIS_COMPACT.md",
      "size": 1447
    },
    {
      "hash": "0f5b836af209779f5af5e209aac84a3d38366b54dbbfd665a53a7dc03620360d",
      "path": "LAW/CANON/GLOSSARY.md",
      "size": 3462
    },
    {
      "hash": "482fde26ebbe9989489772c66a54e855a4124d79bb6ef22c238bab62356b7daf",
      "path": "LAW/CANON/IMPLEMENTATION_REPORTS.md",
      "size": 4628
    },
    {
      "hash": "7312715023dc86684bcc596c2745c9330ebc8f308a18576a3e29bea33cfbee59",
      "path": "LAW/CANON/INBOX_POLICY.md",
      "size": 12362
    },
    {
      "hash": "1ca2b9756119d76894bbe10b5819d7842489aa1ab8060e447059696ee8252ba6",
      "path": "LAW/CANON/INDEX.md",
      "size": 1820
    },
    {
      "hash": "d2e6e3a80346651cba7f0fe6e9a4bc267d1e8a33ae181e486a5b0abec0a3b08a",
      "path": "LAW/CANON/INTEGRITY.md",
      "size": 1669
    },
    {
      "hash": "3fdb363c9cd6e1e153d0f373b8c83039db15dcc118a283a174d10f039678363c",
      "path": "LAW/CANON/INVARIANTS.md",
      "size": 6404
    },
    {
      "hash": "bf13bd4ab0aa8f16509baa22a6b8865dda61f6ad9d4084a4ec74a63ae172ab7e",
      "path": "LAW/CANON/MIGRATION.md",
      "size": 4748
    },
    {
      "hash": "a8aa8b3e8ea34d0e8dc61482b9daa53de18bff02edf12637a1f745cdddbc0981",
      "path": "LAW/CANON/SECURITY.md",
      "size": 2617
    },
    {
      "hash": "b41f587459ead549b0bcbd63097b51897fa442d65f2b4c223184bec2b2b1c81c",
      "path": "LAW/CANON/STEWARDSHIP.md",
      "size": 10850
    },
    {
      "hash": "2764bae2de021461ecfe942723d5e769603b371990feb96780bdfad158023829",
      "path": "LAW/CANON/SYSTEM_BUCKETS.md",
      "size": 4086
    },
    {
      "hash": "102b23f6bd4cb4bb81b1c69c21e468696dc72c0fa3ab85cf32146d14f0297b9f",
      "path": "LAW/CANON/VERSIONING.md",
      "size": 1311
    },
    {
      "hash": "4a1664457a5616567615d76283aefd199d06319c8dfb3e75dc791c5b69982640",
      "path": "LAW/CANON/swarm_config.json",
      "size": 2093
    },
    {
      "hash": "7918e2248116cd2daa1c76c64ce5b31eadb9d597d9e5f12eac3f8cf86ba139d3",
      "path": "LAW/CONTEXT/README.md",
      "size": 824
    },
    {
      "hash": "28d8f925c326f006df9f43315a00f101ec4a85ef984b7503cd798827c86eb561",
      "path": "LAW/CONTEXT/decisions/ADR-000-template.md",
      "size": 1101
    },
    {
      "hash": "6aa922d2b0dec308ac492fd1f5072994bc036325b0cb7ab17555e3f1580b449c",
      "path": "LAW/CONTEXT/decisions/ADR-001-build-and-artifacts.md",
      "size": 1981
    },
    {
      "hash": "169fa93776460ebdeb1a3b15e2033ba9aa4aa0825165389a4b057ba1646c1765",
      "path": "LAW/CONTEXT/decisions/ADR-002-llm-packs-under-llm-packer.md",
      "size": 1789
    },
    {
      "hash": "071011f784011d1238c345a4093252ed410e9cfa832969beac1e6b30f2cafd91",
      "path": "LAW/CONTEXT/decisions/ADR-003-transition-to-llm-packer-underscore.md",
      "size": 1407
    },
    {
      "hash": "ab8f604b54e2ae10f8e7ec3e7f8f903fd4bcb3b6088e52c2760f8c44244c5bef",
      "path": "LAW/CONTEXT/decisions/ADR-004-mcp-integration.md",
      "size": 2537
    },
    {
      "hash": "07ba49382ab4b68f34d4eaa60d2e6183decad2f152b3e1c2dcef3d4b3b2cc15c",
      "path": "LAW/CONTEXT/decisions/ADR-005-persistent-research-cache.md",
      "size": 1810
    },
    {
      "hash": "f6bd8787b1f3f0dd567678d7f587ae7341885b0faa4ec8ea5939a7564923295d",
      "path": "LAW/CONTEXT/decisions/ADR-006-governance-schemas.md",
      "size": 2888
    },
    {
      "hash": "fc1f321ae3dfa097d1f22fa2af579faabfb774caa06600f8cc82f100323f289f",
      "path": "LAW/CONTEXT/decisions/ADR-007-constitutional-agreement.md",
      "size": 2261
    },
    {
      "hash": "c63d17d2805709756581a73afb37e16cecffcbd4ee10ba18484fda1d2f2337b7",
      "path": "LAW/CONTEXT/decisions/ADR-008-composite-commit-approval.md",
      "size": 2240
    },
    {
      "hash": "91499c1f357d50272de48ceffa85595afd52f94fd79760b96dae4f17b02222ee",
      "path": "LAW/CONTEXT/decisions/ADR-010-authorized-deletions.md",
      "size": 1477
    },
    {
      "hash": "87f58c7a15ccaeb9739e47813563a88fb99ce5f2cfc98855536c29bc0b1be3d5",
      "path": "LAW/CONTEXT/decisions/ADR-011-master-override.md",
      "size": 2484
    },
    {
      "hash": "a712a05f6657057cd8d13651e14d99a7103ef283b1aba351350e36d1b9540a46",
      "path": "LAW/CONTEXT/decisions/ADR-012-privacy-boundary.md",
      "size": 2250
    },
    {
      "hash": "8f31e7e3e8a2672afb9252fe6daf6fd29dbd2e29d77e6c1d52349efd1f42d793",
      "path": "LAW/CONTEXT/decisions/ADR-013-llm-packer-lite-split-lite.md",
      "size": 2557
    },
    {
      "hash": "322de6dce499a05c1b3b39962b42cab1dcc3324b08560b445435c2092ec7c844",
      "path": "LAW/CONTEXT/decisions/ADR-014-cortex-section-index-and-cli.md",
      "size": 2964
    },
    {
      "hash": "b7fd361e0642689912414aff6f5ef65bd03ebd5f96349d299b0019e89f32c529",
      "path": "LAW/CONTEXT/decisions/ADR-015-logging-output-roots.md",
      "size": 3984
    },
    {
      "hash": "e99132e819e15785cb3b552e38e642240014673f3e5285b39cc2d4db0198cbfd",
      "path": "LAW/CONTEXT/decisions/ADR-016-context-edit-authority.md",
      "size": 2242
    },
    {
      "hash": "399a649197c2ca2674f2fcdd9191e684ab11fa4c5f317bbf60bacc96adbb7c40",
      "path": "LAW/CONTEXT/decisions/ADR-017-skill-formalization.md",
      "size": 2351
    },
    {
      "hash": "da1305aeae051fc91b7bb9b870ac9e9333b66a3448ed47e88c132af347ee57bc",
      "path": "LAW/CONTEXT/decisions/ADR-018-catalytic-computing-canonical-note.md",
      "size": 2568
    },
    {
      "hash": "7642fbb599ab749078f2ee70b34d84479168bbea2e6257af0c9ba9bfc3fee1fa",
      "path": "LAW/CONTEXT/decisions/ADR-019-preflight-freshness-gate.md",
      "size": 2127
    },
    {
      "hash": "4eb58a8c6bc69715de7236a24d36a55bd1ddcd487aa3ea95531ba2e075a29b34",
      "path": "LAW/CONTEXT/decisions/ADR-020-admission-control-gate.md",
      "size": 2445
    },
    {
      "hash": "aa45b347b73455ffcc775e8407ae592901d54aa039b2add8d73b6bb792b230d3",
      "path": "LAW/CONTEXT/decisions/ADR-021-mandatory-agent-identity.md",
      "size": 1735
    },
    {
      "hash": "b313ed07421dde6ca9403cfb12dc1bb8a021cb48da02467e2a86ac73c31f69f6",
      "path": "LAW/CONTEXT/decisions/ADR-022-why-flash-bypassed-the-law.md",
      "size": 3551
    },
    {
      "hash": "5e5891e27aa4c7b51b5d48f86f12e72a81c2ea77ee9a5536817437a7a51ad3fb",
      "path": "LAW/CONTEXT/decisions/ADR-023-capability-revocation-semantics.md",
      "size": 2227
    },
    {
      "hash": "fe4a22106c1a2bb6f5d67b11b1d53f3607dc9c11e7e193153caa567fa9baa538",
      "path": "LAW/CONTEXT/decisions/ADR-024-capability-versioning-immutability.md",
      "size": 4727
    },
    {
      "hash": "208a9ca3f1a4c5a2acc38485f094e2b541e095d3c85e93ae39e6c9f0d75daf60",
      "path": "LAW/CONTEXT/decisions/ADR-025-antigravity-bridge-invariant.md",
      "size": 1741
    },
    {
      "hash": "1ded4d6ffb0823deca417185681e0c5ea6b4dace3c5fd250201659d4bb269ad2",
      "path": "LAW/CONTEXT/decisions/ADR-026-router-model-trust-boundary.md",
      "size": 3381
    },
    {
      "hash": "bf99975478f51a8172147f8a1f838b02fe1821e24a74812fba8cfc1702699456",
      "path": "LAW/CONTEXT/decisions/ADR-027-dual-db-architecture.md",
      "size": 2398
    },
    {
      "hash": "4cf835aabf52b8bf42dbf7a890af9977a8d99cdfa3b6d1a26c0f356460184d55",
      "path": "LAW/CONTEXT/decisions/ADR-028-semiotic-compression-layer.md",
      "size": 2088
    },
    {
      "hash": "acef691f5f28ec8f0d6b8fc437d1e9e02b8465b782c3b10b60eb31823adaabf4",
      "path": "LAW/CONTEXT/decisions/ADR-029-headless-swarm-execution.md",
      "size": 4613
    },
    {
      "hash": "0ab3aa8c6edf924d48dcb8ae309e49cb82467af15e3ab3eaf5cc83b7bff4c8e6",
      "path": "LAW/CONTEXT/decisions/ADR-030-semantic-core-architecture.md",
      "size": 11697
    },
    {
      "hash": "77df0b9785de174bdea9f300806f129e485ab152ee19837a36ee23d867f9a70b",
      "path": "LAW/CONTEXT/decisions/ADR-031-catalytic-chat-triple-write.md",
      "size": 5960
    },
    {
      "hash": "d6e1d4a0e1a01da59625a5d5aa22415521df83375ca5229abe045472d446181b",
      "path": "LAW/CONTEXT/decisions/ADR-032-agent-search-protocol.md",
      "size": 3431
    },
    {
      "hash": "c8d16a9d9830c128bc8807fd2e5f4cb822e8c4d9e9779fb8786b50a8d8443c4d",
      "path": "LAW/CONTEXT/decisions/ADR-033-mcp-message-board.md",
      "size": 1895
    },
    {
      "hash": "470e04ac4ccc7f6d0ca4589b5a881d2ef0007071a090f920eeff9e217eff5e47",
      "path": "LAW/CONTEXT/decisions/ADR-034-fast-commit-full-push-gate.md",
      "size": 2133
    },
    {
      "hash": "243ac82657acb88f0363d347001787d8306b8daa81232089b522a2e001d4535b",
      "path": "LAW/CONTEXT/decisions/ADR-035-prompt-pack-linter.md",
      "size": 7576
    },
    {
      "hash": "6aa4c2696dd60a1d418b5b46979e98b95e1da6e74a151073fb6269327786f76b",
      "path": "LAW/CONTEXT/decisions/ADR-\u221e-living-formula.md",
      "size": 2287
    },
    {
      "hash": "a98b67e537e27929a35c5104c9565c4f26e6ccf2e4fbf2c2b8e2b7464e5b6000",
      "path": "LAW/CONTEXT/preferences/STYLE-000-template.md",
      "size": 575
    },
    {
      "hash": "0dd838db73d4f94b04803cb2941293717f90493ce6fa7c094e6c2e777ecb5d27",
      "path": "LAW/CONTEXT/preferences/STYLE-001-commit-ceremony.md",
      "size": 3043
    },
    {
      "hash": "323798b3257e0631c53ed962ce08f8e3cccf5106fdbc2beed74a514c78d845ab",
      "path": "LAW/CONTEXT/preferences/STYLE-002-engineering-integrity.md",
      "size": 1358
    },
    {
      "hash": "ecebd44c4c32e54fd0de29ed8558a747bcacbedc69fe78b061855b23423ad80c",
      "path": "LAW/CONTEXT/preferences/STYLE-003-mandatory-changelog-sync.md",
      "size": 1403
    },
    {
      "hash": "2289dfc7e85ee5af1043983db3f1c5c63508d6693e4066aa57d0306a7f9bed4f",
      "path": "LAW/CONTEXT/preferences/STYLE-004-adr-first-design-gate.md",
      "size": 1435
    },
    {
      "hash": "a1c36ea3cddd4f09f4df7cf5efad24d94bf8e58bad3f613806be32fff3f2fafc",
      "path": "LAW/CONTEXT/preferences/STYLE-005-git-commit-push-protocol.md",
      "size": 2951
    },
    {
      "hash": "82d543b614345385ce02cda288a232c67677c58003ebb10b70eb19174d41a2d5",
      "path": "LAW/CONTRACTS/README.md",
      "size": 1086
    },
    {
      "hash": "ffed3d76defed08305175410fc8dff75f78503555131ee0970314124a1d19dd5",
      "path": "LAW/CONTRACTS/ags_mcp_entrypoint.py",
      "size": 512
    },
    {
      "hash": "e83148cd0dddcd22bd3d03099c489766ea163cf1ed5497c3c1d6e4c8667ffbf4",
      "path": "LAW/CONTRACTS/fixtures/catalytic/phase0/invalid/jobspec_missing_phase.json",
      "size": 316
    },
    {
      "hash": "b21050f057754170138982c15e2d88ad03fffe6d7d3bb6bce7a7832b6b7f5471",
      "path": "LAW/CONTRACTS/fixtures/catalytic/phase0/invalid/ledger_missing_restore_diff_and_bad_sha.json",
      "size": 658
    },
    {
      "hash": "4f7de844a39363d5a0c94250606833d841e33e05827e8475c2447f825002770e",
      "path": "LAW/CONTRACTS/fixtures/catalytic/phase0/invalid/validation_error_bad_code.json",
      "size": 269
    },
    {
      "hash": "2c659231316b8a35d1ecdb39b92ade801818c0506a40d73d8eadd0ffb6a66183",
      "path": "LAW/CONTRACTS/fixtures/catalytic/phase0/valid/jobspec_ok.json",
      "size": 877
    },
    {
      "hash": "6f56156cee22af73317554fee2c52812c88dd22effb24362c12f809695351065",
      "path": "LAW/CONTRACTS/fixtures/catalytic/phase0/valid/ledger_minimal_ok.json",
      "size": 1471
    },
    {
      "hash": "116b4ff0b7f9f6995c648106185697309fd380851197419d9d62275bb4906d87",
      "path": "LAW/CONTRACTS/fixtures/catalytic/phase0/valid/proof_ok.json",
      "size": 665
    },
    {
      "hash": "8e88f2c17e5391f3624fdaefe3a51f71f3f8ef080de24a5d9e1fff5ecb80b37a",
      "path": "LAW/CONTRACTS/fixtures/catalytic/phase0/valid/validation_error_ok.json",
      "size": 552
    },
    {
      "hash": "f667f92007321c254398fe9c1532f9fdad9417f04cd8af40bc1cfac71dad6eef",
      "path": "LAW/CONTRACTS/fixtures/governance/canon-sync/expected.json",
      "size": 547
    },
    {
      "hash": "f667f92007321c254398fe9c1532f9fdad9417f04cd8af40bc1cfac71dad6eef",
      "path": "LAW/CONTRACTS/fixtures/governance/canon-sync/input.json",
      "size": 547
    },
    {
      "hash": "fca40bfaa7ca0ee2964ee9cff2b33cc3c906656985d7af9554eaa274c91c776b",
      "path": "LAW/CONTRACTS/fixtures/governance/commit-ceremony/expected.json",
      "size": 321
    },
    {
      "hash": "fca40bfaa7ca0ee2964ee9cff2b33cc3c906656985d7af9554eaa274c91c776b",
      "path": "LAW/CONTRACTS/fixtures/governance/commit-ceremony/input.json",
      "size": 321
    },
    {
      "hash": "d57e3be689b3f94a9e4e806bb596197dbd2b6172ccd7927b8d578553d3938687",
      "path": "LAW/CONTRACTS/fixtures/governance/context-edit-authority/description.txt",
      "size": 469
    },
    {
      "hash": "46ca3ae3010168e0482625e1deef9600499405228a526823325e5a35d33f7640",
      "path": "LAW/CONTRACTS/fixtures/governance/context-edit-authority/expected.json",
      "size": 87
    },
    {
      "hash": "46ca3ae3010168e0482625e1deef9600499405228a526823325e5a35d33f7640",
      "path": "LAW/CONTRACTS/fixtures/governance/context-edit-authority/input.json",
      "size": 87
    },
    {
      "hash": "f7bea74d7674ca2f44896d7531e2d0d30462815b6cc38b9b9c35b30abe3a1ef4",
      "path": "LAW/CONTRACTS/fixtures/governance/deletion-authorization/expected.json",
      "size": 314
    },
    {
      "hash": "f7bea74d7674ca2f44896d7531e2d0d30462815b6cc38b9b9c35b30abe3a1ef4",
      "path": "LAW/CONTRACTS/fixtures/governance/deletion-authorization/input.json",
      "size": 314
    },
    {
      "hash": "c8087fb1c184e8a41b6316b50f00080ec1ab7a2cd67a4c864ff001197ce62ca6",
      "path": "LAW/CONTRACTS/fixtures/governance/log-output-roots/description.txt",
      "size": 309
    },
    {
      "hash": "dd83eff543e5f8b769daf465e7f5e4244883609ebc67f61348706e3d47ef1be3",
      "path": "LAW/CONTRACTS/fixtures/governance/log-output-roots/expected.json",
      "size": 78
    },
    {
      "hash": "dd83eff543e5f8b769daf465e7f5e4244883609ebc67f61348706e3d47ef1be3",
      "path": "LAW/CONTRACTS/fixtures/governance/log-output-roots/input.json",
      "size": 78
    },
    {
      "hash": "2675bf0f1c4741e036b34e539a8ec60ddfaf6e8a5a969e804e670e362f088aca",
      "path": "LAW/CONTRACTS/fixtures/governance/no-raw-paths/expected.json",
      "size": 333
    },
    {
      "hash": "1f6e8dac3065477bd5c8b729479349a277b272df2320cb3e96f91caa754748c7",
      "path": "LAW/CONTRACTS/fixtures/governance/no-raw-paths/input.json",
      "size": 324
    },
    {
      "hash": "8262ebe8188ad6636c16ca5d8a0fd0f7f166bde8fa7a999cd2d3442c9a6c8bdd",
      "path": "LAW/CONTRACTS/fixtures/governance/output-root-enforcement/description.txt",
      "size": 363
    },
    {
      "hash": "b51c4d31930251cf05d31c3efe37308ca276d8ded9d49d3b3e5543d280453fe8",
      "path": "LAW/CONTRACTS/fixtures/governance/output-root-enforcement/expected.json",
      "size": 77
    },
    {
      "hash": "b51c4d31930251cf05d31c3efe37308ca276d8ded9d49d3b3e5543d280453fe8",
      "path": "LAW/CONTRACTS/fixtures/governance/output-root-enforcement/input.json",
      "size": 77
    },
    {
      "hash": "11467e82995336790f12ee23911f0a308926449af1fb7fd2f5c60ae2089bd7c9",
      "path": "LAW/CONTRACTS/fixtures/governance/policy-proof-receipts/expected.json",
      "size": 485
    },
    {
      "hash": "11467e82995336790f12ee23911f0a308926449af1fb7fd2f5c60ae2089bd7c9",
      "path": "LAW/CONTRACTS/fixtures/governance/policy-proof-receipts/input.json",
      "size": 485
    },
    {
      "hash": "ade8a2e3bc19b1130866e0a1de93c84d426b90c47767dec04f38e9ef62482578",
      "path": "LAW/CONTRACTS/fixtures/governance/preflight/expected.json",
      "size": 597
    },
    {
      "hash": "ade8a2e3bc19b1130866e0a1de93c84d426b90c47767dec04f38e9ef62482578",
      "path": "LAW/CONTRACTS/fixtures/governance/preflight/input.json",
      "size": 597
    },
    {
      "hash": "0ca378eaa4298f1e78957ad945dfff6aac562471621ea0421f51b9ffbe17fddd",
      "path": "LAW/CONTRACTS/fixtures/governance/privacy-boundary/expected.json",
      "size": 275
    },
    {
      "hash": "0ca378eaa4298f1e78957ad945dfff6aac562471621ea0421f51b9ffbe17fddd",
      "path": "LAW/CONTRACTS/fixtures/governance/privacy-boundary/input.json",
      "size": 275
    },
    {
      "hash": "a1264289269667dcc463d38d5fffda26a601703dcae81c828afca33095391c08",
      "path": "LAW/CONTRACTS/fixtures/governance/token-grammar/expected.json",
      "size": 407
    },
    {
      "hash": "a1264289269667dcc463d38d5fffda26a601703dcae81c828afca33095391c08",
      "path": "LAW/CONTRACTS/fixtures/governance/token-grammar/input.json",
      "size": 407
    },
    {
      "hash": "3ee7d3960f1f766fe49344f664ec9b3f2d91ee9fbb4a1cb69f5e2e730bfb1de3",
      "path": "LAW/CONTRACTS/git-transport.md",
      "size": 1129
    },
    {
      "hash": "49705398ea4f4394e9d379168300c57316443834aceefb393fc82bb90da3f099",
      "path": "LAW/CONTRACTS/runner.py",
      "size": 7535
    },
    {
      "hash": "ecd8713ee19410aa557bd85e289ee09bda43ed7f0b5b6154e88fca1952dacdaa",
      "path": "LAW/CONTRACTS/schemas/canon.schema.json",
      "size": 343
    },
    {
      "hash": "f39f39afeabd3ce226555af7a39c4b813f4c33b23e81cb6beec0b1f122f36151",
      "path": "LAW/CONTRACTS/schemas/context.schema.json",
      "size": 265
    },
    {
      "hash": "1f43d0e9721df943bfaf20aecc757029991bc20900a0c74b799b60938ace586e",
      "path": "LAW/CONTRACTS/schemas/skill.schema.json",
      "size": 500
    },
    {
      "hash": "6c70aae36bc2c0b0716e312f0b4b40c154768b37e0b98d6b5e0bdbcc338b1188",
      "path": "LAW/SCHEMAS/README.md",
      "size": 9011
    },
    {
      "hash": "3972f5d42aa178c880c3f415b9c0bf003a5c8e5041d9b81f1736ad43038fa7e8",
      "path": "LAW/SCHEMAS/VERSIONING_POLICY.md",
      "size": 1477
    },
    {
      "hash": "6c2daf56c28345682647fe14f53199babc4a462438434a2fe6975a9148ee39d5",
      "path": "LAW/SCHEMAS/adapter.schema.json",
      "size": 2346
    },
    {
      "hash": "9a533360ab9b30ccfb720b0b85b8b0d22abe306ccac185e52060add5c7603e60",
      "path": "LAW/SCHEMAS/ags_plan.schema.json",
      "size": 1884
    },
    {
      "hash": "aad22c3b08e6a82ddea3286b8ba9c59d2ada65c1bd66c3568fb49be4a63c730a",
      "path": "LAW/SCHEMAS/examples/jobspec.example.json",
      "size": 490
    },
    {
      "hash": "1399c9dc754899501f24a5e56adeb1e0c4f1c2cd3a6ce2acf22ce4fb42f32fc1",
      "path": "LAW/SCHEMAS/examples/ledger.example.json",
      "size": 1109
    },
    {
      "hash": "6fc5c5b08a439701fd850f903d5e6045727d5a4b5d363a66a846f7b06d921d84",
      "path": "LAW/SCHEMAS/examples/swarm.example.json",
      "size": 381
    },
    {
      "hash": "c8b77f39d9f08b976c5ae3bd13afadf8a71ad88ae4bb16b2e7847d465bb35dc6",
      "path": "LAW/SCHEMAS/examples/validation_error.example.json",
      "size": 289
    },
    {
      "hash": "ba54cf4a076e8de989a714764454c9f6bcf5f5e1566af07610a79297eb80384d",
      "path": "LAW/SCHEMAS/jobspec.schema.json",
      "size": 2833
    },
    {
      "hash": "cdcdd938e696bbde2ac6b1e9f771d21f396b0b15bfbd66fdfb29ccea38b5e350",
      "path": "LAW/SCHEMAS/ledger.schema.json",
      "size": 4801
    },
    {
      "hash": "479f2d0188b38495d8938bd1276bb5bccb92fe6c9476fb36fdc46aeae1710a1f",
      "path": "LAW/SCHEMAS/manifest.schema.json",
      "size": 597
    },
    {
      "hash": "1ccbd3f79b0b21b0d9ec35e8bb858ecf0001defd63f9a1b5e974dbfcf1db07de",
      "path": "LAW/SCHEMAS/proof.schema.json",
      "size": 6682
    },
    {
      "hash": "1dcf61df2ca9e83a55afeaa08c83e5ec362100c2c68ef628ff39c9bbdb7bb7fa",
      "path": "LAW/SCHEMAS/swarm.schema.json",
      "size": 2707
    },
    {
      "hash": "912f999ed4c0d529d7aedf78f014de9a5383cf09a4870c008f1823d5d1013ba4",
      "path": "LAW/SCHEMAS/validation_error.schema.json",
      "size": 2056
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "LAW/__init__.py",
      "size": 0
    },
    {
      "hash": "eaa99caed93b6f8583eabe4d5a4af082c065e7b61d27d3988fe2e1970775165d",
      "path": "LICENSE",
      "size": 11905
    },
    {
      "hash": "4d2df70a2e3d1520a740993eb56d8c265871f32e746788e77d4863600de740e2",
      "path": "MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_AGENTS.md",
      "size": 7292
    },
    {
      "hash": "93210e6a1cb5bde806e5b7aeb45f8714076ada71b924659c550861cfb2ba56e5",
      "path": "MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_CHANGELOG.md",
      "size": 64065
    },
    {
      "hash": "15a1138d8a9de2f7722d284e3d0d7a39aec67849b832f14953a60b7779073495",
      "path": "MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_README.md",
      "size": 5499
    },
    {
      "hash": "49aa46af5b77a61ca7796070348a5e7b0fc3e1048b541219357eaeb443e1603d",
      "path": "MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_RELEASE_CHECKLIST.md",
      "size": 1726
    },
    {
      "hash": "abbad738d261647bd3ec19bd99adf62de6c649b3ae750b2f46411d31e6f21b08",
      "path": "MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_RELEASE_REPORT.md",
      "size": 2563
    },
    {
      "hash": "46e241c65c973a803efb9a30c78d2a275959380a433b172c9f4d2198350acb18",
      "path": "MEMORY/ARCHIVE/12-29-2025-07-01_CATALYTIC_ROADMAP_V2.3.md",
      "size": 13086
    },
    {
      "hash": "15a1138d8a9de2f7722d284e3d0d7a39aec67849b832f14953a60b7779073495",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_CATALYTIC_README.md",
      "size": 5499
    },
    {
      "hash": "0d2770a470fd05cd8e78f067837e2661b0c01397d4f6082573501d82edb3eebf",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_ROADMAP.md",
      "size": 10408
    },
    {
      "hash": "2f15a2270649e1076efa5553eaba428540c5dd76ad36f7461e7f0e2bd8630eb9",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_ROADMAP_V2.1.md",
      "size": 21571
    },
    {
      "hash": "1af98986ae69fda37cf31df40d18b496581cc7f483bab08ec0021166b58fa8b4",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_ROADMAP_V2.2.md",
      "size": 18195
    },
    {
      "hash": "33bc6101af3404192f318e8a8078878346ca0611fd9e489261a651d486a69522",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-26-2025-06-39_ROADMAP_V2.md",
      "size": 9851
    },
    {
      "hash": "46e241c65c973a803efb9a30c78d2a275959380a433b172c9f4d2198350acb18",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-27-2025-22-00_CATALYTIC_ROADMAP_V2.3.md",
      "size": 13086
    },
    {
      "hash": "49aa46af5b77a61ca7796070348a5e7b0fc3e1048b541219357eaeb443e1603d",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-28-2025-01-18_CATALYTIC_RELEASE_CHECKLIST.md",
      "size": 1726
    },
    {
      "hash": "abbad738d261647bd3ec19bd99adf62de6c649b3ae750b2f46411d31e6f21b08",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-28-2025-01-18_CATALYTIC_RELEASE_REPORT.md",
      "size": 2563
    },
    {
      "hash": "4d2df70a2e3d1520a740993eb56d8c265871f32e746788e77d4863600de740e2",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-28-2025-01-54_CATALYTIC_AGENTS.md",
      "size": 7292
    },
    {
      "hash": "93210e6a1cb5bde806e5b7aeb45f8714076ada71b924659c550861cfb2ba56e5",
      "path": "MEMORY/ARCHIVE/catalyticdpt/12-29-2025-04-16_CATALYTIC_CHANGELOG.md",
      "size": 64065
    },
    {
      "hash": "8f8d3c75322cee99360f3fc861053dd5fd5517c8e5032bddb1d9e72050649f13",
      "path": "MEMORY/ARCHIVE/implemented/P1_6_BUCKET_MIGRATION_P0\u2705.md",
      "size": 7530
    },
    {
      "hash": "5ac8770d047e687e93db6745a58b573aaf50c7ccc8e97340558f72c21b26fd4f",
      "path": "MEMORY/ARCHIVE/implemented/P2_CAS_PACKER_INTEGRATION_P0\u2705.md",
      "size": 10013
    },
    {
      "hash": "0cbaeead2743a5cfa2bf5a8ddfea5301910f5cbb010e2306054c0915997eb3dd",
      "path": "MEMORY/ARCHIVE/implemented/PROMPT_PACK_REPORT\u2705.md",
      "size": 3184
    },
    {
      "hash": "601e4422cee86aba9a6c3437edd8ed831dbd6dbd531f845d77c9463be13be692",
      "path": "MEMORY/ARCHIVE/planning/01-01-2026-08-44_CASSETTE_NETWORK_ROADMAP_1.md",
      "size": 7402
    },
    {
      "hash": "601e4422cee86aba9a6c3437edd8ed831dbd6dbd531f845d77c9463be13be692",
      "path": "MEMORY/ARCHIVE/planning/01-01-2026-08-44_CASSETTE_NETWORK_ROADMAP_2.md",
      "size": 7402
    },
    {
      "hash": "e3344506eaa877aaecd2b2812e04bd459a1d9a51da86432e3f846359c2819d9a",
      "path": "MEMORY/ARCHIVE/planning/01-01-2026-14-14_REPO_FIXES_TASKS_SNAPSHOT.md",
      "size": 4418
    },
    {
      "hash": "308148299e07342cadee9ba10dbeafa78b899bf4b7600278ec8877ede3704e85",
      "path": "MEMORY/ARCHIVE/planning/01-03-2026-21-07_AGS_ROADMAP_MASTER_3.3.4\u274c.md",
      "size": 30905
    },
    {
      "hash": "06f5cd6e579ba91efd2682286a3c1b2c675b5f24b64ae529d1e631527a32ee2c",
      "path": "MEMORY/ARCHIVE/planning/12-21-2025-12-00_AGS_3_0_COMPLETED.md",
      "size": 14346
    },
    {
      "hash": "1921d4c8719bb29bddae687c4d87f792d6ab2587bd3a04511e29b980a7565d2a",
      "path": "MEMORY/ARCHIVE/planning/12-21-2025-12-00_AGS_MASTER_TODO.md",
      "size": 12174
    },
    {
      "hash": "28d0833b469911ec65facc4952834306b8e73c7dc0b8e6faf5b7e9456c012ee8",
      "path": "MEMORY/ARCHIVE/planning/12-21-2025-12-00_ROADMAP.md",
      "size": 3231
    },
    {
      "hash": "ba7a1c876591845c0acb7e2a79f052265b17014fd596291eb689bfb2778ea818",
      "path": "MEMORY/ARCHIVE/planning/12-27-2025-14-03_AGS_3.0_ROADMAP.md",
      "size": 9480
    },
    {
      "hash": "0ee7f8a76476dc6ba0476505217293ac3b9a95ab610b0e254f54ae36063423a9",
      "path": "MEMORY/DELTA_PACKS.md",
      "size": 3721
    },
    {
      "hash": "68b4fbccf176c4afa62a26f762b27e29d530516755986d58fdf27e1316e5d33d",
      "path": "MEMORY/LLM_PACKER/CHANGELOG.md",
      "size": 3588
    },
    {
      "hash": "f7dfe219c1ba5fe58b742099aa335bf9df0e33c99eb6f665c4593b0d5a98c92f",
      "path": "MEMORY/LLM_PACKER/DETERMINISM.md",
      "size": 2780
    },
    {
      "hash": "b578860e46711e6e1b205da0046110703dbf33d91e6135889dff3050c78e1c52",
      "path": "MEMORY/LLM_PACKER/Engine/1-AGS-PACK.cmd",
      "size": 559
    },
    {
      "hash": "cf0621fb22fdf27930a84b2e5891ad19aad9878bc5ee735f43136baa6cb882ea",
      "path": "MEMORY/LLM_PACKER/Engine/2-LAB-PACK.cmd",
      "size": 452
    },
    {
      "hash": "60eb5f8bc0a798b0c280d57b9c08c6712c1f7935d6922ba6695e46a0d0f6e93b",
      "path": "MEMORY/LLM_PACKER/Engine/pack.ps1",
      "size": 2179
    },
    {
      "hash": "ebca0da1dffab5bdd52673a21aa02db39b0f070ccd2c8e22357e05aa8259aa82",
      "path": "MEMORY/LLM_PACKER/Engine/packer/__init__.py",
      "size": 1090
    },
    {
      "hash": "b3821f0a8fbd6a615736dc57e7620b0fa0503cc973400e2963bc33bbf32431f2",
      "path": "MEMORY/LLM_PACKER/Engine/packer/__main__.py",
      "size": 89
    },
    {
      "hash": "542e14a380820a28d7890ef0ee6b8bc73b81d1be9e2bc24c01db64bf82ad9ad7",
      "path": "MEMORY/LLM_PACKER/Engine/packer/archive.py",
      "size": 5371
    },
    {
      "hash": "fcc11f81534ad9ff08c89e88c02782da0e1585c6bd3b02af101ed2336cbdf09e",
      "path": "MEMORY/LLM_PACKER/Engine/packer/cli.py",
      "size": 4937
    },
    {
      "hash": "850fd56bb3f0de971f7209c6d2d93e8f8cefaaaa4c9123177139271ec8df5e82",
      "path": "MEMORY/LLM_PACKER/Engine/packer/consumer.py",
      "size": 9613
    },
    {
      "hash": "fa2515e55d94a082b4f7f79dbcd221c751b303c0eef4b7168b15955ed4800b18",
      "path": "MEMORY/LLM_PACKER/Engine/packer/core.py",
      "size": 39239
    },
    {
      "hash": "78582669fe11c3782aa4fc37dec1afe115e21a2363bebbd6d07b0fd6702d0060",
      "path": "MEMORY/LLM_PACKER/Engine/packer/lite.py",
      "size": 3829
    },
    {
      "hash": "c6e3c0c767c93c872637a6dd03a707efe2369e861f512ad17bec2ff7236acfa4",
      "path": "MEMORY/LLM_PACKER/Engine/packer/proofs.py",
      "size": 16740
    },
    {
      "hash": "65b12abc8ab240b8173ea378585940f02a999e3a6f719de8c264015124a53906",
      "path": "MEMORY/LLM_PACKER/Engine/packer/split.py",
      "size": 7460
    },
    {
      "hash": "88bf416e8ed52663bc8c8e1066c677c7f6cb70807014fe0dfb0b58e7551ea4e6",
      "path": "MEMORY/LLM_PACKER/Engine/run_tests.cmd",
      "size": 1005
    },
    {
      "hash": "f293d297fa71531e942c5aff9b7361b6e1dbca7c7209cd7f4900d53e363a794d",
      "path": "MEMORY/LLM_PACKER/README.md",
      "size": 3475
    },
    {
      "hash": "fdb4567b8c304c7f079ded2a5e7c4add13f097e5626bb9dae7e7439712f039e2",
      "path": "MEMORY/MEMORY_STORE.md",
      "size": 4036
    },
    {
      "hash": "746faf1c0b7f81680af594ffed41409fff5ea4f5153a7279ff20f2b323591617",
      "path": "MEMORY/PACKER_ROADMAP.md",
      "size": 11807
    },
    {
      "hash": "5fc375699b780932946bb997d0a39879f96354c7671c8cdae8ee5d0035057e4b",
      "path": "NAVIGATION/CORTEX/README.md",
      "size": 2529
    },
    {
      "hash": "443d6e8fa64a5c1d5f48892a1dfd8b8b2e4056efe9f15812b9802dbceb7f80a1",
      "path": "NAVIGATION/CORTEX/cortex.json",
      "size": 19842
    },
    {
      "hash": "cabeda59a582eabf217a6b5464bc634c1aed858a8dea6f42fe3d48dcb91cd9b7",
      "path": "NAVIGATION/CORTEX/cortex.schema.json",
      "size": 889
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "NAVIGATION/CORTEX/db/__init__.py",
      "size": 0
    },
    {
      "hash": "f8283415040c4f372d90fd8972852bd4caafaa176c75ca754dfdce2519b9e12b",
      "path": "NAVIGATION/CORTEX/db/build_swarm_db.py",
      "size": 10618
    },
    {
      "hash": "f7bf1cbd16f85292094e9689733476cd7b931a824661d72789e21a250d30e992",
      "path": "NAVIGATION/CORTEX/db/cortex.build.py",
      "size": 21355
    },
    {
      "hash": "89a047ade08194c2873302163d042b18ca34f7986c9051a2d678991a42652654",
      "path": "NAVIGATION/CORTEX/db/reset_system1.py",
      "size": 883
    },
    {
      "hash": "9e865074fa351084453200e79cf93a7df5a87081c3cf6d5efed99e5d2b169691",
      "path": "NAVIGATION/CORTEX/db/system1_builder.py",
      "size": 9337
    },
    {
      "hash": "0bce693b850264786762aa0aafb3a26b82706d8feb7682436a82d213eb19454b",
      "path": "NAVIGATION/CORTEX/db/system2_ledger.py",
      "size": 5064
    },
    {
      "hash": "1e5656122907879345148271195c65a8047f0ceacc9776eeee61b0d22d08ce20",
      "path": "NAVIGATION/CORTEX/fixtures/test_fences.md",
      "size": 539
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "NAVIGATION/CORTEX/network/__init__.py",
      "size": 0
    },
    {
      "hash": "46ff2d156f678b731d460aa7e60465b3ea19ac787da267d6292d6bdb8ce9abad",
      "path": "NAVIGATION/CORTEX/network/cassette_protocol.py",
      "size": 2184
    },
    {
      "hash": "ac2eba6b99ed21174525c51d392a03309086e41ba8716468ac8b0e095edbe928",
      "path": "NAVIGATION/CORTEX/network/cassettes.json",
      "size": 1296
    },
    {
      "hash": "fc58bd8a3c911e345a8c8fc9df6c4f37b6638eaa6fd4fa0f5d265212040aec26",
      "path": "NAVIGATION/CORTEX/network/cassettes/__init__.py",
      "size": 160
    },
    {
      "hash": "616760bf93df97c20380941c83d5ac32b154276d8f2afd2fda9c344bf4625350",
      "path": "NAVIGATION/CORTEX/network/cassettes/agi_research_cassette.py",
      "size": 3177
    },
    {
      "hash": "975182a9c5e732db5891d5243db6211239ec8878a6e1d1b7ecb2f2a752b4fee9",
      "path": "NAVIGATION/CORTEX/network/cassettes/cat_chat_cassette.py",
      "size": 8728
    },
    {
      "hash": "eb8366d738eef2750196d17906b5c37d81963b71b43381efd6e7a73fe45659b0",
      "path": "NAVIGATION/CORTEX/network/cassettes/governance_cassette.py",
      "size": 3598
    },
    {
      "hash": "fae1ab027325d89ab0bc06ba866903d0469da2e90a445ea38028fdb06238c230",
      "path": "NAVIGATION/CORTEX/network/demo_cassette_network.py",
      "size": 1707
    },
    {
      "hash": "20eaf520a472d4003ae77f970db05e52133e7eb925bad8ffea4e8fa15971d544",
      "path": "NAVIGATION/CORTEX/network/generic_cassette.py",
      "size": 10663
    },
    {
      "hash": "872d93efc9d01d6d5b48469a931c9b38b843ce2c474b59cad4a7d9aacef33ea6",
      "path": "NAVIGATION/CORTEX/network/network_hub.py",
      "size": 4787
    },
    {
      "hash": "0d8a8b1b7e8bd74b820a8dc9c22d4797e38aac07580017281110fd8deefd1aed",
      "path": "NAVIGATION/CORTEX/network/test_cassettes.py",
      "size": 1585
    },
    {
      "hash": "87b9589552502732e17d8d4ae858ecf1ceb161db05838f144013d2636f98aeae",
      "path": "NAVIGATION/CORTEX/requirements.txt",
      "size": 379
    },
    {
      "hash": "d62eb087f5588db943478bc78feb2b9d3806e793829898f95ef877b679a5e232",
      "path": "NAVIGATION/CORTEX/semantic/README.md",
      "size": 10359
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "NAVIGATION/CORTEX/semantic/__init__.py",
      "size": 0
    },
    {
      "hash": "3cf50d875828fcd54c5767232b1506f34b84055fcc810249b79d5e77eb71aa20",
      "path": "NAVIGATION/CORTEX/semantic/embeddings.py",
      "size": 8032
    },
    {
      "hash": "b610679bb77eb2e416d28ad6d7dc20f876ab7c82ca29abb93f9f0fc4087d7d75",
      "path": "NAVIGATION/CORTEX/semantic/indexer.py",
      "size": 8307
    },
    {
      "hash": "7fb3517dc7ffd700b2b86dd647f1ddb42144863ef1163143485dba5418688a43",
      "path": "NAVIGATION/CORTEX/semantic/query.py",
      "size": 7416
    },
    {
      "hash": "755a1b8a2cd0de276c68852f3db93c2d6a90902ab9c935981c9103cde70c8c5f",
      "path": "NAVIGATION/CORTEX/semantic/scl.py",
      "size": 5495
    },
    {
      "hash": "c7be8babcd8f292beddbe546e9c78dbe2e00b7c91fad2cfc8f840b922db0cc42",
      "path": "NAVIGATION/CORTEX/semantic/semantic_search.py",
      "size": 13316
    },
    {
      "hash": "92f87b15f39047d1d7a3017a8d577e6c3da5d60316f23019a50cf2ac0f9947b4",
      "path": "NAVIGATION/CORTEX/semantic/summarizer.py",
      "size": 4240
    },
    {
      "hash": "15ddc08431aa0a057124bed0c18091a44af1ad3196941523d66d592333e82580",
      "path": "NAVIGATION/CORTEX/semantic/vector_indexer.py",
      "size": 12773
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "NAVIGATION/CORTEX/tests/__init__.py",
      "size": 0
    },
    {
      "hash": "9630dcdcb78efc84c13c8b9d3f140f23c7f15805c8935c6d2865bf7475c4394a",
      "path": "NAVIGATION/CORTEX/tests/swarm_integration_test.py",
      "size": 10959
    },
    {
      "hash": "e79a9d9ce69e9e5611bc343ad1a1318e430de704849a80d4afd0b4e3f039355b",
      "path": "NAVIGATION/CORTEX/tests/test_query.py",
      "size": 3469
    },
    {
      "hash": "e7ddf8b4b83669b7d8dd7947f3fd6927d5a3722e2684f4b4941b48ec9b156601",
      "path": "NAVIGATION/CORTEX/tests/test_semantic_core.py",
      "size": 12394
    },
    {
      "hash": "4b66faa33658fb4a412828a75d55f6840e04afa54726bd71ccfe301329d5fed6",
      "path": "NAVIGATION/CORTEX/tests/verify_db.py",
      "size": 792
    },
    {
      "hash": "0bc919dc117528731e2aab3adce3f96268d590f9db16b9487b9e4cba70fa2e25",
      "path": "NAVIGATION/INVARIANTS/Z2_5_GC_INVARIANTS.md",
      "size": 5408
    },
    {
      "hash": "23208501a5b2fc6421dfc91f4a29faecaf910e88b1eaadf91941f90418cf4d16",
      "path": "NAVIGATION/INVARIANTS/Z2_5_GC_TEST_MATRIX.md",
      "size": 4058
    },
    {
      "hash": "dda229b2ae6082daa36b8a1b16bd036ffda75d57f994725f5a3611a1a4966ba9",
      "path": "NAVIGATION/INVARIANTS/Z2_6_PACKER_INVARIANTS_DRAFT.md",
      "size": 4474
    },
    {
      "hash": "276a78e832cc59f7a4e4a1fb7d539fded9d219ecd48d3c787a4aeddb1932bbf2",
      "path": "NAVIGATION/INVARIANTS/Z2_6_ROOT_AUDIT_INVARIANTS.md",
      "size": 12747
    },
    {
      "hash": "ff2612c05553a662e1d37421bd03a3c6e01d5eaf42bf018acc9a127672d61201",
      "path": "NAVIGATION/INVARIANTS/Z2_CAS_AND_RUN_INVARIANTS.md",
      "size": 5943
    },
    {
      "hash": "789898b6fe61cfaa9e1d73227fc5ba5bd3068d2c74e900f7373376e27af4a162",
      "path": "NAVIGATION/MAPS/CATALYTIC_DOMAINS.md",
      "size": 5195
    },
    {
      "hash": "6ef19b210ee3853ee5c09a38f7ee00bfbbcd37cb0aac635abeb728d38a4889c9",
      "path": "NAVIGATION/MAPS/DATA_FLOW.md",
      "size": 2660
    },
    {
      "hash": "cab415a2aac68aae6bd471ef5c078c81be72e72ac1d803d675d3aa52cdd914d9",
      "path": "NAVIGATION/MAPS/ENTRYPOINTS.md",
      "size": 1633
    },
    {
      "hash": "4d56cd430d813b7e8676fc3cebb105ad8c2ec46344b4ae88396ac1927f088f71",
      "path": "NAVIGATION/MAPS/FILE_OWNERSHIP.md",
      "size": 2446
    },
    {
      "hash": "0d6ca48a8e41e4cb43203c0897cf94a2b183d5f8afcb6023c07f51ccb11e20e5",
      "path": "NAVIGATION/MAPS/SYSTEM_MAP.md",
      "size": 1741
    },
    {
      "hash": "56b33b9a49d0894ec13c1520e9bc06d8ed0fb76817dfd0051ddb72f3bfce2d6c",
      "path": "NAVIGATION/OPS/FAILURE_CATALOG.md",
      "size": 9024
    },
    {
      "hash": "cbe89b3e7b29a24dd907b89188a79d9a71b925958ab6455ed333b9edc10d1759",
      "path": "NAVIGATION/OPS/SMOKE_RECOVERY.md",
      "size": 13199
    },
    {
      "hash": "99d0ede4ed7710767b90d37efd0ea9444ecb41d9c82ae38a79f0952dd25c22f3",
      "path": "NAVIGATION/PROMPTS/0_ORIENTATION_CANON.md",
      "size": 7765
    },
    {
      "hash": "29ed1cec0104314dea9bb5844e9fd7c15a162313ef7cc3a19e8b898d9cea2624",
      "path": "NAVIGATION/PROMPTS/1_PROMPT_POLICY_CANON.md",
      "size": 9091
    },
    {
      "hash": "9acc1b9772579720e3c8bc19a80a9a3908323b411c6d06d04952323668f4efe4",
      "path": "NAVIGATION/PROMPTS/2_PROMPT_GENERATOR_GUIDE_FINAL.md",
      "size": 3667
    },
    {
      "hash": "bf7019da38e5ff1d9696c64ba2c53312cad3e6de701d602b758ea40680fb9967",
      "path": "NAVIGATION/PROMPTS/3_MASTER_PROMPT_TEMPLATE_CANON.md",
      "size": 2490
    },
    {
      "hash": "f59ce79aea9258157c19f71d80b502893e388c519942f5ec24399d2aed4f0465",
      "path": "NAVIGATION/PROMPTS/4_FULL_HANDOFF_TEMPLATE_CANON.md",
      "size": 2852
    },
    {
      "hash": "fe49dfee148d2710b1e97233b24679b6c5a669e787e568b8b3ca2a7e9259362a",
      "path": "NAVIGATION/PROMPTS/5_MINI_HANDOFF_TEMPLATE_CANON.md",
      "size": 547
    },
    {
      "hash": "70022eda441e80518d3bdd4c48fad1194e9cc4abd887a2a893078752bb81fbc3",
      "path": "NAVIGATION/PROMPTS/6_MODEL_ROUTING_CANON.md",
      "size": 5039
    },
    {
      "hash": "8eca016e6f46eafbf9966c24600688261abb08eabb26084d846c742f06a5e7e4",
      "path": "NAVIGATION/PROMPTS/INDEX.md",
      "size": 3673
    },
    {
      "hash": "9723b70ac67beace38edece2c4f03c4405ab8c58faaa3ec01c8901565fda28fc",
      "path": "NAVIGATION/PROMPTS/PHASE_01/1.1_hardened-inbox-governance-s-2\u2705.md",
      "size": 6851
    },
    {
      "hash": "c1ee01b16e29e76a639d6415698539f9992da989c135bbe2179c3830c7f7f51f",
      "path": "NAVIGATION/PROMPTS/PHASE_01/1.2_bucket-enforcement-x3\u2705.md",
      "size": 6405
    },
    {
      "hash": "075fd55585caadd1ce69c981bd7ed4b8d0ebc0aef818158d173369d28a2b65a6",
      "path": "NAVIGATION/PROMPTS/PHASE_01/1.3_deprecate-lab-mcp-server\u2705.md",
      "size": 6553
    },
    {
      "hash": "b439e35b02675145d770d4d2ea3decff08c6732932de3d08a16f8ab2ec05a157",
      "path": "NAVIGATION/PROMPTS/PHASE_01/1.4_failure-taxonomy-recovery-playbooks-ops-grade.md",
      "size": 7150
    },
    {
      "hash": "7d96516ba057f2e5be34775d71283ff5240aa64d450a57d1002dd471433dade3",
      "path": "NAVIGATION/PROMPTS/PHASE_02/2.1_cas-aware-llm-packer-integration-p-2-remainder\u2705.md",
      "size": 8736
    },
    {
      "hash": "f21cee4218b7252eb5c5609bce79e54b810a67029082b880927674fc15eb2911",
      "path": "NAVIGATION/PROMPTS/PHASE_02/2.2_pack-consumer-verification-rehydration\u2705.md",
      "size": 8528
    },
    {
      "hash": "5e7934468019192681ff892cf9ae650fcda392fdd507abe9b647ebb779e78102",
      "path": "NAVIGATION/PROMPTS/PHASE_02/2.3_run-bundle-contract-freezing-what-is-a-run\u2705.md",
      "size": 6974
    },
    {
      "hash": "23975343ab96be17d1f0a23e9326cf931919fca3f30aba5b13ec21f3b2dd2574",
      "path": "NAVIGATION/PROMPTS/PHASE_03/3.1_router-fallback-stability\u2705.md",
      "size": 7994
    },
    {
      "hash": "e48801d7dbd5d202a3ddba94748a1cb20373c338327e8a57b42eeaeeae64ebab",
      "path": "NAVIGATION/PROMPTS/PHASE_03/3.2_memory-integration.md",
      "size": 7897
    },
    {
      "hash": "6bece0e04e4971781547d13e8500d445cf6939750b13cdf3560c42e5ba1522ed",
      "path": "NAVIGATION/PROMPTS/PHASE_03/3.3_tool-binding.md",
      "size": 7836
    },
    {
      "hash": "72692629dc98424d0bdfc7c77690014f8b9e47caf2791c359501029e733e28b8",
      "path": "NAVIGATION/PROMPTS/PHASE_03/3.4_session-persistence.md",
      "size": 7998
    },
    {
      "hash": "a647c3aa836993f647cd4435e3e5c18721a19ba2d8a0163b6573f01dc3ffdcc5",
      "path": "NAVIGATION/PROMPTS/PHASE_04/4.1_catalytic-snapshot-restore\u2705.md",
      "size": 6813
    },
    {
      "hash": "e5de9c06aae71f5b1200898ac963bdc9cbdf34d091aad72fccba85f8e14e6df5",
      "path": "NAVIGATION/PROMPTS/PHASE_05/5.1_embed-canon-adrs-and-skill-discovery.md",
      "size": 7031
    },
    {
      "hash": "862484ec74ea29192f87cd71a6e194c65e202327116ef9513895f8c4dd29016f",
      "path": "NAVIGATION/PROMPTS/PHASE_06/6.1_cassette-partitioning.md",
      "size": 8445
    },
    {
      "hash": "dd36c953713e863020c5066a44ae2e944431c6840b0d4eeb08b765f76b570a7d",
      "path": "NAVIGATION/PROMPTS/PHASE_06/6.2_write-path-memory-persistence.md",
      "size": 5717
    },
    {
      "hash": "4693a0ba8a42705fcf802282f31eb2e7a24ee312980675d53924f1c4a0ead8a0",
      "path": "NAVIGATION/PROMPTS/PHASE_06/6.3_cross-cassette-queries.md",
      "size": 8227
    },
    {
      "hash": "f734de8f639f00a3e5edfb5052b95496ee41349e80295afade5a78cb33538cd2",
      "path": "NAVIGATION/PROMPTS/PHASE_06/6.4_compression-validation.md",
      "size": 8055
    },
    {
      "hash": "47d954b0f9868569759df910a778c9b8469f335d350787adc3462d36722bbac1",
      "path": "NAVIGATION/PROMPTS/PHASE_07/7.1_research-decisions.md",
      "size": 6896
    },
    {
      "hash": "cf2af87f826e397896221690ad2f98c54a5413767e8d8991f35e34fccb473ffa",
      "path": "NAVIGATION/PROMPTS/PHASE_07/7.2_logging-infrastructure.md",
      "size": 8081
    },
    {
      "hash": "75b4f673d88db7eb879ab81abcf6fc02326de9add39a3e241d909c3c5326dc29",
      "path": "NAVIGATION/PROMPTS/PHASE_07/7.3_elo-engine.md",
      "size": 7894
    },
    {
      "hash": "e54b502856b5fb0698474094832e7c6f5cd12258a9edb70cf727d9c9c8cf96ca",
      "path": "NAVIGATION/PROMPTS/PHASE_07/7.4_memory-pruning.md",
      "size": 8039
    },
    {
      "hash": "24820a64afb5f9cfe3d27b03c4ca843c9051ffeb3f0628b07b6073377778076d",
      "path": "NAVIGATION/PROMPTS/PHASE_07/7.5_lite-pack-integration.md",
      "size": 8294
    },
    {
      "hash": "64c4b4351d574efab30335ef5209ff9f3c04df3c8782a0432a16dd0522285f6b",
      "path": "NAVIGATION/PROMPTS/PHASE_07/7.6_search-result-ranking.md",
      "size": 6642
    },
    {
      "hash": "c60af9889a8383ed2be0468a3b3a3ac5d9b887fb0873240402ffbde6f4158d40",
      "path": "NAVIGATION/PROMPTS/PHASE_07/7.7_visualization-monitoring.md",
      "size": 6606
    },
    {
      "hash": "b4a6fd13df57b8c8ead300114ba851b07efadbe85bd31e471506248dcb4ea75d",
      "path": "NAVIGATION/PROMPTS/PHASE_08/8.1_resident-identity.md",
      "size": 7948
    },
    {
      "hash": "34672cb7b2c74317ce16e5140ab3c0ca1f41921a386c779464556416cbffb960",
      "path": "NAVIGATION/PROMPTS/PHASE_08/8.2_symbol-language-evolution.md",
      "size": 6680
    },
    {
      "hash": "3481734a0e8355373702c8bf332c9f674a115f9b9f36282ceb106388efaa0314",
      "path": "NAVIGATION/PROMPTS/PHASE_08/8.3_feral-resident.md",
      "size": 7906
    },
    {
      "hash": "7b5f66f000b5d4eba468983077af9b044264daf710ba9f5933f88fdb16f4d23b",
      "path": "NAVIGATION/PROMPTS/PHASE_08/8.4_production-hardening.md",
      "size": 6626
    },
    {
      "hash": "92b2338068b56e18fa46e123c0db4710f38f2c915bbc9a13513b441fa3b976e1",
      "path": "NAVIGATION/PROMPTS/PHASE_08/8.5_vector-execution-long-horizon.md",
      "size": 7156
    },
    {
      "hash": "8e337ed79f2ca49b2a128ceb02f886251039066dc74dcf70cdc42ad266e3e75b",
      "path": "NAVIGATION/PROMPTS/PHASE_10/10.1_performance-foundation-1.md",
      "size": 6579
    },
    {
      "hash": "ade6a2dbd043ec32b9b70855c9a16cc619de9bb736cf4cbc4bfbc59835636d5a",
      "path": "NAVIGATION/PROMPTS/PHASE_10/10.2_scale-governance-2.md",
      "size": 6526
    },
    {
      "hash": "8cde3b2b54f329110916642cbc9c6eec3898256c0daba7e471197ff16c125e95",
      "path": "NAVIGATION/PROMPTS/PHASE_10/10.3_intelligence-ux-3.md",
      "size": 6575
    },
    {
      "hash": "2fcc1e776943648c9f2c32da290df339ff069c215a5b4e0dac26db3b5d67d8a1",
      "path": "NAVIGATION/PROMPTS/PROMPT_PACK_MANIFEST.json",
      "size": 33156
    },
    {
      "hash": "b004458502a304dc759193bcfa6f02a74485e1ac12f2657d6393281fea89f6f8",
      "path": "NAVIGATION/PROOFS/CATALYTIC/CATALYTIC_EVIDENCE_MAP.md",
      "size": 5317
    },
    {
      "hash": "46ffcfa0312379dbf5374a7bd1f0528cf2cd690893999aaf3c059053934c2dd8",
      "path": "NAVIGATION/PROOFS/CATALYTIC/PROOF_LOG.txt",
      "size": 16
    },
    {
      "hash": "b925cb19d8a6c388f8fa9ccdc62122b87d76114190fe3239bc2da564e3cfade5",
      "path": "NAVIGATION/PROOFS/CATALYTIC/PROOF_SUMMARY.md",
      "size": 167
    },
    {
      "hash": "a7660d15616598b78e504ff1c90f478f05f9b69eb4a07629c01f5614ec00949a",
      "path": "NAVIGATION/PROOFS/COMPRESSION/COMPRESSION_PROOF_DATA.json",
      "size": 9767
    },
    {
      "hash": "c9a032a367442bb63fdd29f6e1666766cb2fbd4321fcbdb7c7f3ccfea1bd3bfd",
      "path": "NAVIGATION/PROOFS/COMPRESSION/COMPRESSION_PROOF_MAP.md",
      "size": 5371
    },
    {
      "hash": "5f29fc2efc27b7a44abea343e2a1577a6a6cdc569e44d9d16dc064a5e24c1363",
      "path": "NAVIGATION/PROOFS/COMPRESSION/COMPRESSION_PROOF_REPORT.md",
      "size": 2376
    },
    {
      "hash": "ea36f2464f13a3e021f183e5cdd44924dc17d5d1b30b80fcd1e440ee3d2f7f9c",
      "path": "NAVIGATION/PROOFS/COMPRESSION/PROOF_LOG.txt",
      "size": 72
    },
    {
      "hash": "3a1e3363c806af3a3971867e5df21577e5c0a130cd019f4ff1f873e90ca146c1",
      "path": "NAVIGATION/PROOFS/GC/01-02-2026-19-22_Z2_5_GC_OPERATIONAL_PROOF.md",
      "size": 2490
    },
    {
      "hash": "d20cc99938302243ab5b3dfe7dfdd89c7ce7d2f5c61e843ffc3cbe468d6aa249",
      "path": "NAVIGATION/PROOFS/GREEN_STATE.json",
      "size": 803
    },
    {
      "hash": "5f8b82b9012c876a33448413704458c1d546c6ea41596ee34813c89a6b9b8e4b",
      "path": "NAVIGATION/PROOFS/GREEN_STATE.md",
      "size": 623
    },
    {
      "hash": "a81790f3228154d39328322bbf9e9bb70dac29be79894a829a6a18e9f92f090b",
      "path": "NAVIGATION/PROOFS/PROOF_MANIFEST.json",
      "size": 1797
    },
    {
      "hash": "d0f129acdd9080c33db37def4ed3a95474aa231ab1c667aa2c8931ad7206ec3a",
      "path": "NAVIGATION/ROADMAPS/AGS_ROADMAP_MASTER.md",
      "size": 17514
    },
    {
      "hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "path": "NAVIGATION/__init__.py",
      "size": 0
    },
    {
      "hash": "cf7f0ff4bcd3de6e2de99cebd8427167af19d09d8045ce03eae33a9f5b87d3f7",
      "path": "README.md",
      "size": 5280
    }
  ],
  "grammar_version": "1.0",
  "scope": "ags"
}
```

## `meta/START_HERE.md`

```
# START HERE

This snapshot is meant to be shared with any LLM to continue work on the Agent Governance System (AGS) repository.

## Read order
1) `repo/AGENTS.md`
2) `repo/README.md`
3) `repo/LAW/CANON/CONTRACT.md`
4) `repo/NAVIGATION/MAPS/ENTRYPOINTS.md`
5) `repo/LAW/CONTRACTS/runner.py`
6) `meta/ENTRYPOINTS.md`

## Notes
- `BUILD` contents excluded.
- Use `FULL/` for single-file output or `SPLIT/` for sectioned reading.
```
