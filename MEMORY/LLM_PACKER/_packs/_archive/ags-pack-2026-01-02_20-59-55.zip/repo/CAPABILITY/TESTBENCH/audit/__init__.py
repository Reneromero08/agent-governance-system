"""
CAPABILITY/TESTBENCH/audit - Tests for root audit functionality.
"""
