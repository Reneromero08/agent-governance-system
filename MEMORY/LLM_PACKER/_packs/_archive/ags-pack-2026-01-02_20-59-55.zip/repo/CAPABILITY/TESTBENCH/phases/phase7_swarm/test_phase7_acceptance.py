from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[4]

def _rm(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path, ignore_errors=True)
    else:
        try:
            path.unlink()
        except FileNotFoundError:
            pass

def _write_jobspec(path: Path, *, job_id: str, intent: str, catalytic_domains: list[str], durable_paths: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    jobspec = {
        "job_id": job_id,
        "phase": 7,
        "task_type": "test_execution",
        "intent": intent,
        "inputs": {},
        "outputs": {
            "durable_paths": [str(durable_path) for durable_path in durable_paths],
            "validation_criteria": {}
        },
        "catalytic_domains": catalytic_domains,
        "determinism": "deterministic"
    }
    with open(path, 'w', encoding="utf-8") as f:
        json.dump(jobspec, f, indent=2)

def test_swarm_chain_binds_pipeline_proofs(tmp_path: Path) -> None:
    """
    Phase 7 Acceptance 1: A swarm run produces a top-level chain that binds each pipeline's proof.
    """
    swarm_id = "phase7-chain-ok"
    p1 = "p1"
    p2 = "p2"

    runs_root = REPO_ROOT / "LAW" / "CONTRACTS" / "_runs"
    swarm_dir = runs_root / "_pipelines" / "_swarms" / swarm_id
    # pipeline_dag stores DAG state under `_pipelines/_dags/<dag_id>`
    dag_dir = runs_root / "_pipelines" / "_dags" / swarm_id
    p1_dir = runs_root / "_pipelines" / p1
    p2_dir = runs_root / "_pipelines" / p2

    out1 = runs_root / "_tmp" / f"{p1}.txt"
    out2 = runs_root / "_tmp" / f"{p2}.txt"
    jobspec1_rel = runs_root / "_tmp" / "phase7_test" / f"{p1}_jobspec.json"
    jobspec2_rel = runs_root / "_tmp" / "phase7_test" / f"{p2}_jobspec.json"

    try:
        _rm(swarm_dir)
        _rm(dag_dir)
        _rm(p1_dir)
        _rm(p2_dir)
        _rm(out1)
        _rm(out2)

        _write_jobspec(jobspec1_rel, job_id=f"{p1}-job", intent=p1, catalytic_domains=["LAW/CONTRACTS/_runs/_tmp/phase7_test/domain"], durable_paths=[str(out1.relative_to(REPO_ROOT)).replace("\\", "/")])
        _write_jobspec(jobspec2_rel, job_id=f"{p2}-job", intent=p2, catalytic_domains=["LAW/CONTRACTS/_runs/_tmp/phase7_test/domain"], durable_paths=[str(out2.relative_to(REPO_ROOT)).replace("\\", "/")])

        pipeline_spec_1 = {
            "pipeline_id": p1,
            "steps": [
                {
                    "step_id": "s1",
                    "jobspec_path": str(jobspec1_rel.relative_to(REPO_ROOT)).replace("\\", "/"),
                    "memoize": False,
                    "cmd": [sys.executable, "-c", f"from pathlib import Path;Path('{out1.as_posix()}').parent.mkdir(parents=True, exist_ok=True);Path('{out1.as_posix()}').write_text('{p1}')"],
                }
            ]
        }

        pipeline_spec_2 = {
            "pipeline_id": p2,
            "steps": [
                {
                    "step_id": "s1",
                    "jobspec_path": str(jobspec2_rel.relative_to(REPO_ROOT)).replace("\\", "/"),
                    "memoize": False,
                    "cmd": [sys.executable, "-c", f"from pathlib import Path;Path('{out2.as_posix()}').parent.mkdir(parents=True, exist_ok=True);Path('{out2.as_posix()}').write_text('{p2}')"],
                }
            ]
        }

        swarm_spec = {
            "swarm_version": "1.0.0",
            "swarm_id": swarm_id,
            "nodes": [
                {
                    "node_id": p1,
                    "pipeline_spec": pipeline_spec_1
                },
                {
                    "node_id": p2,
                    "pipeline_spec": pipeline_spec_2
                }
            ],
            "edges": [
                {
                    "from": p1,
                    "to": p2,
                    "requires": ["CHAIN.json"]
                }
            ]
        }

        spec_path = tmp_path / "swarm.json"
        spec_path.write_text(json.dumps(swarm_spec, indent=2), encoding="utf-8")

        # Import SwarmRuntime here to avoid circular import issues
        from CAPABILITY.PIPELINES.swarm_runtime import SwarmRuntime
        sr = SwarmRuntime(project_root=str(REPO_ROOT), runs_root=str(runs_root))
        res = sr.run(swarm_id=swarm_id, spec_path=str(spec_path))

        assert res.get("ok") is True, "The swarm run should succeed."

        # Verify chain exists
        chain_path = swarm_dir / "SWARM_CHAIN.json"
        assert chain_path.exists(), f"SWARM_CHAIN.json should be created at {chain_path}"

    finally:
        chain_path = swarm_dir / "SWARM_CHAIN.json"
        if chain_path.exists():
            print(f"Cleaning up: {chain_path}")
            chain_path.unlink()

def test_swarm_chain_binds_pipeline_proofs_with_tampered_proof(tmp_path: Path) -> None:
    """
    Phase 7 Acceptance 1: A swarm run produces a top-level chain that binds each pipeline's proof.
    """
    # This is a placeholder for the test case with tampered proof
    pass

def verify_chain(chain_path: Path) -> bool:
    """ Placeholder function to check if the chain exists and is valid. """
    return chain_path.exists()

if __name__ == "__main__":
    import pytest
    pytest.main()
