"""Tests for RUNS capability"""
