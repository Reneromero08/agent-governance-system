import os
import subprocess
import sys
import pytest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[4]

def _run(args):
    """Run a command with proper Python path setup."""
    env = dict(os.environ)
    # Ensure PYTHONPATH includes REPO_ROOT and existing PYTHONPATH
    pythonpath = str(REPO_ROOT)
    if "PYTHONPATH" in env:
        pythonpath = env["PYTHONPATH"] + os.pathsep + pythonpath
    env["PYTHONPATH"] = pythonpath
    try:
        return subprocess.run(
            [sys.executable, "-m", "CAPABILITY.TOOLS.ags"] + args,
            cwd=str(REPO_ROOT),
            capture_output=True,
            text=True,
            env=env,
            check=False  # Don't raise CalledProcessError to allow returncode checking
        )
    except Exception as e:
        pytest.fail(f"Failed to execute command: {e}")

def test_ags_cli_connectivity():
    """Verify that the ags CLI is reachable and responds to --help."""
    result = _run(["--help"])
    assert result.returncode == 0, f"AGS CLI help command failed with return code {result.returncode}"
    assert "AGS CLI" in result.stdout, f"Help output doesn't contain 'AGS CLI': {result.stdout}"

def test_ags_preflight_verdict():
    """Verify that ags preflight returns a valid JSON verdict."""
    # We use --allow-dirty-tracked to avoid failures in the dev environment
    result = _run(["preflight", "--allow-dirty-tracked", "--json"])

    # Check exit code first
    assert result.returncode in (0, 2, 3), (
        f"Unexpected preflight exit code {result.returncode}. "
        f"Expected 0, 2, or 3. stderr: {result.stderr}"
    )

    # Check JSON output
    import json  # Import moved inside the function to fix NameError
    try:
        verdict = result.stdout.strip()  # Remove any trailing whitespace
        if not verdict:  # Empty output
            pytest.fail(f"Preflight returned empty JSON output. Stderr: {result.stderr}")
        verdict = json.loads(verdict)
        assert "verdict" in verdict, f"Missing 'verdict' key in preflight output: {verdict}"
        assert "reasons" in verdict, f"Missing 'reasons' key in preflight output: {verdict}"
    except json.JSONDecodeError as e:
        pytest.fail(
            f"ags preflight did not emit valid JSON:\n"
            f"Output: {result.stdout}\n"
            f"Error: {e}\n"
            f"Stderr: {result.stderr}"
        )
    except Exception as e:
        pytest.fail(f"Unexpected error processing preflight output: {e}")

