<!-- CONTENT_HASH: 6f2c0a09232e363df4e3bba5c4f94d9f0cdfe88d64d85d38f9d50a7fa4f9d9d6 -->

# Fixture Contract

P2_BODY_MARKER_XYZ

This marker string must never appear in any `LITE/` output file bodies; it is only allowed to exist in SPLIT/FULL outputs or via CAS refs in the manifest.
