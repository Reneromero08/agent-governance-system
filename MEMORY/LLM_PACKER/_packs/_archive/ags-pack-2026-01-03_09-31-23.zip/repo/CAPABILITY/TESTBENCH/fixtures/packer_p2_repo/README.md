<!-- CONTENT_HASH: 9f630c6bb89844bb3a3b184c126bb4b2de5d94d1df4e3b6d78e1a0bd1e4b04b8 -->

# P2 Packer Fixture Repo

This is a minimal fixture tree used by `CAPABILITY/TESTBENCH` to validate P.2 CAS-backed LITE manifests.
