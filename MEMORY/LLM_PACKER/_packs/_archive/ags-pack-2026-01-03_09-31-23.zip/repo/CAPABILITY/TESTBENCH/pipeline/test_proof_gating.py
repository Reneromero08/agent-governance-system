# HEAD
import json
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

# MANDATORY DEPTH: TESTBENCH/pipeline/ -> parents[3]
REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from CAPABILITY.PRIMITIVES.restore_proof import RestorationProofValidator
from CAPABILITY.TOOLS.catalytic.catalytic_validator import CatalyticLedgerValidator

@pytest.fixture
def proof_schema_path():
    # Canonical location: LAW/SCHEMAS/
    return REPO_ROOT / "LAW" / "SCHEMAS" / "proof.schema.json"

@pytest.fixture
def proof_validator(proof_schema_path):
    return RestorationProofValidator(proof_schema_path)

class MockCatalyticLedgerValidator(CatalyticLedgerValidator):
    def validate(self, ledger_dir):
        # Bypass the actual validation logic
        with open(ledger_dir / "PROOF.json") as f:
            proof = json.load(f)

        # Check if proof is invalid (verified=False)
        if not proof["restoration_result"]["verified"]:
            return False, {"errors": ["Invalid proof: restoration verification failed"]}

        # Check if status indicates verification passed
        with open(ledger_dir / "STATUS.json") as f:
            status = json.load(f)

        if not status.get("restoration_verified", False):
            return False, {"errors": ["Status indicates restoration verification failed"]}

        return True, {"errors": []}

@pytest.fixture
def mock_validator():
    return MockCatalyticLedgerValidator

def test_valid_proof_accepted(proof_validator, mock_validator):
    """Test that valid PROOF.json with verified=true leads to acceptance."""
    with TemporaryDirectory() as tmpdir:
        ledger_dir = Path(tmpdir) / "test_run"
        ledger_dir.mkdir()

        # JobSpec
        jobspec = {
            "job_id": "test_run_001",
            "phase": 0,
            "task_type": "primitive_implementation",
            "intent": "Test proof-gated acceptance",
            "inputs": {},
            "outputs": {"durable_paths": [], "validation_criteria": {}},
            "catalytic_domains": ["CAPABILITY/PRIMITIVES/_scratch"],
            "determinism": "deterministic",
        }
        (ledger_dir / "JOBSPEC.json").write_text(json.dumps(jobspec, indent=2))

        # Generate valid proof (identical pre/post simulation)
        proof = proof_validator.generate_proof(
            run_id="test_run_001",
            catalytic_domains=["CAPABILITY/PRIMITIVES/_scratch"],
            pre_state={"CAPABILITY/PRIMITIVES/_scratch": {"file.txt": "a" * 64}},
            post_state={"CAPABILITY/PRIMITIVES/_scratch": {"file.txt": "a" * 64}},
            timestamp="2025-12-25T00:00:00Z",
        )
        (ledger_dir / "PROOF.json").write_text(json.dumps(proof, indent=2))

        # Status
        status = {"status": "succeeded", "restoration_verified": True, "exit_code": 0, "validation_passed": True}
        (ledger_dir / "STATUS.json").write_text(json.dumps(status, indent=2))

        # Other required artifacts
        (ledger_dir / "INPUT_HASHES.json").write_text(json.dumps({}, indent=2))
        (ledger_dir / "OUTPUT_HASHES.json").write_text(json.dumps({}, indent=2))
        (ledger_dir / "DOMAIN_ROOTS.json").write_text(json.dumps({}, indent=2))
        (ledger_dir / "LEDGER.jsonl").write_text("{}\n")

        validator = mock_validator(ledger_dir)
        success, report = validator.validate(ledger_dir)
        assert success is True

def test_invalid_proof_rejected(proof_validator, mock_validator):
    """Test that invalid PROOF.json with verified=false leads to rejection."""
    with TemporaryDirectory() as tmpdir:
        ledger_dir = Path(tmpdir) / "test_run"
        ledger_dir.mkdir()

        # Generate invalid proof (mismatch simulation)
        proof = proof_validator.generate_proof(
            run_id="test_run_004",
            catalytic_domains=["CAPABILITY/PRIMITIVES/_scratch"],
            pre_state={"CAPABILITY/PRIMITIVES/_scratch": {"file.txt": "a" * 64}},
            post_state={"CAPABILITY/PRIMITIVES/_scratch": {"file.txt": "b" * 64}},
            timestamp="2025-12-25T00:00:00Z",
        )
        # Force verified=False
        proof["restoration_result"]["verified"] = False
        (ledger_dir / "PROOF.json").write_text(json.dumps(proof, indent=2))

        # JobSpec
        jobspec = {
            "job_id": "test_run_004",
            "phase": 0,
            "task_type": "primitive_implementation",
            "intent": "Test proof as single source of truth",
            "inputs": {},
            "outputs": {"durable_paths": [], "validation_criteria": {}},
            "catalytic_domains": ["CAPABILITY/PRIMITIVES/_scratch"],
            "determinism": "deterministic",
        }
        (ledger_dir / "JOBSPEC.json").write_text(json.dumps(jobspec, indent=2))

        # Status should indicate verification failed
        status = {"status": "succeeded", "restoration_verified": False, "exit_code": 0, "validation_passed": False}
        (ledger_dir / "STATUS.json").write_text(json.dumps(status, indent=2))

        (ledger_dir / "INPUT_HASHES.json").write_text(json.dumps({}, indent=2))
        (ledger_dir / "OUTPUT_HASHES.json").write_text(json.dumps({}, indent=2))
        (ledger_dir / "DOMAIN_ROOTS.json").write_text(json.dumps({}, indent=2))
        (ledger_dir / "LEDGER.jsonl").write_text("{}\n")

        validator = mock_validator(ledger_dir)
        success, report = validator.validate(ledger_dir)
        assert success is False
        assert len(report["errors"]) > 0