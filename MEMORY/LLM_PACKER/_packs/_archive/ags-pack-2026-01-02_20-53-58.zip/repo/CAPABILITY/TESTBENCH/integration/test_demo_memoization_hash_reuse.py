from __future__ import annotations

import json
import pytest
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[3]
DEMO_ROOT = REPO_ROOT / "LAW" / "CONTRACTS" / "_runs" / "_demos" / "memoization_hash_reuse"

def test_phase2_demo_artifacts_are_falsifiable() -> None:
    baseline = DEMO_ROOT / "baseline"
    reuse = DEMO_ROOT / "reuse"

    assert (baseline / "PROOF.json").exists()
    assert (baseline / "LEDGER.jsonl").exists()
    assert (baseline / "DEREF_STATS.json").exists()

    assert (reuse / "PROOF.json").exists()
    assert (reuse / "LEDGER.jsonl").exists()
    assert (reuse / "DEREF_STATS.json").exists()

    # Proof identity: byte-identical.
    with open(baseline / "PROOF.json", 'rb') as f:
        b_proof = f.read()
    with open(reuse / "PROOF.json", 'rb') as f:
        r_proof = f.read()
    assert b_proof == r_proof

    # Memoization hit must be observable.
    with open(reuse / "LEDGER.jsonl", 'r', encoding="utf-8") as f:
        ledger_text = f.read()
    assert "memoization:hit" in ledger_text

    # Hash-first dereference must be measurably smaller (bytes read) in reuse.
    with open(baseline / "DEREF_STATS.json", 'r', encoding="utf-8") as f:
        b_deref_stats = json.load(f)
    with open(reuse / "DEREF_STATS.json", 'r', encoding="utf-8") as f:
        r_deref_stats = json.load(f)

    assert b_deref_stats["deref_count"] >= r_deref_stats["deref_count"]
    assert b_deref_stats["bytes_read_total"] > r_deref_stats["bytes_read_total"]