<!-- CONTENT_HASH: GENERATED -->

# B

This is document B.

