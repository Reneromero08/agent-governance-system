# AGS Pack Index

This directory contains a generated snapshot of the repository intended for LLM handoff.

## Read order
1) `repo/AGENTS.md`
2) `repo/README.md`
3) `repo/LAW/CANON/CONTRACT.md` and `repo/LAW/CANON/INVARIANTS.md` and `repo/LAW/CANON/VERSIONING.md`
4) `repo/NAVIGATION/MAPS/ENTRYPOINTS.md`
5) `repo/LAW/CONTRACTS/runner.py` and `repo/CAPABILITY/SKILLS/`
6) `repo/NAVIGATION/CORTEX/` and `repo/CAPABILITY/TOOLS/`
7) `meta/ENTRYPOINTS.md` and `meta/PACK_INFO.json` (Snapshot specific)

## Notes
- `BUILD` contents are excluded.
- Single-file bundles available in `FULL/`.
