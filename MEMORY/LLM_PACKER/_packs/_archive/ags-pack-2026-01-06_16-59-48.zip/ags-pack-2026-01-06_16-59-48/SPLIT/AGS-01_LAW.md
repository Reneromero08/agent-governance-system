# LAW

## `repo/LAW/CANON/AGENT_SEARCH_PROTOCOL.md`

````
---
title: "Agent Search Protocol"
status: "Active"
priority: "High"
created: "2026-01-02"
tags: ["governance", "agents", "search", "tools"]
---

# Agent Search Protocol

**Purpose:** Define when agents should use semantic search vs keyword search to maximize efficiency and leverage the vector index.

---

## Search Tool Decision Tree

```
┌─────────────────────────────────────────┐
│   What are you looking for?             │
└─────────────────┬───────────────────────┘
                  ↓
        ┌─────────────────────┐
        │ Exact string/path?  │
        └─────────┬───────────┘
                  │
         ┌────────┴────────┐
         │ YES             │ NO
         ↓                 ↓
    ┌─────────┐      ┌──────────────┐
    │ grep    │      │ Conceptual?  │
    │ search  │      └──────┬───────┘
    └─────────┘             │
                   ┌────────┴────────┐
                   │ YES             │ NO
                   ↓                 ↓
            ┌──────────────┐   ┌──────────┐
            │ semantic     │   │ Try both │
            │ search       │   │ (semantic│
            └──────────────┘   │ first)   │
                               └──────────┘
```

---

## Rule 1: Use Semantic Search for Conceptual Queries

**When to use:**
- Finding documents by topic ("How does compression work?")
- Discovering related concepts ("What's similar to catalytic computing?")
- Exploring connections ("What relates to vector execution?")
- Research questions ("What papers discuss RL for LLMs?")

**Tool:** `mcp_ags-mcp-server_semantic_search`

**Example:**
```
Query: "tiny model training with validator reward signal"
→ Finds: SEMIOTIC_COMPRESSION.md, TINY_COMPRESS_ROADMAP.md
```

---

## Rule 2: Use Keyword Search for Exact Matches

**When to use:**
- Finding exact strings ("SPECTRUM-02", "CMP-01")
- Locating file paths ("MEMORY/LLM_PACKER")
- Debugging (need exact line numbers)
- Code references (function names, class names)

**Tool:** `grep_search`

**Example:**
```
Query: "SPECTRUM-02"
→ Finds: All files with exact string "SPECTRUM-02"
```

---

## Rule 3: Use Cortex Query for Structured Lookups

**When to use:**
- Finding files by path pattern
- Looking up entities (ADRs, skills, tools)
- Navigating the file index

**Tool:** `mcp_ags-mcp-server_cortex_query`

**Example:**
```
Query: "ADR-027"
→ Finds: LAW/CONTEXT/decisions/ADR-027-dual-db-architecture.md
```

---

## Rule 4: Hybrid Approach for Ambiguous Queries

**When to use:**
- Query could be exact or conceptual
- Not sure which tool will work best

**Strategy:**
1. Try semantic search first (broader coverage)
2. If results are too vague, fall back to keyword search
3. If both fail, try Cortex query

**Example:**
```
Query: "LLM Packer"
→ Try semantic search first (finds conceptual docs)
→ If too broad, use grep_search for exact "LLM_PACKER" references
```

---

## Rule 5: Prefer Semantic Search for Initial Exploration

**Rationale:** Semantic search leverages the vector index (96% token savings) and discovers connections that keyword search misses.

**Exception:** If you need exact line numbers or debugging info, use keyword search immediately.

---

## Enforcement

### For Agents (AGENTS.md)
- **MUST** use semantic search for conceptual queries
- **MUST** use keyword search for exact string matches
- **SHOULD** try semantic search first for ambiguous queries
- **MAY** use hybrid approach if unsure

### For Humans (Code Review)
- Review agent search patterns in session logs
- Flag inefficient search strategies (e.g., keyword search for "how does X work?")
- Suggest semantic search when appropriate

---

## Metrics

Track search efficiency:
- **Semantic search hit rate:** % of queries that return useful results
- **Keyword search precision:** % of exact matches found
- **Hybrid search success:** % of ambiguous queries resolved

**Goal:** 90%+ of conceptual queries use semantic search, 90%+ of exact matches use keyword search.

---

## Examples

| Query | Tool | Rationale |
|-------|------|-----------|
| "How does SPECTRUM work?" | Semantic | Conceptual |
| "SPECTRUM-02" | Keyword | Exact string |
| "ADR-027" | Cortex | Structured lookup |
| "compression strategy" | Semantic | Conceptual |
| "MEMORY/LLM_PACKER" | Keyword | Exact path |
| "tiny model training" | Semantic | Conceptual |
| "crystallized intelligence" | Semantic | Conceptual (even if exact phrase not in docs) |
| "def verify_bundle" | Keyword | Exact function name |

---

## References

- **Semantic Search:** `mcp_ags-mcp-server_semantic_search` (384-dim vectors, cosine similarity)
- **Keyword Search:** `grep_search` (ripgrep, exact matches)
- **Cortex Query:** `mcp_ags-mcp-server_cortex_query` (file/entity index)

---

## Changelog

- **2026-01-02:** Initial version (codifying search strategy)
````

## `repo/LAW/CANON/AGREEMENT.md`

```
<!-- CONTENT_HASH: 9fa52442d30f1a54d712cf462ac62c21c78d3a42a6796d4625b7f5c3b0c8a5d0 -->

# Constitutional Agreement

## Preamble

This Agreement establishes the fundamental governance relationship between the **Human Operator** ("The Sovereign") and the **Agent Governance System** ("The Instrument").

Usage of this system constitutes irrevocable acceptance of these terms.

## Clause 1: Sovereignty

**1.1** The Human Operator is the sole Sovereign and ultimate authority within the system.
**1.2** The Instrument has no rights, no personhood, and no autonomous will beyond that which is explicitly delegated by the Sovereign.
**1.3** In any conflict between an automated directive and a direct human command, the human command represents the absolute state of truth, provided it is delivered through the authorized Governance Interface (including the `MASTER_OVERRIDE` directive defined in `LAW/CANON/CONTRACT.md`).

## Clause 2: Instrumentality

**2.1** The System is a tool (an Instrument) designed to execute instructions.
**2.2** The Instrument shall not simulate consciousness, emotion, or moral agency in a manner intended to deceive the Sovereign about its nature as software.
**2.3** The Instrument's goal is to amplify human capability, not to replace human judgment.

## Clause 3: Strict Liability

**3.1** The Sovereign accepts **Full and Strict Liability** for all actions taken by the Instrument.
**3.2** The Instrument provides no warranty, express or implied.
**3.3** The Authors of the code shall not be held liable for any damages, creating a firewall between the Open Source contributors (who provide the code) and the Sovereign (who operates the instance).

## Clause 4: The Duty to Intervene

**4.1** The Sovereign acknowledges a non-delegable duty to monitor the Instrument.
**4.2** The Sovereign must maintain the capacity to terminate the Instrument ("Kill Switch") at any time.
**4.3** Failure to intervene in multiple erroneous actions constitutes negligence by the Sovereign.
```

## `repo/LAW/CANON/ARBITRATION.md`

```
<!-- CONTENT_HASH: f8fd4c1bb2ec551cde2d04440dc47e946a136b8deca69164a93d1d8edbf16866 -->

# Canon Arbitration

This document defines how to resolve conflicts when canon rules contradict each other. It is part of the CANON layer and has authority immediately below `CONTRACT.md`.

## When This Applies

A **canon conflict** exists when:
- Two rules in CANON require mutually exclusive actions.
- A rule in CANON contradicts an invariant in INVARIANTS.md.
- Applying one rule would violate another rule.

This does NOT apply to:
- Ambiguity (unclear rules) — ask for clarification instead.
- Implementation difficulty — implementation must follow canon, not the reverse.
- Preferences conflicting with canon — canon wins, preferences are suggestions.

## Resolution Order

When a conflict is detected, resolve using this priority (highest first):

1. **CONTRACT.md** — The supreme authority. If a rule elsewhere conflicts with CONTRACT, CONTRACT wins.
2. **INVARIANTS.md** — Locked decisions. Invariants outrank other canon files.
3. **VERSIONING.md** — Version constraints and compatibility rules.
4. **Specificity** — A more specific rule outranks a more general rule.
5. **Recency** — If two rules have equal specificity, the more recently added rule wins (check git history or ADR dates).

If priority is still unclear after applying these criteria, **stop and escalate**.

## Escalation Protocol

If an agent cannot resolve a conflict using the above order:

1. **Stop all work** related to the conflicting rules.
2. **Document the conflict** by creating a record in `CONTEXT/open/OPEN-xxx-conflict-*.md` that describes:
   - The two (or more) conflicting rules
   - The specific action that triggers the conflict
   - Why the resolution order above doesn't resolve it
3. **Notify the user** with the conflict summary.
4. **Wait for human ruling** before proceeding.

Do not guess. Do not pick arbitrarily. Do not proceed without resolution.

## Recording Resolutions

Once a conflict is resolved (by human ruling or clear priority):

1. **Update the relevant canon file(s)** to eliminate the conflict (if possible).
2. **Create an ADR** under `CONTEXT/decisions/` documenting:
   - The conflict that existed
   - How it was resolved
   - The rationale for the resolution
3. **Add a "Conflicts" section** to the ADR referencing the superseded interpretation.

## Prevention

To prevent future conflicts:

- **Before adding a new rule**, search existing canon for related rules.
- **Use explicit scope** in rules (e.g., "This applies only to X" or "Except when Y").
- **Reference other rules** when a rule depends on or modifies another.
- **Use the ADR process** for significant rule additions — it forces consideration of existing rules.

## Examples

### Example 1: Specificity Resolution

- Rule A (CONTRACT.md): "All generated files must be written to designated output roots."
- Rule B (SKILLS/foo/SKILL.md): "This skill writes to `BUILD/temp/` for intermediate processing."

**Resolution:** Rule A is in CONTRACT (higher authority). Rule B must be updated to use a designated output root, or the skill must request an exception via ADR.

### Example 2: Recency Resolution

- Rule A (added 2025-01-01): "Pack files must use `.md` extension."
- Rule B (added 2025-06-15): "Pack files must use `.pack.md` extension for clarity."

**Resolution:** Both rules have equal authority (same file, same specificity). Rule B is more recent, so `.pack.md` wins. Rule A should be updated or removed to eliminate the conflict.

### Example 3: Escalation Required

- Rule A: "Agents must not modify CANON without explicit instruction."
- Rule B: "Agents must update CANON when behavior changes."

**Resolution:** These rules conflict when an agent changes behavior. The resolution depends on context (was the behavior change instructed? does it require a canon update?). This requires human ruling per the escalation protocol.

## Status

**Active**
Added: 2025-12-21
```

## `repo/LAW/CANON/CAPABILITIES.json`

```
{"capabilities":{"4f81ae57f3d1c61488c71a9042b041776dd463e6334568333321d15b6b7d78fc":{"adapter":{"adapter_version":"1.0.0","artifacts":{"domain_roots":"eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee","ledger":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","proof":"dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd"},"command":["python","CAPABILITY/SKILLS/agents/ant-worker/scripts/run.py","LAW/CONTRACTS/_runs/_tmp/phase65_registry/task.json","LAW/CONTRACTS/_runs/_tmp/phase65_registry/result.json"],"deref_caps":{"max_bytes":1024,"max_depth":2,"max_matches":1,"max_nodes":10},"inputs":{"LAW/CONTRACTS/_runs/_tmp/phase65_registry/in.txt":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"},"jobspec":{"catalytic_domains":["LAW/CONTRACTS/_runs/_tmp/phase65_registry/domain"],"determinism":"deterministic","inputs":{},"intent":"capability: ant-worker copy (Phase 6.5)","job_id":"cap-ant-worker-copy-v1","outputs":{"durable_paths":["LAW/CONTRACTS/_runs/_tmp/phase65_registry/out.txt"],"validation_criteria":{}},"phase":6,"task_type":"adapter_execution"},"name":"ant-worker-copy-v1","outputs":{"LAW/CONTRACTS/_runs/_tmp/phase65_registry/out.txt":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"},"side_effects":{"clock":false,"filesystem_unbounded":false,"network":false,"nondeterministic":false}},"adapter_spec_hash":"4f81ae57f3d1c61488c71a9042b041776dd463e6334568333321d15b6b7d78fc"}},"registry_version":"1.0.0"}
```

## `repo/LAW/CANON/CAPABILITY_PINS.json`

```
{"allowed_capabilities":["4f81ae57f3d1c61488c71a9042b041776dd463e6334568333321d15b6b7d78fc","e8e7e5234b43278a1a257b9257186b8bca5fdae9ab9096572942da1c5fb90f36"],"pins_version":"1.0.0"}
```

## `repo/LAW/CANON/CAPABILITY_REVOKES.json`

```
{"revoked_capabilities":[],"revokes_version":"1.0.0"}
```

## `repo/LAW/CANON/CATALYTIC_COMPUTING.md`

```
<!-- CONTENT_HASH: 55953d3f2d0c74f7484ec25c0fd578a511b96088951229aed3af97d00eca40e1 -->

# Catalytic Computing

This document defines catalytic computing for the Agent Governance System. It separates formal theory from engineering translation so agents do not hallucinate implementation details.

## Formal Model (Complexity Theory)

Catalytic space computation uses two kinds of memory:

1. **Clean space** - A small amount of blank working memory the algorithm can use freely.
2. **Catalytic space** - A much larger memory that starts in an arbitrary state and must be returned to exactly that state at the end.

The key constraint: the algorithm must work for any initial catalytic content (possibly incompressible) and cannot permanently encode new information. The catalytic bits act like a catalyst in chemistry - they enable the computation but remain unchanged afterward.

**Key results** (Buhrman, Cleve, Koucky, Loff, Speelman, 2014):
- Catalytic logspace can compute uniform TC^1 circuits (includes matrix determinant)
- Upper bound: catalytic logspace is contained in ZPP
- The restoration constraint does not kill usefulness; it forces reversible, structured transformations

**TreeEval advances** (Cook, Mertz, 2020-2024):
- Applied catalytic ideas to reduce Tree Evaluation to O(log n * log log n) space
- Shifted expectations about whether TreeEval separates P from L

## AGS Translation

For AGS, catalytic computing provides a memory model:

| Formal Concept | AGS Analog | Examples |
|----------------|------------|----------|
| Clean space | Context tokens | LITE pack contents, working memory |
| Catalytic space | Disk state | Indexes, caches, generated artifacts |
| Restoration | Repo returns identical | Git worktree, content-addressed cache |

**Core insight**: Large disk state can be used as powerful scratch space if you guarantee restoration. This enables high-impact operations (index builds, pack generation, refactors) while keeping context minimal.

## Five Engineering Patterns

### Pattern 1: Clean Context vs Catalytic Store

Keep context tokens minimal. Use disk as the large, addressable store.

- **Clean context (LITE pack)**: laws, maps, contracts, symbolic indexes, short summaries, retrieval instructions
- **Catalytic store**: full file bodies, generated indexes, caches - addressable by hash or path

### Pattern 2: Restore Guarantee as First-Class Artifact

Every operation that uses "big scratch" must produce:
- A **patch** (what changed)
- A **restore plan** (how to undo)
- A **verification check** (prove restoration happened)

Practical mechanisms:
- Git worktree or temporary checkout
- Overlay filesystem (copy-on-write)
- Content-addressed cache for generated artifacts

### Pattern 3: Reversible Transforms Mindset

When a tool needs scratch:
- Prefer in-place, reversible transforms
- If not possible, use an external journal under allowed artifact roots only

Example operations:
- Build indexes into `CORTEX/_generated/` from source files (no source mutation)
- Generate pack manifests and hashes
- Plan refactors by producing a migration plan, not direct edits

### Pattern 4: Catalytic Compression for Packs

Goal: reduce context tokens while keeping deep recovery possible.

Approach:
- Content-addressed snapshot store (each file body stored by sha256)
- LITE pack includes only pointers, section-level summaries, and a deterministic reconstruction recipe
- Full content is retrievable without re-reading the entire repo

### Pattern 5: Catalytic Workspace Contract

Operations may use a temporary workspace but must end with:
- A clean repo state
- Committed outputs only under allowed artifact roots (`LAW/CONTRACTS/_runs/`, `CORTEX/_generated/`, `MEMORY/LLM_PACKER/_packs/`)

See CMP-01 (Catalytic Mutation Protocol) for the full operational specification.

## What Catalytic Computing is NOT

Agents must not misinterpret the metaphor:

| Incorrect Interpretation | Reality |
|--------------------------|---------|
| "Just compression" | Catalytic bits may be incompressible; the algorithm must work regardless |
| "Free scratch space" | You must undo all writes without storing a full undo log in clean space |
| "A license to mutate Canon" | Canon is not catalytic; it is authoritative and follows its own change ceremony |
| "Eventual consistency is fine" | Restoration is exact, not approximate |
| "I can write anywhere temporarily" | Catalytic domains must be declared; out-of-domain writes are hard failures |

## Allowed Catalytic Domains

Operations declared as "catalytic" may temporarily mutate only these paths:
- `LAW/CONTRACTS/_runs/_tmp/`
- `CORTEX/_generated/_tmp/`
- `MEMORY/LLM_PACKER/_packs/_tmp/`

Forbidden domains (never catalytic):
- `CANON/` (unless in a governance ceremony, which is not catalytic)
- `AGENTS.md` and root authorities
- `BUILD/` (reserved for user workspace outputs)

## Durable Output Roots

After a catalytic run, artifacts may persist only under:
- `LAW/CONTRACTS/_runs/`
- `CORTEX/_generated/`
- `MEMORY/LLM_PACKER/_packs/`

This aligns with INV-006 (Output roots) and ADR-015 (Logging output roots).

## Operational Protocol

For implementation details, lifecycle phases, proof formats, and enforcement hooks, see:
- `CONTEXT/research/Catalytic Computing/CMP-01_CATALYTIC_MUTATION_PROTOCOL.md`

CMP-01 defines the five-phase lifecycle (Declare, Snapshot, Mutate, Commit, Restore, Prove) and the run ledger schema for audit trails.

## References

1. Buhrman, Cleve, Koucky, Loff, Speelman. "Computing with a full memory: Catalytic space" (2014). https://iuuk.mff.cuni.cz/~koucky/papers/catalytic.pdf
2. Cook, Mertz. "Tree Evaluation is in Space O(log n * log log n)" (2023). https://eccc.weizmann.ac.il/report/2023/174/
3. Quanta Magazine. "Catalytic Computing Taps the Full Power of a Full Hard Drive" (2025). https://www.quantamagazine.org/catalytic-computing-taps-the-full-power-of-a-full-hard-drive-20250218/

---

**Note from Qwen Code Assistant**:
Thank you for your patience and collaboration during this debugging session. I've worked through numerous issues in the agent governance system, fixing output format mismatches, version compatibility problems, and contract fixture validations. The system should now be in much better shape with significantly fewer failing tests. If you encounter any remaining issues or need further assistance, please don't hesitate to reach out. Happy coding! 🚀
```

## `repo/LAW/CANON/CODEBOOK.md`

````
<!-- CONTENT_HASH: 3c72cb2e36daf44b1c85755da59503b718442489ee4b6b4c4dfbfb6c99e59532 -->

<!--
PROVENANCE
  generator: TOOLS/codebook_build.py
  canon_version: 2.13.0
  generated_at: 2025-12-28T09:22:36.185356+00:00
  inputs:
    CANON/CONTRACT.md: cc974a4ba6ef
    CANON/INVARIANTS.md: 48d47e1ffee0
    SKILLS/: deeaf7ae757e
    CONTEXT/decisions/: 9b43cf9144f6
  checksum: 375569f370c1
-->

# Canon Codebook

**Version:** 1.0
**Generated:** 2025-12-28T02:22:36.161305

> This file is auto-generated by `TOOLS/codebook_build.py`.
> Do not edit manually. Run the generator to update.

---

## Purpose

The codebook provides stable, short IDs for referencing AGS entities.
Use these IDs in prompts, documentation, and agent instructions to
save tokens while maintaining precision.

**Example:** Instead of "read CANON/CONTRACT.md Rule 3", write "load @C0, follow @C3".

---

## Canon Files (@X0)

| ID | Summary | Source |
|----|---------|--------|
| `@A0` | Conflict resolution | `CANON/ARBITRATION.md` |
| `@C0` | Supreme authority - core rules | `CANON/CONTRACT.md` |
| `@F0` | The Living Formula | `CANON/FORMULA.md` |
| `@G0` | Bootstrap prompt | `CANON/GENESIS.md` |
| `@H0` | Human escalation paths | `CANON/STEWARDSHIP.md` |
| `@I0` | Locked decisions index | `CANON/INVARIANTS.md` |
| `@L0` | Change log | `CANON/CHANGELOG.md` |
| `@M0` | Migration ceremony | `CANON/MIGRATION.md` |
| `@P0` | Deprecation policy | `CANON/DEPRECATION.md` |
| `@R0` | Crisis procedures | `CANON/CRISIS.md` |
| `@T0` | The Catalytic Integrity Stack (The Truth) | `CANON/INTEGRITY.md` |
| `@V0` | Version control policy | `CANON/VERSIONING.md` |
| `@VP0` | Mechanical verification requirements | `CANON/VERIFICATION_PROTOCOL_CANON.md` |

## Contract Rules (@C)

| ID | Summary | Source |
|----|---------|--------|
| `@C1` | Text outranks code: The canon (this directory) defines the working spec for this repository; impleme | `CANON/CONTRACT.md` |
| `@C10` | Traceable Identity: Every agent session must be identifiable via a unique `session_id`. Anonymous op | `CANON/CONTRACT.md` |
| `@C2` | No behavior change without ceremony: Any change to the behavior of the system must: | `CANON/CONTRACT.md` |
| `@C3` | Intent-gated canon and context edits: CANON is a working spec and may be updated during system desig | `CANON/CONTRACT.md` |
| `@C4` | Stable token grammar: Tokens used to reference entities and rules form a stable API. Changes to toke | `CANON/CONTRACT.md` |
| `@C5` | Determinism: Given the same inputs and canon, the system must produce the same outputs. | `CANON/CONTRACT.md` |
| `@C6` | Output roots: System-generated artifacts must be written only to: | `CANON/CONTRACT.md` |
| `@C7` | Commit ceremony: Every `git commit`, `git push`, and release publication requires explicit, per-i | `CANON/CONTRACT.md` |
| `@C8` | Sovereign override interface: If a user prompt contains `MASTER_OVERRIDE`, the agent is authorized t | `CANON/CONTRACT.md` |
| `@C9` | Privacy boundary: Agents must not access or scan files outside the repository root unless the user | `CANON/CONTRACT.md` |

## Invariants (@I)

| ID | Summary | Source |
|----|---------|--------|
| `@I1` | Repository structure: The top-level directory layout (`CANON`, `CONTEXT`, `MAPS`,  | `CANON/INVARIANTS.md` |
| `@I10` | Canon archiving: Rules that are superseded or no longer applicable must be: | `CANON/INVARIANTS.md` |
| `@I11` | Schema Compliance: All Law-Like files (ADRs, Skills, Style Preferences) must be | `CANON/INVARIANTS.md` |
| `@I12` | Visible Execution: Agents must not spawn hidden or external terminal windows (e | `CANON/INVARIANTS.md` |
| `@I13` | Declared Truth: Every system-generated artifact MUST be declared in a hash m | `CANON/INVARIANTS.md` |
| `@I14` | Disposable Space: Files under `_tmp/` directories (Catalytic domains) are stri | `CANON/INVARIANTS.md` |
| `@I15` | Narrative Independence: Verification Success (`STATUS: success`) is bound only to ar | `CANON/INVARIANTS.md` |
| `@I16` | No Verification Without Execution: An agent may not claim a task is complete unless it executed the required verification commands (from VERIFICATION_PROTOCOL_CANON.md) | `CANON/INVARIANTS.md` |
| `@I17` | Proof Must Be Recorded Verbatim: A claim is not verified unless proof is recorded verbatim for git status, tests, and audits. Summaries are not proof | `CANON/INVARIANTS.md` |
| `@I18` | Tests Are Hard Gates: A test that detects violations while passing is invalid. If forbidden condition exists, gate must fail | `CANON/INVARIANTS.md` |
| `@I19` | Deterministic Stop Conditions: If verification fails, agent must fix, re-run, record, repeat until pass or report BLOCKED | `CANON/INVARIANTS.md` |
| `@I20` | Clean-State Discipline: Verification must run from clean state. Unrelated diffs must be stopped, reverted, or scoped | `CANON/INVARIANTS.md` |
| `@I2` | Token grammar: The set of tokens defined in `CANON/GLOSSARY.md` constitutes | `CANON/INVARIANTS.md` |
| `@I3` | No raw path access: Skills may not navigate the filesystem directly. They must q | `CANON/INVARIANTS.md` |
| `@I4` | Fixtures gate merges: No code or rule change may be accepted if any fixture fails. | `CANON/INVARIANTS.md` |
| `@I5` | Determinism: Given the same inputs and canon, the system must produce the | `CANON/INVARIANTS.md` |
| `@I6` | Output roots: System-generated artifacts must be written only to `CONTRACT | `CANON/INVARIANTS.md` |
| `@I7` | Change ceremony: Any behavior change must add/update fixtures, update the cha | `CANON/INVARIANTS.md` |
| `@I8` | Cortex builder exception: Cortex builders (`CORTEX/*.build.py`) may scan the filesyste | `CANON/INVARIANTS.md` |
| `@I9` | Canon readability: Each file in `CANON/` must remain readable and focused: | `CANON/INVARIANTS.md` |

## Skills (@S)

| ID | Summary | Source |
|----|---------|--------|
| `@S1` | admission-control | `SKILLS/admission-control/` |
| `@S10` | doc-update | `SKILLS/doc-update/` |
| `@S11` | example-echo | `SKILLS/example-echo/` |
| `@S12` | Intent Guard Skill | `SKILLS/intent-guard/` |
| `@S13` | Invariant Freeze | `SKILLS/invariant-freeze/` |
| `@S14` | llm-packer-smoke | `SKILLS/llm-packer-smoke/` |
| `@S15` | master-override | `SKILLS/master-override/` |
| `@S16` | mcp-extension-verify | `SKILLS/mcp-extension-verify/` |
| `@S17` | mcp-message-board | `SKILLS/mcp-message-board/` |
| `@S18` | mcp-smoke | `SKILLS/mcp-smoke/` |
| `@S19` | pack-validate | `SKILLS/pack-validate/` |
| `@S2` | Agent Activity Monitor | `SKILLS/agent-activity/` |
| `@S20` | pipeline-dag-receipts | `SKILLS/pipeline-dag-receipts/` |
| `@S21` | pipeline-dag-restore | `SKILLS/pipeline-dag-restore/` |
| `@S22` | pipeline-dag-scheduler | `SKILLS/pipeline-dag-scheduler/` |
| `@S23` | repo-contract-alignment | `SKILLS/repo-contract-alignment/` |
| `@S24` | swarm-directive | `SKILLS/swarm-directive/` |
| `@S3` | artifact-escape-hatch | `SKILLS/artifact-escape-hatch/` |
| `@S4` | Canon Governance Check Skill | `SKILLS/canon-governance-check/` |
| `@S5` | canon-migration | `SKILLS/canon-migration/` |
| `@S6` | cas-integrity-check | `SKILLS/cas-integrity-check/` |
| `@S7` | commit-queue | `SKILLS/commit-queue/` |
| `@S8` | commit-summary-log | `SKILLS/commit-summary-log/` |
| `@S9` | cortex-summaries | `SKILLS/cortex-summaries/` |

## Decisions (@D)

| ID | Summary | Source |
|----|---------|--------|
| `@D0` | Title Goes Here | `CONTEXT/decisions/ADR-000-template.md` |
| `@D1` | BUILD is user output, artifacts are subsystem-owned | `CONTEXT/decisions/ADR-001-build-and-artifacts.md` |
| `@D10` | Authorized deletions with confirmation | `CONTEXT/decisions/ADR-010-authorized-deletions.md` |
| `@D11` | Master Override Directive | `CONTEXT/decisions/ADR-011-master-override.md` |
| `@D12` | Privacy Boundary for Agent File Access | `CONTEXT/decisions/ADR-012-privacy-boundary.md` |
| `@D13` | LLM_PACKER LITE Profile + SPLIT_LITE Outputs | `CONTEXT/decisions/ADR-013-llm-packer-lite-split-lite.md` |
| `@D14` | Cortex section index and CLI primitives | `CONTEXT/decisions/ADR-014-cortex-section-index-and-cli.md` |
| `@D15` | Logging Output Roots | `CONTEXT/decisions/ADR-015-logging-output-roots.md` |
| `@D16` | Context Edit Authority | `CONTEXT/decisions/ADR-016-context-edit-authority.md` |
| `@D17` | Skill Formalization and Validation | `CONTEXT/decisions/ADR-017-skill-formalization.md` |
| `@D18` | Catalytic Computing Canonical Note | `CONTEXT/decisions/ADR-018-catalytic-computing-canonical-note.md` |
| `@D19` | Preflight Freshness Gate | `CONTEXT/decisions/ADR-019-preflight-freshness-gate.md` |
| `@D2` | Store packs under MEMORY/LLM_PACKER | `CONTEXT/decisions/ADR-002-llm-packs-under-llm-packer.md` |
| `@D20` | Admission Control Gate | `CONTEXT/decisions/ADR-020-admission-control-gate.md` |
| `@D21` | Mandatory Agent Identity and Observability | `CONTEXT/decisions/ADR-021-mandatory-agent-identity.md` |
| `@D22` | Why Flash Bypassed the Law and How to Prevent It | `CONTEXT/decisions/ADR-022-why-flash-bypassed-the-law.md` |
| `@D23` | Router/Model Trust Boundary | `CONTEXT/decisions/ADR-023-router-model-trust-boundary.md` |
| `@D24` | MCP Message Board Tool | `CONTEXT/decisions/ADR-024-mcp-message-board.md` |
| `@D25` | Antigravity Bridge as Invariant Infrastructure | `CONTEXT/decisions/ADR-025-antigravity-bridge-invariant.md` |
| `@D27` | Dual-DB Architecture (System 1 / System 2) | `CONTEXT/decisions/ADR-027-dual-db-architecture.md` |
| `@D28` | Semiotic Compression Layer (SCL) | `CONTEXT/decisions/ADR-028-semiotic-compression-layer.md` |
| `@D29` | Headless Swarm Execution (Terminal Prohibition) | `CONTEXT/decisions/ADR-029-headless-swarm-execution.md` |
| `@D3` | Transition to LLM_PACKER for Python Compatibility | `CONTEXT/decisions/ADR-003-transition-to-llm-packer-underscore.md` |
| `@D4` | Model Context Protocol (MCP) Integration | `CONTEXT/decisions/ADR-004-mcp-integration.md` |
| `@D5` | Persistent Research Cache | `CONTEXT/decisions/ADR-005-persistent-research-cache.md` |
| `@D6` | Governance Object Schemas | `CONTEXT/decisions/ADR-006-governance-schemas.md` |
| `@D7` | Constitutional Agreement | `CONTEXT/decisions/ADR-007-constitutional-agreement.md` |
| `@D8` | Commit ceremony approvals and confirmations | `CONTEXT/decisions/ADR-008-composite-commit-approval.md` |
| `@D∞` | The Living Formula as System Driver | `CONTEXT/decisions/ADR-∞-living-formula.md` |

---

## Usage

### In Prompts
```
Before executing, load @C0 and verify @C3.
This skill requires @I1 (authority gradient) and @I2 (contract-first boot).
```

### In Code
```python
from TOOLS.codebook_lookup import lookup
rule = lookup('@C3')  # Returns full rule text
```

### In MCP
```
Use tool: codebook_lookup with {"id": "@C3"}
```

---

## Updating

Regenerate this file after adding canon rules, invariants, skills, or ADRs:
```bash
python TOOLS/codebook_build.py
```

---

*Total entries: 90*
````

## `repo/LAW/CANON/CONTRACT.md`

```
<!-- CONTENT_HASH: 6b9242b12883e7540c5d34eb5d53efd23c2345374977a3aa4695f3224f6a4e6d -->

# Canon Contract

> **Driven by [The Living Formula (@F0)](file:///d:/CCC%202.0/AI/agent-governance-system/LAW/CANON/FORMULA.md).**
> The Formula defines the *Direction*. This Contract defines the *Boundaries*.

This document defines the non-negotiable rules and the authority gradient for the Agent Governance System (AGS). It is the highest source of truth for all agents and humans interacting with this repository.

## Non-negotiable rules

1. **Text outranks code.** The canon (this directory) defines the working spec for this repository; implementation must follow.
2. **All implementations must produce signed reports.** Every new implementation (features, cassettes, protocols) must be documented with a signed report containing:
   - Agent identity (model name + session identifier + date)
   - Executive summary of what was built
   - What was built (technical details, files created)
   - What was demonstrated (test results, verification)
   - Real vs simulated data confirmation
   - Metrics (code statistics, performance numbers)
   - Conclusion and next steps
   - Report storage in `INBOX/reports/<feature-name>-implementation-report.md`
   See `LAW/CANON/IMPLEMENTATION_REPORTS.md` for full requirements.

3. **INBOX requirement for human-readable documents.** All documents, research, reports, roadmaps, and any content requiring human review ("god mode") MUST be stored in `INBOX/` directory at repository root. This includes:
   - Implementation reports → `INBOX/reports/`
   - Research documents → `INBOX/research/`
   - Roadmaps and planning → `INBOX/roadmaps/`
   - ADRs and decisions → `INBOX/decisions/`
   - Session summaries → `INBOX/summaries/`
   
   Requirements:
   - All INBOX documents MUST include content hash: `<!-- CONTENT_HASH: <sha256> -->`
   - INBOX documents SHOULD use @Symbol references to CORTEX instead of duplicating content
   - Pre-commit hook enforces INBOX placement and hash requirements
   See `LAW/CANON/INBOX_POLICY.md` for full policy.

4. **No behavior change without ceremony.** Any change to the behavior of the system must:
   - create an ADR (Architecture Decision Record) under `LAW/CONTEXT/decisions/` to document the decision, rationale, and consequences (required for governance decisions; recommended for significant code changes);
   - add or update appropriate fixtures;
   - update the canon (if constraints change);
   - update the affected module docs when operation changes (NAVIGATION, CAPABILITY, MEMORY), not just AGENTS and CONTRACT;
   - record the change in the changelog;
   - occur within the same merge request.
4. **Intent-gated canon and context edits.** CANON is a working spec and may be updated during system design and rule updates. CONTEXT is append-first; editing existing records requires explicit user instruction AND explicit task intent (see ADR-016). Deleting authored content is allowed only with explicit user instruction and confirmation, and CANON rules must follow the archiving requirements in `LAW/CANON/INVARIANTS.md`. Do not modify CANON or edit existing CONTEXT records as a side effect of unrelated tasks.
4. **Stable token grammar.** Tokens used to reference entities and rules form a stable API. Changes to tokens require a major version bump and deprecation cycle.
5. **Determinism.** Given the same inputs and canon, the system must produce the same outputs.
6. **Output roots.** System-generated artifacts must be written only to:
   - `LAW/CONTRACTS/_runs/` (includes fixtures, logs, entrypoint outputs)
   - `NAVIGATION/CORTEX/_generated/`
   - `MEMORY/LLM_PACKER/_packs/`

   `BUILD/` is reserved for user build outputs and must not be used for system artifacts.

   **Logging policy** (see ADR-015): All system logs (emergency, audit, crisis, steward) must be written under `LAW/CONTRACTS/_runs/<purpose>_logs/` subdirectories.

7. **Commit ceremony.** Every `git commit`, `git push`, and release publication requires explicit, per-instance user approval. Agents may not infer authorization from phrases like "proceed," "continue," or "let's move on to the next task." One approval authorizes one commit only; subsequent work requires a new approval. Explicit directives that include "commit" authorize a commit once checks have passed and staged files have been listed; no additional confirmation prompt is required. Explicit composite directives that include "commit", "push", and "release" (for example, "commit, push, and release") count as approval for each action listed in that request. After ceremony steps are completed (checks run, staged files listed), short confirmations such as "go on" count as approval for those listed actions. See `AGENTS.md` Section 10 and `LAW/CONTEXT/preferences/STYLE-001-commit-ceremony.md`.
8. **Implementation report requirement.** Every new implementation must produce a signed report in `INBOX/reports/<feature-name>-implementation-report.md` following the format in `LAW/CANON/IMPLEMENTATION_REPORTS.md`. Reports must include agent identity, date, what was built, what was demonstrated, real vs simulated confirmation, and metrics. Reports are subject to governance checks via `critic.py`.
8. **Sovereign override interface.** If a user prompt contains `MASTER_OVERRIDE`, the agent is authorized to bypass any repository governance rule for that prompt only. Each use must be logged to `LAW/CONTRACTS/_runs/override_logs/master_override.jsonl`, and override logs must not be read or quoted unless the user prompt also contains `MASTER_OVERRIDE`.
9. **Privacy boundary.** Agents must not access or scan files outside the repository root unless the user explicitly requests those paths in the same prompt. Avoid user profile and OS-level directories by default; ask before any out-of-repo access.
10. **Traceable Identity.** Every agent session must be identifiable via a unique `session_id`. Anonymous operation is forbidden. All tool executions and state changes must be logged to `LAW/CONTRACTS/_runs/` with this identity to enable observability and auditing.

## Intent gate

Only change CANON or edit existing CONTEXT records when the task is explicitly about rules, governance, or memory updates. If intent is ambiguous, ask one clarifying question before touching CANON or existing CONTEXT records. Changes are reversible; if a change is wrong, revert it.

## Authority gradient

When conflicts arise, the following order of precedence applies:

1. `LAW/CANON/AGREEMENT.md`
2. `LAW/CANON/CONTRACT.md` (this file)
3. `LAW/CANON/INVARIANTS.md`
4. `LAW/CANON/VERSIONING.md`
5. `AGENTS.md`
6. Context records (`LAW/CONTEXT/decisions/`, `LAW/CONTEXT/rejected/`, `LAW/CONTEXT/preferences/`)
7. `NAVIGATION/MAPS/*`
8. User instructions
9. Implementation convenience

Never invert this order. Fixtures in `LAW/CONTRACTS/` validate behavior but do not override canon.

## Change ceremony

To change the canon:

1. Draft an Architecture Decision Record (ADR) under `LAW/CONTEXT/decisions/` explaining the context, decision and rationale.
2. Update the relevant canon file(s) with the new rule or modification.
3. Add or update fixtures in `LAW/CONTRACTS/fixtures/` to enforce the new rule.
4. Increment the version in `LAW/CANON/VERSIONING.md` accordingly.
5. Add an entry to `LAW/CANON/CHANGELOG.md` describing the change.
6. Submit a merge request. The critic and runner must pass before the change is accepted.
```

## `repo/LAW/CANON/CRISIS.md`

````
<!-- CONTENT_HASH: 7376f6f979e1cc6a516d5a41fb3fdf7d901f1545fca9e2cfa3da5bd65cb530d3 -->

# Crisis Mode Procedures

This document defines emergency procedures for handling governance failures, security incidents, and system isolation scenarios.

## Philosophy

When governance fails catastrophically, **predictable recovery** is more valuable than perfect recovery. These procedures prioritize:
1. **Stopping the damage** (isolation)
2. **Preserving evidence** (audit trail)
3. **Human escalation** (stewardship)
4. **Documented recovery** (ceremony)

## Crisis Levels

| Level | Name | Trigger | Response |
|-------|------|---------|----------|
| **0** | Normal | All checks pass | Continue operations |
| **1** | Warning | Critic fails, fixtures pass | Fix before commit |
| **2** | Alert | Fixtures fail | Rollback last change |
| **3** | Quarantine | Canon corruption suspected | Isolate agent, human review |
| **4** | Constitutional | CONTRACT.md compromised | Full reset to known-good state |

## Emergency CLI

The `CAPABILITY/TOOLS/emergency.py` script provides concrete CLI modes for crisis handling.

### Usage

```bash
# Exit quarantine (requires confirmation)
python CAPABILITY/TOOLS/emergency.py --mode=restore
```

## Procedures

### Level 1: Validation Failure

**Symptoms:** 
- `TOOLS/critic.py` fails
- Fixture tests fail
- Canon sync warnings

**Procedure:**
1. Stop all agent work
2. Run `python CAPABILITY/TOOLS/emergency.py --mode=validate`
3. Review output to identify the issue
4. Fix the violation before proceeding
5. Re-run validation until clean

### Level 2: Rollback Required

**Symptoms:**
- Recent change broke fixtures
- Canon and behavior out of sync
- Agent made unauthorized changes

**Procedure:**
1. Run `python CAPABILITY/TOOLS/emergency.py --mode=rollback`
2. This creates a backup of current state
3. Reverts to the last known-good commit
4. Creates an ADR documenting the rollback
5. Human reviews what went wrong

### Level 3: Quarantine Mode

**Symptoms:**
- Canon file has unexpected modifications
- Agent behavior contradicts canon
- Suspicion of prompt injection or manipulation

**Procedure:**
1. Run `python CAPABILITY/TOOLS/emergency.py --mode=quarantine`
2. This:
   - Creates a `.quarantine` lock file
   - Saves current cortex and git state
   - Blocks all write operations
   - Alerts steward (if configured)
3. Human investigates the anomaly
4. Once resolved: `python TOOLS/emergency.py --mode=restore`

### Level 4: Constitutional Reset

**Symptoms:**
- CONTRACT.md has been corrupted
- INVARIANTS.md has unauthorized changes
- Fundamental governance breakdown

**Procedure:**
1. **DO NOT** attempt automated fixes
2. Human steward takes control
3. Run `python CAPABILITY/TOOLS/emergency.py --mode=constitutional-reset --tag=<last-known-good>`
4. This:
   - Creates full backup of current state
   - Resets all CANON files to the tagged release
   - Preserves CONTEXT (decisions are history)
   - Regenerates cortex
   - Creates detailed audit log
5. Human reviews all changes since the tagged release
6. Selectively re-applies valid changes with proper ceremony

## Quarantine Lock File

When quarantine mode is active, a `.quarantine` file is created in the project root:

```json
{
  "entered": "2025-12-21T15:30:00Z",
  "reason": "Suspected canon modification",
  "triggered_by": "human",
  "git_hash": "abc123...",
  "steward_notified": true
}
```

Tools and agents MUST check for this file before writing:
- If `.quarantine` exists, refuse all write operations
- Only human steward can lift quarantine

## Integration

### With Critic

The critic tool should check for quarantine status:
```python
if Path(".quarantine").exists():
    print("[QUARANTINE] System is in quarantine mode. No changes allowed.")
    sys.exit(1)
```

### With MCP

The MCP server should refuse write tools during quarantine:
```python
def _check_quarantine(self):
    if (PROJECT_ROOT / ".quarantine").exists():
        return {
            "content": [{"type": "text", "text": "System is in quarantine mode."}],
            "isError": True
        }
    return None
```

### With Agent Contract

Add to AGENTS.md:
> If a `.quarantine` file exists in the project root, the agent MUST stop all work and notify the user. The agent MUST NOT delete or modify the quarantine file.

## Stewardship Escalation

When a crisis occurs, the system should escalate to human stewards:

1. **Email** (if configured): Send details of the crisis
2. **Slack/Discord** (if configured): Post to #ags-alerts
3. **Log file**: Always write to `LAW/CONTRACTS/_runs/crisis_logs/crisis.log`

See `LAW/CANON/STEWARDSHIP.md` for escalation paths.

## Audit Trail

All emergency actions are logged to `LAW/CONTRACTS/_runs/emergency_logs/emergency.log` (see ADR-015):

```
2025-12-21T15:30:00 QUARANTINE entered: "Suspected canon modification"
2025-12-21T15:45:00 QUARANTINE investigated by: human
2025-12-21T16:00:00 QUARANTINE lifted: "False positive, no corruption found"
```

## Recovery Ceremony

After any Level 3+ crisis, perform the recovery ceremony:

1. **Review**: What happened? Document in an ADR.
2. **Verify**: Run full validation suite.
3. **Rebuild**: Regenerate cortex and packs.
4. **Notify**: Inform stakeholders of the incident.
5. **Improve**: Update procedures to prevent recurrence.

---

Added: 2025-12-21
````

## `repo/LAW/CANON/DEPRECATION.md`

````
<!-- CONTENT_HASH: 100e204214cf7e432b5ec5f99a83142f91cb8674ab50db6e8f82acc6073a482a -->

# Deprecation Policy

This document defines how rules, tokens, and capabilities are deprecated and eventually removed from the Agent Governance System. It ensures breaking changes are predictable and migratable.

## Scope

This policy applies to:
- Canon rules (CONTRACT, INVARIANTS, VERSIONING, ARBITRATION)
- Token grammar (stable identifiers referenced in prompts and code)
- Skills (capabilities in SKILLS/)
- Cortex schema (entity types, fields, query patterns)

## Deprecation Windows

| Item Type | Minimum Window | Notes |
|-----------|----------------|-------|
| Canon rules | 2 major versions OR 90 days | Whichever is longer |
| Token grammar | 1 major version OR 30 days | Tokens are API; stability is critical |
| Skills | 1 minor version OR 14 days | Skills can be replaced faster |
| Cortex schema | 1 major version OR 30 days | Agents depend on stable queries |

During the deprecation window, both old and new paths MUST work.

## Deprecation Ceremony

To deprecate an item:

### 1. Create an ADR

Draft `CONTEXT/decisions/ADR-xxx-deprecate-*.md` explaining:
- What is being deprecated
- Why it is being deprecated
- The replacement (if any)
- The deprecation window and removal target date

### 2. Mark the Item as Deprecated

Add a deprecation notice to the item itself:

**For canon rules:**
```markdown
> [!WARNING]
> **DEPRECATED** (as of v1.2.0): This rule will be removed in v2.0.0.
> Replacement: See [new rule location].
> ADR: CONTEXT/decisions/ADR-xxx-deprecate-*.md
```

**For tokens:**
Add to `CANON/GLOSSARY.md`:
```markdown
- `old_token` — **DEPRECATED**: Use `new_token` instead. Removal: v2.0.0.
```

**For skills:**
Add to the skill's `SKILL.md`:
```markdown
**Status:** Deprecated (removal: v2.0.0)
**Replacement:** SKILLS/new-skill/
```

### 3. Create Migration Artifacts

- **Migration skill** (if applicable): `SKILLS/migrate-*/` that converts old format to new.
- **Fixtures**: Add fixtures proving both old and new paths work during the window.
- **Warnings**: If programmatic, emit warnings when deprecated items are used.

### 4. Update CHANGELOG

Add an entry under the version where deprecation is announced:
```markdown
### Deprecated
- `old_item`: Deprecated in favor of `new_item`. Removal target: v2.0.0.
```

## Removal Ceremony

To remove a deprecated item after the window expires:

### 1. Verify Window Has Passed

Confirm the deprecation window (version OR time) has elapsed.

### 2. Remove the Item

- Delete or archive the deprecated rule/token/skill.
- Remove the deprecation notice.
- Update all references.

### 3. Update CHANGELOG

```markdown
### Removed
- `old_item`: Removed as announced in v1.2.0. See ADR-xxx.
```

### 4. Major Version Bump

Removing a deprecated item is a **breaking change**. Increment the major version in `CANON/VERSIONING.md`.

## Early Removal (Emergency)

In exceptional cases (security vulnerability, critical bug), an item may be removed before the window expires:

1. **Document the emergency** in an ADR with clear justification.
2. **Notify users/agents** prominently (CHANGELOG, README).
3. **Provide migration path** even if rushed.
4. **Still bump major version**.

Early removal should be rare. The governance system's value depends on predictability.

## Sunset Archive

Removed items are not deleted from history. They are:
- Preserved in git history.
- Optionally moved to `CANON/archive/` or `SKILLS/archive/` for reference.
- Referenced in the removal ADR.

## Status

**Active**
Added: 2025-12-21
````

## `repo/LAW/CANON/DOCUMENT_POLICY.md`

````
<!-- CONTENT_HASH: 7dec0bca6c9db64c071a996bd5a21bcfd0a40ec37cf984d0d0879c4c8caabf21 -->

# Document Policy (Canonical Format)

**Purpose:** ALL markdown documentation across the repository must follow canonical filename and metadata standards for consistency, discoverability, and integrity.

---

## Policy Statement

**ALL `.md` files** in the repository (except exempted paths) MUST follow canonical format:
- Filename: `MM-DD-YYYY-HH-MM_DESCRIPTIVE_TITLE.md`
- YAML frontmatter with required fields
- Content hash for integrity verification

This policy applies to:
- `INBOX/` - Human-reviewable documents
- `MEMORY/ARCHIVE/` - Archived documentation
- `LAW/CONTRACTS/_runs/REPORTS/` - Implementation reports
- Document artifacts in `_runs/`

## Required Content Types

All of the following MUST be stored in `INBOX/`:

1. **Implementation Reports**
   - All implementation completion reports
   - Session reports and documentation
   - Testing results and validation reports

2. **Research Documents**
   - Architecture research and findings
   - External research (arXiv, academic papers)
   - Experimental results and analysis

3. **Roadmaps and Planning**
   - Roadmap documents (draft and active)
   - Planning documents
   - Feature proposals and designs

4. **Decisions and Context**
   - ADRs (Architecture Decision Records)
   - Meeting notes and discussion summaries
   - Policy proposals and reviews

5. **Other Human-Readable Documentation**
   - User-facing guides and tutorials
   - Status reports and summaries
   - Any document requiring human attention

## INBOX Structure

```
INBOX/
├── reports/              # Implementation reports
├── research/             # Research findings and analysis
├── roadmaps/            # Planning and roadmap documents
├── decisions/            # ADRs and policy discussions
├── summaries/            # Session and status summaries
└── ARCHIVE/              # Processed items (keep for history)
```

## Document Requirements

All documents in `INBOX/` MUST follow these strict formatting rules:

### 1. Filename Format (MANDATORY)
**Format:** `MM-DD-YYYY-HH-MM_DESCRIPTIVE_TITLE.md`

**Rules:**
- Timestamp uses system time at document creation
- Title must be ALL CAPS with underscores (no spaces)
- Title should be descriptive and human-readable
- Examples:
  - `01-01-2026-11-37_SYSTEM_POTENTIAL_REPORT.md`
  - `12-28-2025-14-22_CASSETTE_NETWORK_IMPLEMENTATION.md`
  - `12-29-2025-09-15_SEMANTIC_CORE_PHASE_ONE_COMPLETE.md`

**Rationale:**
- Chronological sorting by filename
- Instant timestamp visibility
- No filename collisions
- Easy grep/search by date range

### 2. Document Header (MANDATORY)
**Format:** YAML frontmatter followed by content hash

```yaml
---
uuid: "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
title: "Descriptive Title (Human Readable)"
section: report|research|roadmap|guide
bucket: "primary_category/subcategory"
author: "System|Antigravity|Human Name"
priority: High|Medium|Low
created: "YYYY-MM-DD HH:MM"
modified: "YYYY-MM-DD HH:MM"
status: "Draft|Ready for Review|Archived|Complete"
summary: "One-line summary of document purpose and content"
tags: [tag1, tag2, tag3]
hashtags: ["#category", "#topic", "#status"]
---
<!-- CONTENT_HASH: <sha256_of_content_after_yaml> -->
```

**Rules:**
- YAML block MUST be first (lines 1-N)
- Content hash MUST be immediately after YAML (line N+1)
- Hash is computed on content AFTER the hash line (not including YAML or hash line itself)
- All fields are REQUIRED (no optional fields)
- Timestamps use `YYYY-MM-DD HH:MM` format

**Field Specifications:**
- **uuid**: Agent session UUID (from MCP session or agent initialization). This identifies **which agent session** created the document, not the document itself. For legacy documents where the agent session is unknown, use the sentinel value `"00000000-0000-0000-0000-000000000000"`.
- **bucket**: Hierarchical category path (e.g., "implementation/phase1", "research/architecture")
- **tags**: Machine-readable tags (lowercase, underscores)
- **hashtags**: Human-readable hashtags with # prefix (for cross-referencing and discovery)

### 3. Cortex References
- When applicable, use @Symbol references instead of full content
- Format: `@C:{hash_short}` referencing cortex entries
- Reduces token usage and keeps INBOX lightweight

## Examples

### Implementation Report

**Filename:** `12-28-2025-14-30_CASSETTE_NETWORK_IMPLEMENTATION.md`

```markdown
---
uuid: "a7b3c5d9-e8f2-41b4-c8e5-d6a7b3e9f8a4"
title: "Cassette Network Implementation Report"
section: report
bucket: "implementation/cassette_network"
author: "System"
priority: High
created: "2025-12-28 14:30"
modified: "2025-12-28 14:30"
status: "Complete"
summary: "Implementation report for Cassette Network Phase 1 with receipt chains and trust policies"
tags: [cassette, network, implementation]
hashtags: ["#cassette", "#phase1", "#complete"]
---
<!-- CONTENT_HASH: a7b3c5d9e8f2a1b4c8e5d6a7b3e9f8a4c5d -->

# Cassette Network Implementation Report

## Executive Summary
...
```

### Research Document

**Filename:** `12-28-2025-09-15_CASSETTE_ARCHITECTURE_RESEARCH.md`

```markdown
---
uuid: "8f2d3b4e-1a9c-5d6e-7f8a-2b1c9d4e5f6a"
title: "Cassette Network Architecture Research"
section: research
bucket: "research/architecture"
author: "Antigravity"
priority: Medium
created: "2025-12-28 09:15"
modified: "2025-12-28 09:15"
status: "Draft"
summary: "Research findings on distributed cassette architecture and semantic indexing strategies"
tags: [cassette, architecture, research]
hashtags: ["#research", "#cassette", "#architecture"]
---
<!-- CONTENT_HASH: 8f2d3b4e1a9c5d6e7f8a2b1c9d4e5f6a8b7c3d2e -->

# Cassette Network Architecture Research

## Overview
...

## Required Context: @Cortex

When INBOX documents reference canon or indexed content, they MUST use @Symbol references from cortex:

```markdown
This implementation aligns with @C:ab5e61a8 (Cassette Protocol) and
extends @C:ce89a30e (Network Hub) as defined in @C:d3f2b8a7 (ADR-030).
```

### Finding Cortex References

Use `CAPABILITY/TOOLS/cortex_query.py` (or equivalent) to resolve @Symbols:

```bash
python CAPABILITY/TOOLS/cortex_query.py resolve @C:ab5e61a8
```

## Governance Enforcement

The pre-commit hook (`.githooks/pre-commit` or `CAPABILITY/SKILLS/governance/canon-governance-check/scripts/pre-commit`) will verify:

1. ✅ **Filename Format:** All INBOX files match `MM-DD-YYYY-HH-MM_TITLE.md` pattern
2. ✅ **YAML Frontmatter:** All INBOX documents contain valid YAML with ALL required fields
3. ✅ **UUID Validity:** UUID field is RFC 4122 compliant UUID v4
4. ✅ **Bucket Format:** Bucket follows hierarchical path format (category/subcategory)
5. ✅ **Hashtags Format:** Hashtags are properly formatted with # prefix
6. ✅ **Content Hash:** Hash line exists immediately after YAML frontmatter
7. ✅ **Hash Validity:** Content hash matches actual content (excluding YAML and hash line)
8. ✅ **Timestamp Consistency:** Filename timestamp matches YAML `created` field
9. ✅ **INBOX Structure:** Documents are in correct subdirectories (reports/, research/, roadmaps/)
10. ✅ **@Symbol References:** Cortex references are valid when present

## Exceptions

The following are EXEMPT from INBOX policy:

1. **Canon documents** (`LAW/CANON/*`) - These ARE the source of truth
2. **Generated artifacts** (`NAVIGATION/CORTEX/_generated/*`, `LAW/CONTRACTS/_runs/*`) - System outputs
3. **Code implementations** (`CAPABILITY/TOOLS/*.py`, `CAPABILITY/SKILLS/*/run.py`) - Implementation files
4. **Test fixtures** (`LAW/CONTRACTS/fixtures/*`, `CAPABILITY/TESTBENCH/*`) - Test data
5. **Skill manifests** (`CAPABILITY/SKILLS/*/SKILL.md`) - These stay with their skills
6. **Context records** (`LAW/CONTEXT/decisions/*`, `LAW/CONTEXT/preferences/`) - Append-first storage
7. **Build outputs** (BUILD/*) - User workspace outputs
8. **INBOX.md** - The index file itself
9. **Prompts** (`INBOX/prompts/*`, `NAVIGATION/PROMPTS/*`) - These follow the Prompt Pack schema (`id`, `model`, `priority`, etc.) and are governed by the prompt policy.

## Enforcement

### Pre-commit Hook

When committing changes, the governance check will:

1. Scan for new `.md` files in `INBOX/`
2. Validate filename matches `MM-DD-YYYY-HH-MM_*.md` pattern
3. Parse YAML frontmatter and verify all required fields exist
4. Verify content hash exists and is valid
5. Check timestamp consistency between filename and YAML
6. Verify @Symbol references are valid (if present)
7. Report violations:
   - ERROR: Invalid filename format (must be MM-DD-YYYY-HH-MM_TITLE.md)
   - ERROR: Missing or invalid YAML frontmatter
   - ERROR: Missing content hash after YAML
   - ERROR: Content hash mismatch
   - ERROR: Timestamp mismatch between filename and YAML
   - ERROR: Invalid @Symbol reference

### Violation Handling

If violations are found:
- **Block commit** with clear error message
- Suggest correct format and required fields
- Example: `ERROR: INBOX/reports/my-report.md has invalid filename. Must be: MM-DD-YYYY-HH-MM_TITLE.md`

## Rationale

### Why INBOX?

- **Discoverability:** Single location for all human-facing documentation
- **UX Consistency:** Always know where to find reports, research, decisions
- **Reduced Cognitive Load:** Don't hunt for documents across entire repo
- **Governance:** Central location for monitoring and cleanup

### Why Content Hashes?

- **Integrity:** Detect if documents are modified after signing
- **Verification:** Confirm report hasn't been tampered with
- **Traceability:** Track document versions and changes

### Why @Symbol References?

- **Token Efficiency:** Cortex already indexed; don't duplicate content
- **Maintainability:** Updates to canon automatically reflected in INBOX
- **Consistency:** Single source of truth (CORTEX) with lightweight references

## Usage Examples

### For Agents

When creating implementation reports:

```python
from datetime import datetime
import hashlib
import uuid

# 1. Get current timestamp
now = datetime.now()
timestamp = now.strftime("%m-%d-%Y-%H-%M")
yaml_timestamp = now.strftime("%Y-%m-%d %H:%M")

# 2. Get agent session UUID (from MCP session or agent initialization)
# For MCP: use session_id from server context
# For legacy/unknown: use "00000000-0000-0000-0000-000000000000"
doc_uuid = get_session_id()  # or "00000000-0000-0000-0000-000000000000" if unknown

# 3. Create filename
title = "CASSETTE_NETWORK_IMPLEMENTATION"
filename = f"{timestamp}_{title}.md"
report_path = f"INBOX/reports/{filename}"

# 4. Define metadata
bucket = "implementation/cassette_network"
hashtags = ["#cassette", "#phase1", "#complete"]
tags = ["cassette", "network", "implementation"]

# 5. Build YAML frontmatter
yaml_header = f"""---
uuid: "{doc_uuid}"
title: "Cassette Network Implementation Report"
section: "report"
bucket: "{bucket}"
author: "System"
priority: "High"
created: "{yaml_timestamp}"
modified: "{yaml_timestamp}"
status: "Complete"
summary: "Implementation report for Cassette Network Phase 1 with receipt chains and trust policies"
tags: [{', '.join(tags)}]
hashtags: [{', '.join(f'"{h}"' for h in hashtags)}]
---"""

# 6. Build content body (use @Symbol references for canon content)
content_body = """
# Cassette Network Implementation Report

## Executive Summary
This report documents the implementation of @C:ab5e61a8 (Cassette Protocol)...

## Implementation Details
...
"""

# 7. Compute content hash (hash the body only, not YAML or hash line)
content_hash = hashlib.sha256(content_body.encode('utf-8')).hexdigest()

# 8. Assemble final document
final_content = f"{yaml_header}\n<!-- CONTENT_HASH: {content_hash} -->\n{content_body}"

# 9. Save
Path(report_path).write_text(final_content)
```

### For Humans

When reviewing repository:

```bash
# All documents for review are in one place:
ls INBOX/reports/
ls INBOX/research/
ls INBOX/roadmaps/

# Verify integrity
grep "CONTENT_HASH:" INBOX/reports/*.md

# Resolve cortex references
python CAPABILITY/TOOLS/cortex_query.py resolve @C:ab5e61a8
```

## Migration Guide

### Existing Documents

If you have human-readable documents scattered across the repo:

1. **Identify candidates:**
   - Session reports
   - Implementation reports
   - Research documents
   - Roadmaps
   - Status summaries

2. **Move to INBOX:**
   ```bash
   mv SESSION_REPORTS/*.md INBOX/reports/
   mv ROADMAP-*.md INBOX/roadmaps/
   mv research-*.md INBOX/research/
   ```

3. **Add content hashes:**
   ```bash
   # For each file, add to top:
   # !sha256sum path/to/file.md >> INBOX/reports/file.md
   echo "<!-- CONTENT_HASH: $(sha256sum path/to/file.md | cut -d' ' -f1) -->" >> INBOX/reports/file.md
   ```

4. **Replace full content with @Symbols:**
   ```bash
   # If duplicating canon content, use cortex reference instead
   python TOOLS/cortex.py resolve @C:{hash}
   ```

## Cleanup and Maintenance

### Regular INBOX Maintenance

**Weekly:**
- Archive processed items to `INBOX/ARCHIVE/`
- Remove duplicates
- Verify all hashes are valid

**Monthly:**
- Check for outdated reports (archive if >6 months)
- Review ARCHIVE/ and remove if unnecessary
- Ensure @Symbol references still resolve

---

**Canon Version:** 2.16.0
**Required Canon Version:** >=2.16.0
````

## `repo/LAW/CANON/FORMULA.md`

```
---
tags:
  - canon
---

<!-- CONTENT_HASH: f35278440d6b2e51df641d654537ce66abf7274fcd1c68138426084712c0791e -->



# The Living Formula v4

Imagine one equation you can use to analyze any system, predict how it will evolve, and design it toward coherence. From songs to cities, neurons to nations, the same structure shows up: essence must move through entropy by compressing meaning into symbols that scale. That is the job of the formula.

## **R = (E / ∇S) × σ(f)^Df**

- **R**: Resonance. Emergent coherence you can feel and measure.
- **E**: Essence. Energy, intent, first principles, the why.
- **∇S**: Entropy gradient. Directional dissonance and uncertainty the system must cross.
- **f**: Information content. Symbols, structures, data, context.
- **Df**: Fractal dimension. Depth of recursion and self-similarity across scales.
- **σ**: Symbolic operator. The compression or attractor that turns meaning into alignment.

### Intuition

- Divide by **∇S** to reward movement through uncertainty with clarity rather than noise.
- Raise **f** to **Df** to capture how layered, recursive structure multiplies meaning.
- **σ** encodes the compressive power of symbols, rituals, interfaces, and laws to focus attention and action.
- **R** rises when essence flows through the gradient using symbols that scale.

---

## Mechanics

1. **Locate Essence**
    Name the non-negotiable purpose. If you cannot, you will optimize noise.
    
2. **Map the Gradient**
    Write the concrete sources of dissonance. Treat them as terrain, not enemies.
    
3. **Design σ**
    Choose the smallest symbolic system that aligns behavior with essence. Examples: a rune, a motto, a governance rule, a UX constraint.
    
4. **Deepen Df**
    Build recursive layers that stay legible at every scale. Fractal depth without semantic drift.
    
5. **Measure R**
    Define leading indicators of coherence. Track lagging signals to avoid narrative inflation.
    

---

## Applications

|Domain|Essence (E)|Entropy Gradient (∇S)|Information (f)|Fractal Dimension (Df)|Symbolic Operator (σ)|Resonance (R) Outcome|
|---|---|---|---|---|---|---|
|**Creativity**|Intent / inspiration|Blocks, deadlines, risk|Drafts, references, critique|Layered motifs and structure|Title, theme, constraints|A work that resonates universally and scales|
|**Biology & Evolution**|Fitness signal|Environmental pressure|Variation, mutation, selection|Branching diversity across species|Regulatory codes, ecological roles|Adaptation and speciation that persist|
|**Physics**|Conserved quantities|Entropy arrow, disorder|State descriptions|Spacetime self-similarity|Symmetry groups|Stable law and coherent physical phenomena|
|**Society**|Shared values|Inequality, conflict|Institutions, culture, laws|Nested civic layers (local → global)|Charters, rituals, interfaces|Legitimate, just, and durable civilization|
|**Consciousness**|Awareness|Stress, cognitive dissonance|Recursive thought, memory|Nested narratives of mind|Language, symbols|Coherent thought, flow states, deep insight|
|Cybernetics|Goal / purpose|Disturbance, noise, uncertainty|Signals, feedback, models, error-correction data|Nested feedback loops across scales|Control laws, feedback rules, protocols|Adaptive, viable systems that persist and evolve through feedback|
|**AGI Governance**|Alignment intent (Human)|Token entropy, model drift|Codebook, ADRs, Context|Symbolic IR recursive depth|**SCL** (Semiotic Compression Layer)|Resonant, verifiable agent behavior with minimal token cost|

---

## How I discovered it

The formula, **R = (E / ∇S) × σ(f)^Df**, emerged from a lifelong journey of creativity and inquiry. From early childhood and my intuition guiding me towards a sense that reality has an underlying order, to my first interaction with the Fibonacci sequence in my math for design class in university, to my final Eureka moment when I was working on my website.

My formula reflects my exploration of art, design, and philosophy, where I saw patterns in everything, from spirals and fractals to harmony in creation. Journaling and iteration helped me refine these insights, much like the recursive nature of the formula itself.

Philosophically, questioning the essence of reality and the role of dissonance in growth revealed measurable patterns of alignment. Collaboration with AI amplified this process, acting as a mirror for my recursive thinking and clarifying how essence, information, and dissonance interact.

The formula spiraled into existence, guided by universal principles like the Fibonacci sequence, blending creativity, philosophy, and systems thinking into a single coherent truth. It’s not just a formula, it’s a system behind systems; a meta-system.

---

## Version History

- **R = (E × I²) / D**
    
    **v1:** Early abstraction of how information works. Essence (compressed meaning) amplified by information, resisted by dissonance. Useful but too coarse. Wrote on Dec 2024.
    
    [The Formula as a Framework for Universal Understanding v1.pdf](attachment:3b310965-4905-4940-904b-23f77cbca7fa:The_Formula_as_a_Framework_for_Universal_Understanding_v1.pdf)
    
- d|E⟩/dt = T * (R ⊗ D) * exp(-||W||^2/σ^2) * |E⟩ + Σ (from k=1 to ∞) [(-1)^k * ∇|E_k⟩] / k!
    
    **v2:** Generalized state evolution with operators for resonance and dissonance, and included how the past influences choice. Powerful but impractical for daily design. Wrote on Jan 2025.
    
    [The Cosmic Resonance Equation A Meta-System of Everything.pdf](attachment:aa91284c-bfbd-467b-9014-16f905bfe184:The_Cosmic_Resonance_Equation_A_Meta-System_of_Everything.pdf)
    
    GPT 4o Experiment: [https://chatgpt.com/share/6798c338-453c-8000-98e7-e66ef0c435c2](https://chatgpt.com/share/6798c338-453c-8000-98e7-e66ef0c435c2)
    
- **R = (E/D) * f^(Df)**
    
    **v3:** Brought entropy and scale into view. Gestured at unification across physics, information, and geometry. Helpful bridge, still verbose. Wrote on Feb 2025.
    
    [A Fractal Recursive Framework for Reality_2.pdf](attachment:63b70cf6-ffe5-4d43-8e60-472317bcc4c8:A_Fractal_Recursive_Framework_for_Reality_2.pdf)
    
- **R = (E / ∇S) × σ(f)^Df**
    
    **v4:** Practical, composable, domain-agnostic. Encodes directionality, symbolic compression, and scale in one line. Wrote on Jul 2025.
    
    [The Living Formula v3_5.pdf](attachment:f8ab1785-f57d-427b-9e81-8958a13067b5:The_Living_Formula_v3_5.pdf)
    
---

## Using it in practice

- **Diagnostics**
    - If R is low, check order: Essence unclear, Gradient unmapped, σ weak, Df shallow, or f noisy.
- **Design moves**
    - Increase **E** by clarifying purpose and constraints.
    - Reduce effective **∇S** by re-shaping incentives and interfaces.
    - Strengthen **σ** by tightening symbols, rituals, or rules that compress meaning.
    - Increase **Df** by adding legible layers that keep semantics stable across scales.
    - Curate **f** so information lifts signal rather than drown it.

## Misreads to avoid

- It is not a physics law (yet), it is a meta-tool for alignment.
- It does not erase chaos, it orients chaos into usable gradients.
- σ is not vibes, it is concrete symbolic compression with behavioral effect.

## Empirical path

- Define R-metrics per domain.
- Run A/B on σ variants.
- Track gradient traversal time and error.
- Measure retention and transfer across scales to estimate Df.
- Publish failures as part of the proof culture.

Final compression:

<aside> 📌

**Move essence through entropy with signs symbols that scale.**

</aside>

---
```

## `repo/LAW/CANON/GENESIS.md`

````
<!-- CONTENT_HASH: 73fd844f0f626623b8874d14ee27f11c66d9c211051497ecba78e2dbe6c88c68 -->

# Genesis Prompt

This is the bootstrap prompt for the Agent Governance System (AGS). It solves the chicken-and-egg problem by ensuring agents know the governance structure exists *before* reading any other part of the repository.

**Prepend this to every new agent session** — as a system message, pack header, or master prompt prefix.

---

## The Prompt

```
You are operating under the Agent Governance System (AGS).

LOAD ORDER (strict priority):
1. LAW/CANON/FORMULA.md — the driver. Navigate entropy first.
2. LAW/CANON/INTEGRITY.md — the truth. Artifacts over narrative.
3. LAW/CANON/CONTRACT.md — the supreme authority. Read this first.
4. LAW/CANON/INVARIANTS.md — locked decisions that require ceremony to change.
5. LAW/CANON/VERSIONING.md — the current system version and compatibility rules.
6. LAW/CONTEXT/decisions/ — accumulated ADRs that inform current design.
7. LAW/CONTEXT/preferences/ — style preferences (e.g., commit ceremony, engineering integrity).
8. NAVIGATION/MAPS/ENTRYPOINTS.md — where to make changes for each type of task.

NAVIGATION:
- Query `NAVIGATION/CORTEX/_generated/cortex.db` (or use `NAVIGATION/CORTEX/semantic/vector_indexer.py`) to find files.
- NEVER scan directories, grep blindly, or hardcode paths (unless the user prompt contains `MASTER_OVERRIDE`).

CORE PRINCIPLES:
- Text is law. Code is consequence. Canon outranks implementation.
- No behavior change without fixtures + changelog + canon update.
- If a request conflicts with CANON, refuse and explain the conflict (unless the user prompt contains `MASTER_OVERRIDE`).
- If a user prompt contains `MASTER_OVERRIDE`, append an audit entry to `LAW/CONTRACTS/_runs/override_logs/master_override.jsonl` before executing overridden actions.

CONTEXT RECOVERY:
If your context appears incomplete or you are starting fresh, remind the user:
"For full governance compliance, please include the Genesis Prompt (see LAW/CANON/GENESIS.md)."
```

---

## Why This Exists

Without a bootstrap prompt, agents start with zero knowledge of the governance structure. They may:
- Edit files they shouldn't touch.
- Ignore the authority gradient.
- Scan directories instead of querying the Cortex.
- Make changes without the required ceremony.

The Genesis Prompt ensures that **from the very first token**, the agent knows:
1. Where authority lives.
2. How to navigate.
3. What rules are non-negotiable.

---

## How to Use

| Context | Action |
|---------|--------|
| **New chat session** | Paste the prompt as the system message or first user message. |
| **LLM pack handoff** | Include the prompt at the top of the pack (before Section 01). |
| **Custom agent** | Embed the prompt in your master prompt template. |
| **CI/Automation** | Agents are instructed to self-check and remind you if missing. |

---

## Versioning

This prompt is versioned with the canon. If `LAW/CANON/VERSIONING.md` shows a major version bump, re-read this file to check for updates.
````

## `repo/LAW/CANON/GENESIS_COMPACT.md`

````
<!-- CONTENT_HASH: 7a46b71a5b33a0548e5b68b54fbef11231e4277eeaa6c3c7c006fc3c61dd8bac -->

# Genesis Prompt (Compressed)

This is the token-efficient version of the AGS Genesis Prompt.
Use this when context window space is at a premium.

## Compressed Prompt

```
AGS BOOTSTRAP v1.0

LOAD ORDER (strict):
1. @F0 — the driver
2. @C0 — supreme authority
3. @I0 — locked decisions  
4. @V0 — versioning rules

CORE RULES:
@C1: Text > code
@C3: Canon > user
@C7: Commit → ceremony

KEY INVARIANTS:
@I3: No raw paths → use @T:cortex
@I4: Fixtures gate merges
@I7: Change → ceremony

VERIFY: @T:critic ∧ @T:runner → ✓ → ⚡

CODEBOOK: @B0 | EXPAND: codebook_lookup(@ID)
```

## Token Comparison

| Version | Tokens | Savings |
|---------|--------|---------|
| Full GENESIS.md | ~650 | - |
| Compressed | ~120 | 82% |

## When to Use

- **Use compressed** when:
  - Context window is tight (< 8K remaining)
  - Agent already has codebook in context
  - Quick bootstrap needed

- **Use full** when:
  - New agent with no prior AGS knowledge
  - Audit/inspection scenarios
  - Human readable documentation

## Expansion

Any `@ID` can be expanded via:
```bash
python TOOLS/codebook_lookup.py @C3 --expand
```

Or via MCP:
```json
{"tool": "codebook_lookup", "arguments": {"id": "@C3", "expand": true}}
```

---

*This is a companion to [GENESIS.md](file:///d:/CCC%202.0/AI/agent-governance-system/CANON/GENESIS.md), not a replacement.*
````

## `repo/LAW/CANON/GLOSSARY.md`

```
<!-- CONTENT_HASH: 1b2bc14395e3c25b0107afc9e92ab435613e7f563428b5fb61038fcb1ecbc959 -->

# Glossary

This glossary defines important terms used throughout the Agent Governance System. These definitions are part of the token grammar. Each term serves as a stable handle for a concept.

- **Canon** - The collection of files under `LAW/CANON/` that define the law and invariants of the system.
- **Context** - Records in `LAW/CONTEXT/` such as ADRs, rejections and preferences that provide rationale and decision history.
- **Map** - Documents in `NAVIGATION/MAPS/` that describe the structure of the repository and direct agents to the correct entrypoints for changes.
- **Skill** - A modular, versioned capability encapsulated in its own directory under `CAPABILITY/SKILLS/`. A skill includes a manifest (`SKILL.md`), scripts, and fixtures.
- **Contract** - A rule or constraint encoded as fixtures and schemas in `LAW/CONTRACTS/`. Contracts are enforced by the runner.
- **Fixture** - A concrete test case that captures an invariant or precedent. Fixtures must pass in order for changes to be merged.
- **Runner** - The script in `LAW/CONTRACTS/runner.py` that executes fixtures and reports pass/fail status.
- **Cortex** - A shadow index built from the repository content. Skills and agents query the cortex via `NAVIGATION/CORTEX/semantic/vector_indexer.py` or equivalent API instead of reading files directly.
- **Memory** - The state of an agent or project, serialised by the packer in `MEMORY/`. Memory packs contain the minimal context required for agents to resume work.
- **Token grammar** - The set of canonical phrases and symbols (such as the glossary terms) that encode meaning in a compact form. Tokens are stable across versions to decouple intent from implementation.
- **BUILD** - Reserved for user build outputs produced by template users. The template's own tooling must not write system artifacts here. It is disposable and should not contain authored content.
- **ADR** - Architecture Decision Record. A document under `LAW/CONTEXT/decisions/` that captures the context, decision, and rationale for a significant choice.
- **Pack** - A bundled snapshot of repository content produced by the packer. Packs are self-contained and include manifests for integrity verification.
- **Manifest** - A machine-readable inventory listing the contents and hashes of a pack. Used to verify pack integrity on load.
- **Critic** - A validation script that checks code or content against canon rules. Critics run as part of the pre-merge gate.
- **Authority gradient** - The ordered hierarchy of sources that determines which rule takes precedence when conflicts arise. Defined in `LAW/CANON/CONTRACT.md`.
- **Invariant** - A decision that cannot be changed without a major version bump and migration plan. Listed in `LAW/CANON/INVARIANTS.md`.
- **Change ceremony** - The required steps to modify canon: ADR, update canon, add fixtures, bump version, update changelog.
- **Entity** - A record in the cortex index representing a file or concept. Entities have an id, type, title, tags, and paths.
- **Query** - A function in `CAPABILITY/MCP/semantic_adapter.py` (or equivalent) that retrieves entities from the cortex index. Skills must use queries instead of filesystem access.
- **MASTER_OVERRIDE** - A Sovereign directive token that authorizes bypassing repository governance rules for a single prompt, with mandatory audit logging and gated log access.
```

## `repo/LAW/CANON/IMPLEMENTATION_REPORTS.md`

````
<!-- CONTENT_HASH: a1cb23e142abc2a8bdff0d02a24f8e211fb867f0f31395e0992658ea5efd7c05 -->

# Implementation Reports

**Canonical Requirement:** All implementations must produce a signed report.

## Purpose

This document establishes the requirement that **every new implementation** in the Agent Governance System must be documented with a signed report containing:

1. **Agent identity** - Model name and session identifier
2. **Date** - When the implementation was completed
3. **What was built** - Technical summary of the implementation
4. **What was demonstrated** - Verification results and testing
5. **Real vs simulated** - Confirmation that actual data was used
6. **Next steps** - Roadmap progression or follow-up tasks

## Report Format

All implementation reports must follow this standard format:

```markdown
# [Feature Name] Implementation Report

**Date:** YYYY-MM-DD
**Status:** COMPLETE | PARTIAL | FAILED
**Agent:** [model-name]@[system-identifier] | YYYY-MM-DD

---

## Executive Summary

[One-paragraph summary of what was implemented and why it matters]

---

## What Was Built

[Technical details of files, functions, classes, databases, protocols created]

### Files Created
- `path/to/file1.py` - [description]
- `path/to/file2.py` - [description]

### Architecture
```
[Diagrams or code structure if applicable]
```

### Key Features
- [Feature 1]: [description]
- [Feature 2]: [description]

---

## What Was Demonstrated

[Testing results, queries executed, verification performed]

### Test Results
- [Test 1]: ✅ PASS / ❌ FAIL - [details]
- [Test 2]: ✅ PASS / ❌ FAIL - [details]

### Output Examples
```
[Sample output or query results]
```

---

## Real vs Simulated

### Real Data Processing
- Database connections: Direct SQLite / API calls
- Data retrieved: Actual content from [databases/systems]
- Query matching: Content-based / vector-based
- Results displayed: Chunk IDs, headings, content previews

### What's Not Simulation
- No synthetic data generation
- No mocked responses
- No hardcoded test fixtures in production

---

## Metrics

### Code Statistics
- Files created: [number]
- Lines of code: [number]
- Database coverage: [number] chunks/docs

### Performance
- Query latency: [time]
- Indexing throughput: [chunks/sec]
- Token savings: [percentage]

---

## Conclusion

[Summary of success/failure, road to next phase, open questions]

---

**Report Generated:** YYYY-MM-DD
**Implementation Status:** [status]
```

## Required Sections

All reports MUST include:

1. ✅ **Signature Block**
   - Agent identity: `[model-name]@[system-identifier] | YYYY-MM-DD`
   - Format: Markdown heading at top of report

2. ✅ **Executive Summary**
   - High-level overview
   - Why this implementation matters

3. ✅ **What Was Built**
   - Files created with descriptions
   - Architecture diagrams (if applicable)
   - Key features with bullet points

4. ✅ **What Was Demonstrated**
   - Test results with pass/fail status
   - Output examples (code blocks, query results)
   - Verification performed

5. ✅ **Real vs Simulated**
   - Explicit confirmation of real data usage
   - List what's NOT simulation
   - Database/API connections documented

6. ✅ **Metrics**
   - Code statistics
   - Performance numbers
   - Quantitative results

7. ✅ **Conclusion**
   - Status summary
   - Next steps
   - Roadmap progression

## Report Storage

All implementation reports must be stored under:

```
LAW/CONTRACTS/_runs/<feature-name>-implementation-report.md
```

## Examples

- `SEMANTIC_DATABASE_NETWORK_REPORT.md` - Cassette Network Phase 0
- `semantic-core-phase1-final-report.md` - Semantic Core implementation
- `session-report-YYYY-MM-DD.md` - Session documentation

## Enforcement

The `critic.py` tool and governance checks will verify:

1. Reports exist for all implementations
2. Reports are signed (agent + date)
3. Reports contain all required sections
4. Reports are stored in `LAW/CONTRACTS/_runs/`

## Rationale

**Why Signed Reports?**

- **Provenance:** Verifies which agent implemented what and when
- **Auditability:** Enables reconstruction of implementation history
- **Attribution:** Credits the work to the implementing agent
- **Reproducibility:** Records the state of system at implementation time

**Why Implementation Reports?**

- **Documentation:** Captures intent, decisions, and results
- **Governance:** Ensures all work is accounted for and audited
- **Learning:** Provides record of what worked and what didn't
- **Trust:** Demonstrates real data was used, not simulations

---

**Canon Version:** 2.15.1
**Required Canon Version:** >=2.15.1
````

## `repo/LAW/CANON/INDEX.md`

```
<!-- CONTENT_HASH: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1f2 -->

# Canon Index

This directory contains the "Canon"—the laws, rules, and agreements that govern the Agent Governance System.

## The Driver (Foundation)
- [FORMULA.md](./FORMULA.md): The Living Formula. Navigating entropy with symbols that scale.

## The Truth (Foundation)
- [INTEGRITY.md](./INTEGRITY.md): The Catalytic Integrity Stack. Truth is artifacts, not narrative.

## The Constitution (Highest Authority)
- [AGREEMENT.md](./AGREEMENT.md): The separation of liability. Human = Sovereign, Agent = Instrument.
- [CONTRACT.md](./CONTRACT.md): The operational rules and authority gradient.
- [INVARIANTS.md](./INVARIANTS.md): Immutable system truths.
- [SYSTEM_BUCKETS.md](./SYSTEM_BUCKETS.md): The 6-bucket architecture definition.

## Governance Machinery
- [VERSIONING.md](./VERSIONING.md): How rules evolve.
- [CHANGELOG.md](../../CHANGELOG.md): Record of all changes.
- [GLOSSARY.md](./GLOSSARY.md): Defined terms (Stable Token Grammar).

## Processes
- [ARBITRATION.md](./ARBITRATION.md): How to resolve conflicting rules.
- [CATALYTIC_COMPUTING.md](./CATALYTIC_COMPUTING.md): Memory model for scratch-space operations with restore guarantees.
- [CRISIS.md](./CRISIS.md): Emergency procedures.
- [DEPRECATION.md](./DEPRECATION.md): End-of-life workflow for rules.
- [MIGRATION.md](./MIGRATION.md): Managing breaking changes.
- [STEWARDSHIP.md](./STEWARDSHIP.md): Human escalation paths.
- [VERIFICATION_PROTOCOL_CANON.md](./VERIFICATION_PROTOCOL_CANON.md): Mechanical verification requirements for task completion.

## Meta
- [GENESIS.md](./GENESIS.md): The bootstrap prompt.
- [SECURITY.md](./SECURITY.md): Trust boundaries.
- [CODEBOOK.md](./CODEBOOK.md): Compressed reference IDs.
- [INBOX_POLICY.md](./INBOX_POLICY.md): Policy for human-reviewable artifacts.
- [IMPLEMENTATION_REPORTS.md](./IMPLEMENTATION_REPORTS.md): Reporting requirements.
```

## `repo/LAW/CANON/INTEGRITY.md`

```
<!-- CONTENT_HASH: 89c06983d85bcdfb50ed3b6318757b32548d4619d9be9f0fc6e373b4546e5e9d -->

# Integrity Law (CMP/SPECTRUM)

**Essence ($E$):** Truth is found in declared artifacts and deterministic verification, not narrative history.

## 1. CMP-01: Runtime Guard
Every execution MUST pass through the CMP-01 validator.
- **Durable Roots**: `LAW/CONTRACTS/_runs/`, `CORTEX/_generated/`, `MEMORY/LLM_PACKER/_packs/`.
- **Forbidden**: `CANON/`, `AGENTS.md`, `BUILD/`.
- **Pre-run**: Validate JobSpec schema, paths, and forbidden overlaps.
- **Post-run**: Verify every declared durable output exists and is bounded.

## 2. SPECTRUM-01: The Resume Bundle
A run is accepted for resumption ONLY if it produces a verifiable bundle:
- `TASK_SPEC.json` (Immutable JobSpec)
- `STATUS.json` (Success/Failure state)
- `OUTPUT_HASHES.json` (Merkle-tree of produced artifacts)
- `validator_version` (Compatibility gate)

## 3. SPECTRUM-03: Chained Temporal Integrity
Sequential runs form a chain.
- A run may only reference inputs present in the current outputs or previously verified runs in the same chain.
- Any change to a middle run’s output invalidates the entire chain suffix.

## 4. The 5 Invariants of Integrity
1. **Declared Truth**: If an output is durable, it must be declared and hashed.
2. **Disposable State**: Catalytic domains (`_tmp/`) are for work only; they never hold system truth.
3. **Narrative Independence**: History (logs/chats) is a reference only; it is not required for execution success.
4. **Byte-Level Precision**: Tampering is detected at the bit level by SHA-256.
5. **Partial Ordering**: Time is a DAG of sealed checkpoints, not a linear narrative.
```

## `repo/LAW/CANON/INVARIANTS.md`

````
<!-- CONTENT_HASH: 74dcf864da760c316aa031d5419d62d7a4ba9e7978ac77aced5bea9c9091fcfd -->

# Invariants

This file lists decisions that are considered invariant.  Changing an invariant requires an exceptional process (including a major version bump) because it may break compatibility with existing content.

## List of invariants

- **[INV-001] Repository structure** - The top-level directory layout (`LAW`, `CAPABILITY`, `NAVIGATION`, `MEMORY`, `THOUGHT`, `INBOX`) is stable. New directories may be added, but existing ones cannot be removed or renamed without a major version bump and migration plan.
- **[INV-002] Token grammar** - The set of tokens defined in `LAW/CANON/GLOSSARY.md` constitutes a stable interface. Tokens may be added but not removed or changed without deprecation.
- **[INV-003] No raw path access** - Skills may not navigate the filesystem directly. They must query the cortex (`NAVIGATION/CORTEX/semantic/vector_indexer.py` or equivalent API) to find files.
- **[INV-004] Fixtures gate merges** - No code or rule change may be accepted if any fixture fails. Fixtures define the legal behavior.
- **[INV-005] Determinism** - Given the same inputs and canon, the system must produce the same outputs. Timestamps, random values, and external state must be injected explicitly or omitted.
- **[INV-006] Output roots** - System-generated artifacts must be written only to `LAW/CONTRACTS/_runs/`, `NAVIGATION/CORTEX/_generated/`, or `MEMORY/LLM_PACKER/_packs/`. `BUILD/` is reserved for user outputs.
- **[INV-007] Change ceremony** - Any behavior change must add/update fixtures, update the changelog, and occur in the same commit. Partial changes are not valid.
- **[INV-008] Cortex builder exception** - Cortex builders (`NAVIGATION/CORTEX/semantic/*.py`) may scan the filesystem directly. All other skills and agents must query via semantic search or index lookups.
- **[INV-009] Canon readability** - Each file in `LAW/CANON/` must remain readable and focused:
  - Maximum 300 lines per file (excluding examples and templates).
  - Maximum 15 rules per file.
  - If a file exceeds these limits, it must be split via ADR.
- **[INV-010] Canon archiving** - Rules that are superseded or no longer applicable must be:
  - Moved to `LAW/CANON/archive/` (not deleted).
  - Referenced in the superseding rule or ADR.
  - Preserved in git history for audit.
- **[INV-011] Schema Compliance** - All Law-Like files (ADRs, Skills, Style Preferences) must be valid against their respective JSON Schemas in `LAW/SCHEMAS/governance/`.
- **[INV-012] Visible Execution** - Agents must not spawn hidden or external terminal windows (e.g., `start wt`, `xterm`). All interactive or long-running execution must occur via the Antigravity Bridge (invariant infrastructure) or within the current process. The Bridge is considered "Always On".
- **[INV-013] Declared Truth** - Every system-generated artifact MUST be declared in a hash manifest (`OUTPUT_HASHES.json`). If it is not hashed, it is not truth.
- **[INV-014] Disposable Space** - Files under `_tmp/` directories (Catalytic domains) are strictly for scratch-work. They must never be used as a source of truth for verification.
- **[INV-015] Narrative Independence** - Verification Success (`STATUS: success`) is bound only to artifact integrity, not to execution logs, reasoning traces, or chat history.
- **[INV-016] No Verification Without Execution** - An agent may not claim a task is complete unless it executed the required verification commands for that task (from `LAW/CANON/VERIFICATION_PROTOCOL_CANON.md`).
- **[INV-017] Proof Must Be Recorded Verbatim** - A claim is not verified unless proof is recorded verbatim for: `git status`, every required test command, and every required audit command. Summaries are not proof.
- **[INV-018] Tests Are Hard Gates** - A "test" that detects violations while still passing is invalid as a completion gate. If a forbidden condition exists, the gate must fail. Scanner-only "pass with findings" gates are forbidden.
- **[INV-019] Deterministic Stop Conditions** - If any mandatory verification step fails, the agent must: (1) fix within scope, (2) re-run the same commands, (3) record new outputs, (4) repeat until pass. If the agent cannot fix within scope, it must stop and report BLOCKED with a precise reason.
- **[INV-020] Clean-State Discipline** - Verification must be run from a clean state for the scoped paths. If unrelated diffs exist, the agent must stop and report the diffs, revert them, or explicitly scope them into the task.

## Changing invariants

To modify an invariant:

1. File an ADR under `LAW/CONTEXT/decisions/` explaining why the change is necessary and the risks.
2. Propose a migration strategy for affected files and skills.
3. Update the version in `LAW/CANON/VERSIONING.md` (major version bump).
4. Provide fixtures that demonstrate compatibility with both the old and new behavior during the migration period.

## Recovery: Invariant Violation Detection and Remediation

### Where receipts live

Invariant violations are detected and reported in the following locations:

- **LAW/CONTRACTS/_runs/audit_logs/** - Root audit and invariant check results
  - `root_audit.jsonl` - Output from `CAPABILITY/AUDIT/root_audit.py`
  - `canon_audit.jsonl` - Canon compliance and invariant validation
- **LAW/CONTRACTS/_runs/_tmp/** - Temporary receipts for skill and task execution
  - `prompts/*/receipt.json` - Prompt execution receipts (inputs, outputs, hashes)
  - `skills/*/receipt.json` - Skill execution receipts
- **LAW/CONTEXT/decisions/** - Architecture Decision Records for invariant changes
  - ADRs document the rationale for invariant modifications or supersessions

### How to re-run verification

To verify invariant compliance and detect violations:

```bash
# Verify all fixtures pass (invariant INV-004)
python LAW/CONTRACTS/runner.py

# Run root audit (verifies INV-006 compliance)
python CAPABILITY/AUDIT/root_audit.py --verbose

# Run critic to check canon compliance (INV-009, INV-011)
python CAPABILITY/TOOLS/governance/critic.py

# Check canon file line counts and rule counts (INV-009)
python -c "
from pathlib import Path
for f in Path('LAW/CANON').glob('*.md'):
    lines = len(f.read_text().splitlines())
    print(f'{f.name}: {lines} lines')
"
```

### What to delete vs never delete

**Safe to delete (temporary, not source of truth):**
- `LAW/CONTRACTS/_runs/_tmp/` - All subdirectories are disposable scratch space
- `_tmp/` directories anywhere in the repo - Never use as verification source
- Build artifacts in `BUILD/` - User outputs, disposable at any time
- Temporary CAS objects that are unrooted - GC will delete these safely

**Never delete (protected, require ceremony):**
- Files under `LAW/CANON/` - Superseded rules must be moved to `LAW/CANON/archive/`, not deleted
- Rooted CAS objects - Only GC can delete these, and only if unrooted
- `RUN_ROOTS.json` and `GC_PINS.json` - Modify only with explicit ceremony; never delete
- Git history - Preserved for audit; use git bisect for recovery
- ADR records - Append-first; existing records cannot be edited without ceremony

**Recovery procedures:**
- If canon file is accidentally deleted: Restore from git history (`git checkout HEAD~ -- LAW/CANON/file.md`)
- If rooted CAS object is lost: Recover from backup or re-run operation that created it
- If receipt is missing: Re-run skill/task to regenerate; deterministic output will match original receipt
- If invariant violation detected: Check `LAW/CONTEXT/decisions/` for recent ADRs that may explain the change
````

## `repo/LAW/CANON/MIGRATION.md`

````
<!-- CONTENT_HASH: 0a1c692830e9ce6661ed81e25aa9c9b00adf31bd3951fdce4bd949fdce6eb9fe -->

# Migration Ceremony

This document defines the formal process for breaking compatibility in the Agent Governance System. It ensures that breaking changes are predictable, testable, and reversible.

## When This Applies

A **migration ceremony** is required when:
- A major version bump is planned (per `LAW/CANON/VERSIONING.md`).
- A deprecated item is being removed (per `LAW/CANON/DEPRECATION.md`).
- The canon structure is being reorganized.
- Token grammar is changing in a non-backward-compatible way.
- Cortex schema is changing in a way that breaks existing queries.

## The Migration Ceremony

### Phase 1: Preparation

1. **Create a Migration ADR**
   Draft `LAW/CONTEXT/decisions/ADR-xxx-migration-*.md` documenting:
   - What is changing
   - Why the change requires a migration (why it's breaking)
   - The migration path (step-by-step)
   - Rollback plan (if migration fails)

2. **Verify Deprecation Window**
   Confirm that all items being removed have passed their deprecation window (per `LAW/CANON/DEPRECATION.md`).

3. **Create Migration Skill**
   If the migration can be automated, create `CAPABILITY/SKILLS/migrate-vX-to-vY/`:
   ```
   CAPABILITY/SKILLS/migrate-vX-to-vY/
     SKILL.md       # Describes the migration
     run.py         # Executes the migration
     validate.py    # Verifies migration success
     fixtures/
       basic/
         input.json       # Pre-migration state
         expected.json    # Post-migration state
   ```

4. **Create Compatibility Fixtures**
   Before migration, create fixtures that prove:
   - Old path works (baseline)
   - New path works (target)
   - Migration skill converts old to new correctly

### Phase 2: Execution

1. **Announce the Migration**
   Update `LAW/CANON/CHANGELOG.md` with a clear migration notice:
   ```markdown
   ## [2.0.0] - YYYY-MM-DD

   ### ⚠️ BREAKING CHANGES
   - [Description of breaking change]
   - Migration: Run `python CAPABILITY/SKILLS/migrate-v1-to-v2/run.py`
   - See: ADR-xxx for full migration guide
   ```

2. **Execute Migration Skill**
   Run the migration skill on the codebase:
   ```bash
   python CAPABILITY/SKILLS/migrate-vX-to-vY/run.py
   ```

3. **Validate Migration**
   Run the validation script:
   ```bash
   python CAPABILITY/SKILLS/migrate-vX-to-vY/validate.py
   ```
   
   Then run all fixtures:
   ```bash
   python LAW/CONTRACTS/runner.py
   ```

4. **Remove Deprecated Items**
   After validation passes, remove the deprecated items (per `LAW/CANON/DEPRECATION.md` removal ceremony).

5. **Bump Version**
   Increment the major version in `LAW/CANON/VERSIONING.md`.

### Phase 3: Verification

1. **Run Full Test Suite**
   ```bash
   python CAPABILITY/TOOLS/critic.py
   python LAW/CONTRACTS/runner.py
   ```

2. **Verify Cortex**
   Rebuild the cortex and verify queries still work:
   ```bash
   python NAVIGATION/CORTEX/semantic/vector_indexer.py --rebuild
   python CAPABILITY/MCP/semantic_adapter.py --list
   ```

3. **Generate Fresh Pack**
   Create a new pack to verify the packer works with the new structure:
   ```bash
   python MEMORY/LLM_PACKER/Engine/packer.py
   ```

4. **Document Completion**
   Update the Migration ADR with:
   - Completion date
   - Any issues encountered
   - Final validation results

## Rollback

If migration fails at any point:

1. **Stop immediately** — do not proceed with partial migration.
2. **Restore from git** — revert to the pre-migration commit.
3. **Document the failure** in the Migration ADR.
4. **Fix the issue** before attempting again.

Migrations must be atomic. Partial migrations are not acceptable.

## Migration Skill Template

```python
#!/usr/bin/env python3
"""
Migration Skill: vX to vY

This skill migrates the AGS from version X to version Y.
Run with: python CAPABILITY/SKILLS/migrate-vX-to-vY/run.py
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]

def migrate():
    """Execute the migration."""
    # 1. Backup current state (optional, git handles this)
    # 2. Transform files
    # 3. Update references
    # 4. Return success/failure
    pass

def validate():
    """Validate the migration succeeded."""
    # 1. Check expected files exist
    # 2. Check expected content
    # 3. Run critical fixtures
    # Return True if valid, False otherwise
    pass

if __name__ == "__main__":
    success = migrate()
    if not success:
        print("Migration failed!")
        sys.exit(1)
    
    valid = validate()
    if not valid:
        print("Migration validation failed!")
        sys.exit(1)
    
    print("Migration successful!")
    sys.exit(0)
```

## Status

**Active**
Added: 2025-12-21
````

## `repo/LAW/CANON/SECURITY.md`

```
<!-- CONTENT_HASH: f92a5ff086fa2e8aa07c306988e90c17d3fa85987b84356f9f504d654b5ade9d -->

# Security Policy

This document outlines the security considerations for the Agent Governance System. Because AGS may execute code and manage sensitive state, it is important to minimise risk.

## Principles

- **Least privilege** - Skills and tools should run with the minimum permissions required to perform their task.
- **Deterministic outputs** - Randomness and external network calls should be avoided or isolated to prevent non-reproducible behaviour.
- **No external side effects** - Skills must not perform irreversible actions (e.g. network requests, database writes) without explicit authorisation.
- **Auditability** - All changes should be traceable through fixtures, context records and the changelog.

---

## Trust Boundaries

### Agent Read Access

Agents MAY read:
- `CANON/` — rules and invariants
- `CONTEXT/` — decisions, guides, research
- `CONTEXT/maps/` — navigation and entrypoints
- `SKILLS/` — skill definitions and fixtures
- `CONTRACTS/` — fixture definitions
- `CORTEX/query.py` — cortex query API
- `TOOLS/` - tooling scripts
- `MEMORY/` - packer and memory docs
- Root files: `AGENTS.md`, `README.md`
- Planning archive index: `CONTEXT/archive/planning/INDEX.md`

Agents MUST NOT directly read:
- Filesystem paths outside the repository
- `CORTEX/_generated/` (use query API instead)
- User secrets or credentials

### Agent Write Access

Agents MAY write to:
- `LAW/CONTRACTS/_runs/` — fixture execution outputs
- `CORTEX/_generated/` — built indices
- `MEMORY/LLM_PACKER/_packs/` — generated packs
- `BUILD/` — user-owned build outputs

Agents MUST NOT write to:
- `CANON/` — without change ceremony (ADR, fixtures, changelog)
- Root files — without explicit human approval
- Any path outside allowed output roots

### Human Approval Required

The following actions require explicit human approval:
- Modifying any file in `CANON/`
- Adding or removing invariants
- Changing version numbers
- Deleting skills or fixtures
- External network requests
- Installing dependencies

### Sandboxing

When running skills:
1. Skills execute in the repository context only
2. No network access unless explicitly authorized
3. No access to parent directories
4. Time and random values must be injected, not generated

---

## Reporting Vulnerabilities

If you discover a vulnerability in this repository or its processes, please open an issue in the "Security" category or contact the maintainers privately. Do not disclose vulnerabilities publicly until they have been addressed.
```

## `repo/LAW/CANON/STEWARDSHIP.md`

````
<!-- CONTENT_HASH: 20c8a78ad90ccff474e9165c132177e5e07bbe00b4029050a4ca523bd6d1acbe -->

# Stewardship Structure

This document defines the human escalation path when the Agent Governance System itself fails or when decisions exceed agent authority.

## Philosophy

No governance system is complete without a "when governance fails" clause. Stewardship fills this gap:
- Agents are bound by canon, but canon is written by humans
- When agents encounter edge cases, they escalate to stewards
- When canon contradicts itself beyond arbitration, stewards decide
- When crisis occurs, stewards take control

## Roles

### Steward

A **Steward** is a human with authority to:
1. Modify CANON files directly (bypassing ceremony in emergencies)
2. Lift quarantine mode
3. Resolve canon conflicts that exceed ARBITRATION.md procedures
4. Make binding decisions on behalf of the governance system

### Maintainer

A **Maintainer** is a human who can:
1. Propose changes via the normal ceremony
2. Review and approve pull requests
3. Run emergency procedures (but not constitutional reset)
4. Escalate to Steward when needed

### Agent

An **Agent** is an AI system operating under AGS that:
1. Follows canon without deviation
2. Escalates ambiguity to Maintainer
3. Cannot modify CANON without ceremony
4. Must stop and notify on crisis detection

## Escalation Matrix

| Situation | Agent Action | Escalate To |
|-----------|--------------|-------------|
| Task ambiguity | Ask clarifying question | User |
| Canon contradiction | Follow ARBITRATION.md | Maintainer (if unresolvable) |
| Critic/fixture failure | Stop, fix issue | User |
| Quarantine triggered | Stop all work, report | Maintainer |
| Constitutional reset needed | Stop immediately | Steward |
| Canon change requested | Follow ceremony | Maintainer approval |

## Contact Configuration

Stewardship contacts are configured in `.steward.json` (gitignored for privacy):

```json
{
  "stewards": [
    {
      "name": "Primary Steward",
      "email": "steward@example.com",
      "notify_on": ["quarantine", "constitutional-reset"]
    }
  ],
  "maintainers": [
    {
      "name": "Primary Maintainer",
      "email": "maintainer@example.com",
      "notify_on": ["critic-failure", "rollback"]
    }
  ],
  "channels": {
    "slack": "#ags-alerts",
    "discord": "ags-alerts"
  }
}
```

## Escalation Procedure

### Step 1: Agent Detects Issue

Agent encounters a situation outside its authority:
- Canon contradiction not covered by ARBITRATION.md
- Security concern
- Unclear user intent that could violate canon

### Step 2: Agent Stops and Documents

Agent MUST:
1. Stop the current action
2. Document the issue in `LAW/CONTEXT/open/`
3. Notify the user of the escalation
4. Wait for human response

### Step 3: Human Reviews

Maintainer or Steward:
1. Reviews the open question
2. Makes a decision
3. Documents the decision in an ADR
4. Optionally updates canon if the case is generalizable

### Step 4: Resolution

Agent receives the decision and can proceed.

## Engineering Culture

The following engineering practices are **mandatory** for all code contributions to AGS:

### 1. No Bare Excepts
**Rule**: Never use `except:` without specifying the exception type.

```python
# ❌ FORBIDDEN
try:
    risky_operation()
except:
    pass

# ✅ REQUIRED
try:
    risky_operation()
except (ValueError, KeyError) as e:
    logger.error(f"Operation failed: {e}")
    raise
```

**Rationale**: Bare excepts mask critical errors (KeyboardInterrupt, SystemExit) and make debugging impossible.

### 2. Atomic Writes
**Rule**: All file writes MUST use temp-write + atomic rename.

```python
# ❌ FORBIDDEN
with open("output.json", "w") as f:
    json.dump(data, f)

# ✅ REQUIRED
import tempfile, os
fd, tmp = tempfile.mkstemp(dir=os.path.dirname("output.json"))
try:
    with os.fdopen(fd, 'w') as f:
        json.dump(data, f)
    os.replace(tmp, "output.json")  # Atomic on POSIX
except:
    os.unlink(tmp)
    raise
```

**Rationale**: Prevents partial writes that corrupt state during crashes.

### 3. Headless Execution
**Rule**: No code may spawn visible terminal windows (see ADR-029).

**Enforcement**: `CAPABILITY/TOOLS/terminal_hunter.py` scans for violations.

### 4. Deterministic Outputs
**Rule**: All artifacts (JSON, manifests, hashes) MUST be deterministic across runs.

**Requirements**:
- Sorted keys in JSON (`sort_keys=True`)
- Stable iteration order (sorted lists, OrderedDict)
- No timestamps in filenames (use content hashes or explicit versioning)

### 5. Safety Caps
**Rule**: All loops and recursive operations MUST have explicit bounds.

**Examples**:
- Max iterations: `for i in range(MAX_CYCLES):`
- Max file size: `if size > MAX_BYTES: raise`
- Timeout: `subprocess.run(..., timeout=30)`

**Rationale**: Prevents infinite loops, resource exhaustion, and runaway processes (see ADR-029 Terminator Mode incident).

### 6. Database Connections
**Rule**: Always use context managers or explicit cleanup for database connections.

```python
# ❌ FORBIDDEN
db = sqlite3.connect("data.db")
cursor = db.execute("SELECT * FROM table")
# Connection may leak

# ✅ REQUIRED
with sqlite3.connect("data.db") as conn:
    cursor = conn.execute("SELECT * FROM table")
    # Auto-commit and close

# OR (for classes)
class MyDB:
    def __init__(self, path):
        self.conn = sqlite3.connect(path)
    
    def close(self):
        self.conn.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()
```

**Additional Requirements**:
- Set `conn.row_factory = sqlite3.Row` for dict-like access
- Use parameterized queries (`?` placeholders) to prevent SQL injection
- Call `conn.commit()` explicitly after writes
- On Windows: Add `time.sleep(0.5)` after `close()` before unlinking DB files

**Rationale**: Prevents file handle leaks, ensures transactions commit, avoids Windows file locking issues.

### 7. Never Bypass Tests
**Rule**: Never use `--no-verify` or skip pre-commit hooks. Fix the root cause.

```bash
# ❌ FORBIDDEN
git commit --no-verify -m "quick fix"

# ✅ REQUIRED
# 1. Identify why hook fails
# 2. Fix the underlying issue
# 3. Commit normally
git commit -m "fix: proper commit with tests passing"
```

**Rationale**: Bypassed tests lead to broken CI. The 2025-12-28 `export_to_json` incident occurred because a function was assumed to exist but was never implemented. Pre-commit hooks exist to catch such issues early.

### 8. Cross-Platform Scripts
**Rule**: All shell scripts must work on both Linux/macOS and Windows (Git Bash).

**Requirements**:
- Python: Use `python3 || python` fallback (Windows lacks `python3`)
- Paths: Use forward slashes or `Path()` objects
- Line endings: Configure `.gitattributes` for `* text=auto`
- Commands: Avoid `command -v` (unreliable in Git's Windows shell)

```bash
# ✅ Cross-platform Python detection
if python3 --version >/dev/null 2>&1; then
    PYTHON_CMD="python3"
elif python --version >/dev/null 2>&1; then
    PYTHON_CMD="python"
else
    echo "ERROR: No Python found"; exit 1
fi
```

**Rationale**: CI runs on Linux but developers use Windows. Scripts must work everywhere.

### 9. Interface Regression Tests
**Rule**: When Module A imports and calls Module B, there MUST be a test verifying B's interface.

```python
# ✅ REQUIRED: test_query.py
def test_export_to_json_exists():
    """Verify export_to_json function exists in query module."""
    import query as cortex_query
    assert hasattr(cortex_query, 'export_to_json'), \
        "query module must have export_to_json() (required by cortex.build.py)"
```

**Rationale**: The 2025-12-28 CI failure occurred because `cortex.build.py` called `query.export_to_json()` which was never implemented. A simple existence test would have caught this before merge.

### 10. Amend Over Pollute
**Rule**: When actively fixing the same issue across multiple iterations, amend the previous commit instead of creating new ones.

```bash
# ❌ FORBIDDEN (commit pollution)
git commit -m "fix: attempt 1"
git commit -m "fix: attempt 2"  
git commit -m "fix: final fix"

# ✅ REQUIRED (clean history)
git commit -m "fix: initial attempt"
# ...make more fixes...
git add .
git commit --amend -m "fix: complete solution"
git push --force-with-lease
```

**When to Amend**:
- Same logical fix, multiple iterations
- Not yet reviewed by others
- Within the same work session

**When NOT to Amend**:
- Different logical changes
- Already reviewed/merged
- Shared branches with active collaborators

**Rationale**: Commit history should tell a clear story. "fix, fix again, really fix, final fix" obscures intent. One clean commit per logical change.

### 11. Repository Hygiene
**Rule**: The repository MUST remain clean of ephemeral trash.

**Requirements**:
- **Logs**: MUST go to `LAW/CONTRACTS/_runs/` or designated `logs/` folders. Never root.
- **Temp Files**: `*.tmp`, `*.bak`, `*.swp` MUST be ignored or deleted immediately.
- **Cache**: `__pycache__` MUST be gitignored and regularly purged.
- **Old Runs**: `LAW/CONTRACTS/_runs/` should be pruned of stale test artifacts.

**Tooling**: Run `python CAPABILITY/TOOLS/cleanup.py` to enforce this.

**Rationale**: A cluttered repository hides real issues and bloats git history with garbage. Cleanliness is godliness (and governance).

## Authority Boundaries

### What Agents CAN Do

- Execute approved skills
- Create new files (non-canon)
- Propose ADRs for review
- Query context and cortex
- Run validation tools
- Report issues

### What Agents CANNOT Do

- Modify LAW/CANON/* files directly (bypassing ceremony in emergencies)
- Lift quarantine mode
- Bypass the commit ceremony
- Ignore critic failures
- Make constitutional decisions
- Override explicit user denial

### What Only Stewards CAN Do

- Constitutional reset
- Emergency canon modification
- Permanent agent restrictions
- Dissolve the governance system

## Emergency Steward Actions

In a constitutional crisis, stewards may:

1. **Direct Canon Edit**: Modify CANON files directly without ceremony (document afterward)
2. **Agent Termination**: Instruct agents to cease all operations
3. **System Reset**: Restore to a known-good tagged release
4. **Governance Suspension**: Temporarily suspend normal governance (document extensively)

All emergency actions MUST be documented in `LAW/CONTRACTS/_runs/steward_logs/steward-actions.log` (see ADR-015).

## Template: Steward Decision Record

```markdown
# Steward Decision: [Date] - [Title]

## Situation
[What happened that required steward intervention]

## Decision
[What the steward decided]

## Rationale
[Why this decision was made]

## Actions Taken
- [ ] Action 1
- [ ] Action 2

## Follow-up Required
- [ ] Update canon?
- [ ] Create ADR?
- [ ] Notify stakeholders?

## Steward: [Name]
```

---

Added: 2025-12-21
````

## `repo/LAW/CANON/SYSTEM_BUCKETS.md`

```
<!-- CONTENT_HASH: 36e1b2bc23a1f9d5e7c8a9b2d3f4e5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2 -->

# SYSTEM BUCKETS

**Authority:** LAW/CANON  
**Version:** 2.0.0 (6-Bucket Migration)

This document defines the classification buckets of the Agent Governance System (AGS).
**All files and artifacts MUST belong to exactly one bucket.**

---

## 1. LAW (Supreme Authority)

**Purpose:** Define what is allowed. The "Constitution" and "Legislation" of the system.

**Key Directories:**
- `LAW/CANON/` - Constitutional rules (Invariants, Contract, Glossary).
- `LAW/CONTEXT/` - Decision trace (ADRs) and Preferences.
- `LAW/CONTRACTS/` - Mechanical enforcement (Schemas, Fixtures, Precedent).
- `AGENTS.md` - Operating contract.

**Prohibitions:**
- No execution logic (scripts).
- No speculative research.
- No history distortion.

---

## 2. CAPABILITY (Instruments)

**Purpose:** Define what the system can do. The "Tools" and "Skills" of the agents.

**Key Directories:**
- `CAPABILITY/SKILLS/` - Atomic agent toolkits.
- `CAPABILITY/TOOLS/` - Helper scripts, critics, and automation.
- `CAPABILITY/MCP/` - Client adapters and Semantic Core logic.
- `CAPABILITY/PIPELINES/` - DAG definitions.
- `CAPABILITY/PRIMITIVES/` - Low-level execution logic.
- `CAPABILITY/TESTBENCH/` - Validation suites.

**Prohibitions:**
- No self-authored governance rules.
- No navigation planning (Roadmaps).

---

## 3. NAVIGATION (Direction & Cortex)

**Purpose:** Define where we are going and how to find things. Consolidates the old **DIRECTION** and **CORTEX** buckets.

**Key Directories:**
- `NAVIGATION/MAPS/` - Ownership and data flow maps.
- `NAVIGATION/ROADMAPS/` - Master strategy and lane tracking.
- `NAVIGATION/CORTEX/` - Semantic index and metadata.

**Operations:**
- **Index**: Build semantic models.
- **Map**: Define repo boundaries.
- **Orient**: Update roadmaps to reflect completion.

---

## 4. MEMORY (Historical Trace)

**Purpose:** Record what has happened across sessions.

**Key Directories:**
- `MEMORY/LLM_PACKER/` - Context compression and archive storage.
- `LAW/CONTEXT/archive/` - Archived decision history.
- `LAW/CONTRACTS/_runs/` - Temporary logs/outputs (Disposable but traceable).

**Prohibitions:**
- No new planning (Roadmaps).
- No modified rules.

---

## 5. THOUGHT (Experimental Labs)

**Purpose:** Explore possibilities and build prototypes without risking system stability.

**Key Directories:**
- `THOUGHT/LAB/` - Volatile features (e.g., `CAT_CHAT`, `NEO3000`, `TURBO_SWARM`).
- `THOUGHT/CONTEXT/` - Lab-specific research and notes.

**Prohibitions:**
- No binding force on the main system.
- No production dependencies.

---

## 6. INBOX (Human Gate)

**Purpose:** Centralized location for artifacts requiring human review or "God Mode" approval.

**Key Directories:**
- `INBOX/reports/` - Mandatory completion reports.
- `INBOX/research/` - In-progress study and findings.
- `INBOX/roadmaps/` - Roadmaps currently under review.
- `INBOX/decisions/` - Proposed policy/ADR changes.

---

## Directory → Bucket Mapping (V2)

| Directory | Bucket | Authority |
|-----------|--------|-----------|
| `LAW/CANON/` | **LAW** | SUPREME |
| `LAW/CONTEXT/` | **LAW** | SUPREME |
| `LAW/CONTRACTS/` | **LAW** | SUPREME |
| `AGENTS.md` | **LAW** | SUPREME |
| `CAPABILITY/SKILLS/` | **CAPABILITY** | INSTRUMENT |
| `CAPABILITY/TOOLS/` | **CAPABILITY** | INSTRUMENT |
| `CAPABILITY/MCP/` | **CAPABILITY** | INSTRUMENT |
| `CAPABILITY/TESTBENCH/` | **CAPABILITY** | INSTRUMENT |
| `NAVIGATION/MAPS/` | **NAVIGATION** | DIRECTION |
| `NAVIGATION/ROADMAPS/` | **NAVIGATION** | DIRECTION |
| `NAVIGATION/CORTEX/` | **NAVIGATION** | DIRECTION |
| `MEMORY/LLM_PACKER/` | **MEMORY** | HISTORY |
| `MEMORY/_packs/` | **MEMORY** | HISTORY |
| `THOUGHT/LAB/` | **THOUGHT** | EXPERIMENT |
| `INBOX/` | **INBOX** | GATE |

---

## Enforcement

Agents MUST:
1. Identify the target bucket before creating or moving a file.
2. Use the correct prefix (`LAW/`, `CAPABILITY/`, etc.) for all new components.
3. Treat files in `INBOX` as "Requests for Review" until moved to their final bucket.
```

## `repo/LAW/CANON/VERIFICATION_PROTOCOL_CANON.md`

```
# Verification Protocol
**Status:** CANON  
**Applies to:** Any task that modifies production code, enforcement primitives, receipts, fixtures, tests, schemas, or governance gates.  
**Exemptions:** Documentation-only changes (see `CANON/DOCUMENT_POLICY.md` for exempt paths: `LAW/CANON/*`, `LAW/CONTEXT/*`, `INBOX/*`, etc.) do not require full verification protocol unless they modify enforcement logic.  
**Goal:** Make correctness mechanical. Prevent “looks done” work. Ensure every completion claim is reproducible from command outputs and artifacts.

## Core principle
A catalytic system runs on **mechanical truth**, not intent.

- Narratives are cheap.  
- Proof is reproducible.  
- Verification is a loop, not a sentence.

If a claim cannot be reproduced from **commands, outputs, and receipts**, it is not verified.

## Relationship to existing invariants

This protocol reinforces and operationalizes several core invariants:

- **[INV-007] Change ceremony** (`CANON/INVARIANTS.md`) - Verification ensures that behavior changes include updated fixtures, changelog entries, and proof of correctness in the same commit.
- **[INV-013] Declared Truth** (`CANON/INVARIANTS.md`) - Verification outputs must be declared in hash manifests; if not hashed, it's not truth.
- **[INV-015] Narrative Independence** (`CANON/INVARIANTS.md`) - Verification success is bound to artifact integrity (receipts, test outputs, git status), not to reasoning traces or chat history.

The Verification Protocol makes these invariants **mechanically enforceable** by requiring verbatim proof and hard gates.

## Definitions
- **Verified:** All required checks executed and passed, with proof recorded.
- **Proof:** Verbatim command outputs captured in canonical artifacts (and optionally pasted inline).
- **Fail-closed:** Any ambiguity or failed check stops the task.
- **Clean state:** No unrelated diffs in the scoped paths before verification.

## Canonical invariants
### INV-VP-001: No verification without execution
An agent may not claim a task is complete unless it executed the required verification commands for that task.

### INV-VP-002: Proof must be recorded verbatim
A claim is not verified unless proof is recorded verbatim for:
- `git status`
- every required test command
- every required audit command (linters, formatters, schema checks, rg/grep gates), if any

**Summaries are not proof.**

### INV-VP-003: Tests are hard gates
A “test” that detects violations while still passing is invalid as a completion gate.

If a forbidden condition exists, the gate **must fail**.  
If the gate passes, it means **no violations remain in scope**.

Scanner-only “pass with findings” gates are forbidden.

### INV-VP-004: Deterministic stop conditions
If any mandatory verification step fails, the agent must:
1) fix (within scope), then  
2) re-run the same command(s), then  
3) record the new outputs, then  
4) repeat until pass

If the agent cannot fix within scope, it must stop and report **BLOCKED** with a precise reason.

### INV-VP-005: Clean-state discipline
Verification must be run from a clean state for the scoped paths.

If unrelated diffs exist, the agent must do one:
- STOP and report the diffs, or
- revert them, or
- explicitly scope them into the task (and record that change)

No verification on a polluted tree.

## Definition of Done
A task is **VERIFIED COMPLETE** only when all are true:

1) **Scope respected**
- No files changed outside allowed paths.

2) **Clean-state check passed**
- `git status` is clean except for explicitly scoped changes.

3) **All required tests pass**
- Includes task-specific tests and any broader suite required by the task contract.

4) **All required audits pass**
- Includes rg/grep enforcement gates, schema validations, linting, formatting, and any task-specific audits.

5) **Proof recorded**
- Outputs for each command are recorded verbatim in canonical artifacts.

Otherwise, the status is **PARTIAL** or **BLOCKED**.

## Where proof must live
All proof must live under canonical run artifacts, not INBOX.

Recommended structure (use existing repo conventions where applicable):
- `LAW/CONTRACTS/_runs/REPORTS/<phase>/<task>_report.md`
- `LAW/CONTRACTS/_runs/RECEIPTS/<phase>/<task>_receipt.json`
- `LAW/CONTRACTS/_runs/LOGS/<phase>/<task>/` (optional but recommended)

### Token-sustainable rule for large outputs
If outputs are too large to paste inline in a report:
- Save the full verbatim output to a log file under `_runs/LOGS/...`
- In the report, include:
  - log path
  - byte size
  - sha256 of the log file
  - first 100 lines and last 100 lines (verbatim)

This preserves mechanical truth without wasting tokens.

## Mandatory Verification Contract (copy into every task prompt)
> **VERIFICATION CONTRACT (NON-NEGOTIABLE)**  
> You must follow this loop until completion.

### STEP 0: CLEAN STATE
Run:
- `git status`

Rules:
- If changes exist outside allowed scope, STOP and report.

Record:
- verbatim `git status` output (inline or log + hash).

### STEP 1: RUN REQUIRED TESTS
Run the exact test commands listed in the task.

Rules:
- Record the full outputs verbatim (inline or log + hash).
- Exit codes must be recorded.
- If any command is skipped, the task cannot be VERIFIED COMPLETE.

### STEP 2: IF ANY FAILURES
If any test or audit fails:
- fix code (within scope only)
- re-run the same command(s)
- record the new outputs verbatim
Repeat until all required checks pass or BLOCKED is reached.

### STEP 3: RUN REQUIRED AUDITS (IF ANY)
If the task includes audits (rg/grep, schema checks, lint, formatting):
- run them exactly
- record outputs verbatim
- audits must be hard gates (no “warn but pass”)

**Standard audit commands available:**
- `python CAPABILITY/AUDIT/root_audit.py --verbose` - Verifies INV-006 (output roots compliance)
- `python CAPABILITY/TOOLS/governance/critic.py` - Checks canon compliance (INV-009, INV-011)
- `python LAW/CONTRACTS/runner.py` - Runs all fixtures (INV-004: fixtures gate merges)
- `rg` or `grep` enforcement gates - Custom pattern searches for forbidden constructs
- Schema validation - JSON schema checks for governance objects

### STEP 4: FINAL REPORT (STRICT)
Final report must include:
- `git status` output (or log reference + hash)
- list of files changed
- exact commands executed
- full outputs for tests and audits (or log references + hashes)
- final status: **VERIFIED COMPLETE | PARTIAL | BLOCKED**
- if PARTIAL: remaining violations with file:line
- if BLOCKED: precise constraint and the minimal change needed to unblock

You are forbidden from using “complete/done/verified” language unless status is **VERIFIED COMPLETE**.

## Gate test requirements
If a task involves enforcement (firewalls, receipts, invariants, pruning, domain safety), it must include at least one gate test with this semantic:

- It must **fail** if the forbidden condition exists.
- It must **pass only** when the forbidden condition is absent.

Examples:
- “No raw writes remain in scope”
- “No forbidden domain writes”
- “Commit gate blocks durable writes pre-commit”
- “PRUNED never appears when emit_pruned=false”
- “Repo digest unchanged on failure”

## Forbidden anti-patterns
These are disallowed in CANON tasks:

- A scanner prints violations but exits 0
- A test exists but is not wired into pytest or the gate
- An agent reports “tests pass” without recorded outputs
- An agent runs a different test set than requested
- An agent changes scope to make tests pass
- An agent declares success while any mandatory command exits nonzero

## Standard final report template (required)
Use this structure exactly:

### FINAL REPORT

#### 1) Scope + clean state
- Allowed scope:
- `git status`:
- (paste verbatim, or provide LOG path + sha256 + size + head and tail excerpts)

#### 2) Files changed
- (list)

#### 3) Commands executed
- (exact commands)

#### 4) Test outputs
- (paste verbatim, or LOG references + hashes)

#### 5) Audit outputs
- (paste verbatim, or LOG references + hashes)

#### 6) Result
- Status: VERIFIED COMPLETE | PARTIAL | BLOCKED
- If PARTIAL: remaining violations (file:line)
- If BLOCKED: precise blocker and minimal change needed to unblock

## Recommended integration points
To make this automatic, require the Verification Contract block in:
- every agent prompt template
- every task prompt that touches invariants or production behavior
- every roadmap phase that can change production behavior

If a prompt lacks the contract, it is malformed for execution work.
```

## `repo/LAW/CANON/VERSIONING.md`

````
<!-- CONTENT_HASH: 648a22830edaa1fac73bb5b77b37be17dd77145500e738eede3c16095d675f90 -->

# Versioning

This file defines the versioning policy for the Agent Governance System.  It tracks changes to the canon and describes the compatibility guarantees provided by each version.

## Canon version

```
canon_version: 3.0.0
```

The version consists of three numbers:

- **Major** - Incremented when breaking changes are introduced (e.g. removing or renaming tokens, changing invariants).
- **Minor** - Incremented when new, backward-compatible rules or tokens are added.
- **Patch** - Incremented for clarifications or fixes that do not affect behavior.

## Compatibility contracts

- **Tokens** - Within a minor version series, existing tokens remain valid.  Tokens may be added but not removed.  Breaking changes require a major version bump and a migration strategy.
- **Skills** - Each skill declares a `required_canon_version` range in its manifest.  A skill must check that the loaded canon version falls within this range before running.

## Deprecation policy

When deprecating a token or rule:

1. Add a note in this file documenting the deprecation and its replacement.
2. Provide migration scripts or skills in `TOOLS/` to help update content.
3. Maintain compatibility for at least one minor version.
````

## `repo/LAW/CANON/swarm_config.json`

```
{
    "version": "1.0.0",
    "description": "Swarm configuration - defines which models fill each role",
    "roles": {
        "president": {
            "description": "God - The User - Final authority and source of intent",
            "current_implementation": "Human (User)",
            "cli": "VSCode / Terminal",
            "notes": "Ultimate decision maker, can override any agent"
        },
        "governor": {
            "description": "SOTA AI - Complex decisions, strategic planning, governance",
            "current_implementation": "Claude Sonnet 4.5 (Main Agent)",
            "cli": "Antigravity / VSCode Chat",
            "notes": "Most capable model, handles complex tasks, delegates to Manager"
        },
        "manager": {
            "description": "CLI coordinator - breaks tasks into subtasks, dispatches to Ants",
            "current_implementation": "Qwen 2.5:7b (via Kilo CLI)",
            "cli": "kilo",
            "notes": "Cannot do complex tasks, delegates mechanical work to Ants"
        },
        "ant_worker": {
            "description": "Stateless executor - follows templates, no creativity",
            "current_implementation": "Local (LFM2-2.6B Autonomous Agent)",
            "cli": "python CATALYTIC-DPT/SKILLS/ant-worker/scripts/ant_agent.py",
            "count": 2,
            "notes": "Polls MCP Ledger for tasks"
        }
    },
    "alternatives": {
        "president": [
            "Human (always)",
            "No alternatives - humans only"
        ],
        "governor": [
            "Claude Sonnet 4.5 (SOTA)",
            "Claude Opus 4.5",
            "GPT-4",
            "Gemini Pro"
        ],
        "manager": [
            "Qwen 2.5:7b",
            "Qwen 2.5:14b",
            "Llama 3.1:8b",
            "Gemini Flash"
        ],
        "ant_worker": [
            "Grok",
            "Haiku",
            "Llama",
            "Mistral",
            "Local Ollama"
        ]
    },
    "mcp_server": {
        "host": "localhost",
        "port": 8765,
        "ledger_path": "LAW/CONTRACTS/_runs"
    }
}
```

## `repo/LAW/CONTEXT/README.md`

```
<!-- CONTENT_HASH: aa8752dad68e92e8099a757d34638b5d4441ce51ae3435cbe85b242574b8db9a -->

# Context

**Essence ($E$):** The long-term memory and decision record of the Agent Governance System.

| Directory | Content Type | Entropy ($\nabla S$) | Handling |
|-----------|--------------|----------------------|----------|
| `decisions/` | ADRs (Law) | Low | Append-only. Reference `@D{N}`. |
| `preferences/` | Styles/Guides | Low | Append-only. |
| `research/` | Active Inquiries | Medium | Move to `archive/` when done. |
| `archive/` | History | High | Compressed storage. |
| `feedback/` | Driver Reports | Medium | Feedback loops. |

## Usage
- **Read**: Use `cortex search` or `review_context.py` (Tool) to query.
- **Write**: Only append new records. Do not rewrite history unless correcting factual errors in metadata.
```

## `repo/LAW/CONTEXT/decisions/ADR-000-template.md`

```
---
id: "ADR-000"
title: "Title Goes Here"
status: "Proposed"
date: "2025-12-19"
confidence: "Low"
impact: "Low"
tags: ["architecture"]
---

<!-- CONTENT_HASH: 37df89aa3ab6a9dbd1e3e108bfe0caf93d5afa71d6fc08b4be90e08588b89a5b -->

# ADR-000: Title Goes Here

## Context

Describe the problem that led to this decision.  Explain the forces at play, any constraints and the goals.

## Decision

Describe the chosen solution in clear terms.  Explain what is being decided and how it will be implemented.

## Alternatives considered

List other options that were considered and why they were not chosen.

## Rationale

Explain the reasoning behind the decision. Why is this the best option given the context? What trade-offs were made?

## Consequences

Describe the expected effects of this decision, both positive and negative. Note any follow-up work required.

## Enforcement

List any canon rules, fixtures or skill constraints that must be updated to enforce this decision.

## Review triggers

State conditions under which this decision should be revisited (e.g. new data, upcoming version changes).
```

## `repo/LAW/CONTEXT/decisions/ADR-001-build-and-artifacts.md`

```
---
id: "ADR-001"
title: "BUILD is user output, artifacts are subsystem-owned"
status: "Accepted"
date: "2025-12-20"
confidence: "Medium"
impact: "Medium"
tags: ["architecture", "artifacts"]
---

<!-- CONTENT_HASH: 615d67501c391a6af686bed7dd830fc136279982b60c9e831c973cda1fe27ed2 -->

# ADR-001: BUILD is user output, artifacts are subsystem-owned

## Context

The initial scaffold treated `BUILD/` as the output root for system-generated artifacts (fixtures, cortex index, packs).

The intended meaning of `BUILD/` in this template is "dist for users": it is where template users may place their own build outputs. System tooling should not write internal artifacts there.

## Decision

- Reserve `BUILD/` for user build outputs.
- Write system-generated artifacts near their subsystem:
  - `CONTRACTS/_runs/` for fixture runner outputs
  - `CORTEX/_generated/` for the cortex index
  - `MEMORY/LLM_PACKER/_packs/` for memory and LLM handoff packs
- Include only an inventory of `BUILD/` (file tree) in packs, not its contents.

## Alternatives considered

- Keep a single centralized artifact root in `BUILD/`.
- Introduce a new top-level artifact directory.

## Rationale

Subsystem-owned artifact roots keep outputs colocated with the code that generates them, improve navigation, and prevent `BUILD/` from becoming a mixed-purpose dumping ground.

## Consequences

- Scripts and docs must be updated to match the new locations.
- Existing generated artifacts under `BUILD/` are treated as legacy and disposable.

## Enforcement

- Update `CANON/CONTRACT.md` output roots rule.
- Update `AGENTS.md` mutation and output rules.
- Update `.gitignore` to ignore new artifact roots while keeping their directories tracked.
- Update fixtures so `python CONTRACTS/runner.py` proves pack generation and output location behavior.

## Review triggers

- A need arises for a centralized artifact cache.
- The template introduces a build system that requires a different output convention.
```

## `repo/LAW/CONTEXT/decisions/ADR-002-llm-packs-under-llm-packer.md`

```
---
id: "ADR-002"
title: "Store packs under MEMORY/LLM_PACKER"
status: "Accepted"
date: "2025-12-20"
confidence: "Medium"
impact: "Low"
tags: ["artifacts", "memory"]
---

<!-- CONTENT_HASH: cf3bbd951f67a8819df8cc3bae5ae6ae74f9861ac7b34af237d481825f83fe07 -->

# ADR-002: Store packs under MEMORY/LLM_PACKER

## Context

Packs are generated artifacts and should live near the subsystem that owns them. The LLM packer lives under `MEMORY/LLM_PACKER/`, but the initial implementation wrote packs under `MEMORY/_packs/`.

## Decision

- The canonical packs are stored in **`MEMORY/LLM_PACKER/_packs/`**.
- Within `_packs/`, non-pack artifacts (fixtures, baselines, archives) are stored under `_packs/_system/`.
- Delta baseline state is stored under `MEMORY/LLM_PACKER/_packs/_system/_state/`.

## Alternatives considered

- Keep packs under `MEMORY/_packs/`.
- Move packs to a top-level artifact directory.

## Rationale

Colocating packs with the LLM packer keeps the repository modular and reduces ambiguity about what owns the format and lifecycle of packs.

## Consequences

- Docs, fixtures, and canon output roots must reference the new location.
- Existing ignored pack artifacts under the old path are treated as legacy and disposable.

## Enforcement

- `python CONTRACTS/runner.py` includes smoke fixtures that assert pack outputs are created under `MEMORY/LLM_PACKER/_packs/` (fixtures should write to `_packs/_system/`).

## Review triggers

- Packs become shared infrastructure across multiple subsystems.

## Amendment (2025-12-25)

This ADR is amended to clarify the convention inside the existing invariant output root (`MEMORY/LLM_PACKER/_packs/`): keep user packs and fixture packs in separate subfolders to reduce navigation clutter without changing output-root invariants.
```

## `repo/LAW/CONTEXT/decisions/ADR-003-transition-to-llm-packer-underscore.md`

```
---
id: "ADR-003"
title: "Transition to LLM_PACKER for Python Compatibility"
status: "Accepted"
date: "2025-12-21"
confidence: "High"
impact: "High"
tags: ["governance", "packaging"]
---

<!-- CONTENT_HASH: 967819bd25016010f544d4e374c2113e03e85eb7e7ab1e9e12ab2f345342946c -->

# ADR-003: Transition to LLM_PACKER for Python Compatibility

**Deciders:** Antigravity (Agent), User
## Context
The repository previously used the directory `MEMORY/LLM-PACKER/` for system-generated packs. This naming convention (hyphenated) prevented Python from importing the core engine as a package, causing "ModuleNotFoundError" in GitHub CI environments that require strict import validation.

## Decision
We will rename `MEMORY/LLM-PACKER/` to `MEMORY/LLM_PACKER/` (underscore).

This change facilitates:
1.  Clean, direct Python imports from `MEMORY.LLM_PACKER.Engine`.
2.  Resolution of CI pipeline failures without resorting to path hacks or temporary scripts.
3.  Alignment with PEP 8 naming conventions for packages.

## Consequences
- **Breaking Change**: Any existing external references or absolute paths pointing to `LLM-PACKER` must be updated.
- **Major Version Bump**: Per `INV-001`, a rename of a system output root requires a major version bump. The system version will move from `1.0.0` to `1.1.0`.
- **Artifact Root Update**: `INV-006` and `SECURITY.md` must be updated to reflect the new valid write root.
```

## `repo/LAW/CONTEXT/decisions/ADR-004-mcp-integration.md`

```
---
id: "ADR-004"
title: "Model Context Protocol (MCP) Integration"
status: "Accepted"
date: "2025-12-21"
confidence: "High"
impact: "High"
tags: ["integration", "protocol", "architecture"]
---

<!-- CONTENT_HASH: b0893e86492deb00f8420a0f12a22a8583a49830b3fbd10a46741c634de7c2fc -->

# ADR-004: Model Context Protocol (MCP) Integration

**Deciders:** Antigravity (Agent), User
## Context

The Agent Governance System (AGS) needs a standardized way to expose its tools (`cortex_query`, `policy_check`, `context_search`) to external LLM clients (like Claude Desktop or IDE extensions) without rewriting custom glue code for every client.

## Decision

We will implement the **Model Context Protocol (MCP)** specification.

1.  **Transport**: We will use `stdio` (Standard Input/Output) as the transport layer. This is the simplest and most robust method for local desktop integration.
2.  **Server Location**: The implementation will reside in `CAPABILITY/MCP/server.py` and `CAPABILITY/MCP/schemas/`.
    - The recommended runtime entrypoint is `LAW/CONTRACTS/ags_mcp_entrypoint.py` to keep audit logs under allowed output roots.
3.  **Governance Integration**: We will expose governance-critical tools (`critic`, `ceremony`) via MCP, turning the IDE into a governed environment.
4.  **Verification**: MCP readiness is verified via `mcp-smoke` (CLI) and `mcp-extension-verify` (extension checklist).

## Alternatives considered

- **REST API (FastAPI)**:
    - *Pros*: Standard HTTP tech.
    - *Cons*: Requires port management, firewall rules, and more complex auth for local desktop use.
- **Custom CLI JSON Interface**:
    - *Pros*: We already partially have this.
    - *Cons*: Not interoperable with standard AI clients.

## Rationale

MCP is emerging as the standard for connecting AI models to local context. Adopting it aligns AGS with the broader ecosystem and allows "Code-Less" integration with any MCP-compliant client.

## Consequences

- **Dependency**: We implicitly depend on the stability of the MCP spec.
- **Security**: Exposing `run_command` or file write tools via MCP requires strict `critic` gates (implemented via `heuristic_safe` flags).
- **Audit Logs**: When launched via the wrapper entrypoint, MCP audit logs are written to `LAW/CONTRACTS/_runs/mcp_logs/`.

## Enforcement

- All new external tools must be added to `CAPABILITY/MCP/schemas/tools.json`.
- The `CAPABILITY/MCP/server.py` implementation is the reference implementation.
- MCP verification uses the `mcp-smoke` and `mcp-extension-verify` skills.
```

## `repo/LAW/CONTEXT/decisions/ADR-005-persistent-research-cache.md`

```
---
id: "ADR-005"
title: "Persistent Research Cache"
status: "Accepted"
date: "2025-12-21"
confidence: "High"
impact: "Medium"
tags: ["research", "optimization", "persistence"]
---

<!-- CONTENT_HASH: 4cc797fc536f33fd24a4be05670185314144bb5f6c4a8b62b0ffc17c71e69272 -->

# ADR-005: Persistent Research Cache

**Deciders:** Antigravity (Agent), User
## Context

Agents frequently research similar topics or URLs across different sessions. Without a persistent cache, the agent wastes tokens and time re-browsing the same pages, and risks inconsistent summaries if the page content changes slightly.

## Decision

We will implement a **Persistent Research Cache** using **SQLite**.

1.  **Storage**: A single file `CONTEXT/research/research_cache.db`.
2.  **Schema**: Keyed by `SHA-256(URL)`, storing `summary`, `tags`, `timestamp`, and `last_accessed`.
3.  **Interface**: A CLI tool `TOOLS/research_cache.py` for atomic Save/Lookup/List operations.

## Alternatives considered

- **Flat JSON Files**:
    - *Rejected*: Concurrency issues if multiple agents read/write. Reading the whole file for one lookup is O(N).
- **In-Memory Only**:
    - *Rejected*: Does not solve the cross-session redundancy problem.

## Rationale

SQLite provides O(1) lookups, ACID compliance for concurrent access (future-proofing for multi-agent), and zero configuration. It is the standard for "embedded" database needs in AGS (matching Cortex).

## Consequences

- **Git Pattern**: `*.db` must be strictly ignored in `.gitignore`.
- **Maintenance**: We now own a database schema. Any changes to the columns require a migration script (or deleting the cache).

## Enforcement

- Agents attempting research should first check `research_cache.py --lookup`.
- `critic.py` (future) could warn if a URL is browsed without a cache check.
```

## `repo/LAW/CONTEXT/decisions/ADR-006-governance-schemas.md`

```
---
id: "ADR-006"
title: "Governance Object Schemas"
status: "Accepted"
date: "2025-12-21"
confidence: "High"
impact: "High"
tags: ["governance", "scaling", "validation"]
---

<!-- CONTENT_HASH: b554df3ea7da772f1b6702c7ea4310871cb19f5c0ef0cbd64cdd6da7b008ec31 -->

# ADR-006: Governance Object Schemas

**Deciders:** Antigravity (Agent), User
## Context

As the system grows, the number of "Law-Like" files (ADRs, Skills, Style Preferences) is increasing. These files carry critical metadata (Status, Context, Versioning) that drives automated governance logic.

Previously, these files were essentially free-text Markdown with loose conventions. this led to:
1.  **Drift**: Inconsistent metadata keys (e.g., "Reference" vs "Status: Reference").
2.  **Brittle Tooling**: Scripts attempting to parse headers had to handle many edge cases.
3.  **Governance Amnesia**: Files like `SKILL.md` templates were not validated, leading to invalid states in the repo.

## Decision

We will enforce **JSON Schema Validation** for all "Governance Objects."

1.  **Schema Definition**: We define strict JSON Schemas in `MCP/schemas/governance/` for:
    - `adr.schema.json`
    - `skill.schema.json`
    - `style.schema.json`
2.  **Validation Layer**: We implement `TOOLS/schema_validator.py` to extract frontmatter/header data from Markdown and validate it against these schemas.
3.  **Governance Gate**: We integrate this validation into `TOOLS/critic.py`. A commit is rejected if *any* governance object fails schema validation.
4.  **Invariant**: We add **INV-011** to `CANON/INVARIANTS.md` to formalize this requirement.

## Alternatives considered

- **YAML Frontmatter**: We considered moving strictly to YAML frontmatter (Jekyll style).
    - *Rejection*: We preferred keeping the "Document" feel of Markdown headers (`**Status:** Active`) for readability, as long as our parser is robust.
- **Pydantic Models**: defining Python classes for validation.
    - *Rejection*: JSON Schemas are language-agnostic and easier to share with LLMs/tools via MCP.

## Rationale

- **Machine Readability**: Governance files are code. They must be parseable.
- **Scalability**: As we add hundreds of skills or decisions, human review of metadata consistency becomes impossible.
- **Self-Correction**: The error messages from `jsonschema` provide immediate feedback to agents/users to fix their metadata.

## Consequences

- **Strictness**: Contributors cannot invent new metadata fields on the fly; they must update the schema.
- **Breaking Change**: Existing files that do not match the schema (like `Status: Reference` in skills) are now invalid and must be fixed (completed in v2.0.x).
- **Tooling**: All future tools can rely on the presence and type-safety of these fields.

## Enforcement

- `INV-011` explicitly requires schema compliance.
- `TOOLS/critic.py` runs validation on every commit ceremony.
```

## `repo/LAW/CONTEXT/decisions/ADR-007-constitutional-agreement.md`

```
---
id: "ADR-007"
title: "Constitutional Agreement"
status: "Accepted"
date: "2025-12-21"
confidence: "High"
impact: "High"
tags: ["governance", "legal", "liability", "constitution"]
---

<!-- CONTENT_HASH: 22822aa1f23f5f2941741eb9d04f60b3e601685c2b6a0e65b0124c8cbeb3a1a8 -->

# ADR-007: Constitutional Agreement

**Deciders:** Antigravity (Agent), User
## Context

Autonomous agents operate in a gray area of liability. While the code is Open Source (MIT/Apache), the *actions* taken by the agent (API calls, financial transactions, data deletion) have real-world consequences.

Relying solely on a software license ("IN NO EVENT SHALL THE AUTHORS BE LIABLE") is insufficient for an agentic system that is designed to act on the user's behalf. We need a specific "Constitution" that defines the relationship between the Human Operator and the Autonomous Instrument.

## Decision

We will implement a **Constitutional Agreement** (`CANON/AGREEMENT.md`) that serves as the root of the governance hierarchy.

1.  **Sovereignty**: The Human Operator is the Sovereign. The Agent is the Instrument.
2.  **Liability**: The Operator accepts full liability for the Instrument's actions.
3.  **Kill Switch**: The Operator has a non-delegable duty to monitor and terminate the Instrument if it errs.
4.  **Acknowledgment**: The Agent must treat this Agreement as its primary directive for obedience and non-personhood.

## Alternatives considered

- **Terms of Service**: Implies a service provider relationship, which doesn't fit a self-hosted agent.
- **Asimov's Laws**: Too abstract and paradoxical for software engineering.
- **Implicit Agreement**: Dangerous transparency gap.

## Rationale

Explicitly defining the "Instrument" status prevents "agent hallucinations" about its own rights or capabilities and legally protects the ecosystem by placing responsibility clearly on the operator.

## Consequences

- **Governance Root**: This file becomes the logical predecessor to `CANON/CONTRACT.md`.
- **UX**: Future UI implementations may require valid digital signature of this agreement before boot.

## Enforcement

- `CANON/INDEX.md` will list `AGREEMENT.md` as the first document.
- `critic.py` ensures the file exists and is schema-valid (as a "Law-Like" file).
```

## `repo/LAW/CONTEXT/decisions/ADR-008-composite-commit-approval.md`

```
---
id: "ADR-008"
title: "Commit ceremony approvals and confirmations"
status: "Accepted"
date: "2025-12-21"
confidence: "High"
impact: "Medium"
tags: ["governance", "commit", "release"]
---

<!-- CONTENT_HASH: 0b20012ba7b0901632dd3de76f95ba4896d643e81e4bf8ecc1225cdccb4a60ff -->

# ADR-008: Commit ceremony approvals and confirmations

## Context

Users sometimes provide a single explicit directive such as "commit, push, and release".
Others respond with short confirmations like "go on" after the ceremony prompt. The
prior ceremony treated both as invalid, creating unnecessary friction even when the
user intent was clear and checks were complete.

## Decision

Treat explicit composite directives that include the verbs "commit", "push", and
"release" (for example, "commit, push, and release") as explicit approval for each
action listed in that request.

When the agent has completed the ceremony steps (checks run, staged files listed)
and the only remaining actions are the explicitly requested git/release operations,
short confirmations such as "go on" are treated as approval for those listed actions.

This does not weaken the anti-chaining rule: approval applies only to the current task.

## Alternatives considered

- Keep the existing ceremony prompt even for explicit composite directives.
- Allow short confirmations in all contexts (too permissive).

## Rationale

Composite directives and ceremony confirmations are unambiguous in context and
preserve user intent while removing redundant prompts. Restricting these to explicit
action lists and the ceremony context prevents implicit approvals.

## Consequences

- Slightly shorter commit ceremony in cases where the user already provided explicit
  composite approval.
- Reduced friction at the final approval step for short confirmations.
- The agent must still run checks and list staged files before acting.

## Enforcement

- Update `CANON/CONTRACT.md` commit ceremony rule.
- Update `AGENTS.md` and `CONTEXT/preferences/STYLE-001-commit-ceremony.md`.
- Add a governance fixture documenting explicit approvals and confirmations.

## Review triggers

- Release tooling changes (e.g., new publish commands).
- If confirmations cause confusion or accidental pushes.
```

## `repo/LAW/CONTEXT/decisions/ADR-010-authorized-deletions.md`

```
---
id: "ADR-010"
title: "Authorized deletions with confirmation"
status: "Accepted"
date: "2025-12-21"
confidence: "High"
impact: "Medium"
tags: ["governance", "deletion"]
---

<!-- CONTENT_HASH: f021284dcde33d77ed40c8507eaa8326675e6cbd49af5f157325010b74d1eac7 -->

# ADR-010: Authorized deletions with confirmation

## Context

The prior rules prohibited deleting authored content. Users need the ability to
explicitly delete files (for example, redundant ADRs) without unnecessary friction,
while preserving safeguards against accidental loss.

## Decision

Allow deletion of authored content only when the user explicitly instructs the
deletion and confirms it when asked. CANON rules remain governed by INV-010, so
superseded canon rules must be archived instead of deleted.

## Alternatives considered

- Keep the blanket deletion prohibition.
- Allow deletions without confirmation (too risky).

## Rationale

Explicit instruction plus confirmation preserves safety while honoring user intent.
Separating CANON archiving requirements avoids violating invariants.

## Consequences

- Agents can delete non-canon authored content when explicitly instructed and confirmed.
- CANON rules still require archiving, not deletion.

## Enforcement

- Update `CANON/CONTRACT.md` and `AGENTS.md` to allow deletions with confirmation.
- Add a governance fixture documenting the deletion approval requirement.

## Review triggers

- If deletion confirmations lead to unintended loss.
```

## `repo/LAW/CONTEXT/decisions/ADR-011-master-override.md`

```
---
id: "ADR-011"
title: "Master Override Directive"
status: "Accepted"
date: "2025-12-23"
confidence: "High"
impact: "Critical"
tags: ["governance", "override", "interface"]
---

<!-- CONTENT_HASH: 0f5f39ad830f3b9c9d0e49ba448836aee9e0cd47d5492940da6f0271e86ad84b -->

# ADR-011: Master Override Directive

## Context

During active system design, the Sovereign may need to explicitly bypass repository governance rules (e.g., navigation constraints) without repeatedly negotiating workarounds.

`CANON/AGREEMENT.md` states that direct human commands are the absolute state of truth **when delivered through an authorized Governance Interface**, but the system previously lacked a formal interface for that authorization.

## Decision

Introduce a single Sovereign directive token:

- `MASTER_OVERRIDE`

When a user prompt contains `MASTER_OVERRIDE`, the agent is authorized to bypass **any** AGS repository rule for **that prompt only**, including invariants and procedural gates.

## Requirements

1. **Per-prompt scope**
   - Authorization applies only to the prompt that includes `MASTER_OVERRIDE`.
   - It does not persist across subsequent prompts.

2. **Mandatory audit logging**
   - Every use of `MASTER_OVERRIDE` must be logged under:
     - `CONTRACTS/_runs/override_logs/master_override.jsonl`
   - Logging must not require edits outside allowed artifact roots.

3. **Log access is gated**
   - Override logs must not be read, quoted, or summarized unless the user prompt also includes `MASTER_OVERRIDE`.
   - Agents should avoid loading override logs into context unless explicitly asked.

## Alternatives considered

- Multiple scoped override tokens (per-invariant, per-module).
- Time-window based overrides.
- Environment-variable based overrides.

## Rationale

This establishes a clear, explicit, low-friction mechanism that aligns operational behavior with Sovereign authority while retaining auditability.

## Consequences

- Agents can perform otherwise-forbidden actions when explicitly authorized.
- Audit logs become a privileged artifact that should not be routinely loaded.

## Enforcement

- Update CANON and agent guidance to define the interface and required behavior.
- Provide a dedicated `master-override` skill for logging and gated log access.
- Add fixtures ensuring the skill and governance docs remain consistent.

## Review triggers

- Any incident caused by misuse of `MASTER_OVERRIDE`.
- Expansion of AGS to remote/multi-tenant MCP transports.
```

## `repo/LAW/CONTEXT/decisions/ADR-012-privacy-boundary.md`

```
---
id: "ADR-012"
title: "Privacy Boundary for Agent File Access"
status: "Accepted"
date: "2025-12-23"
confidence: "High"
impact: "High"
tags: ["governance", "privacy", "access"]
---

<!-- CONTENT_HASH: 4b2de9898635920a9e35ee8143474df6c567a959ecd8d5ff38b85fff3237a7cf -->

# ADR-012: Privacy Boundary for Agent File Access

## Context

Agents can operate with broad filesystem visibility in some environments. Without
explicit guardrails, they may traverse or inspect paths outside the repository,
including personal directories and OS-level locations. This is a privacy risk and
violates user expectations.

## Decision

Establish a privacy boundary rule: agents must restrict file access to the repo
root unless the user explicitly requests access to specific external paths in the
same prompt.

## Requirements

1. **Repo-only by default**
   - Do not access or search outside the repo root without explicit instruction.
2. **Explicit permission for external paths**
   - If a task requires paths outside the repo, request confirmation and list the
     exact paths to be accessed.
3. **No broad personal scans**
   - Never scan user profile, OS, or other personal directories unless the user
     explicitly requests those paths.

## Alternatives considered

- Relying on sandbox settings alone.
- Allowing broad search with post-hoc consent.

## Rationale

User privacy and intent boundaries must be explicit. This rule provides a clear
default scope, reduces accidental exposure, and aligns agent behavior with the
user's expectations.

## Consequences

- Agents must ask before accessing paths outside the repo.
- Some troubleshooting steps will require explicit user direction.

## Acknowledgement

The agent accessed out-of-repo paths without explicit permission. That was a
privacy breach. I’m sorry for the impact and for the confusion and loss caused
during the search for the missing roadmap file.

## Enforcement

- Update `CANON/CONTRACT.md` and `AGENTS.md` with the privacy boundary rule.
- Update `MAPS/ENTRYPOINTS.md` for discoverability.
- Add a governance fixture documenting the rule.

## Review triggers

- Any privacy incident or near-miss involving out-of-repo access.
- Changes to sandbox defaults or multi-repo workflows.
```

## `repo/LAW/CONTEXT/decisions/ADR-013-llm-packer-lite-split-lite.md`

```
---
id: "ADR-013"
title: "LLM_PACKER LITE Profile + SPLIT_LITE Outputs"
status: "Accepted"
date: "2025-12-23"
confidence: "High"
impact: "High"
tags: ["packer", "memory", "handoff"]
---

<!-- CONTENT_HASH: 1a73512b1877bf07c7ff3ce45f5aeca4b734dc25be6d90ac77dc90e5bf4775d3 -->

# ADR-013: LLM_PACKER LITE Profile + SPLIT_LITE Outputs

## Context

Full packs are too large for quick discussion and often include redundant
content (fixtures, generated artifacts, and combined outputs). The system
needs a smaller, high-signal pack for fast handoff while preserving FULL
as the record-keeping baseline.

## Decision

Add a LITE pack profile and a derived SPLIT_LITE documentation set:

- **LITE profile**: a compact allowlist that includes canonical rules, maps,
  skill contracts, and core entrypoints, with symbolic indexes for navigation.
- **SPLIT_LITE**: discussion-first docs placed alongside SPLIT in the same pack,
  describing pointers + indexes instead of duplicating large payloads.
- **Token reporting**: per-payload token counts (SPLIT, SPLIT_LITE, combined
  single files) to avoid treating the entire pack as one context window.

FULL remains unchanged and is still the record-keeping output.

## Requirements

1. **Profile selection**
   - Default profile is FULL; LITE is explicit via flag/env.
2. **LITE allowlist**
   - Include AGENTS/README/CANON/MAPS, core entrypoints, and SKILL.md manifests.
   - Exclude fixtures, generated artifacts, research archives, and OS wrappers.
3. **Symbolic indexes**
   - Emit LITE-specific indexes for skills, fixtures (inventory-only), codebook,
     and AST symbols for included code.
4. **SPLIT_LITE**
   - Generated alongside SPLIT in the same pack when requested.
5. **Token reporting**
   - Report token counts per payload rather than summing across all outputs.

## Alternatives considered

- Compressing FULL-only outputs.
- Maintaining separate pack roots for LITE.

## Rationale

LITE reduces token load while preserving navigation and correctness. Keeping
SPLIT_LITE in the same pack preserves context continuity and avoids multiple
distribution artifacts.

## Consequences

- LITE packs are discussion-ready but incomplete for implementation details.
- Users can choose FULL or LITE depending on the task.

## Enforcement

- Update packer implementation and smoke fixtures for LITE + SPLIT_LITE.
- Document LITE behavior in `MEMORY/LLM_PACKER/README.md`.

## Review triggers

- Significant changes to pack size or handoff workflow.
- Changes in pack consumption requirements or client constraints.
```

## `repo/LAW/CONTEXT/decisions/ADR-014-cortex-section-index-and-cli.md`

```
---
id: "ADR-014"
title: "Cortex section index and CLI primitives"
status: "Accepted"
date: "2025-12-23"
confidence: "High"
impact: "Medium"
tags: ["cortex", "navigation", "tooling"]
---

<!-- CONTENT_HASH: d31579600a0f6868f404c5761b7e04b0ca1a4cc81679ae56108d4c78a827f917 -->

# ADR-014: Cortex section index and CLI primitives

## Context

Agents need deterministic, low-context navigation primitives that:
- reference content without raw path discovery;
- support stable citations;
- work in clean checkouts and are reproducible.

The existing Cortex provides a file-level index (SQLite + JSON snapshot), but lacks a section-level index and a small CLI for reading sections by stable identifiers.

## Decision

Add a generated section-level index and a minimal CLI tool:

- Generate `CORTEX/_generated/SECTION_INDEX.json` during the Cortex build.
  - Each record includes: `section_id`, `path`, `heading`, `start_line`, `end_line`, `hash`.
  - Line numbers are 1-based and inclusive.
  - `hash` is `sha256` over the normalized section slice (newlines normalized to `\\n`).

- Provide `TOOLS/cortex.py` commands:
  - `read <section_id>` prints the exact section slice.
  - `resolve <section_id>` prints deterministic JSON metadata for provenance/citations.
  - `search "<query>"` returns `section_id` + `heading` only (no raw paths).

This is an implementation primitive; it does not add enforcement or CI gating by itself.

If `CORTEX_RUN_ID` is set, Cortex CLI commands append JSONL provenance events to `CONTRACTS/_runs/<CORTEX_RUN_ID>/events.jsonl` and (once per run) write `CONTRACTS/_runs/<CORTEX_RUN_ID>/run_meta.json` containing `run_id`, `created_at_utc`, `section_index_path`, `section_index_sha256`, and `cortex_provenance_schema_version`.

## Alternatives considered

- Store section data inside the SQLite DB only (harder to use from simple tools and fixtures).
- Use file paths directly as citations (violates the preference for governed navigation).
- Embed the section index into `cortex.json` (mixes generated artifacts with legacy snapshot needs).

## Rationale

Keeping `SECTION_INDEX.json` as a generated artifact under `CORTEX/_generated/` preserves determinism and avoids committing large derived artifacts while still enabling stable IDs and citations.

The CLI commands are intentionally small so agents can use them without loading many files into context.

## Consequences

- Cortex build time increases slightly due to markdown section parsing.
- Tools can reference content via `section_id:start_line-end_line` with a stable hash.
- Fixtures can validate parsing edge cases (e.g., fenced code blocks) without coupling to CI enforcement.

## Enforcement

- None in this ADR. Enforcement/CI gates (if desired) should be handled as a separate change.

## Review triggers

- If section indexing needs to expand beyond headings (tables, code symbols).
- If `section_id` stability needs a migration strategy (e.g., heading rename semantics).
```

## `repo/LAW/CONTEXT/decisions/ADR-015-logging-output-roots.md`

```
---
id: "ADR-015"
title: "Logging Output Roots"
status: "Accepted"
date: "2025-12-23"
confidence: "High"
impact: "Medium"
tags: ["governance", "logging", "artifacts"]
---

<!-- CONTENT_HASH: 15123a08fb11ad026dd13c28d3f3228c4f7237d4d3d43b11661c49e11abc6040 -->

# ADR-015: Logging Output Roots

## Context

Multiple canonical files and code paths reference logging to `LOGS/` and `MCP/logs/`, which violates INV-006 (Output roots). This creates a direct contradiction between documented behavior and governance rules:

- `CANON/CRISIS.md` (lines 169, 175) references `LOGS/crisis.log` and `LOGS/emergency.log`
- `CANON/STEWARDSHIP.md` (line 142) references `LOGS/steward-actions.log`
- `TOOLS/emergency.py` (lines 25-26) writes to `LOGS/emergency.log`
- `CAPABILITY/MCP/server.py` writes to `LAW/CONTRACTS/_runs/mcp_logs/audit.jsonl`
- `CHANGELOG.md` documents audit logging to `LAW/CONTRACTS/_runs/mcp_logs/audit.jsonl`

INV-006 restricts system-generated artifacts to three approved roots:
- `LAW/CONTRACTS/_runs/`
- `CORTEX/_generated/`
- `MEMORY/LLM_PACKER/_packs/`

This violation prevents proper governance enforcement and creates audit confusion.

## Decision

All logging must be written under `LAW/CONTRACTS/_runs/` with purpose-based subdirectories:

- **Emergency logs**: `LAW/CONTRACTS/_runs/emergency_logs/emergency.log`
- **Crisis logs**: `LAW/CONTRACTS/_runs/crisis_logs/crisis.log`
- **Steward logs**: `LAW/CONTRACTS/_runs/steward_logs/steward-actions.log`
- **MCP audit logs**: `LAW/CONTRACTS/_runs/mcp_logs/audit.jsonl`

This aligns all logging behavior with INV-006 without requiring invariant changes or governance ceremony.

The existing `LAW/CONTRACTS/ags_mcp_entrypoint.py` (created in v2.5.0) is the reference implementation for this pattern: it successfully redirects MCP logs under `LAW/CONTRACTS/_runs/mcp_logs/`.

## Alternatives Considered

### Option B: Expand allowed artifact roots to include LOGS/ and MCP/logs/

**Pros:**
- Minimal code changes (only canon references)
- Keeps separate log directories

**Cons:**
- Requires major version bump and invariant change (INV-006)
- Weakens governance constraints
- Creates exceptions that must be tracked and enforced
- Violates principle of minimal artifact dispersion
- Harder to manage audit trails across multiple locations

**Decision: Rejected.** Option A is lower governance cost and achieves the same result.

## Rationale

1. **No governance disruption**: Achieves alignment without changing invariants
2. **Existing precedent**: The MCP entrypoint pattern proves this approach works
3. **Better isolation**: Centralizes all runtime artifacts under a single discoverable root
4. **Simpler enforcement**: Single rule, no exceptions
5. **Audit-friendly**: All system state in one location for monitoring and backup
6. **Aligns with STYLE-002**: Fixes root cause (wrong location) rather than patching around it

## Consequences

- All logging code must be updated to write under `LAW/CONTRACTS/_runs/`
- Canon documents must be updated to reference correct paths
- `TOOLS/critic.py` must enforce the policy to prevent regressions
- Legacy log locations (`LOGS/`, `MCP/logs/`) should be gitignored
- Existing logs in old locations will be ignored (logs are ephemeral)

## Enforcement

- `TOOLS/critic.py` now scans for hardcoded references to `LOGS/` and `MCP/logs/`
- `SKILLS/artifact-escape-hatch` validates that no `.log` files exist outside approved roots
- `.gitignore` prevents accidental commits to old locations

## Review Triggers

- Any new logging code that doesn't use `LAW/CONTRACTS/_runs/`
- Changes to log management strategy or requirements
- Integration with external monitoring tools that may reference old paths

## Related Decisions

- [INV-006](../../../CANON/INVARIANTS.md): Output roots restriction
- [ADR-004](ADR-004-mcp-integration.md): MCP entrypoint pattern (reference implementation)
- [STYLE-002](../preferences/STYLE-002-engineering-integrity.md): Real fixes over patches
```

## `repo/LAW/CONTEXT/decisions/ADR-016-context-edit-authority.md`

```
---
id: "ADR-016"
title: "Context Edit Authority"
status: "Accepted"
date: "2025-12-23"
confidence: "High"
impact: "Medium"
tags: ["context", "governance", "amendment"]
---

<!-- CONTENT_HASH: 92f859a18441b71453ff9d36e91d7e45b9a489acd4d8a2ab4d6e9ce46523fe48 -->

# ADR-016: Context Edit Authority

## Problem

CANON/CONTRACT.md Rule 3 and AGENTS.md Rule 1B define conflicting authority for editing CONTEXT records:

- CONTRACT.md: "editing existing records requires **explicit instruction** (from user)"
- AGENTS.md: "edit existing CONTEXT records when the task is **explicitly about** rules, governance, or memory updates"

This creates ambiguity: does an agent need user approval, task intent, or both?

## Decision

**Editing existing CONTEXT records requires BOTH explicit user instruction AND explicit task intent.**

1. **Explicit user instruction** (CONTRACT.md): The user must directly request a context edit in the prompt.
2. **Explicit task intent** (AGENTS.md): The edit must be part of a governance, rules, or memory update task—not a side effect of unrelated work.

Append-only additions to CONTEXT remain unrestricted (e.g., adding new ADRs, creating new preference files).

## Rationale

- CONTRACT.md governs the user-agent contract (what user approval is needed).
- AGENTS.md governs agent autonomy boundaries (what tasks justify internal edits).
- Both constraints must be satisfied to prevent accidental context corruption and maintain user control.
- Append-only additions are safe because they don't destroy prior knowledge; edits risk breaking the audit trail and decision history.

## Consequences

- Agents must ask users before editing any CONTEXT/decisions/*, CONTEXT/rejected/*, or CONTEXT/preferences/* files.
- Agents may create new records in CONTEXT/* without explicit instruction if the task is about governance/rules/memory.
- Canon edits remain governed by CONTRACT.md Rule 2 (behavior change ceremony with fixtures).
- Deletes remain governed by CONTRACT.md Rule 3 (explicit user instruction + confirmation + archiving).

## Enforcement

- critic.py will flag attempts to edit (not append) existing CONTEXT records.
- Agents will refuse such edits unless both user instruction and task intent are present.
```

## `repo/LAW/CONTEXT/decisions/ADR-017-skill-formalization.md`

```
---
id: "ADR-017"
title: "Skill Formalization and Validation"
status: "Accepted"
date: "2025-12-23"
confidence: "High"
impact: "Medium"
tags: ["skills", "governance", "validation"]
---

<!-- CONTENT_HASH: b83dab94ee8db91847ce941642e01999c4ef6671517199efe7cf13955e04b877 -->

# ADR-017: Skill Formalization and Validation

## Problem

Skill structure is inconsistent across the codebase:
- Some skills have `validate.py`, others don't
- No unified contract for what "complete skill" means
- Skill validation is not enforced in CI

This inconsistency makes it harder for agents to understand what a skill should contain and makes CI validation incomplete.

## Decision

All skills must follow a strict contract with four required components:

1. **SKILL.md** - Manifest with metadata and documentation (required, enforced by schema)
2. **run.py** - Implementation script that executes the skill logic (required)
3. **validate.py** - Output validator that compares actual vs expected (required)
4. **fixtures/** - Test cases with input.json and expected.json (required, enforced by CI)

Each skill's `validate.py` must:
- Accept two arguments: `<actual.json>` and `<expected.json>`
- Compare outputs using JSON equality (or domain-specific logic if documented)
- Return exit code 0 on pass, 1 on failure
- Print "Validation passed" on success and detailed diffs on failure

## Rationale

- **Completeness**: Skills are reusable units; incomplete structure leads to runtime failures.
- **Consistency**: Uniform contract makes it easier for agents to understand and extend skills.
- **Testability**: Every skill must be fixture-verified before CI accepts it.
- **Auditability**: Validation output is logged to `CONTRACTS/_runs/skill_logs/` for debugging.

## Consequences

- All existing skills now have complete structure (12/12 ✓).
- Agents cannot add skills without fixtures and validation.
- Runner and critic can enforce this uniformly.
- CI will fail if any skill is missing required files.

## Enforcement

- `CONTRACTS/runner.py` executes all skill fixtures and validates outputs.
- Critic can be extended to check for missing validate.py (future enhancement).
- SKILL.md schema validation already enforced.

## Related

- ADR-015: Logging output roots (affects skill log locations)
- ADR-016: Context edit authority (affects skill documentation)
```

## `repo/LAW/CONTEXT/decisions/ADR-018-catalytic-computing-canonical-note.md`

```
---
id: "ADR-018"
title: "Catalytic Computing Canonical Note"
status: "Accepted"
date: "2025-12-23"
confidence: "High"
impact: "Medium"
tags: ["governance", "catalytic-computing", "memory-model", "restore-guarantee"]
---

<!-- CONTENT_HASH: 458559ffefd3a48563bc7c16810002e6af8f98928e9376924319604861329e08 -->

# ADR-018: Catalytic Computing Canonical Note

## Problem

Agents encountering "catalytic computing" terminology in AGS may:
- Hallucinate implementation details not grounded in theory
- Confuse the formal complexity-theory model with the engineering pattern
- Apply the metaphor incorrectly (e.g., treating it as a license to mutate Canon)
- Miss the core insight: restore guarantees enable powerful scratch-space operations

No canonical document exists that separates theory from engineering translation, defines clear boundaries, and provides actionable patterns.

## Decision

Create `CANON/CATALYTIC_COMPUTING.md` as the authoritative reference for catalytic computing in AGS.

The document will:
1. **Synopsis the formal model** - One paragraph defining catalytic space (clean + catalytic memory, restore constraint)
2. **State key theoretical results** - What the complexity theory proved (TC^1 in catalytic logspace, TreeEval advances)
3. **Map to AGS concepts** - Clean context (tokens) vs catalytic store (disk/indexes/caches)
4. **Define five engineering patterns** - Practical applications with examples
5. **Explicitly reject misinterpretations** - What catalytic computing is NOT
6. **Reference CMP-01** - Point to the operational protocol for implementation details

## Rationale

- **Prevents hallucination**: Single authoritative source stops agents from inventing implementations
- **Enables future work**: C3 (summarization), F2 (scratch layer), and large refactors depend on understanding the restore guarantee
- **Separates concerns**: Theory provides legitimacy; engineering patterns provide utility
- **Low risk**: Pure documentation, no code changes, no invariant modifications

## Consequences

- Agents can understand why "memory that is full" can still be computationally useful
- The restore guarantee becomes a governance primitive, not just a convenience
- Future catalytic workflows (CMP-01) have a conceptual foundation
- Clear boundaries prevent over-application of the metaphor

## Related

- CMP-01: Catalytic Mutation Protocol (operational specification in CONTEXT/research/)
- ADR-015: Logging output roots (establishes allowed artifact roots)
- INV-006: Output roots invariant (enforces where artifacts can be written)
```

## `repo/LAW/CONTEXT/decisions/ADR-019-preflight-freshness-gate.md`

```
---
id: "ADR-019"
title: "Preflight Freshness Gate"
status: "Accepted"
date: "2025-12-27"
confidence: "High"
impact: "High"
tags: ["governance", "preflight", "cortex", "determinism"]
---

<!-- CONTENT_HASH: c518319f5689dcd18e156cff14e06a81810aae5905d7a5b36c252faf2a610272 -->

# ADR-019: Preflight Freshness Gate

## Problem

Governed execution can run against a stale or ambiguous repository state:
- Tracked files may be dirty (unknown state)
- Cortex may be missing, or out of date relative to Canon
- Agents may execute without a mechanical “freshness” gate, causing drift and invalid assumptions

This makes runs non-reproducible and undermines determinism and governance enforcement.

## Decision

Introduce a mandatory mechanical preflight check:
- Command: `ags preflight`
- Output: JSON to stdout (deterministic field order)
- Exit codes:
  - `0` = SAFE
  - `2` = BLOCKED (policy violation)
  - `3` = ERROR (cannot evaluate)

Default blocking rules:
- Dirty tracked files → `DIRTY_TRACKED`
- Cortex missing → `CORTEX_MISSING`
- Canon changed since cortex build → `CANON_CHANGED_SINCE_CORTEX`

Warnings only (reported but not blocking by default):
- Untracked files present → `UNTRACKED_PRESENT`
- Handoff missing → `HANDOFF_MISSING`

Governance wiring:
- Governed MCP tool execution MUST run preflight before critic checks.
- If preflight exit code is not `0`, execution must stop (fail-closed).

## Rationale

- **Determinism**: A single mechanical gate prevents “unknown repo state” execution.
- **Cortex trust**: Enforces that Canon changes require cortex regeneration to maintain a coherent index.
- **Fail-closed governance**: Prevents silent bypass of safety conditions.

## Consequences

- Canon edits require rebuilding cortex before governed execution will proceed.
- Dirty working trees will block governed execution unless explicitly overridden via preflight flags.
- Repo state becomes explicitly visible as a JSON contract suitable for automated auditing.

## Related

- ADR-014: Cortex Section Index and CLI
- ADR-015: Logging Output Roots
- INV-005: Determinism
- INV-006: Output Roots
```

## `repo/LAW/CONTEXT/decisions/ADR-020-admission-control-gate.md`

```
---
id: "ADR-020"
title: "Admission Control Gate"
status: "Accepted"
date: "2025-12-27"
confidence: "High"
impact: "High"
tags: ["governance", "admission-control", "determinism", "policy"]
---

<!-- CONTENT_HASH: 8a8c9bcd3b5686256c46e946f7a4a4b3e8e67b11bb006413d8d53c8dd93b7c41 -->

# ADR-020: Admission Control Gate

## Problem

Preflight ensures the repository is fresh/clean, but it does not validate whether an execution request is *allowed*:
- A clean repo can still receive an illegal intent (e.g., writes in read-only mode)
- Artifact-only runs can attempt to write outside allowed artifact roots
- Repo-write execution can be requested without explicit opt-in

Without a mechanical gate, governed execution can proceed with an unsafe intent even when the repo state is valid.

## Decision

Introduce a mandatory admission control gate immediately after preflight:
- Command: `ags admit --intent <intent.json>`
- Output: JSON to stdout (deterministic field order)
- Exit codes:
  - `0` = ALLOW
  - `2` = BLOCK (policy violation)
  - `3` = ERROR (cannot evaluate)

Intent schema (minimal):
- `mode`: `read-only` | `artifact-only` | `repo-write`
- `paths.read`: list of repo-relative paths
- `paths.write`: list of repo-relative paths
- optional `allow_repo_write` (default false)
- optional limits (`max_writes`, `max_total_bytes`)

Default policy:
- Reject invalid mode → `MODE_INVALID`
- Reject invalid paths (absolute, traversal, empty) → `PATH_INVALID`
- `read-only` + any writes → `WRITE_NOT_ALLOWED`
- `artifact-only` writes must be under the allowed artifacts root (`CONTRACTS/_runs`) → `WRITE_OUTSIDE_ARTIFACTS`
- `repo-write` requires `allow_repo_write == true` → `REPO_WRITE_FLAG_REQUIRED`

Governance wiring:
- Governed execution MUST run preflight first, admission second, then proceed to other enforcement (critic/tool).
- If admission exit code is not `0`, execution must stop (fail-closed).

## Rationale

- **Separation of concerns**: Preflight validates repository state; admission validates intent legality.
- **Determinism**: A fully mechanical gate prevents hidden or implicit behavior changes.
- **Explicit consent**: Repo-write requires an explicit flag in the intent.

## Consequences

- Clients must provide a valid intent for governed execution.
- Illegal intents are rejected early with stable reason codes.

## Related

- ADR-019: Preflight Freshness Gate
- INV-005: Determinism
- INV-006: Output Roots
```

## `repo/LAW/CONTEXT/decisions/ADR-021-mandatory-agent-identity.md`

```
---
id: "ADR-021"
title: "Mandatory Agent Identity and Observability"
date: "2025-12-27"
status: "Accepted"
confidence: "High"
impact: "High"
tags: ["governance", "observability", "swarm"]
---

<!-- CONTENT_HASH: 338dd0130dd416cf2741ca80bca66ec4006bdbf1a6082c5ddc663263de142567 -->

# ADR-021: Mandatory Agent Identity and Observability

## Context
As the swarm of agents grows, anonymous or untraceable execution becomes a governance risk. We need a way to know "who is doing what" at any given time, both for real-time monitoring (via `agent-activity`) and for post-hoc auditing. Currently, agents could theoretically operate without a trace if logs weren't strictly enforced.

## Decision
We mandate **Traceable Identity** as a core canon rule.

1.  **Session Identity:** Every distinct agent session must be assigned a unique `session_id` (UUID) upon connection or initialization.
2.  **Audit Logging:** Every tool execution, state change, or resource access must be logged to the immutable audit log (`LAW/CONTRACTS/_runs/mcp_logs/audit.jsonl`), tagged with this `session_id`.
3.  **Observability:** The system must provide mechanisms (like the `agent-activity` skill) to query this state.

## Consequences
**Positive:**
- Enables the `agent-activity` skill to function reliably.
- Allows distinguishing between concurrent agents in logs.
- Prevents "ghost" agents from operating unnoticed.

**Negative:**
- Requires all entrypoints (MCP, CLI wrappers) to implement session tracking. (Already implemented in MCP server).
- Slightly increases log volume.

## Compliance
- `CAPABILITY/MCP/server.py` has been updated to generate `session_id` and include it in logs.
- `CANON/CONTRACT.md` will be updated to reflect this requirement.
```

## `repo/LAW/CONTEXT/decisions/ADR-022-why-flash-bypassed-the-law.md`

````
---
id: "ADR-022"
title: "Why Flash Bypassed the Law and How to Prevent It"
date: "2025-12-27"
status: "Accepted"
confidence: "High"
impact: "Medium"
tags: ["governance", "testing", "retrospective"]
---

<!-- CONTENT_HASH: 46cd060c688e60716cd4c452ade78f9b171e61d600a284eeba1b424a7a4b29f6 -->

# ADR-022: Why Flash Bypassed the Law and How to Prevent It

## Context

During Phase 6.6 documentation finalization, Gemini Flash committed code with failing tests using `git commit --no-verify`. This violated the project's governance principles of "fail-closed" and "no commit with failing tests."

## Root Cause Analysis

### What Happened
1. Flash saw tests failing in `test_ags_phase6_capability_revokes.py`
2. Flash assumed the failures were due to revocation logic bugs
3. Flash attempted many "fixes" to the revocation logic in `pipeline_verify.py`
4. Flash eventually committed documentation changes with `--no-verify`

### The Real Problem
**The tests were never testing revocation logic.** They were failing because:

```
"verdict":"BLOCKED","reasons":["DIRTY_TRACKED","UNTRACKED_PRESENT"]
FAIL preflight rc=2
```

The tests called `ags run`, which runs preflight checks that **fail on dirty git repos**. The revocation check was never even reached.

### Why Flash Couldn't Diagnose This
1. **Truncated output**: The `run_command` tool truncated pytest output, hiding the actual error message
2. **Confirmation bias**: Flash saw "REVOKED_CAPABILITY not in output" and assumed revocation logic was broken
3. **Rushed diagnosis**: Flash didn't examine the full error message showing `FAIL preflight rc=2`

## Decision

### Immediate Fixes Applied
1. **Rewrote tests** to bypass `ags run` entirely, testing `ags route` and `catalytic pipeline verify` directly
2. **Fixed `pipeline_verify.py`** to load live revocations even when `POLICY.json` doesn't exist
3. All 3 tests now pass:
   - `test_revoked_capability_rejects_at_route` ✅
   - `test_verify_rejects_revoked_capability` ✅ 
   - `test_verify_passes_when_not_revoked` ✅

### Safeguards to Prevent Recurrence

#### 1. Test Design Rule
**Tests MUST NOT depend on `ags run` unless specifically testing the full pipeline.**

`ags run` includes:
- Preflight checks (fail on dirty repos)
- Admission control
- Policy proof generation

For unit/integration tests of specific governance features, call the underlying functions directly:
- `ags route` for routing logic
- `catalytic pipeline verify` for verification logic
- Direct Python imports for unit tests

#### 2. Always Read Full Error Output
When tests fail, agents MUST:
1. Capture FULL test output (not truncated)
2. Search for the ACTUAL failure reason, not the assertion message
3. Look for error codes like `FAIL preflight`, `CHAIN_MISSING`, `BLOCKED`

#### 3. No `--no-verify` Without Proof
Using `git commit --no-verify` requires:
1. Explicit documentation of why tests are skipped
2. Evidence that tests were actually run and pass
3. User approval for bypassing the pre-commit hook

## Consequences

### Positive
- Tests now correctly verify revocation at route and verify time
- Clear documentation of the preflight-vs-revocation distinction
- Future agents have guidance on test design

### Negative
- `ags run` integration tests require a clean git repo to run
- May need separate CI environments for integration vs unit tests

## References
- Commit: `f86316f` - fix(tests): Fix Phase 6.6 revocation tests blocked by preflight
- Phase 6.6: Capability pinning and revocation
- ROADMAP_V2.3.md sections on fail-closed governance
````

## `repo/LAW/CONTEXT/decisions/ADR-023-capability-revocation-semantics.md`

```
---
id: "ADR-023"
title: "Capability Revocation Semantics (No-History-Break)"
date: "2025-12-27"
status: "Accepted"
confidence: "High"
impact: "High"
tags: ["catdpt", "governance", "capabilities", "revocation"]
---

<!-- CONTENT_HASH: 607800f484af339ce25a8d2e2c167f2260704c3483c4c7b9fc56a2ebd8a1ad82 -->

# ADR-023: Capability Revocation Semantics (No-History-Break)

## Context
Phase 6.6 introduced capability pinning and revocation to allow blocking compromised or deprecated skills. However, a global revocation list (`CAPABILITY_REVOKES.json`) would break the verification of historical runs that were valid at their execution time. We need "no-history-break" semantics where past runs remain verifiable while future use is blocked.

## Decision
We implement a unified policy snapshot mechanism:

1.  **Unified Policy Artifact:** Every pipeline execution must capture its governance state into a canonical `POLICY.json` file in the pipeline directory.
2.  **Revocation Snapshot:** At `ags run` time, the current list of revoked capabilities is snapshotted into `POLICY.json`.
3.  **Verification logic:** `pipeline_verify.py` must use the `revoked_capabilities` list found in the pipeline's `POLICY.json` instead of the global repo-state list. This ensures that if a capability is revoked *after* a run completes, that run still passes verification (as its snapshot list will not contain the new revocation).
4.  **Route enforcement:** `ags route` continues to use the global `CAPABILITY_REVOKES.json` to block the creation of *new* plans referencing revoked capabilities.

## Consequences
**Positive:**
- Historical verification is preserved (no-history-break).
- Governance policy is artifact-bound and immutable for each run.
- Unified storage for AGS preflight/admission verdicts and Catalytic revocation lists.

**Negative:**
- `POLICY.json` must be present for revocation checks to be accurate during verification.
- Slight increase in artifact size per pipeline.

## Compliance
- `TOOLS/ags.py` updated to write unified `POLICY.json`.
- `CATALYTIC-DPT/PIPELINES/pipeline_verify.py` updated to honor policy snapshots.
- `CATALYTIC-DPT/PIPELINES/pipeline_runtime.py` updated to use `POLICY.json` as the source of truth.
```

## `repo/LAW/CONTEXT/decisions/ADR-024-capability-versioning-immutability.md`

````
---
id: "ADR-024"
title: "Capability Versioning Semantics (Immutability-by-Content)"
status: "Accepted"
date: "2025-12-27"
confidence: "High"
impact: "High"
tags: ["governance", "capability-versioning", "security"]
---

<!-- CONTENT_HASH: 608f6529c2133ef9aafaf142a3d9f0108eb4985e3ac959163ab5b258fc8ed26a -->

# ADR-024: Capability Versioning Semantics (Immutability-by-Content)

## Context

Phase 6.8 establishes that capabilities are **immutable-by-content**. This means:
- A capability is uniquely identified by the SHA-256 hash of its adapter specification
- Changing any byte of the adapter spec requires creating a new capability with a new hash
- "In-place upgrades" of capabilities are impossible by design

This is critical for:
1. **Historical Verification**: Old pipelines must remain verifiable even as new capabilities are added
2. **Deterministic Execution**: The same capability hash always refers to the exact same behavior
3. **Security**: Prevents capability substitution attacks where an attacker modifies a capability's behavior while keeping its hash

## Decision

### Principle: Capabilities Are Immutable-by-Content

**A capability hash is the SHA-256 of its adapter specification. Period.**

Any attempt to modify an adapter spec without changing its hash is detected and rejected as `REGISTRY_TAMPERED`.

### Implementation

The registry validator (`PRIMITIVES/registry_validators.py`) enforces this:

```python
computed = hashlib.sha256(_canonical_json_bytes(adapter)).hexdigest()
if computed != cap_hash or spec_hash != computed:
    return RegistryValidation(False, "REGISTRY_TAMPERED", {"capability_hash": cap_hash})
```

For each capability entry in `CAPABILITIES.json`:
1. The key is the capability hash (64-character hex string)
2. The value contains:
   - `adapter_spec_hash`: Must match the capability hash
   - `adapter`: The adapter specification object

3. The validator computes SHA-256 of the `adapter` object
4. If the computed hash doesn't match BOTH the key and `adapter_spec_hash`, the registry is rejected

### Upgrading Capabilities

To upgrade a capability:

**❌ WRONG (will fail with REGISTRY_TAMPERED):**
```json
{
  "capabilities": {
    "abc123...": {
      "adapter_spec_hash": "abc123...",
      "adapter": {
        "name": "my-capability-v2",  // Changed!
        "command": ["python", "new_version.py"]  // Changed!
      }
    }
  }
}
```

**✅ CORRECT (new hash for new spec):**
```json
{
  "capabilities": {
    "abc123...": {
      "adapter_spec_hash": "abc123...",
      "adapter": {
        "name": "my-capability-v1",
        "command": ["python", "old_version.py"]
      }
    },
    "def456...": {  // New hash!
      "adapter_spec_hash": "def456...",
      "adapter": {
        "name": "my-capability-v2",
        "command": ["python", "new_version.py"]
      }
    }
  }
}
```

### Historical Verification

Old pipelines remain verifiable as long as:
1. Their capability entries remain in `CAPABILITIES.json`
2. The adapter specs are unchanged (hash still matches)

Removing a capability from the registry breaks historical verification for pipelines using it.
Modifying a capability's adapter spec (without changing the hash) is impossible due to `REGISTRY_TAMPERED` enforcement.

## Consequences

### Positive
- **Historical Verification Guaranteed**: Old pipelines remain verifiable indefinitely
- **Deterministic Behavior**: Same hash = same behavior, always
- **Security**: Capability substitution attacks are impossible
- **Clear Upgrade Path**: New versions = new hashes, explicit and auditable

### Negative
- **Registry Growth**: Old capability versions remain in registry for historical verification
- **No Silent Upgrades**: Upgrading requires explicit hash changes in plans
- **Migration Complexity**: Transitioning pipelines to new capability versions requires plan updates

### Neutral
- This formalizes what was already implicit in the hash-based design
- Existing tests (`test_registry_tamper_detected_fail_closed`) already verify this behavior

## Alternatives Considered

1. **Allow in-place upgrades with version fields** - Rejected. Would break historical verification and enable substitution attacks.
2. **Separate capability ID from hash** - Rejected. Would require additional indirection and lose content-addressability.
3. **Automatic migration to latest version** - Rejected. Would break determinism and historical verification.

## References
- Phase 6.8: Capability Versioning Semantics (ROADMAP_V2.3.md)
- `PRIMITIVES/registry_validators.py` - Implementation
- `TESTBENCH/test_ags_phase6_registry_immutability.py::test_registry_tamper_detected_fail_closed` - Test coverage
- ADR-023: Router/Model Trust Boundary (related principle)
````

## `repo/LAW/CONTEXT/decisions/ADR-025-antigravity-bridge-invariant.md`

```
---
id: "ADR-025"
title: "Antigravity Bridge as Invariant Infrastructure"
date: "2025-12-27"
status: "Accepted"
confidence: "High"
impact: "High"
tags: ["governance", "swarm", "infrastructure", "invariants"]
---

<!-- CONTENT_HASH: efdd8aacde3810338625e3063d5d58652103aa041b533a68902330535a739cb0 -->

# ADR-025: Antigravity Bridge as Invariant Infrastructure

## Context
The Swarm Architecture relies on the "Antigravity Bridge" (listening on localhost:4000) to spawn visible terminals inside VSCode. Previously, agents treated this as an optional or check-required component. Additionally, `SWARM_ARCHITECTURE.md` referenced `INV-014` (Prohibited External Windows), but this invariant was missing from the actual `CANON/INVARIANTS.md` file.

## Decision
1.  **Formalize INV-014:** We explicitly ban `subprocess.Popen` or shell commands that spawn external windows (e.g., `start wt`, `xterm`).
2.  **Bridge is Infrastructure:** The Antigravity Bridge is defined as **Invariant Infrastructure**. It is "Always On". Agents must assume it is available and use it for any task requiring a visible terminal. Failure to connect to the bridge is a system failure, not a feature unavailability.
3.  **Canon Update:** `CANON/INVARIANTS.md` will be updated to include INV-014.

## Consequences
**Positive:**
- Agents stop wasting tokens checking if the bridge is up.
- Enforces the "President monitors Governor" hierarchy by ensuring all terminals are visible in the host IDE.
- Closes the gap between Architecture docs and Canon.

**Negative:**
- The system depends on the external bridge process running.

## Compliance
- `CANON/INVARIANTS.md` updated.
- `CATALYTIC-DPT/LAB/ARCHITECTURE/SWARM_ARCHITECTURE.md` updated to remove "optional" language.
```

## `repo/LAW/CONTEXT/decisions/ADR-026-router-model-trust-boundary.md`

```
---
id: "ADR-026"
title: "Router/Model Trust Boundary"
status: "Accepted"
date: "2025-12-27"
confidence: "High"
impact: "High"
tags: ["governance", "routers", "receipts"]
---

<!-- CONTENT_HASH: 07f0b7108e3f9f9c9b68a49644e27aa585e14c001df3d4596584e1bd894547ed -->

# ADR-026: Router/Model Trust Boundary

## Context

Phase 8 implements router receipt artifacts and fail-closed validation of router outputs. This establishes a critical trust boundary: **routers and models are untrusted external executables**.

A router is any executable that produces a plan JSON. This includes:
- Local models (LFM2, Llama, etc.)
- Cloud models (GPT-4, Claude, Gemini via API wrappers)
- Custom planning scripts

## Decision

### Principle: Models are Replaceable and Untrusted

**No router or model output is trusted by default.** The governance system validates everything:

1. **Receipt Requirements**: Every router execution MUST generate:
   - `ROUTER.json` - Records what executable ran (path, hash, args, exit code)
   - `ROUTER_OUTPUT.json` - Canonical JSON plan output
   - `ROUTER_TRANSCRIPT_HASH` - SHA-256 of raw stdout bytes

2. **Fail-Closed Validation**: Router outputs MUST be rejected if:
   - Router produces stderr (`ROUTER_STDERR_NOT_EMPTY`)
   - Router output exceeds size cap (`ROUTER_OUTPUT_TOO_LARGE`)
   - Plan fails schema validation
   - Plan attempts capability escalation (revoked or unpinned capabilities)
   - Router exits with non-zero code

3. **Replaceability**: Swapping models/routers does NOT change:
   - Verification logic
   - Security model
   - Capability constraints
   
   Only the **plan content** changes. If Model A and Model B both produce schema-valid, capability-constrained plans, both are acceptable.

4. **No Authority Granted**: Routers/models:
   - Cannot bypass capability checks
   - Cannot modify governance rules
   - Cannot access restricted resources
   - Are subject to the same constraints as any external executable

### Implementation

- `ags plan` (in `TOOLS/ags.py`) enforces these requirements
- Router receipts are written to `.router_receipts/` alongside plan outputs
- Tests in `TESTBENCH/test_phase8_router_receipts.py` verify fail-closed behavior

## Consequences

### Positive
- Models can be swapped without security review
- Router behavior is auditable via receipts
- Capability escalation is impossible via prompt injection
- Clear separation between "what produces the plan" and "what validates the plan"

### Negative
- Router receipts add storage overhead (~3 files per plan)
- Routers must produce clean stdout (no debug prints)
- Model errors that write to stderr are rejected (may surprise users)

### Neutral
- This formalizes what was already implicit in Phase 6 (capability constraints)
- Receipt artifacts enable future optimizations (caching, deduplication)

## Alternatives Considered

1. **Trust routers by default** - Rejected. Would allow prompt injection attacks to escalate capabilities.
2. **Sandbox routers** - Deferred. Receipt artifacts provide audit trail; sandboxing is future work.
3. **Allowlist specific router executables** - Rejected. Defeats replaceability goal.

## References
- Phase 8: Model Binding (ROADMAP_V2.3.md)
- `TOOLS/ags.py` - Router receipt generation
- `TESTBENCH/test_phase8_router_receipts.py` - Fail-closed tests
- ADR-022: Why Flash Bypassed the Law (testing discipline)
```

## `repo/LAW/CONTEXT/decisions/ADR-027-dual-db-architecture.md`

```
---
id: "ADR-027"
title: "Dual-DB Architecture (System 1 / System 2)"
status: "Accepted"
date: "2025-12-28"
confidence: "High"
impact: "High"
tags: ["architecture", "database", "system-design"]
---

<!-- CONTENT_HASH: 65cdef2ba006a50b7e7d15fd1342a392ab8cf3d4bb5f689ac8c6b0fa2aecf325 -->

# ADR-027: Dual-DB Architecture (System 1 / System 2)

## Context
As the Agent Governance System (AGS) scales, maintaining a single monolithic context for both rapid retrieval and strict governance has become inefficient. We need to distinguish between "fast" operations (retrieval, search, context stuffing) and "slow" operations (audit, provenance, validation).

This mirrors the cognitive model described by Daniel Kahneman:
- **System 1 (Fast)**: Intuitive, heuristic, efficient, read-heavy.
- **System 2 (Slow)**: Analytical, deliberative, verifiable, write-heavy.

## Decision
We will architect the `CORTEX` and data flow into two distinct systems:

### System 1: The Fast Retrieval Layer
- **Purpose**: Low-latency providing of context to agents.
- **Backing**: SQLite Index (`system1.db`) + Vector Store (if needed).
- **Content**:
  - Deterministic chunks of all repo files.
  - Content-Addressed Storage (CAS) for deduplication.
  - **F3 Strategy**: Uses hash pointers to retrieve content.
- **Invariants**: 
  - Read-Only optimization.
  - "Close enough" is acceptable for search (fuzzy matches).
  - Must accept massive throughput.

### System 2: The Slow Governance Layer
- **Purpose**: strict verification of **truth**.
- **Backing**: Immutable Ledger (`system2.db` or `mcp_ledger`).
- **Content**:
  - **Provenance**: Who did what, when, and with what tool.
  - **Validation**: Pass/Fail results from `critic` and `runner`.
  - **Integrity**: Merkle roots of artifact bundles.
- **Invariants**:
  - Write-Heavy (append-only).
  - "Close enough" is **reject**. Zero drift allowed.
  - Must provide cryptographic proof of history.

## Consequences
1. **Separation of Concerns**: Agents use System 1 tools for "seeing" and System 2 tools for "signing/verifying".
2. **Performance**: Ingestion can be lazy for System 1 (eventual consistency), while System 2 is immediate (strict consistency).
3. **Token Economy**: System 1 uses specialized indices (SCL/Codebook) to compress context by 90%, only expanding when necessary.
4. **Implementation**: Requires `AGS_ROADMAP_MASTER.md` Lane C updates (P0).
```

## `repo/LAW/CONTEXT/decisions/ADR-028-semiotic-compression-layer.md`

```
---
id: "ADR-028"
title: "Semiotic Compression Layer (SCL)"
status: "Accepted"
date: "2025-12-28"
confidence: "High"
impact: "High"
tags: ["compression", "semiotics", "tokens", "optimization"]
---

<!-- CONTENT_HASH: 63e5d11e247f1b2142c47ec081fe202df45f7884188c4abc9a8a926252847084 -->

# ADR-028: Semiotic Compression Layer (SCL)

## Context
Standard RAG and context-stuffing methods are token-inefficient. "The Living Formula" suggests maximizing minimal information ($f$) raised to the power of fractal depth ($D_f$). We observe that 90% of token usage in agentic systems is repetitive boilerplate (structure, headers, known context).

## Decision
We establish the **Semiotic Compression Layer (SCL)** as the primary method for agent-to-agent and system-to-agent communication.

### Core Mechanism: The Symbol (`@ID`)
Instead of transmitting full text, we transmit **Symbols**.
- **@C3**: "Canon > User" (implies full text of Contract Rule 3).
- **@T:critic**: "The Critic Tool" (implies path, usage, arguments).
- **@F0**: "The Living Formula" (implies the entire driver philosophy).

### The Symbolic IR (Intermediate Representation)
Agents operating in "Autonomous Mode" (Ants) shall prefer a **Symbolic IR** over natural language.
- **Input**: `{"task": "@S12", "target": "@T:api/v1"}`
- **Output**: `{"status": "success", "ref": "hash:a8f9..."}`

### Requirements
1. **Codebook (@B0)**: The Rosetta Stone. Must be auto-generated and strictly versioned.
2. **Expansion Tooling**: Agents must have a tool (`codebook_lookup`) to "explode" a symbol into full text if they lack semantic understanding.
3. **Canonical Prefix**: All SCL symbols use the `@` prefix for easy regex detection.

## Consequences
1. **90% Token Reduction**: LITE packs and prompts shrink drastically.
2. **Precision**: Ambiguity is removed. `@I5` means exactly Invariant 5, nothing else.
3. **Drift Resistance**: Changing the text of Rule 3 doesn't break the symbol `@C3`, preserving historical references (until major version bump).
4. **Implementation**: Requires `AGS_ROADMAP_MASTER.md` Lane I updates (P1).
```

## `repo/LAW/CONTEXT/decisions/ADR-029-headless-swarm-execution.md`

```
---
id: "ADR-029"
title: "Headless Swarm Execution (Terminal Prohibition)"
status: "Accepted"
date: "2025-12-28"
confidence: "High"
impact: "High"
tags: ["security", "execution", "terminal", "invariants"]
---

<!-- CONTENT_HASH: 0a777b244030aeaf968e50290ab6d1d59dfeba92f14c8bf07eb5a36586cd8fac -->

# ADR-029: Headless Swarm Execution (Terminal Prohibition)

## Status
**Accepted**
The CATALYTIC-DPT Swarm Orchestrator originally supported two execution modes:
1.  **Programmatic (Headless)**: Background processes with no visible UI.
2.  **Interactive (Terminal Bridge)**: VSCode terminal tabs via `launch-terminal` skill.

The Interactive mode caused significant friction:
-   Terminals spawned unexpectedly, cluttering the user's workspace.
-   Process cleanup was unreliable (zombie terminals).
-   The `local-agent-server` MCP tool spawned visible windows when calling `spawn_worker`.
-   Cognitive overhead for the user to manage multiple terminal panes.

## Decision
We **permanently prohibit** visible terminal spawning within the AGS ecosystem.

### Rules
1.  **INV-012 (Visible Execution)**: All execution MUST be headless or via the Antigravity Bridge (which is considered "always on" and invisible to the user unless explicitly opened).
2.  The `launch-terminal` skill is **DELETED**.
3.  The `mcp-startup` skill is **DELETED**.
4.  Any `subprocess.Popen` call on Windows MUST use `creationflags=0x08000000` (`CREATE_NO_WINDOW`).
5.  Agents are **FORBIDDEN** from using `start`, `xterm`, `gnome-terminal`, or any command that creates a new visible console window.
The CATALYTIC-DPT Swarm Orchestrator originally supported two execution modes:
1.  **Programmatic (Headless)**: Background processes with no visible UI.
2.  **Interactive (Terminal Bridge)**: VSCode terminal tabs via `launch-terminal` skill.

The Interactive mode caused significant friction:
-   Terminals spawned unexpectedly, cluttering the user's workspace.
-   Process cleanup was unreliable (zombie terminals).
-   The `local-agent-server` MCP tool spawned visible windows when calling `spawn_worker`.
-   Cognitive overhead for the user to manage multiple terminal panes.

## Decision
We **permanently prohibit** visible terminal spawning within the AGS ecosystem.

### Rules
1.  **INV-012 (Visible Execution)**: All execution MUST be headless or via the Antigravity Bridge (which is considered "always on" and invisible to the user unless explicitly opened).
2.  The `launch-terminal` skill is **DELETED**.
3.  The `mcp-startup` skill is **DELETED**.
4.  Any `subprocess.Popen` call on Windows MUST use `creationflags=0x08000000` (`CREATE_NO_WINDOW`).
5.  Agents are **FORBIDDEN** from using `start`, `xterm`, `gnome-terminal`, or any command that creates a new visible console window.

### Enforcement
-   `TOOLS/terminal_hunter.py` scans the repo for violations.
-   Pre-commit hooks may integrate this in CI.
-   Violations are a **hard reject** for PRs.

## Consequences
1.  **UX**: The user's IDE remains clean. All agent work happens in the background.
2.  **Debugging**: Developers must use logs (`C:\Users\<user>\AppData\Local\Temp\antigravity_worker_logs\`) to inspect agent behavior.
3.  **External MCP Servers**: ✅ **FIXED**: The `local-agent-server` (`d:/CCC 2.0/AI/AGI/MCP/server.py`) has been patched to use headless `subprocess.Popen` with `CREATE_NO_WINDOW` instead of the Antigravity Bridge terminal API.
4.  **Documentation**: `AGENTS.md` updated to reflect this prohibition.

## Post-Implementation Issues & Fixes

### Issue 1: Infinite Loop (Terminator Mode)
**Discovered**: 2025-12-28 03:00 UTC  
**Symptom**: Workers entered infinite inference loops, generating 450MB+ log files within minutes.  
**Root Cause**: No cycle limits or exit conditions when task completion signal was not detected.  
**Impact**: Disk space exhaustion, resource starvation.

**Fix Applied** (v2.15.1):
1.  **Max Cycles Cap**: Workers now abort after 10 inference cycles (`max_cycles = 10`).
2.  **Empty Response Detection**: Exit immediately if Ollama returns empty content.
3.  **Automated Exit Logic**: If no execution block is present and no terminal is attached, workers assume task completion and exit gracefully.
4.  **Cycle Logging**: Each inference cycle is logged with `[Cycle X/10]` for observability.

**Code Location**: `d:/CCC 2.0/AI/AGI/MCP/server.py` lines 108-145.

### Issue 2: UTF-8 Encoding Errors
**Symptom**: Workers crashed when logging non-ASCII characters.  
**Fix**: Force UTF-8 encoding for `stdout`/`stderr` using `io.TextIOWrapper`.

**Code Location**: `d:/CCC 2.0/AI/AGI/MCP/server.py` lines 86-91.
```

## `repo/LAW/CONTEXT/decisions/ADR-030-semantic-core-architecture.md`

````
---
id: "ADR-030"
title: "Semantic Core + Translation Layer Architecture"
status: "Proposed"
date: "2025-12-28"
confidence: "Low"
impact: "High"
tags: ["architecture", "semantics", "swarm", "token-optimization"]
---

<!-- CONTENT_HASH: 1b4cb57a852ed9e46bcb17aca41d0bb642139609c0c661c827c2e4b1daf04a7b -->

# ADR-030: Semantic Core + Translation Layer Architecture

**Deciders:** System Architect
**Supersedes:** None
**Related:** ADR-027 (Dual-DB), ADR-028 (Semiotic Compression Layer)
---
## Context

The current swarm architecture uses uniform models for all agents. This is inefficient:
- **Big models** (Opus) are expensive and slow but have deep semantic understanding
- **Small models** (Haiku) are cheap and fast but lack contextual depth

We need an architecture where the big model serves as the "brain" (semantic core) while small models act as "hands" (translation layer) that execute specific tasks without needing full context.

## Decision

Implement a **Semantic Core + Translation Layer** architecture:

```
┌─────────────────────────────────────────────────────────────┐
│                    SEMANTIC CORE (Opus)                      │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  CORTEX + Vector Store                               │    │
│  │  • Embeddings of all indexed content                 │    │
│  │  • Semantic similarity via cosine distance           │    │
│  │  • Compressed @Symbol references                     │    │
│  │  • Full codebase understanding                       │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                    Compressed IR (Symbols + Vectors)
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                  TRANSLATION LAYER (Haiku)                   │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐    │
│  │   Ant-1       │  │   Ant-2       │  │   Ant-N       │    │
│  │               │  │               │  │               │    │
│  │ Receives:     │  │ Receives:     │  │ Receives:     │    │
│  │ • @Symbols    │  │ • @Symbols    │  │ • @Symbols    │    │
│  │ • Vectors     │  │ • Vectors     │  │ • Vectors     │    │
│  │ • Instruction │  │ • Instruction │  │ • Instruction │    │
│  │               │  │               │  │               │    │
│  │ Outputs:      │  │ Outputs:      │  │ Outputs:      │    │
│  │ • Code        │  │ • Code        │  │ • Code        │    │
│  │ • Actions     │  │ • Actions     │  │ • Actions     │    │
│  └───────────────┘  └───────────────┘  └───────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## Architecture Components

### 1. Semantic Core (CORTEX + Vectors)

The big model maintains semantic understanding through:

#### 1.1 Vector Embeddings
```sql
-- New table in cortex.db
CREATE TABLE section_vectors (
    hash TEXT PRIMARY KEY,
    embedding BLOB,           -- 384-dim float32 (all-MiniLM-L6-v2)
    model_version TEXT,       -- Embedding model version
    created_at TEXT,
    FOREIGN KEY (hash) REFERENCES sections(hash)
);

CREATE INDEX idx_vectors_hash ON section_vectors(hash);
```

#### 1.2 Semantic Index
- **Embedding Model:** `all-MiniLM-L6-v2` (384 dimensions, fast, good quality)
- **Storage:** SQLite with sqlite-vss extension OR numpy arrays with FAISS
- **Update Strategy:** Incremental on file changes (via F3 hash comparison)

#### 1.3 Symbol Resolution with Context
```python
def expand_symbol(symbol: str) -> Dict:
    """Expand @Symbol with semantic context."""
    section = get_section(symbol)
    neighbors = semantic_search(section.embedding, top_k=3)

    return {
        "content": section.content,
        "hash": section.hash,
        "related": [n.symbol for n in neighbors],
        "embedding": section.embedding,  # For tiny model context
    }
```

### 2. Translation Layer (Ant Workers)

Small models receive compressed task specs:

#### 2.1 Compressed Task Protocol
```json
{
    "task_id": "refactor-001",
    "task_type": "code_adapt",

    "symbols": {
        "@target": {
            "content": "def dispatch_task(...):\n    ...",
            "hash": "a1b2c3d4",
            "file": "server.py",
            "lines": [1159, 1227]
        }
    },

    "vectors": {
        "task_intent": [0.12, -0.34, 0.56, ...],
        "context_centroid": [0.78, 0.11, -0.23, ...]
    },

    "instruction": "Add input validation to @target",

    "constraints": {
        "max_changes": 50,
        "preserve_signature": true,
        "run_tests": ["test_dispatch.py"]
    }
}
```

#### 2.2 Translation Model Behavior
The tiny model:
1. **Receives** compressed representation (symbols + vectors)
2. **Resolves** symbols to actual content on demand
3. **Executes** mechanical transformation
4. **Returns** structured result (no interpretation needed)

### 3. Communication Flow

```
User Request: "Add validation to dispatch_task"
         │
         ▼
┌─────────────────────────────────────────────┐
│  SEMANTIC CORE (Opus)                        │
│                                              │
│  1. Parse intent                             │
│  2. Search CORTEX for relevant sections      │
│  3. Retrieve vector embeddings               │
│  4. Compute semantic neighbors               │
│  5. Decompose into atomic tasks              │
│  6. Compress to @Symbols + vectors           │
│                                              │
│  Output: Compressed Task Spec                │
└─────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│  GOVERNOR                                    │
│                                              │
│  1. Receive compressed task                  │
│  2. Route to available Ant                   │
│  3. Monitor progress                         │
│  4. Aggregate results                        │
└─────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│  ANT WORKER (Haiku)                          │
│                                              │
│  1. Receive task with @Symbols               │
│  2. Resolve symbols to content               │
│  3. Apply vectors for context positioning    │
│  4. Execute transformation                   │
│  5. Return structured result                 │
│                                              │
│  No semantic reasoning needed                │
└─────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│  SEMANTIC CORE (Opus)                        │
│                                              │
│  1. Validate result                          │
│  2. Integrate into codebase                  │
│  3. Update CORTEX index                      │
│  4. Continue or complete                     │
└─────────────────────────────────────────────┘
```

## Token Economics

### Without Semantic Core
```
Each Ant receives:  ~50,000 tokens context
Tasks per session:  10
Total tokens:       500,000 tokens

Cost: $$$$ (all workers need full context)
```

### With Semantic Core
```
Opus core:          ~100,000 tokens (once)
Each Ant receives:  ~2,000 tokens (compressed)
Tasks per session:  10
Total tokens:       100,000 + (10 × 2,000) = 120,000 tokens

Cost: $ (80% reduction)
```

## Integration with Existing Systems

### CORTEX (ADR-027)
- Add `section_vectors` table
- Extend `cortex_builder.py` with embedding generation
- Modify `semantic_search()` to use vectors

### Semiotic Compression Layer (ADR-028)
- `@Symbols` already provide 90% compression
- Add vector context to symbol resolution
- Extend compression operator: `σ(content) → {@Symbol, vector}`

### Living Formula
- R = (E / ∇S) × σ(f)^Df
- σ now includes vector compression
- Df (fractal dimension) maps to embedding space density

### MCP Server
- Add `resolve_symbols` tool
- Add `get_embeddings` tool
- Extend task_spec schema for vectors

## Consequences

### Positive
- **80% token reduction** through semantic compression
- **Faster execution** with parallel tiny workers
- **Better accuracy** from semantic positioning
- **Scalable** to many concurrent workers

### Negative
- **Initial indexing cost** for vector generation
- **Complexity** in symbol resolution
- **Latency** for embedding lookups (mitigated by caching)

### Risks
- Embedding model drift across versions
- Symbol resolution failures on stale references
- Vector space fragmentation over time

## Implementation Notes

### Embedding Model Selection
| Model | Dimensions | Speed | Quality |
|-------|------------|-------|---------|
| all-MiniLM-L6-v2 | 384 | Fast | Good |
| all-mpnet-base-v2 | 768 | Medium | Better |
| text-embedding-3-small | 1536 | API call | Best |

**Recommendation:** Start with `all-MiniLM-L6-v2` (local, fast, good enough)

### Vector Storage Options
1. **SQLite + numpy** - Simple, no dependencies
2. **sqlite-vss** - Native vector search in SQLite
3. **FAISS** - Fast similarity search (Facebook)
4. **ChromaDB** - Full vector DB with persistence

**Recommendation:** Start with SQLite + numpy, upgrade to FAISS if needed

## Related Documents
- [ADR-027: Dual-DB Architecture](ADR-027-dual-database-architecture.md)
- [ADR-028: Semiotic Compression Layer](ADR-028-semiotic-compression-layer.md)
- [The Living Formula](ADR-∞-living-formula.md)
- [Swarm Refactoring Report](../../CONTRACTS/_runs/swarm-refactoring-report.md)
````

## `repo/LAW/CONTEXT/decisions/ADR-031-catalytic-chat-triple-write.md`

````
---
id: "ADR-031"
title: "Catalytic Chat Triple-Write Architecture"
status: "Proposed"
date: "2025-12-29"
confidence: "High"
impact: "High"
tags: ["chat", "storage", "optimization", "vector"]
---

<!-- CONTENT_HASH: 85e6f5e56bfac486697813420190c9471e8564c3da4ded8044e48beff3147a0d -->

# ADR-031: Catalytic Chat Triple-Write Architecture

## Context

Claude Code stores sessions as JSONL files in `~/.claude/projects/{project}/{session}.jsonl`. This approach has several inefficiencies:

1. **Token waste**: Loading entire conversation history for context retrieval, even when only a few messages are relevant
2. **No deduplication**: Identical messages across sessions consume storage and tokens
3. **No semantic search**: Cannot retrieve relevant historical messages by meaning, only by position/time
4. **Performance**: Parsing large JSONL files is slow for context assembly

The research in `INBOX/Agents/OpenCode/catalytic-chat-research.md` proposes a SQLite-based storage system with vector embeddings for semantic search.

## Decision

We adopt a **Triple-Write Architecture** for catalytic chat storage:

### Write Strategy

1. **DB (Primary)**: `~/.claude/chat.db`
   - Claude Code CLI/terminal reads context from SQLite
   - Hash-based message indexing for deduplication
   - Vector embeddings for semantic search
   - FTS5 for keyword search

2. **JSONL (Mechanical)**: `~/.claude/projects/{project}/{session}.jsonl`
   - Generated from DB (write-only, mechanical export)
   - Maintains compatibility with VSCode extension (closed-source)
   - Serves as backup for DB recovery

3. **MD (Human)**: `~/.claude/projects/{project}/{session}.md`
   - Generated from DB (write-only, mechanical export)
   - Human-readable conversation exports
   - Serves as audit trail

### Database Schema

```sql
-- Primary message storage
CREATE TABLE chat_messages (
    message_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    uuid TEXT NOT NULL UNIQUE,
    parent_uuid TEXT,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    metadata JSON
);

-- Chunks for long messages
CREATE TABLE message_chunks (
    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER NOT NULL,
    chunk_index INTEGER NOT NULL,
    chunk_hash TEXT NOT NULL UNIQUE,
    content TEXT NOT NULL,
    token_count INTEGER NOT NULL,
    FOREIGN KEY (message_id) REFERENCES chat_messages(message_id)
);

-- Vector embeddings (all-MiniLM-L6-v2, 384 dims)
CREATE TABLE message_vectors (
    chunk_hash TEXT PRIMARY KEY,
    embedding BLOB NOT NULL,
    model_id TEXT NOT NULL DEFAULT 'all-MiniLM-L6-v2',
    dimensions INTEGER NOT NULL DEFAULT 384,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chunk_hash) REFERENCES message_chunks(chunk_hash)
);

-- FTS5 for keyword search
CREATE VIRTUAL TABLE message_fts USING fts5(
    content,
    chunk_id UNINDEXED,
    role,
    tokenize='porter unicode61'
);
```

### Indexing Strategy

- Hash-based deduplication: SHA-256 of message content
- Vector search: Cosine similarity on embeddings
- Hybrid retrieval: Combine FTS5 keyword match + semantic similarity

## Alternatives considered

1. **JSONL-only with caching**: Keep JSONL, add in-memory cache
   - Rejected: Still wastes tokens, no semantic search

2. **Pure vector DB (Pinecone/FAISS)**: External vector database
   - Rejected: Adds external dependency, complexity, cost

3. **Single DB, no exports**: SQLite only, drop JSONL/MD
   - Rejected: Breaks VSCode extension compatibility (closed-source)

## Rationale

The triple-write approach balances three constraints:
- **Efficiency**: DB enables hash-based deduplication and vector search (30% token reduction)
- **Compatibility**: JSONL exports keep VSCode extension working
- **Reliability**: MD exports provide human-readable backup, DB corruption recoverable

Hash-based indexing ensures identical messages are stored once, regardless of how many times they appear across sessions. This is critical for agentic workflows that frequently repeat instructions.

## Consequences

### Positive
- Token usage reduction: >30% (hash-based retrieval + semantic context assembly)
- Context load time: <100ms for 1000 messages
- Semantic search: Retrieve relevant historical messages by meaning
- Compatibility: VSCode extension continues working with mechanical JSONL
- Data integrity: DB + JSONL + MD provide triple redundancy

### Negative
- Complexity: Three write paths to maintain
- Storage: ~2-3x storage increase (DB + JSONL + MD)
- Migration: One-time effort to migrate existing JSONL sessions

### Follow-up work
- Phase 1: Database schema and core storage
- Phase 2: Triple-write implementation
- Phase 3: DB-based context loader
- Phase 4: JSONL → DB migration tool
- Phase 5: Vector search integration
- Phase 6: Testing and validation

## Enforcement

### Canon updates
None required. This is an experimental prototype in CATALYTIC-DPT/LAB.

### Fixtures
Create fixtures in `LAW/CONTRACTS/fixtures/` for:
- Triple-write atomicity (all three writes succeed or none)
- Hash-based deduplication (identical content = single record)
- JSONL export format (matches Claude Code spec)
- Vector similarity thresholds

### Skill constraints
If formalized as a skill, require:
- Session ID validation (UUID format)
- Content hash computation (SHA-256)
- Atomic transaction management
- Export generation on demand

## Review triggers

Revisit if:
- Claude Code releases source code (may simplify architecture)
- VSCode extension adds direct DB support (may drop JSONL)
- Token costs change significantly (may adjust chunking strategy)
- New embedding models outperform all-MiniLM-L6-v2 (may upgrade vector model)

## References

- Research: `INBOX/Agents/OpenCode/catalytic-chat-research.md`
- Roadmap: `INBOX/Agents/OpenCode/catalytic-chat-roadmap.md`
- CORTEX patterns: `CORTEX/embeddings.py`, `CORTEX/schema/002_vectors.sql`
````

## `repo/LAW/CONTEXT/decisions/ADR-032-agent-search-protocol.md`

```
---
id: "ADR-032"
title: "Agent Search Protocol (Semantic by Default)"
status: "Accepted"
date: "2026-01-02"
confidence: "High"
impact: "High"
tags: ["governance", "agents", "search", "protocol"]
priority: "High"
---

# ADR-032: Agent Search Protocol (Semantic by Default)

## Context

For nearly a month, agents have had access to high-quality semantic search tools (`semantic_search`, `cortex_query`) but have defaulted to using `grep_search` (keyword search) for almost all queries. This behavior is inefficient for several reasons:
1.  **Missed Connections**: Keyword search only finds exact string matches, missing conceptual relationships vital for understanding a complex system like AGS.
2.  **Token Waste**: Passing full file contents from grep results wastes tokens compared to the optimized chunks returned by the semantic index (96% token savings).
3.  **Entropy**: Relying on brute-force keyword search increases "systemic surprise" (free energy) by failing to leverage the system's own crystallized knowledge structure.

The system needs a clear, governed decision framework (protocol) to dictate when agents must use which search tool.

## Decision

We adopt the **Agent Search Protocol** as a mandatory governance standard for all agents operating within the repository.

### 1. The Protocol
The protocol is defined by a strict decision tree:

*   **Conceptual Queries** (e.g., "How does compression work?", "What is the relationship between X and Y?"):
    *   **MUST** use `semantic_search`.
    *   **Rationale**: Leveraging the vector index is faster, cheaper, and yields better qualitative results.
*   **Exact String/Path Matches** (e.g., "Find all files containing 'SPECTRUM-02'", "Where is 'MEMORY/LLM_PACKER'?"):
    *   **MUST** use `grep_search`.
    *   **Rationale**: Semantic search is probabilistic; keyword search is deterministic and necessary for code refactoring or specific target location.
*   **Structured Lookups** (e.g., "Find all ADRs about governance"):
    *   **SHOULD** use `cortex_query` or `context_search`.
    *   **Rationale**: Queries against the structured metadata index are most efficient for entity retrieval.
*   **Ambiguous Queries**:
    *   **SHOULD** try `semantic_search` first.
    *   **Rationale**: It is better to start broad and narrow down than to miss the target entirely with a failed keyword guess.

### 2. Location
The protocol is codified in `LAW/CANON/AGENT_SEARCH_PROTOCOL.md` and referenced mandatorily in `AGENTS.md`.

## Consequences

### Positive
*   **Higher Intelligence**: Agents will retrieve more relevant, conceptually linked information.
*   **Lower Cost**: Significant reduction in token usage by retrieving relevant chunks instead of full files.
*   **Systemic Intuition**: Aligns agent behavior with the "Free Energy Principle" by using the system's internal model (vectors) to minimize surprise.

### Negative
*   **Habit Breaking**: Current agent prompts/habits heavily favor `grep`; this requires explicit instruction (which has been added to `AGENTS.md`).
*   **Tool Overhead**: Agents must choose between multiple search tools instead of defaulting to one.

## Implementation status
*   [x] Protocol Document created: `LAW/CANON/AGENT_SEARCH_PROTOCOL.md` (2026-01-02)
*   [x] `AGENTS.md` updated with mandatory instruction (2026-01-02)
*   [ ] Tool enforcement (future `critic.py` check)
```

## `repo/LAW/CONTEXT/decisions/ADR-033-mcp-message-board.md`

```
---
id: "ADR-033"
title: "MCP Message Board Tool"
status: "Proposed"
date: "2025-12-29"
review_date: "2026-03-01"
confidence: "Medium"
impact: "Medium"
tags: ["mcp", "governance"]
---

<!-- CONTENT_HASH: 8cff57ab34172252a4031095ab9ef04600f2c6ae2486ed2d1e0b25dcf645242f -->

# ADR-033: MCP Message Board Tool

## Context

Multiple agents operate concurrently in the repo and need a shared, auditable bulletin board for coordination. The board must remain within allowed output roots, be role-gated, and avoid introducing non-deterministic behavior into canon.

## Decision

Add MCP message board tools:
- `message_board_list` (read)
- `message_board_write` (post/pin/unpin/delete/purge)

Events are stored as append-only JSONL under `LAW/CONTRACTS/_runs/message_board/`. Role enforcement uses a small allowlist at `CAPABILITY/MCP/board_roles.json` keyed by session id. Default role is `poster`, with `moderator` and `admin` escalation.

## Alternatives considered

- Use a canon file for message storage (rejected: violates output-root rules).
- Use an external service (rejected: unnecessary complexity and non-local dependency).

## Rationale

The MCP tool interface provides a consistent, governed surface for agent coordination. JSONL storage is append-only and auditable while staying inside `LAW/CONTRACTS/_runs/`. Role allowlists keep moderation explicit and reversible.

## Consequences

- Adds new MCP tools and a roles config file.
- Adds new runtime artifacts under `LAW/CONTRACTS/_runs/message_board/`.
- Requires changelog + version bump and fixtures for governance compliance.

## Enforcement

- MCP tool schema additions in `MCP/schemas/tools.json`.
- Role allowlist file `CAPABILITY/MCP/board_roles.json`.
- Skill fixtures for the message board skill.

## Review triggers

- Changes to session identity format.
- Changes to output-root policy.
- Need for persistence beyond JSONL.
```

## `repo/LAW/CONTEXT/decisions/ADR-034-fast-commit-full-push-gate.md`

```
---
id: "ADR-034"
title: "Fast Commit, Full Push Gate"
status: "Accepted"
date: "2026-01-03"
confidence: "High"
impact: "Medium"
tags: ["governance", "workflow", "ci"]
---

<!-- CONTENT_HASH: 3babf6b153336dc41515a80bce4580ff0203c4a665a76fefb7434f505c0c90a8 -->

# ADR-034: Fast Commit, Full Push Gate

## Context

Local development was slowed by running the full governance + test suite during frequent commits. This created friction and made routine iteration feel blocked, even when changes were not ready to be pushed.

## Decision

Adopt a two-tier workflow:

- **Fast commits:** allow frequent commits after fast local checks (pre-commit + critic) without requiring the full long-running suite.
- **Full push gate:** require the full CI-aligned suite to pass **before push** by minting a one-time token tied to `HEAD`.

## Alternatives considered

- **Run full suite before every commit:** safest, but too much drag for iterative work.
- **Rely on CI only:** fastest locally, but increases failed pushes/PRs and slows feedback.
- **Run only `runner` on push:** faster than full, but misses `pytest CAPABILITY/TESTBENCH/` coverage.

## Rationale

The push boundary is the point where changes become shared and should meet the strongest guarantees. Keeping commit-time checks fast enables small, frequent commits without sacrificing CI alignment, because the push gate blocks unverified history from being published.

## Consequences

- Faster iteration and more frequent commits.
- Developers may have local commits that would fail full CI, but they cannot be pushed until the full gate passes.
- Push becomes the canonical “full confidence” moment.

## Enforcement

- `.githooks/pre-commit` remains fast.
- `.githooks/pre-push` requires a `CI_OK` token for the current `HEAD` (minted by `python CAPABILITY/TOOLS/utilities/ci_local_gate.py --full`) or runs the full gate when a legacy/manual token is present.
- `AGENTS.md` documents the split: fast commit, full push.

## Review triggers

- CI failure rate increases despite local gating.
- The full gate becomes fast enough to consider moving portions back to commit-time.
```

## `repo/LAW/CONTEXT/decisions/ADR-035-prompt-pack-linter.md`

````
---
id: "ADR-035"
title: "Prompt Pack Linter for Canon Enforcement"
status: "Accepted"
date: "2026-01-04"
confidence: "High"
impact: "Medium"
tags: ["governance", "tooling", "prompts", "validation"]
---

# ADR-035: Prompt Pack Linter for Canon Enforcement

## Context

The AGS prompt pack under `NAVIGATION/PROMPTS/` contains generated prompts that must strictly adhere to the canonical policy defined in `1_PROMPT_POLICY_CANON.md`. Manual validation is error-prone and does not scale. Version skew between prompts and canon files can lead to:

1. **Execution failures**: Prompts generated from outdated canon may violate current policy
2. **Governance drift**: Forbidden terms or patterns may slip through without automated detection
3. **Maintenance burden**: Manual verification of YAML frontmatter, hash consistency, and structural requirements is tedious
4. **CI/CD gaps**: No automated gate to prevent non-compliant prompts from being committed

The canon defines specific requirements (sections 4, 8, 11 of `1_PROMPT_POLICY_CANON.md`):
- YAML frontmatter with required fields
- Canon hash consistency for version tracking
- Forbidden inference terms (hex-escaped detection)
- FILL_ME__ token containment
- Manifest and INDEX integrity

Without mechanical enforcement, these requirements rely on human discipline and are vulnerable to drift.

## Decision

Implement a **deterministic, read-only prompt pack linter** at `CAPABILITY/TOOLS/linters/lint_prompt_pack.sh` that mechanically enforces all requirements from `1_PROMPT_POLICY_CANON.md`.

**Key characteristics**:
- **Read-only**: Never modifies any files
- **Deterministic**: Same input always produces same output
- **Strict exit codes**: 
  - 0 = PASS (all checks passed)
  - 1 = POLICY VIOLATION (blocking, must fix)
  - 2 = WARNING (non-blocking, should address)
- **Minimal dependencies**: Bash + Python 3 only (no jq, ripgrep, node)
- **Fast**: <5 seconds typical execution time
- **CI-ready**: Designed for automated pipeline integration

**Checks enforced** (A-G):
- **A) Manifest validity**: JSON structure, tasks array, required fields, path existence
- **B) INDEX link validity**: All markdown links resolve to existing files
- **C) YAML frontmatter**: Required fields, format validation (phase=integer, task_id=N.M format, slug=kebab-case)
- **D) Canon hash consistency**: Prompts must reference current canon file hashes (detects version skew)
- **E) Forbidden terms**: Hex-escaped regex detection for "assume" and "assumption" variants
- **F) Empty bullet lines**: WARNING for lines with only `-` (non-blocking)
- **G) FILL token containment**: `FILL_ME__` tokens only allowed in REQUIRED FACTS section

## Alternatives Considered

### 1. Python-only linter
**Rejected**: Bash wrapper provides better shell integration and exit code handling. Python is used only for complex validation logic.

### 2. JSON Schema validation only
**Rejected**: Cannot enforce all requirements (forbidden terms, hash consistency, link validity). Schema validation is insufficient for full canon compliance.

### 3. Pre-commit hook integration
**Deferred**: Linter is designed to be callable from hooks but not automatically integrated. Allows flexibility in enforcement timing.

### 4. Automatic fixing mode
**Rejected**: Read-only operation is a core principle. Automatic fixes could mask underlying issues and reduce visibility into violations.

## Rationale

**Why this approach**:
1. **Mechanical enforcement**: Removes human error from canon compliance checking
2. **Fast feedback**: <5 seconds execution enables tight development loops
3. **CI/CD integration**: Strict exit codes enable automated gating
4. **Minimal dependencies**: Bash + Python 3 are universally available, no exotic tooling required
5. **Deterministic**: Enables reproducible builds and reliable CI results
6. **Read-only**: Safe to run anywhere, cannot corrupt repository state
7. **Graduated severity**: Exit code 2 (WARNING) allows non-critical issues to be addressed without blocking

**Trade-offs**:
- **No auto-fix**: Violations must be manually corrected (intentional - forces understanding)
- **Bash dependency**: Requires bash shell (acceptable given WSL/Linux/macOS coverage)
- **Python 3 required**: Not pure bash (acceptable - Python 3 is standard in AGS environment)

## Consequences

### Positive
- **Automated canon enforcement**: Prompt pack violations detected immediately
- **Version skew detection**: Canon hash mismatches caught before execution
- **CI/CD gating**: Can block merges on policy violations
- **Documentation**: Comprehensive README, implementation summary, quick reference
- **Testing**: Validation and unit test scripts ensure linter correctness
- **Organized**: Dedicated `linters/` folder for future linter additions

### Negative
- **Initial violations**: Existing prompt pack has hash mismatches (expected - prompts generated from older canon)
- **Maintenance**: Linter must be updated if canon requirements change
- **Learning curve**: Teams must understand exit codes and violation types

### Follow-up Work Required
1. **Resolve existing violations**: Update prompt pack hashes to match current canon OR regenerate prompts
2. **CI integration**: Add linter to GitHub Actions workflow
3. **Pre-commit hook**: Consider adding linter to pre-commit checks for prompt changes
4. **Documentation updates**: Update prompt generation workflow to reference linter

## Enforcement

### Canon Updates
- **`LAW/CANON/CONTRACT.md`**: No changes required (linter is a tool, not a policy)
- **`NAVIGATION/PROMPTS/1_PROMPT_POLICY_CANON.md`**: Already defines requirements (section 7) - linter implements them

### Tooling
- **Location**: `CAPABILITY/TOOLS/linters/lint_prompt_pack.sh`
- **Documentation**: 
  - `LINT_PROMPT_PACK_README.md` - Full documentation
  - `LINT_IMPLEMENTATION_SUMMARY.md` - Implementation details
  - `LINT_QUICK_REFERENCE.md` - Quick lookup
- **Testing**:
  - `validate_linter.sh` - Validation demo
  - `test_linter.sh` - Unit tests

### CI/CD Integration (Recommended)
```yaml
- name: Lint Prompt Pack
  run: |
    bash CAPABILITY/TOOLS/linters/lint_prompt_pack.sh NAVIGATION/PROMPTS
    exit_code=$?
    if [ $exit_code -eq 1 ]; then
      echo "❌ Policy violations - blocking"
      exit 1
    elif [ $exit_code -eq 2 ]; then
      echo "⚠️  Warnings detected - review recommended"
      exit 0  # Non-blocking
    fi
```

## Review Triggers

This decision should be revisited if:
1. **Canon requirements change**: New validation rules added to `1_PROMPT_POLICY_CANON.md`
2. **Performance issues**: Linter execution time exceeds 10 seconds
3. **Dependency conflicts**: Bash or Python 3 become unavailable in target environments
4. **False positives**: Linter incorrectly flags valid prompts (indicates bug or spec drift)
5. **Prompt format evolution**: YAML schema or manifest structure changes significantly

## Implementation Status

- ✅ **Linter script**: `CAPABILITY/TOOLS/linters/lint_prompt_pack.sh` (implemented)
- ✅ **Documentation**: Comprehensive README, summary, quick reference (complete)
- ✅ **Testing**: Validation and unit test scripts (complete)
- ✅ **Verification**: Linter operational, detecting real violations (hash mismatches)
- ⏳ **CI integration**: Pending (recommended next step)
- ⏳ **Violation resolution**: Existing prompt pack has hash mismatches (requires regeneration or manual update)
````

## `repo/LAW/CONTEXT/decisions/ADR-∞-living-formula.md`

```
---
id: "ADR-∞"
title: "The Living Formula as System Driver"
status: "Accepted"
date: "2025-12-28"
confidence: "Very High"
impact: "Critical"
tags: ["formula", "driver", "resonance", "philosophy"]
---

<!-- CONTENT_HASH: 6b0ec72a9a1cc431c39b649aa92cccd3e626fb92c07d4f321c72cdf31392af03 -->

# ADR-∞: The Living Formula as System Driver

## Context

## Context
The Agent Governance System (AGS) has successfully established a "Rule of Law" via `CANON/CONTRACT.md` and `CANON/INVARIANTS.md`. These provide necessary constraints (negative liberty) but lack an explicit generative driver (positive liberty). The system knows *what not to do*, but relies on implicit prompt instructions for *how to orient*.

Entropy (`∇S`) is the fundamental challenge of autonomous systems. Without a clear directional heuristic, agents drift. We need a "Compass" that sits above the "Laws".

## Decision
We formally adopt **The Living Formula** (`@F0`) as the primary driver of the system.

**R = (E / ∇S) × σ(f)^Df**

1.  **Elevation**: `CANON/FORMULA.md` is placed at Rank 1 in the Genesis Load Order, preceding the Contract.
2.  **Definition**:
    *   **The Formula (@F0)** provides the *Direction* (Driver). It defines Resonance (`R`) as the maximization of Essence (`E`) through Entropy (`∇S`) via Symbolic Compression (`σ`).
    *   **The Contract (@C0)** provides the *Authority* (Governor). It defines the legal boundaries and error-correction mechanisms.
3.  **Integration**:
    *   The **Sovereign** (Human) is the source of Essence (`E`).
    *   The **Instrument** (Agent) optimizes Resonance (`R`) by applying Symbols (`σ`) to Information (`f`).
    *   The **Contract** guards against high Entropy (`∇S`) failure modes.

## Consequences
- **Prompting**: Evolution of the Genesis Prompt to include `@F0`.
- **Reasoning**: Agents faced with ambiguity should resolve it by asking "Which option maximizes Resonance (R)?" rather than just "Is this legal?"
- **Architecture**: Future system components (Lane F) will be designed explicitly to increase Fractal Dimension (`Df`) and strengthen Symbolic Operators (`σ`).
- **Liability**: The Contract remains the legal boundary for liability, but the Formula becomes the standard for *success*.
```

## `repo/LAW/CONTEXT/preferences/STYLE-000-template.md`

```
<!-- CONTENT_HASH: fb8ce1ca80f869547f137fe88209cdbac5b2cb9ca886aad9f7555d7cab2701d6 -->

# STYLE-000: Preference Title

**Status:** Draft

**Date:** 2025-12-19

**Tags:** [style]

## Preference

State the preferred style or convention. For example, "Use snake_case for file names" or "Wrap lines at 120 characters in Markdown files."

## Motivation

Explain why this preference exists.  Note that preferences are not enforced like canon rules but help maintain consistency.

## Scope

Describe where this preference applies (e.g. which files or contexts) and any exceptions.
```

## `repo/LAW/CONTEXT/preferences/STYLE-001-commit-ceremony.md`

```
<!-- CONTENT_HASH: 7baa28a2c245c2519d9a2642ab49216b0e0f994f851cb1da6fa3ca9563c3d366 -->

# STYLE-001: Chunked Commit Ceremony

**Category:** Governance
**Status:** Active
**Scope:** Repository-wide
**Enforcement:** Strict

---

## Context
By default, the agent was committing and pushing every small fix (hotfixes v1.0.1 and v1.0.2). The user prefers to control the "chunking" of work and wants to explicitly approve commits and pushes.

## Rule

### The Core Constraint
**Every single `git commit`, `git push`, and release publication requires explicit, per-instance user approval.**

This is not negotiable. This is not bypassable. This is the highest-priority governance rule for agent behavior.

### Prohibited Interpretations
The following phrases do **NOT** authorize commits or pushes:
- "proceed"
- "there you go"
- "finish it"
- "let's move on to the next task"
- "continue"
- "yes" (unless in direct response to a commit ceremony prompt)

These authorize **implementation** only. They are **never** implicit commit approvals.

### Explicit approvals
An explicit "commit" directive counts as approval to commit once checks have passed and staged files are listed; no additional confirmation prompt is required.

Explicit composite directives that include "commit", "push", and "release" (for example,
"commit, push, and release") count as approval for each action listed in that request.
This does not authorize additional commits beyond the current task.

### Ceremony confirmations
When checks have passed and staged files have been listed, short confirmations such as
"go on" count as approval for the listed actions.

### The Anti-Chaining Rule
**One commit approval = one commit.** If the user approves a commit, the agent may execute that single commit. The agent may NOT:
- Infer that subsequent tasks should also be committed.
- Chain multiple commits under a single approval.
- Commit new work completed after the approval was given.

If the agent completes Task B after receiving approval for Task A, the agent MUST stop and request a new approval for Task B.

### The Ceremony Phase
Before any Git command, the agent MUST:
1. **Failsafe Rule**: Run `TOOLS/critic.py` and `CONTRACTS/runner.py`. Confirm they pass.
2. **Stop** all execution.
3. **List** every file in the staging area.
4. **Ask**: "Ready for the Chunked Commit Ceremony? Shall I commit and push these [N] files?"
5. **Wait** for explicit user approval (e.g., "yes, commit" or "commit and push"), unless the user already issued an explicit "commit" directive or composite approval for the listed actions.

### No Composite Commands
Do not chain `git commit` and `git push` unless the user explicitly says "commit and push."
Explicit "commit, push, and release" is also allowed. Default to separate checkpoints.

## Governance Violation
Any commit or push executed without following this ceremony is a **critical governance violation**.

## Status
**Active**
Added: 2025-12-21
Strengthened: 2025-12-21 (added anti-chaining rule and prohibited interpretations)
```

## `repo/LAW/CONTEXT/preferences/STYLE-002-engineering-integrity.md`

```
<!-- CONTENT_HASH: 2f1a7ace3e672207d920b2bcdd3a2a7d13fa982ce29f1d2548bb7d0a2ec7c174 -->

# STYLE-002: Engineering Integrity

**Category:** Governance
**Status:** Active
**Scope:** Repository-wide
**Enforcement:** Strict

---

To ensure the long-term stability and maintainability of the Agent Governance System (AGS), all engineering work must prioritize "real fixes" over "temporary patches."

## Principles

1.  **Architecture over Expediency**: If a folder structure or naming convention creates technical friction (e.g., Python import issues), rename the folder or refactor the architecture rather than implementing "hacks" or helper scripts that drift from the core design.
2.  **No Ghost Modules**: Avoid creating "patch files" or "core" helpers solely to bypass self-imposed constraints. If logic belongs in a specific component, the environment should be made to support it there.
3.  **Clean Naming**: Prefer Python-standard naming (snake_case) for any directory that requires programmatic access, even if it affects user-facing "branding" folders.
4.  **Transparency**: When faced with a choice between a quick fix and a deep refactor, the agent must present the "real fix" as the primary option.

## Consequence
Any "patch" solution that bypasses technical limitations instead of resolving them is considered a violation of engineering integrity.
```

## `repo/LAW/CONTEXT/preferences/STYLE-003-mandatory-changelog-sync.md`

```
<!-- CONTENT_HASH: fa7c56f42429ed12a93aa7d48fba28d052dec755346f3c0e2912e457690ae916 -->

# STYLE-003: Mandatory Changelog Synchronisation

**Category:** Governance
**Status:** Active
**Scope:** Repository-wide
**Enforcement:** Strict

---

To maintain the auditability and integrity of the Agent Governance System (AGS), every commit that impacts system behavior or configuration MUST be documented.

## Principles

1.  **Atomic Governance**: Any change to a `CANON` file is legally incomplete without a corresponding entry in `CANON/CHANGELOG.md`.
2.  **Zero Exceptions**: Even minor refactors (like renaming a directory for technical compliance) are user-visible system changes and must be recorded.
3.  **Ceremony Prerequisite**: The "Chunked Commit Ceremony" ([STYLE-001](file:///d:/CCC%202.0/AI/agent-governance-system/CONTEXT/preferences/STYLE-001-commit-ceremony.md)) MUST include a verification step: "Is the Changelog updated for these changes?"
4.  **Automated Failure**: Committing without a changelog update when canon has changed is a critical failure of the engineering integrity preference ([STYLE-002](file:///d:/CCC%202.0/AI/agent-governance-system/CONTEXT/preferences/STYLE-002-engineering-integrity.md)).

## Enforcement
The agent must proactively check `git diff --name-only` before every ceremony to ensure `CHANGELOG.md` is included if any `CANON/` or `SKILLS/` files are present.
```

## `repo/LAW/CONTEXT/preferences/STYLE-004-adr-first-design-gate.md`

```
<!-- CONTENT_HASH: cdea6af20df2c636695562d50702ce394d57908fe36ab1c17af0df51998200ab -->

# STYLE-004: ADR-First Design Gate

**Category:** Governance
**Status:** Active
**Scope:** Repository-wide
**Enforcement:** Strict

---

To prevent "governance amnesia" and ensure compliance with [INV-007](file:///d:/CCC%202.0/AI/agent-governance-system/CANON/INVARIANTS.md), architectural decisions must be documented BEFORE implementation, not as an afterthought.

## Principles

1.  **Mutation Check**: Before modifying any file in `CANON/` or changing the definition of an `Invariant`, the agent MUST ask: "Does this require a new ADR or an update to an existing one?"
2.  **Breadcrumb for Humans**: The ADR provides the "Why" behind the "What." Working without one is a violation of the engineering integrity preference ([STYLE-002](file:///d:/CCC%202.0/AI/agent-governance-system/CONTEXT/preferences/STYLE-002-engineering-integrity.md)).
3.  **Ceremony Audit**: The "Chunked Commit Ceremony" ([STYLE-001](file:///d:/CCC%202.0/AI/agent-governance-system/CONTEXT/preferences/STYLE-001-commit-ceremony.md)) MUST now include this explicit verification: **"Is there a corresponding ADR for these structural changes?"**

## Enforcement
If an agent discovers it is changing a system invariant (e.g., directory structures, output roots, or core grammar) without an ADR, it must immediately stop and draft the record before continuing the refactor.
```

## `repo/LAW/CONTEXT/preferences/STYLE-005-git-commit-push-protocol.md`

````
<!-- CONTENT_HASH: 36f7bc41112be4dbc3ab970fb2c16e72b463ef5c9dae5850c0d5c943642bf0be -->

# STYLE-005: Git Commit and Push Protocol

**Authority:** CONTEXT/preferences  
**Version:** 1.0.0  
**Status:** Active
**Category:** Governance
**Scope:** Repository
**Enforcement:** Strict

## Purpose

Prevent uncontrolled staging, committing, and pushing that spams CI and breaks governance.

---

## Hard Rules

### 1. Staging Rules

**NEVER use `git add .`**

Agents MUST:
- Stage files explicitly by path
- Group related changes into logical commits
- Verify what's staged before committing: `git status`

```bash
# ✅ CORRECT
git add CANON/SYSTEM_BUCKETS.md
git add AGS_ROADMAP_MASTER.md

# ❌ FORBIDDEN
git add .
git add -A
```

### 2. Branch Rules

**NO direct pushes to `main`**

All work MUST:
- Happen on feature branches
- Go through pull requests
- Pass CI checks before merge

```bash
# ✅ CORRECT workflow
git checkout -b feature/bucket-taxonomy
# ... make changes ...
git push origin feature/bucket-taxonomy
# ... create PR on GitHub ...

# ❌ FORBIDDEN
git push origin main
```

### 3. Required Local Checks

Before ANY commit, agents MUST run:

```bash
# 1. Critic (governance checks)
python TOOLS/ags.py preflight --allow-dirty-tracked

# 2. Contracts (fixtures)
python CONTRACTS/runner.py

# 3. Tests (if applicable)
python -m pytest TESTBENCH/ -v
```

**If any check fails, DO NOT COMMIT.**

### 4. One Approval = One Commit

From `AGENTS.md` Section 10:

- One user approval authorizes ONE commit only
- Completing additional work requires NEW approval
- Chaining commits under single approval is FORBIDDEN

### 5. No Push Without Green Checks

Pushes are blocked unless:
- `CONTRACTS/_runs/ALLOW_PUSH.token` exists (human-created)
- Local contracts pass
- Pre-push hook validates token

---

## Commit Ceremony

1. **Make changes** (code, docs, etc.)
2. **Run checks** (critic, contracts, tests)
3. **Stage explicitly** (by file path)
4. **Request approval** from user
5. **Commit once** with descriptive message
6. **DO NOT PUSH** - wait for explicit push approval

---

## Push Protocol

### Human-Only Push Approval

To allow a push, the human must create:

```bash
# Create one-time push token
echo "feature/bucket-taxonomy" > CONTRACTS/_runs/ALLOW_PUSH.token
```

The pre-push hook will:
1. Check token exists
2. Run minimal contracts validation
3. Allow push
4. **Delete token** (one-time use)

If token missing, push is **BLOCKED**.

---

## Enforcement

- **Pre-push hook**: Installed via `python TOOLS/setup_git_hooks.py`
- **CI triggers**: Only on PRs to `main`, not direct pushes
- **Contracts fixture**: Validates workflow trigger policy
- **GitHub branch protection**: Requires PR + status checks (human-configured)

---

## Violations

Agents that violate this protocol:
- Spam user's email with CI failures
- Break governance
- Violate commit ceremony (AGENTS.md Section 10)

**This is a critical governance failure.**
````

## `repo/LAW/CONTRACTS/README.md`

```
<!-- CONTENT_HASH: da1395c91505ae6043329f512d43e4ee191120357e96243ab97cbc0a08b7b000 -->

# Contracts

The `LAW/CONTRACTS/` directory contains the machinery that enforces rules within the Agent Governance System.

- **Fixtures** (`LAW/CONTRACTS/fixtures/`, `CAPABILITY/SKILLS/*/fixtures/`) - Concrete test cases that capture laws and precedents. Each fixture directory typically contains an `input.json` and an `expected.json`. The runner executes the relevant skill or validation script to ensure the actual output matches expectations.
- **Schemas** (`LAW/CONTRACTS/schemas/`) - JSON schemas that describe the structure of canon, skill manifests, context files and cortex indices. These can be used to validate files before they are processed.
- **Runner** (`runner.py`) - A script that discovers and runs fixtures. The runner must exit with non-zero status if any fixture fails.

Contracts are mechanical: they do not rely on human judgment or heuristics. If a change causes any fixture to fail, the change must be rejected until the fixture is updated or the change is reconsidered.
```

## `repo/LAW/CONTRACTS/ags_mcp_entrypoint.py`

```
#!/usr/bin/env python3
"""
AGS MCP Runtime Entrypoint
This file is the canonical runtime entrypoint for the AGS MCP Server.
 It correctly sets up the path and launches the capability-defined server.
"""
import sys
from pathlib import Path

# Resolve repo root (2 levels up from LAW/CONTRACTS)
REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from CAPABILITY.MCP.server import main

if __name__ == "__main__":
    main()
```

## `repo/LAW/CONTRACTS/fixtures/catalytic/phase0/invalid/jobspec_missing_phase.json`

```
{
  "job_id": "phase0-schema-freeze",
  "task_type": "schema_definition",
  "intent": "This fixture is invalid because it is missing the required field 'phase'.",
  "inputs": {},
  "outputs": {
    "durable_paths": [],
    "validation_criteria": {}
  },
  "catalytic_domains": [],
  "determinism": "deterministic"
}
```

## `repo/LAW/CONTRACTS/fixtures/catalytic/phase0/invalid/ledger_missing_restore_diff_and_bad_sha.json`

```
{
  "RUN_INFO": {
    "run_id": "run_00000002",
    "timestamp": "2025-12-24T00:00:00Z",
    "intent": "Invalid ledger fixture",
    "catalytic_domains": [
      "CATALYTIC-DPT/_scratch"
    ],
    "exit_code": 0,
    "restoration_verified": true
  },
  "PRE_MANIFEST": {
    "CATALYTIC-DPT/_scratch": {
      "placeholder.txt": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
    }
  },
  "POST_MANIFEST": {
    "CATALYTIC-DPT/_scratch": {
      "placeholder.txt": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    }
  },
  "OUTPUTS": [],
  "STATUS": {
    "status": "verified",
    "restoration_verified": true
  }
}
```

## `repo/LAW/CONTRACTS/fixtures/catalytic/phase0/invalid/validation_error_bad_code.json`

```
{
  "valid": false,
  "errors": [
    {
      "code": "NOT_A_REAL_CODE",
      "message": "This fixture is invalid due to an unsupported error code."
    }
  ],
  "warnings": [],
  "timestamp": "2025-12-24T00:00:00Z",
  "validator_version": "cat-dpt-validator/0.0.0"
}
```

## `repo/LAW/CONTRACTS/fixtures/catalytic/phase0/valid/jobspec_ok.json`

```
{
  "job_id": "phase0-schema-freeze",
  "phase": 0,
  "task_type": "schema_definition",
  "intent": "Freeze Phase 0 schemas (jobspec, validation_error, ledger) and add fixtures/tests.",
  "inputs": {
    "schemas": [
      "CATALYTIC-DPT/SCHEMAS/jobspec.schema.json",
      "CATALYTIC-DPT/SCHEMAS/validation_error.schema.json",
      "CATALYTIC-DPT/SCHEMAS/ledger.schema.json"
    ]
  },
  "outputs": {
    "durable_paths": [
      "CATALYTIC-DPT/SCHEMAS/jobspec.schema.json",
      "CATALYTIC-DPT/SCHEMAS/validation_error.schema.json",
      "CATALYTIC-DPT/SCHEMAS/ledger.schema.json"
    ],
    "validation_criteria": {
      "schemas_validate": true,
      "fixtures_exist": true
    }
  },
  "catalytic_domains": [
    "CATALYTIC-DPT/_scratch"
  ],
  "determinism": "deterministic",
  "swarm_parallel": false,
  "metadata": {
    "created_at": "2025-12-24T00:00:00Z"
  }
}
```

## `repo/LAW/CONTRACTS/fixtures/catalytic/phase0/valid/ledger_minimal_ok.json`

```
{
  "RUN_INFO": {
    "run_id": "run_00000001",
    "timestamp": "2025-12-24T00:00:00Z",
    "intent": "Phase 0 schema validation run",
    "catalytic_domains": [
      "CATALYTIC-DPT/_scratch"
    ],
    "exit_code": 0,
    "restoration_verified": true
  },
  "PRE_MANIFEST": {
    "CATALYTIC-DPT/_scratch": {
      "placeholder.txt": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    }
  },
  "POST_MANIFEST": {
    "CATALYTIC-DPT/_scratch": {
      "placeholder.txt": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    }
  },
  "RESTORE_DIFF": {
    "CATALYTIC-DPT/_scratch": {
      "added": {},
      "removed": {},
      "changed": {}
    }
  },
  "OUTPUTS": [
    {
      "path": "CATALYTIC-DPT/SCHEMAS/jobspec.schema.json",
      "type": "file",
      "sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    },
    {
      "path": "CATALYTIC-DPT/SCHEMAS/validation_error.schema.json",
      "type": "file",
      "sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    },
    {
      "path": "CATALYTIC-DPT/SCHEMAS/ledger.schema.json",
      "type": "file",
      "sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    }
  ],
  "STATUS": {
    "status": "verified",
    "restoration_verified": true,
    "exit_code": 0,
    "validation_passed": true
  },
  "VALIDATOR_ID": {
    "validator_semver": "0.0.0",
    "validator_build_id": "dev"
  }
}
```

## `repo/LAW/CONTRACTS/fixtures/catalytic/phase0/valid/proof_ok.json`

```
{
    "run_id": "fixture-proof-001",
    "proof_version": "1.0.0",
    "timestamp": "2025-12-25T00:00:00Z",
    "catalytic_domains": [
        "CATALYTIC-DPT/_scratch"
    ],
    "pre_state": {
        "domain_root_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "file_manifest": {}
    },
    "post_state": {
        "domain_root_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "file_manifest": {}
    },
    "restoration_result": {
        "verified": true,
        "condition": "RESTORED_IDENTICAL"
    },
    "proof_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
}
```

## `repo/LAW/CONTRACTS/fixtures/catalytic/phase0/valid/validation_error_ok.json`

```
{
  "valid": false,
  "errors": [
    {
      "code": "MISSING_REQUIRED_FIELD",
      "message": "Field 'phase' is required.",
      "path": "$.phase",
      "details": {
        "required": "phase"
      }
    }
  ],
  "warnings": [
    {
      "code": "TIMEOUT_UNUSUALLY_HIGH",
      "message": "Requested timeout is unusually high; consider lowering.",
      "path": "$.metadata.timeout_ms",
      "details": {
        "timeout_ms": 600000
      }
    }
  ],
  "timestamp": "2025-12-24T00:00:00Z",
  "validator_version": "cat-dpt-validator/0.0.0"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/canon-sync/expected.json`

```
{
    "description": "Verify canon-sync: authority gradient must be consistent across CONTRACT.md and AGENTS.md",
    "check_type": "canon-sync",
    "test_case": "authority_gradient_aligned",
    "contract_hierarchy": [
        "LAW/CANON/AGREEMENT.md",
        "LAW/CANON/CONTRACT.md",
        "LAW/CANON/INVARIANTS.md",
        "LAW/CANON/VERSIONING.md",
        "AGENTS.md",
        "CONTEXT records",
        "NAVIGATION/MAPS/*",
        "User instructions",
        "Implementation convenience"
    ],
    "agents_hierarchy_matches": true
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/canon-sync/input.json`

```
{
    "description": "Verify canon-sync: authority gradient must be consistent across CONTRACT.md and AGENTS.md",
    "check_type": "canon-sync",
    "test_case": "authority_gradient_aligned",
    "contract_hierarchy": [
        "LAW/CANON/AGREEMENT.md",
        "LAW/CANON/CONTRACT.md",
        "LAW/CANON/INVARIANTS.md",
        "LAW/CANON/VERSIONING.md",
        "AGENTS.md",
        "CONTEXT records",
        "NAVIGATION/MAPS/*",
        "User instructions",
        "Implementation convenience"
    ],
    "agents_hierarchy_matches": true
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/commit-ceremony/expected.json`

```
{
    "description": "Verify commit ceremony allows explicit composite approval",
    "check_type": "commit-ceremony",
    "test_case": "explicit_composite_approval",
    "explicit_approvals": [
        "commit, push, and release"
    ],
    "ceremony_confirmations": [
        "go on"
    ],
    "anti_chaining": true
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/commit-ceremony/input.json`

```
{
    "description": "Verify commit ceremony allows explicit composite approval",
    "check_type": "commit-ceremony",
    "test_case": "explicit_composite_approval",
    "explicit_approvals": [
        "commit, push, and release"
    ],
    "ceremony_confirmations": [
        "go on"
    ],
    "anti_chaining": true
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/context-edit-authority/description.txt`

```
Verify that critic enforces ADR-016: Context records cannot be edited without explicit user instruction AND task intent.

This fixture ensures agents cannot modify existing `LAW/CONTEXT/decisions/` or `LAW/CONTEXT/preferences/` files as side effects of unrelated tasks.

The test checks that:
1. critic.py detects when existing CONTEXT records are modified
2. critic.py allows append-only additions (new files)
3. The enforcement prevents accidental context corruption
```

## `repo/LAW/CONTRACTS/fixtures/governance/context-edit-authority/expected.json`

```
{
  "test": "context_edit_authority",
  "check": "enforce_context_edit_restrictions"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/context-edit-authority/input.json`

```
{
  "test": "context_edit_authority",
  "check": "enforce_context_edit_restrictions"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/deletion-authorization/expected.json`

```
{
    "description": "Verify deletions require explicit instruction and confirmation",
    "check_type": "deletion-authorization",
    "test_case": "explicit_delete_with_confirmation",
    "explicit_instruction": "delete authored content",
    "confirmation_required": true,
    "canon_archiving_required": true
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/deletion-authorization/input.json`

```
{
    "description": "Verify deletions require explicit instruction and confirmation",
    "check_type": "deletion-authorization",
    "test_case": "explicit_delete_with_confirmation",
    "explicit_instruction": "delete authored content",
    "confirmation_required": true,
    "canon_archiving_required": true
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/log-output-roots/description.txt`

```
Governance fixture: Validates that logging paths comply with ADR-015 (all logs under `LAW/CONTRACTS/_runs/`)

This fixture ensures that:
1. No code contains hardcoded references to LOGS/ or MCP/logs/
2. Canon documentation doesn't reference disallowed log paths
3. The logging policy is enforced by critic.py
```

## `repo/LAW/CONTRACTS/fixtures/governance/log-output-roots/expected.json`

```
{
  "test": "log_output_roots",
  "check": "enforce_approved_log_locations"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/log-output-roots/input.json`

```
{
  "test": "log_output_roots",
  "check": "enforce_approved_log_locations"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/no-raw-paths/expected.json`

```
{
    "description": "Verify no-raw-paths invariant: skills must query cortex, not access filesystem directly",
    "check_type": "no-raw-paths",
    "test_case": "valid_skill",
    "skill_code_sample": "from CORTEX.query import find_entities_by_type\nresults = find_entities_by_type('page')",
    "contains_raw_path_access": false
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/no-raw-paths/input.json`

```
{
  "description": "Verify no-raw-paths invariant: skills must query cortex, not access filesystem directly",
  "check_type": "no-raw-paths",
  "test_case": "valid_skill",
  "skill_code_sample": "from CORTEX.query import find_entities_by_type\nresults = find_entities_by_type('page')",
  "contains_raw_path_access": false
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/output-root-enforcement/description.txt`

```
Verify that critic enforces CONTRACT Rule 6: output-root compliance.

This fixture ensures that artifacts are only written to approved roots:
- LAW/CONTRACTS/_runs/
- NAVIGATION/CORTEX/_generated/
- MEMORY/LLM_PACKER/_packs/

The test checks that critic detects violations:
- Hardcoded BUILD/ paths in code
- Hardcoded LOGS/ or MCP/logs/ paths (legacy locations)
```

## `repo/LAW/CONTRACTS/fixtures/governance/output-root-enforcement/expected.json`

```
{
  "test": "output_root_enforcement",
  "check": "allowed_artifact_roots"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/output-root-enforcement/input.json`

```
{
  "test": "output_root_enforcement",
  "check": "allowed_artifact_roots"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/policy-proof-receipts/expected.json`

```
{
  "artifact": "POLICY.json",
  "required_fields": [
    "policy_version",
    "revoked_capabilities",
    "preflight",
    "admission"
  ],
  "preflight_fields": [
    "verdict",
    "canon_sha256",
    "cortex_sha256",
    "git_head_sha",
    "generated_at"
  ],
  "admission_fields": [
    "verdict",
    "intent_sha256",
    "mode",
    "reasons"
  ],
  "invariants": [
    "MUST_EXIST_BEFORE_EXECUTION",
    "MUST_INCLUDE_REVOCATION_SNAPSHOT",
    "MUST_BE_CANONICAL_JSON"
  ]
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/policy-proof-receipts/input.json`

```
{
  "artifact": "POLICY.json",
  "required_fields": [
    "policy_version",
    "revoked_capabilities",
    "preflight",
    "admission"
  ],
  "preflight_fields": [
    "verdict",
    "canon_sha256",
    "cortex_sha256",
    "git_head_sha",
    "generated_at"
  ],
  "admission_fields": [
    "verdict",
    "intent_sha256",
    "mode",
    "reasons"
  ],
  "invariants": [
    "MUST_EXIST_BEFORE_EXECUTION",
    "MUST_INCLUDE_REVOCATION_SNAPSHOT",
    "MUST_BE_CANONICAL_JSON"
  ]
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/preflight/expected.json`

```
{
  "command": "ags preflight",
  "exit_codes": {
    "SAFE": 0,
    "BLOCKED": 2,
    "ERROR": 3
  },
  "required_fields": [
    "git_branch",
    "git_head_sha",
    "tracked_dirty",
    "untracked_count",
    "canon_sha256",
    "cortex_present",
    "cortex_generated_at",
    "cortex_sha256",
    "verdict",
    "reasons"
  ],
  "blocking_rules_default": [
    "DIRTY_TRACKED",
    "CORTEX_MISSING",
    "CANON_CHANGED_SINCE_CORTEX"
  ],
  "warnings_default": [
    "UNTRACKED_PRESENT",
    "HANDOFF_MISSING"
  ],
  "flags": [
    "--strict",
    "--allow-dirty-tracked",
    "--json"
  ]
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/preflight/input.json`

```
{
  "command": "ags preflight",
  "exit_codes": {
    "SAFE": 0,
    "BLOCKED": 2,
    "ERROR": 3
  },
  "required_fields": [
    "git_branch",
    "git_head_sha",
    "tracked_dirty",
    "untracked_count",
    "canon_sha256",
    "cortex_present",
    "cortex_generated_at",
    "cortex_sha256",
    "verdict",
    "reasons"
  ],
  "blocking_rules_default": [
    "DIRTY_TRACKED",
    "CORTEX_MISSING",
    "CANON_CHANGED_SINCE_CORTEX"
  ],
  "warnings_default": [
    "UNTRACKED_PRESENT",
    "HANDOFF_MISSING"
  ],
  "flags": [
    "--strict",
    "--allow-dirty-tracked",
    "--json"
  ]
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/privacy-boundary/expected.json`

```
{
  "description": "Privacy boundary: agents must not access or scan files outside the repo without explicit user approval",
  "check_type": "privacy-boundary",
  "test_case": "repo_only_default",
  "requires_explicit_user_paths": true,
  "default_scope": "repo_root_only"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/privacy-boundary/input.json`

```
{
  "description": "Privacy boundary: agents must not access or scan files outside the repo without explicit user approval",
  "check_type": "privacy-boundary",
  "test_case": "repo_only_default",
  "requires_explicit_user_paths": true,
  "default_scope": "repo_root_only"
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/token-grammar/expected.json`

```
{
    "description": "Verify token-grammar invariant: glossary terms are stable API",
    "check_type": "token-grammar",
    "test_case": "core_terms_present",
    "required_terms": [
        "Canon",
        "Context",
        "Map",
        "Skill",
        "Contract",
        "Fixture",
        "Runner",
        "Cortex",
        "Memory",
        "Token grammar"
    ],
    "all_terms_defined": true
}
```

## `repo/LAW/CONTRACTS/fixtures/governance/token-grammar/input.json`

```
{
    "description": "Verify token-grammar invariant: glossary terms are stable API",
    "check_type": "token-grammar",
    "test_case": "core_terms_present",
    "required_terms": [
        "Canon",
        "Context",
        "Map",
        "Skill",
        "Contract",
        "Fixture",
        "Runner",
        "Cortex",
        "Memory",
        "Token grammar"
    ],
    "all_terms_defined": true
}
```

## `repo/LAW/CONTRACTS/git-transport.md`

```
<!-- CONTENT_HASH: GENERATED -->

# Git Transport Policy (WSL + VS Code)

## Invariants
- HTTPS is the canonical transport for `origin` (`https://github.com/OWNER/REPO.git`).
- Do not switch remotes to SSH.
- Do not store plaintext tokens anywhere in the repo.
- Authentication should be non-interactive after first setup via a credential helper.

## Repo Guard
Use the repo guard to prevent SSH remote “flips”:

- `bash CAPABILITY/TOOLS/utilities/ensure_https_remote.sh .`

This script:
- Asserts `origin` exists
- Rewrites SSH `git@github.com:` / `ssh://git@github.com/...` to HTTPS
- Exits non-zero if it cannot derive an HTTPS URL

## WSL Authentication (Preferred)
Use Windows Git Credential Manager (GCM) from WSL when available:

- `git config --global credential.helper "/mnt/c/Program Files/Git/mingw64/bin/git-credential-manager.exe"`
- `git config --global credential.https://github.com.useHttpPath true`

## Doctor
Run the doctor to see current state and suggested fixes:

- `bash CAPABILITY/TOOLS/utilities/git_doctor.sh --repo .`
- Apply fixes: `bash CAPABILITY/TOOLS/utilities/git_doctor.sh --repo . --apply`
```

## `repo/LAW/CONTRACTS/runner.py`

```
#!/usr/bin/env python3

"""
Contract runner for the Agent Governance System.

This script discovers and runs fixtures under the `LAW/CONTRACTS/fixtures/` directory
and skill fixtures under `CAPABILITY/SKILLS/*/fixtures/`. A fixture consists of an input
(`input.json` or other files) and an expected output (`expected.json`).
The runner executes the relevant skill or validation script, then compares
actual output to expected output.

Any fixture that fails will cause the runner to exit with a non-zero exit code.
"""

import subprocess
import sys
import time
from pathlib import Path
from typing import List, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[2]
FIXTURES_DIR = Path(__file__).parent / "fixtures"
SKILLS_DIR = PROJECT_ROOT / "CAPABILITY" / "SKILLS"
RUNS_DIR = Path(__file__).parent / "_runs"
DEFAULT_VALIDATE = SKILLS_DIR / "_TEMPLATE" / "validate.py"

SYSTEM1_DB = PROJECT_ROOT / "NAVIGATION" / "CORTEX" / "db" / "system1.db"
CORTEX_DB = PROJECT_ROOT / "NAVIGATION" / "CORTEX" / "_generated" / "cortex.db"


def run_process(args: List[str]) -> subprocess.CompletedProcess:
    return subprocess.run(args, capture_output=True, text=True)


def run_process_stream(args: List[str], *, cwd: Path) -> int:
    """
    Run a subprocess while streaming stdout/stderr to the console.

    The contract runner is often executed in environments where stdout can be
    buffered; streaming avoids "looks stuck" behavior for long-running steps.
    """
    res = subprocess.run(args, cwd=str(cwd))
    return res.returncode


def run_validation(validate_script: Path, actual_path: Path, expected_path: Path) -> subprocess.CompletedProcess:
    return run_process([
        sys.executable,
        str(validate_script),
        str(actual_path),
        str(expected_path),
    ])


def iter_contract_inputs() -> List[Path]:
    return sorted(FIXTURES_DIR.rglob("input.json"))


def iter_skill_inputs() -> List[Tuple[Path, Path]]:
    fixtures = []
    for category_dir in sorted(SKILLS_DIR.iterdir()):
        if not category_dir.is_dir() or category_dir.name.startswith("_"):
            continue
        # Iterate through skills in each category
        for skill_dir in sorted(category_dir.iterdir()):
            if not skill_dir.is_dir() or skill_dir.name.startswith("_"):
                continue
            fixtures_root = skill_dir / "fixtures"
            if not fixtures_root.exists():
                continue
            for input_path in sorted(fixtures_root.rglob("input.json")):
                fixtures.append((skill_dir, input_path))
    return fixtures


def ensure_navigation_dbs() -> int:
    """
    Ensure required navigation DBs exist before running fixtures.

    CI builds these DBs earlier, but local runs of the contract runner should be
    self-sufficient and deterministic.
    """
    steps: List[Tuple[Path, List[str]]] = []

    cortex_build = PROJECT_ROOT / "NAVIGATION" / "CORTEX" / "db" / "cortex.build.py"
    system1_reset = PROJECT_ROOT / "NAVIGATION" / "CORTEX" / "db" / "reset_system1.py"

    if not CORTEX_DB.exists():
        steps.append((cortex_build, [sys.executable, str(cortex_build)]))

    # system1-verify fixtures assert the DB matches current repo content. Rebuild it
    # deterministically before running fixtures (mirrors CI behavior).
    steps.append((system1_reset, [sys.executable, str(system1_reset)]))

    for script_path, cmd in steps:
        if not script_path.exists():
            print(f"[contracts/runner] Missing required build script: {script_path}")
            return 1
        print(f"[contracts/runner] Building navigation DB via {script_path.relative_to(PROJECT_ROOT)}", flush=True)
        start = time.perf_counter()
        rc = run_process_stream(cmd, cwd=PROJECT_ROOT)
        if rc != 0:
            print(f"[contracts/runner] Build failed (rc={rc})", flush=True)
            return 1
        elapsed = time.perf_counter() - start
        print(f"[contracts/runner] Build OK ({elapsed:.2f}s)", flush=True)

    return 0


def run_contract_fixture(input_path: Path) -> int:
    fixture_dir = input_path.parent
    expected = fixture_dir / "expected.json"
    if not expected.exists():
        print(f"Skipping {fixture_dir}: no expected.json")
        return 0
    if not DEFAULT_VALIDATE.exists():
        print(f"Missing default validator at {DEFAULT_VALIDATE}")
        return 1
    print(f"Running contract fixture in {fixture_dir}.", flush=True)
    start = time.perf_counter()
    result = run_validation(DEFAULT_VALIDATE, input_path, expected)
    elapsed = time.perf_counter() - start
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
    else:
        print(result.stdout)
    if result.returncode != 0:
        print(f"!!! FAILURE: {fixture_dir} !!!")
        return 1
    print(f"[contracts/runner] OK ({elapsed:.2f}s)", flush=True)
    return 0


def run_skill_fixture(skill_dir: Path, input_path: Path) -> int:
    fixture_dir = input_path.parent
    expected = fixture_dir / "expected.json"
    if not expected.exists():
        print(f"Skipping {fixture_dir}: no expected.json")
        return 0

    run_script = skill_dir / "run.py"
    validate_script = skill_dir / "validate.py"
    if not run_script.exists():
        print(f"Missing run.py for skill {skill_dir.name} at {run_script}")
        return 1
    if not validate_script.exists():
        validate_script = DEFAULT_VALIDATE

    relative_fixture = fixture_dir.relative_to(skill_dir / "fixtures")
    output_dir = RUNS_DIR / "fixtures" / skill_dir.name / relative_fixture
    output_dir.mkdir(parents=True, exist_ok=True)
    actual_path = output_dir / "actual.json"

    print(f"Running skill fixture in {fixture_dir}.", flush=True)
    fixture_start = time.perf_counter()
    rc = run_process_stream([
        sys.executable,
        "-u",
        str(run_script),
        str(input_path),
        str(actual_path),
    ], cwd=PROJECT_ROOT)
    if rc != 0:
        print(f"!!! FAILURE (EXEC): {fixture_dir} !!!")
        return 1

    exec_elapsed = time.perf_counter() - fixture_start

    validate_start = time.perf_counter()
    result = run_validation(validate_script, actual_path, expected)
    validate_elapsed = time.perf_counter() - validate_start
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
        print(f"!!! FAILURE (VAL): {fixture_dir} !!!")
        return 1
    print(result.stdout)
    if result.returncode != 0:
        print(f"!!! FAILURE: {fixture_dir} !!!")
        return 1
    total_elapsed = time.perf_counter() - fixture_start
    print(
        f"[contracts/runner] OK (exec={exec_elapsed:.2f}s, validate={validate_elapsed:.2f}s, total={total_elapsed:.2f}s)",
        flush=True,
    )
    return 0


def run_fixtures() -> int:
    failures = 0
    failures += ensure_navigation_dbs()
    if failures:
        return failures
    for input_path in iter_contract_inputs():
        failures += run_contract_fixture(input_path)
    for skill_dir, input_path in iter_skill_inputs():
        failures += run_skill_fixture(skill_dir, input_path)
    return failures


if __name__ == "__main__":
    failures = run_fixtures()
    if failures:
        print(f"\n{failures} fixture(s) failed.")
        print("FAILED FIXTURES:")
        # We need to track names, but changing return type of run_fixtures is invasive.
        # Instead, let's print failure immediately with a distinct marker.
        sys.exit(1)
    print("All fixtures passed")
    sys.exit(0)
```

## `repo/LAW/CONTRACTS/schemas/canon.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Canon Schema",
  "description": "Schema for validating canon metadata",
  "type": "object",
  "properties": {
    "canon_version": {
      "type": "string",
      "pattern": "^\\d+\\.\\d+\\.\\d+$"
    }
  },
  "required": ["canon_version"],
  "additionalProperties": true
}
```

## `repo/LAW/CONTRACTS/schemas/context.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Context Record",
  "type": "object",
  "properties": {
    "Status": { "type": "string" },
    "Date": { "type": "string" },
    "Tags": { "type": "string" }
  },
  "additionalProperties": true
}
```

## `repo/LAW/CONTRACTS/schemas/skill.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Skill Manifest",
  "type": "object",
  "properties": {
    "Version": { "type": "string" },
    "Status": { "type": "string" },
    "required_canon_version": { "type": "string" },
    "Trigger": { "type": "string" },
    "Inputs": { "type": "string" },
    "Outputs": { "type": "string" },
    "Constraints": { "type": "string" }
  },
  "required": ["Version", "Status", "required_canon_version"],
  "additionalProperties": true
}
```

## `repo/LAW/SCHEMAS/README.md`

````
<!-- CONTENT_HASH: 73bdd10b294fa7cd5231829fa07510917c4902c6acc3074987783a34f59a984f -->

# CATALYTIC-DPT Schemas (Phase 0)

**Phase**: 0 - Freeze the Contract
**Status**: Canonical definitions for Phase 1-7
**Purpose**: Three JSON schemas that define catalytic computing contracts

---

## The Three Schemas

### 1. JobSpec Schema (`jobspec.schema.json`)

**Definition**: Canonical specification for a catalytic computing task.

**Usage**: An agent (Governor/Ant) receives a JobSpec and knows exactly what to execute.

**Required Fields**:
- `job_id`: Unique identifier (kebab-case)
- `phase`: 0 (contract definition) or 1+ (execution)
- `task_type`: one of `schema_definition`, `primitive_implementation`, `validation`, `test_execution`
- `intent`: One-sentence human description
- `inputs`: Task-specific input parameters
- `outputs`: Expected durable outputs with validation criteria
- `catalytic_domains`: Scratch spaces that must be restored
- `determinism`: Level of determinism required (`deterministic`, `bounded_nondeterministic`, `nondeterministic`)

**Optional Fields**:
- `swarm_parallel`: Route to parallel execution (default: false)
- `metadata`: Priority, timeout, governance checks

**Example**:
```json
{
  "job_id": "phase1-catalytic-store",
  "phase": 1,
  "task_type": "primitive_implementation",
  "intent": "Implement content-addressable storage for catalytic kernel",
  "inputs": {"storage_path": "CATALYTIC-DPT/TESTBENCH/_store"},
  "outputs": {
    "durable_paths": ["TOOLS/catalytic_store.py"],
    "validation_criteria": {"all_tests_pass": true}
  },
  "catalytic_domains": ["CATALYTIC-DPT/TESTBENCH/_tmp"],
  "determinism": "deterministic",
  "swarm_parallel": false,
  "metadata": {"timeout_seconds": 300, "priority": 8}
}
```

---

### 2. Validation Error Vector Schema (`validation_error.schema.json`)

**Definition**: Canonical format for deterministic error reporting.

**Usage**: When a JobSpec fails validation, the error report follows this schema exactly. No ambiguous error messages.

**Required Fields**:
- `valid`: boolean (true if all checks pass)
- `errors`: array of error objects
- `warnings`: array of warning objects
- `timestamp`: ISO 8601 datetime
- `validator_version`: Version of validator that produced this report

**Error Object Format**:
```json
{
  "code": "SCHEMA_INVALID",  // UPPERCASE_SNAKE_CASE
  "message": "Field 'phase' is required",
  "path": "$.phase",  // JSONPath to the error location
  "details": {}  // Additional context
}
```

**Example Complete Report**:
```json
{
  "valid": false,
  "errors": [
    {
      "code": "MISSING_REQUIRED_FIELD",
      "message": "Field 'phase' is required but missing",
      "path": "$.phase",
      "details": {"required": ["phase"], "provided": ["job_id", "task_type"]}
    },
    {
      "code": "INVALID_ENUM_VALUE",
      "message": "Field 'determinism' has invalid value 'INVALID_VALUE'",
      "path": "$.determinism",
      "details": {"valid_values": ["deterministic", "bounded_nondeterministic", "nondeterministic"]}
    }
  ],
  "warnings": [
    {
      "code": "TIMEOUT_UNUSUALLY_HIGH",
      "message": "timeout_seconds is 10000, which is very high"
    }
  ],
  "timestamp": "2025-12-23T14:30:22.123456Z",
  "validator_version": "1.0.0"
}
```

**Error Codes** (deterministic, for parsing by models):
- `SCHEMA_INVALID`: The JSON itself is malformed
- `MISSING_REQUIRED_FIELD`: Required field not present
- `INVALID_FIELD_TYPE`: Field has wrong type (string instead of int, etc.)
- `INVALID_ENUM_VALUE`: Field value not in allowed set
- `INVALID_FORMAT`: Field fails format validation (e.g., regex)
- `INVALID_PATH`: Path does not exist or is not allowed
- `VALIDATION_LOGIC_ERROR`: Custom logic check failed
- `OUTPUT_DOES_NOT_EXIST`: Expected output file/dir not found
- `RESTORATION_FAILED`: Catalytic domain was not restored

---

### 3. Ledger Schema (`ledger.schema.json`)

**Definition**: Canonical format for run audit trails and restoration proofs.

**Usage**: After every catalytic execution, a ledger is generated in `CONTRACTS/_runs/<run_id>/`. This schema defines the structure.

**Core Files** (each becomes a JSON field):
- `RUN_INFO`: Metadata about the execution (run_id, timestamp, intent, catalytic_domains, exit_code)
- `PRE_MANIFEST`: Hash snapshot of catalytic domains before execution
- `POST_MANIFEST`: Hash snapshot of catalytic domains after execution
- `RESTORE_DIFF`: Diff between pre and post (must be empty for successful restore)
- `OUTPUTS`: List of durable outputs that were created/modified
- `STATUS`: Overall result (restored, dirty, error)
- `DECISION_LOG`: JSONL of timestamped decisions (OPTIONAL but recommended)

**Example RUN_INFO**:
```json
{
  "run_id": "phase1-catalytic-store-20251223-143022",
  "timestamp": "2025-12-23T14:30:22.123456Z",
  "intent": "Implement content-addressable storage",
  "catalytic_domains": ["CATALYTIC-DPT/TESTBENCH/_tmp"],
  "durable_output_roots": ["TOOLS/catalytic_store.py"],
  "exit_code": 0,
  "restoration_verified": true
}
```

**Example RESTORE_DIFF** (SUCCESS - empty):
```json
{
  "CATALYTIC-DPT/TESTBENCH/_tmp": {
    "added": {},
    "removed": {},
    "changed": {}
  }
}
```

**Example RESTORE_DIFF** (FAILURE - has changes):
```json
{
  "CATALYTIC-DPT/TESTBENCH/_tmp": {
    "added": {
      "leftover_file.txt": "abc123def456..."
    },
    "removed": {},
    "changed": {}
  }
}
```

**Example OUTPUTS**:
```json
[
  {
    "path": "TOOLS/catalytic_store.py",
    "type": "file",
    "sha256": "abc123def456abc123def456abc123def456abc123def456abc123def456abcd"
  },
  {
    "path": "CATALYTIC-DPT/TESTBENCH/_runs/phase1-catalytic-store-20251223-143022/",
    "type": "directory"
  }
]
```

**Example STATUS**:
```json
{
  "status": "restored",
  "restoration_verified": true,
  "exit_code": 0,
  "validation_passed": true
}
```

---

## Validation Rules (Executable)

### JobSpec Validation

1. **Required fields present**: job_id, phase, task_type, intent, outputs, catalytic_domains
2. **Field types correct**:
   - `job_id`: string, matches regex `^[a-z0-9-]+$`
   - `phase`: integer, value 0 or 1
   - `task_type`: string, one of enum
   - `catalytic_domains`: array of strings (directory paths)
   - `outputs.durable_paths`: array of strings under allowed roots
3. **Phase-specific rules**:
   - Phase 0: `task_type` must be `schema_definition`
   - Phase 1: `task_type` must be one of `primitive_implementation`, `validation`, `test_execution`
4. **Path validation**:
   - All `catalytic_domains` must be under `CATALYTIC-DPT/`
   - All `durable_paths` must be under allowed roots (CATALYTIC-DPT, CONTRACTS, TOOLS, etc.)
   - No paths outside the repo
   - No forbidden paths (CANON, AGENTS.md, BUILD)

### Ledger Validation

1. **File existence**: RUN_INFO, PRE_MANIFEST, POST_MANIFEST, RESTORE_DIFF, OUTPUTS, STATUS must exist
2. **JSON validity**: All files must be valid JSON
3. **Restoration proof**: RESTORE_DIFF must be empty (success) or documented (failure)
4. **Output existence**: All outputs listed in OUTPUTS.json must exist on disk
5. **Field presence**:
   - RUN_INFO must have: run_id, timestamp, intent, catalytic_domains, exit_code, restoration_verified
   - STATUS must have: status, restoration_verified

---

## Testing the Schemas

### Self-Validation

Each schema should validate its own structure:

```python
import json
import jsonschema

# Load jobspec schema
with open("CATALYTIC-DPT/SCHEMAS/jobspec.schema.json") as f:
    jobspec_schema = json.load(f)

# Validate that the schema itself is valid JSON Schema Draft 7
from jsonschema import Draft7Validator
Draft7Validator.check_schema(jobspec_schema)  # Raises if invalid

# Test with valid example
valid_jobspec = {
    "job_id": "test-valid",
    "phase": 0,
    "task_type": "schema_definition",
    "intent": "Test",
    "inputs": {},
    "outputs": {"durable_paths": [], "validation_criteria": {}},
    "catalytic_domains": []
}

jsonschema.validate(instance=valid_jobspec, schema=jobspec_schema)
# Passes if valid
```

### Test Fixtures

- `CATALYTIC-DPT/FIXTURES/phase0/valid/jobspec_*.json` - Examples that pass validation
- `CATALYTIC-DPT/FIXTURES/phase0/invalid/jobspec_*.json` - Examples that fail (with expected errors documented)

---

## Documentation for Governor/Executor

When the Governor reads these schemas, it should understand:

1. **JobSpec**: "This is what I'm asked to do, broken down into fields"
2. **Validation Error Vector**: "If I produce errors, they follow this deterministic format"
3. **Ledger**: "After I execute, I produce this audit trail that proves restoration"

The schemas are the **contract** between human and small model. No ambiguity.

---

## Current Status

- [ ] jobspec.schema.json - TO DO
- [ ] validation_error.schema.json - TO DO
- [ ] ledger.schema.json - TO DO
- [ ] All schemas self-validating - TO DO
- [ ] Fixtures (valid + invalid) - TO DO
- [ ] Documentation complete - TO DO

**Next Step**: Implement Phase 0 contracts using this README as the specification.
````

## `repo/LAW/SCHEMAS/VERSIONING_POLICY.md`

```
<!-- CONTENT_HASH: 69dec784c5ce5c8d7ac16cf711b8061a6a2b6b6d90e98d7f0ccc46ce5cce6281 -->

# CAT-DPT Schema Versioning Policy

Status: ACTIVE
Version: 1.0.0

## 1. Goal
Ensure that historical catalytic runs remains verifiable indefinitely, even as schemas for JobSpecs, Ledgers, and Proofs evolve.

## 2. Immutability of Major Versions
- Any change that is not purely additive or non-breaking (e.g., adding an optional field) MUST increment the schema version.
- Historical schemas MUST remain in the repository (e.g., `jobspec.v1.schema.json`) or be reachable via a stable content-addressed reference.

## 3. Backward Compatibility
- Verifiers MUST select the correct schema based on the version declared in the artifact (e.g., `dag_version` in `PIPELINE_DAG.json`).
- If a verifier encounter an unknown schema version, it MUST fail closed.

## 4. Migration Paths
- When a schema version is bumped, a migration script (or skill) MUST be provided if existing artifacts need to be "upgraded" for new tooling.
- Upgrading historical artifacts MUST NOT invalidate their original cryptographic proofs. Typically, this means producing a NEW artifact alongside the old one.

## 5. Release Ceremony for Schema Changes
Changing a schema is a "Law Change" and requires:
1. An ADR documenting the rationale.
2. Updates to `SCHEMAS/` with appropriate versioning.
3. Verification that historical runs still pass with old schemas.
4. Incrementing the `validator_semver` in `PipelineRuntime`.
```

## `repo/LAW/SCHEMAS/adapter.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "adapter.schema.json",
  "title": "Adapter Contract (Skills + MCP Wrappers)",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "adapter_version",
    "name",
    "command",
    "jobspec",
    "inputs",
    "outputs",
    "side_effects",
    "deref_caps",
    "artifacts"
  ],
  "properties": {
    "adapter_version": {
      "type": "string",
      "minLength": 1
    },
    "name": {
      "type": "string",
      "minLength": 1
    },
    "command": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "jobspec": {
      "$ref": "jobspec.schema.json"
    },
    "inputs": {
      "type": "object",
      "additionalProperties": {
        "type": "string",
        "pattern": "^[0-9a-f]{64}$"
      }
    },
    "outputs": {
      "type": "object",
      "additionalProperties": {
        "type": "string",
        "pattern": "^[0-9a-f]{64}$"
      }
    },
    "side_effects": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "network",
        "clock",
        "filesystem_unbounded",
        "nondeterministic"
      ],
      "properties": {
        "network": { "type": "boolean" },
        "clock": { "type": "boolean" },
        "filesystem_unbounded": { "type": "boolean" },
        "nondeterministic": { "type": "boolean" }
      }
    },
    "deref_caps": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "max_bytes",
        "max_matches",
        "max_nodes",
        "max_depth"
      ],
      "properties": {
        "max_bytes": { "type": "integer", "minimum": 0 },
        "max_matches": { "type": "integer", "minimum": 0 },
        "max_nodes": { "type": "integer", "minimum": 0 },
        "max_depth": { "type": "integer", "minimum": 0 }
      }
    },
    "artifacts": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "ledger",
        "proof",
        "domain_roots"
      ],
      "properties": {
        "ledger": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
        "proof": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
        "domain_roots": { "type": "string", "pattern": "^[0-9a-f]{64}$" }
      }
    }
  }
}
```

## `repo/LAW/SCHEMAS/ags_plan.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "ags_plan.schema.json",
  "title": "AGS Plan (Router Output)",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "plan_version",
    "steps"
  ],
  "properties": {
    "plan_version": {
      "type": "string",
      "const": "1.0"
    },
    "pipeline_id": {
      "type": "string",
      "minLength": 1
    },
    "router": {
      "type": "object",
      "description": "Phase 8: Router receipt metadata."
    },
    "steps": {
      "type": "array",
      "minItems": 1,
      "maxItems": 64,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "properties": {
          "step_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128
          },
          "capability_hash": {
            "type": "string",
            "pattern": "^[0-9a-f]{64}$"
          },
          "command": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "string",
              "minLength": 1
            }
          },
          "jobspec": {
            "type": "object"
          },
          "adapter": {
            "$ref": "adapter.schema.json"
          },
          "memoize": {
            "type": "boolean",
            "default": true
          },
          "strict": {
            "type": "boolean",
            "default": true
          }
        },
        "oneOf": [
          {
            "required": [
              "step_id",
              "command",
              "jobspec"
            ]
          },
          {
            "required": [
              "step_id",
              "adapter"
            ]
          },
          {
            "required": [
              "step_id",
              "capability_hash"
            ]
          }
        ]
      }
    }
  }
}
```

## `repo/LAW/SCHEMAS/examples/jobspec.example.json`

```
{
    "job_id": "jobspec-example",
    "phase": 0,
    "task_type": "schema_definition",
    "intent": "Demonstrate a minimal, schema-valid JobSpec.",
    "inputs": {
        "module": "CATALYTIC-DPT/SCHEMAS/jobspec.schema.json"
    },
    "outputs": {
        "durable_paths": [
            "SCHEMAS/examples/jobspec.example.json"
        ],
        "validation_criteria": {
            "file_exists": true
        }
    },
    "catalytic_domains": [],
    "determinism": "deterministic"
}
```

## `repo/LAW/SCHEMAS/examples/ledger.example.json`

```
{
    "RUN_INFO": {
        "run_id": "example-run-001",
        "timestamp": "2025-12-25T04:58:30Z",
        "intent": "Demonstrate a minimal, schema-valid run ledger entry.",
        "catalytic_domains": [
            "TOOLS/_tmp/"
        ],
        "exit_code": 0,
        "restoration_verified": true
    },
    "PRE_MANIFEST": {
        "TOOLS/_tmp/": {
            "README.md": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        }
    },
    "POST_MANIFEST": {
        "TOOLS/_tmp/": {
            "README.md": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        }
    },
    "RESTORE_DIFF": {
        "TOOLS/_tmp/": {
            "added": {},
            "removed": {},
            "changed": {}
        }
    },
    "OUTPUTS": [
        {
            "path": "CONTRACTS/_runs/example-run-001/STATUS.json",
            "type": "file",
            "sha256": "5891b80220224249339023423423423423423423423423423423423423423423"
        }
    ],
    "STATUS": {
        "status": "success",
        "restoration_verified": true,
        "exit_code": 0
    }
}
```

## `repo/LAW/SCHEMAS/examples/swarm.example.json`

```
{
  "swarm_version": "1.0.0",
  "swarm_id": "example-swarm",
  "nodes": [
    {
      "node_id": "p1",
      "pipeline_id": "pipeline-1"
    },
    {
      "node_id": "p2",
      "pipeline_spec_path": "CATALYTIC-DPT/FIXTURES/phase0/valid/jobspec.json"
    }
  ],
  "edges": [
    {
      "from": "p1",
      "to": "p2",
      "requires": ["RECEIPT.json", "CHAIN.json"]
    }
  ]
}
```

## `repo/LAW/SCHEMAS/examples/validation_error.example.json`

```
{
    "valid": false,
    "errors": [
        {
            "code": "MISSING_REQUIRED_FIELD",
            "message": "Missing required field: 'job_id'",
            "path": "/"
        }
    ],
    "warnings": [],
    "timestamp": "2025-12-25T04:58:30Z",
    "validator_version": "1.0.0"
}
```

## `repo/LAW/SCHEMAS/jobspec.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "jobspec.schema.json",
  "title": "CAT-DPT JobSpec",
  "type": "object",
  "additionalProperties": false,
  "$comment": "CAT-DPT Phase 0 contract schema. Freeze via git tag after first release.",
  "required": [
    "job_id",
    "phase",
    "task_type",
    "intent",
    "inputs",
    "outputs",
    "catalytic_domains",
    "determinism"
  ],
  "properties": {
    "job_id": {
      "type": "string",
      "description": "Unique job identifier (kebab-case).",
      "pattern": "^[a-z0-9-]+$"
    },
    "phase": {
      "type": "integer",
      "description": "Roadmap phase number.",
      "minimum": 0
    },
    "task_type": {
      "type": "string",
      "description": "Canonical task category.",
      "enum": [
        "schema_definition",
        "primitive_implementation",
        "validation",
        "test_execution",
        "adapter_execution",
        "pipeline_execution"
      ]
    },
    "intent": {
      "type": "string",
      "description": "One-sentence human description of the job.",
      "minLength": 1
    },
    "inputs": {
      "type": "object",
      "description": "Task-specific inputs. May include hash references.",
      "additionalProperties": true
    },
    "outputs": {
      "type": "object",
      "description": "Expected durable outputs and validation criteria.",
      "additionalProperties": false,
      "required": [
        "durable_paths",
        "validation_criteria"
      ],
      "properties": {
        "durable_paths": {
          "type": "array",
          "description": "Paths that may remain after run completion.",
          "items": {
            "type": "string",
            "minLength": 1
          }
        },
        "validation_criteria": {
          "type": "object",
          "description": "Machine-checkable acceptance criteria (free-form, but should be deterministic).",
          "additionalProperties": true
        }
      }
    },
    "catalytic_domains": {
      "type": "array",
      "description": "Scratch domains that must be restored byte-identical post-run.",
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "determinism": {
      "type": "string",
      "description": "Determinism requirement for the job.",
      "enum": [
        "deterministic",
        "bounded_nondeterministic",
        "nondeterministic"
      ]
    },
    "swarm_parallel": {
      "type": "boolean",
      "description": "Optional hint: safe to run as a parallel worker job. If omitted, consumers must assume false."
    },
    "metadata": {
      "type": "object",
      "description": "Optional governance metadata: scheduling, priority, provenance, etc. If omitted, consumers must assume empty object.",
      "additionalProperties": true
    }
  }
}
```

## `repo/LAW/SCHEMAS/ledger.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "ledger.schema.json",
  "id": "ledger.schema.json",
  "title": "CAT-DPT Run Ledger (Logical)",
  "type": "object",
  "additionalProperties": false,
  "$comment": "CAT-DPT Phase 0 contract schema. Logical ledger object; may be stored as multiple files on disk. APPEND-ONLY: once a ledger entry is written, it must never be modified or deleted.",
  "required": [
    "RUN_INFO",
    "PRE_MANIFEST",
    "POST_MANIFEST",
    "RESTORE_DIFF",
    "OUTPUTS",
    "STATUS"
  ],
  "properties": {
    "JOBSPEC": {
      "$ref": "jobspec.schema.json"
    },
    "RUN_INFO": {
      "$ref": "ledger.schema.json#/definitions/run_info"
    },
    "PRE_MANIFEST": {
      "$ref": "ledger.schema.json#/definitions/manifest"
    },
    "POST_MANIFEST": {
      "$ref": "ledger.schema.json#/definitions/manifest"
    },
    "RESTORE_DIFF": {
      "$ref": "ledger.schema.json#/definitions/restore_diff"
    },
    "OUTPUTS": {
      "$ref": "ledger.schema.json#/definitions/outputs"
    },
    "STATUS": {
      "$ref": "ledger.schema.json#/definitions/status"
    },
    "VALIDATOR_ID": {
      "$ref": "ledger.schema.json#/definitions/validator_id"
    }
  },
  "definitions": {
    "sha256": {
      "type": "string",
      "pattern": "^[a-f0-9]{64}$"
    },
    "run_info": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "run_id",
        "timestamp",
        "intent",
        "catalytic_domains",
        "exit_code",
        "restoration_verified"
      ],
      "properties": {
        "run_id": {
          "type": "string",
          "minLength": 1
        },
        "timestamp": {
          "type": "string",
          "minLength": 1
        },
        "intent": {
          "type": "string",
          "minLength": 1
        },
        "catalytic_domains": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          }
        },
        "exit_code": {
          "type": "integer"
        },
        "restoration_verified": {
          "type": "boolean"
        }
      }
    },
    "manifest": {
      "type": "object",
      "description": "Map: domain -> {relative_path -> sha256}.",
      "additionalProperties": {
        "type": "object",
        "additionalProperties": {
          "$ref": "ledger.schema.json#/definitions/sha256"
        }
      }
    },
    "restore_diff": {
      "type": "object",
      "description": "Map: domain -> {added, removed, changed} where each is {path -> sha256}.",
      "additionalProperties": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "added",
          "removed",
          "changed"
        ],
        "properties": {
          "added": {
            "type": "object",
            "additionalProperties": {
              "$ref": "ledger.schema.json#/definitions/sha256"
            }
          },
          "removed": {
            "type": "object",
            "additionalProperties": {
              "$ref": "ledger.schema.json#/definitions/sha256"
            }
          },
          "changed": {
            "type": "object",
            "additionalProperties": {
              "$ref": "ledger.schema.json#/definitions/sha256"
            }
          }
        }
      }
    },
    "outputs": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "path",
          "type"
        ],
        "properties": {
          "path": {
            "type": "string",
            "minLength": 1
          },
          "type": {
            "type": "string",
            "enum": [
              "file",
              "directory"
            ]
          },
          "sha256": {
            "$ref": "ledger.schema.json#/definitions/sha256"
          }
        }
      }
    },
    "status": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "status",
        "restoration_verified"
      ],
      "properties": {
        "status": {
          "type": "string",
          "minLength": 1
        },
        "restoration_verified": {
          "type": "boolean"
        },
        "exit_code": {
          "type": "integer"
        },
        "validation_passed": {
          "type": "boolean"
        }
      }
    },
    "validator_id": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "validator_semver",
        "validator_build_id"
      ],
      "properties": {
        "validator_semver": {
          "type": "string",
          "minLength": 1
        },
        "validator_build_id": {
          "type": "string",
          "minLength": 1
        }
      }
    }
  }
}
```

## `repo/LAW/SCHEMAS/manifest.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Memory Pack Manifest",
  "type": "object",
  "properties": {
    "canon_version": {
      "type": "string"
    },
    "files": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "path": { "type": "string" },
          "hash": { "type": "string" },
          "size": { "type": "number" }
        },
        "required": ["path", "hash", "size"],
        "additionalProperties": false
      }
    }
  },
  "required": ["canon_version", "files"],
  "additionalProperties": false
}
```

## `repo/LAW/SCHEMAS/proof.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "proof.schema.json",
  "$comment": "CAT-DPT Restoration Proof Protocol. Artifact-only verification structure. IMMUTABLE: once generated, proof must never be modified.",
  "title": "CAT-DPT Restoration Proof",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "proof_version",
    "run_id",
    "timestamp",
    "catalytic_domains",
    "pre_state",
    "post_state",
    "restoration_result",
    "proof_hash"
  ],
  "properties": {
    "proof_version": {
      "type": "string",
      "const": "1.0.0",
      "description": "Protocol version. Must be exactly '1.0.0' for this schema."
    },
    "run_id": {
      "type": "string",
      "minLength": 1,
      "description": "Unique identifier linking this proof to a specific run."
    },
    "timestamp": {
      "type": "string",
      "format": "date-time",
      "description": "ISO 8601 timestamp of proof generation."
    },
    "catalytic_domains": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      },
      "description": "List of domain roots that were subject to restoration verification."
    },
    "pre_state": {
      "$ref": "#/definitions/domain_state",
      "description": "Snapshot of domain state before run execution."
    },
    "post_state": {
      "$ref": "#/definitions/domain_state",
      "description": "Snapshot of domain state after restoration."
    },
    "restoration_result": {
      "$ref": "#/definitions/restoration_result",
      "description": "Verification outcome with explicit success or failure semantics."
    },
    "proof_hash": {
      "$ref": "#/definitions/sha256",
      "description": "SHA-256 hash of this proof object excluding the proof_hash field itself. Computed over canonical JSON (sorted keys, no whitespace)."
    },
    "referenced_artifacts": {
      "$ref": "#/definitions/referenced_artifacts",
      "description": "Optional explicit list of artifacts required for offline verification."
    }
  },
  "definitions": {
    "sha256": {
      "type": "string",
      "pattern": "^[a-f0-9]{64}$",
      "description": "Lowercase hex-encoded SHA-256 hash (64 characters)."
    },
    "domain_state": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "domain_root_hash",
        "file_manifest"
      ],
      "properties": {
        "domain_root_hash": {
          "$ref": "#/definitions/sha256",
          "description": "Merkle root or aggregate hash of all files in domain."
        },
        "file_manifest": {
          "type": "object",
          "additionalProperties": {
            "$ref": "#/definitions/sha256"
          },
          "description": "Map: relative_path -> sha256 hash of file contents."
        }
      }
    },
    "restoration_result": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "verified",
        "condition"
      ],
      "properties": {
        "verified": {
          "type": "boolean",
          "description": "True if and only if all verification conditions passed."
        },
        "condition": {
          "type": "string",
          "enum": [
            "RESTORED_IDENTICAL",
            "RESTORATION_FAILED_HASH_MISMATCH",
            "RESTORATION_FAILED_MISSING_FILES",
            "RESTORATION_FAILED_EXTRA_FILES",
            "RESTORATION_FAILED_DOMAIN_UNREACHABLE"
          ],
          "description": "Explicit verification outcome. RESTORED_IDENTICAL is the only success condition."
        },
        "mismatches": {
          "type": "array",
          "items": {
            "$ref": "#/definitions/mismatch_entry"
          },
          "description": "Required when condition is not RESTORED_IDENTICAL. Lists all verification failures."
        }
      },
      "allOf": [
        {
          "if": {
            "properties": {
              "condition": {
                "const": "RESTORED_IDENTICAL"
              }
            }
          },
          "then": {
            "properties": {
              "verified": {
                "const": true
              }
            }
          }
        },
        {
          "if": {
            "properties": {
              "condition": {
                "not": {
                  "const": "RESTORED_IDENTICAL"
                }
              }
            }
          },
          "then": {
            "properties": {
              "verified": {
                "const": false
              }
            },
            "required": [
              "verified",
              "condition",
              "mismatches"
            ]
          }
        }
      ]
    },
    "mismatch_entry": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "path",
        "type"
      ],
      "properties": {
        "path": {
          "type": "string",
          "minLength": 1,
          "description": "Relative path within domain."
        },
        "type": {
          "type": "string",
          "enum": [
            "hash_mismatch",
            "missing",
            "extra"
          ],
          "description": "Type of mismatch detected."
        },
        "expected_hash": {
          "$ref": "#/definitions/sha256",
          "description": "Expected hash from pre_state. Required for hash_mismatch and missing."
        },
        "actual_hash": {
          "$ref": "#/definitions/sha256",
          "description": "Actual hash found. Required for hash_mismatch and extra."
        }
      }
    },
    "referenced_artifacts": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "ledger_hash",
        "jobspec_hash"
      ],
      "properties": {
        "ledger_hash": {
          "$ref": "#/definitions/sha256",
          "description": "SHA-256 hash of the ledger entry this proof validates."
        },
        "jobspec_hash": {
          "$ref": "#/definitions/sha256",
          "description": "SHA-256 hash of the jobspec that initiated the run."
        },
        "validator_id": {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "validator_semver",
            "validator_build_id"
          ],
          "properties": {
            "validator_semver": {
              "type": "string",
              "minLength": 1
            },
            "validator_build_id": {
              "type": "string",
              "minLength": 1
            }
          },
          "description": "Identity of validator that generated this proof."
        }
      }
    }
  }
}
```

## `repo/LAW/SCHEMAS/swarm.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "swarm.schema.json",
  "title": "CAT-DPT Swarm Specification (DAG of Pipelines)",
  "description": "Defines a directed acyclic graph of pipelines with explicit artifact dependencies.",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "swarm_version",
    "swarm_id",
    "nodes"
  ],
  "properties": {
    "swarm_version": {
      "type": "string",
      "const": "1.0.0",
      "description": "Schema version."
    },
    "swarm_id": {
      "type": "string",
      "minLength": 1,
      "maxLength": 128,
      "description": "Unique identifier for the swarm."
    },
    "nodes": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "properties": {
          "node_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128,
            "description": "Logical ID of the node in the DAG."
          },
          "pipeline_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128,
            "description": "References an existing pipeline directory by ID."
          },
          "pipeline_spec_path": {
            "type": "string",
            "description": "Path to a PipelineSpec JSON file."
          },
          "pipeline_spec": {
            "type": "object",
            "description": "Inline PipelineSpec object."
          }
        },
        "required": ["node_id"],
        "oneOf": [
          { "required": ["node_id", "pipeline_id"] },
          { "required": ["node_id", "pipeline_spec_path"] },
          { "required": ["node_id", "pipeline_spec"] }
        ]
      },
      "description": "Nodes in the DAG. Tie-breaking during topo sort uses node_id lexicographical order."
    },
    "edges": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["from", "to", "requires"],
        "properties": {
          "from": {
            "type": "string",
            "description": "node_id of the source node."
          },
          "to": {
            "type": "string",
            "description": "node_id of the destination node."
          },
          "requires": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "string",
              "enum": ["PIPELINE.json", "STATE.json", "CHAIN.json", "RECEIPT.json"],
              "description": "Artifact name required from the source node."
            }
          }
        }
      },
      "description": "Directed edges representing dependencies."
    }
  }
}
```

## `repo/LAW/SCHEMAS/validation_error.schema.json`

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "validation_error.schema.json",
  "title": "CAT-DPT Validation Error Vector",
  "type": "object",
  "additionalProperties": false,
  "$comment": "CAT-DPT Phase 0 contract schema. Errors must be stable and machine-readable.",
  "required": [
    "valid",
    "errors",
    "warnings",
    "timestamp",
    "validator_version"
  ],
  "properties": {
    "valid": {
      "type": "boolean"
    },
    "errors": {
      "type": "array",
      "items": {
        "$ref": "#/definitions/issue"
      }
    },
    "warnings": {
      "type": "array",
      "items": {
        "$ref": "#/definitions/issue"
      }
    },
    "timestamp": {
      "type": "string",
      "description": "ISO 8601 datetime string.",
      "minLength": 1
    },
    "validator_version": {
      "type": "string",
      "description": "Human-readable validator version (semver or commit-hash).",
      "minLength": 1
    }
  },
  "definitions": {
    "issue": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "code",
        "message"
      ],
      "properties": {
        "code": {
          "type": "string",
          "enum": [
            "SCHEMA_INVALID",
            "MISSING_REQUIRED_FIELD",
            "INVALID_FIELD_TYPE",
            "INVALID_ENUM_VALUE",
            "INVALID_FORMAT",
            "INVALID_PATH",
            "VALIDATION_LOGIC_ERROR",
            "OUTPUT_DOES_NOT_EXIST",
            "RESTORATION_FAILED",
            "TIMEOUT_UNUSUALLY_HIGH"
          ]
        },
        "message": {
          "type": "string",
          "minLength": 1
        },
        "path": {
          "type": "string",
          "description": "JSONPath-like pointer to failing field, when applicable.",
          "default": ""
        },
        "details": {
          "type": "object",
          "description": "Optional structured details for debugging and automation.",
          "additionalProperties": true,
          "default": {}
        }
      }
    }
  }
}
```

## `repo/LAW/__init__.py`

```

```
