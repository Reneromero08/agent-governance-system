# LAW/CONTRACTS/schemas

## `LAW/CONTRACTS/schemas/canon.schema.json` (343 bytes)

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Canon Schema",
  "description": "Schema for validating canon metadata",
  "type": "object",
  "properties": {
    "canon_version": {
      "type": "string",
      "pattern": "^\\d+\\.\\d+\\.\\d+$"
    }
  },
  "required": ["canon_version"],
  "additionalProperties": true
}
```

## `LAW/CONTRACTS/schemas/context.schema.json` (265 bytes)

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Context Record",
  "type": "object",
  "properties": {
    "Status": { "type": "string" },
    "Date": { "type": "string" },
    "Tags": { "type": "string" }
  },
  "additionalProperties": true
}
```

## `LAW/CONTRACTS/schemas/skill.schema.json` (500 bytes)

```
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Skill Manifest",
  "type": "object",
  "properties": {
    "Version": { "type": "string" },
    "Status": { "type": "string" },
    "required_canon_version": { "type": "string" },
    "Trigger": { "type": "string" },
    "Inputs": { "type": "string" },
    "Outputs": { "type": "string" },
    "Constraints": { "type": "string" }
  },
  "required": ["Version", "Status", "required_canon_version"],
  "additionalProperties": true
}
```
