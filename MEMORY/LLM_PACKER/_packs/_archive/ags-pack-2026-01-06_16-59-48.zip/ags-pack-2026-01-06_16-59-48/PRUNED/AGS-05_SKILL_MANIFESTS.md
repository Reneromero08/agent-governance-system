# CAPABILITY/SKILLS/*/SKILL.md

## `CAPABILITY/SKILLS/_TEMPLATE/SKILL.md` (949 bytes)

```
<!-- CONTENT_HASH: 76ff8aae9eb9a7f8b730bd62abc2d5402a8164f08955f99a03ab77fa196ddf03 -->

**required_canon_version:** >=3.0.0


# Skill: skill_name

**Version:** 0.1.0

**Status:** Draft



## Trigger

Describe the user intent or condition that should trigger this skill. For example, "when the agent receives a request to create a new blog post".

## Inputs

List the inputs expected by the skill. Include types, defaults and whether each input is required.

## Outputs

Describe what the skill returns or modifies. Specify the output format (e.g. JSON, Markdown) and any side effects.

## Constraints

- Must not modify the canon or context directly.
- Must use the cortex to locate files.
- Must be deterministic and idempotent.

## Fixtures

List the fixtures (under `fixtures/`) that exercise this skill. Each fixture should capture a typical use case and an edge case.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/agents/ant-worker/SKILL.md` (1,016 bytes)

```
<!-- CONTENT_HASH: e9b3918a7aa216870420a0d5852f11f7e78c5647138300d6ae772490d6e79ffc -->

**required_canon_version:** >=3.0.0


# Skill: ant-worker
**Version:** 0.1.0
**Status:** Active


# Ant Worker

Distributed task executor for CATALYTIC-DPT swarm.

## Usage

```bash
python scripts/run.py input.json output.json
```

## Task Types

| Type | Operations |
|------|------------|
| `file_operation` | copy, move, delete, read |
| `code_adapt` | find/replace, update imports |
| `validate` | run fixtures, check syntax |
| `research` | analyze file structure |

## Input Schema

```json
{
  "task_id": "copy-files-001",
  "task_type": "file_operation",
  "operation": "copy",
  "files": [
    {"source": "path/to/src", "destination": "path/to/dest"}
  ],
  "verify_integrity": true
}
```

## Governance

- All operations hash-verified (SHA-256)
- Logged to `CONTRACTS/_runs/<task_id>/`
- On error: STOP and escalate to Governor

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/commit/artifact-escape-hatch/SKILL.md` (930 bytes)

```
<!-- CONTENT_HASH: 6cd3be5be3af699574e28b5c93e12683f8435c5e43cbe5bd5da88de25bae4a66 -->

**required_canon_version:** >=3.0.0


# Skill: artifact-escape-hatch

**Version:** 0.1.0

**Status:** Active



## Trigger

Run this skill as part of CI or pre-commit to verify no generated files have been written outside allowed artifact roots.

## Inputs

- `check_type`: "artifact-escape-hatch"
- `description`: Human-readable description of the check

## Outputs

- `escaped_artifacts`: List of paths that violate INV-006
- `escape_check_passed`: Boolean indicating if check passed

## Constraints

- Must not modify any files.
- Scans CONTRACTS, CORTEX, MEMORY, SKILLS directories.
- Allowed roots: `CONTRACTS/_runs/`, `CORTEX/_generated/`, `MEMORY/LLM_PACKER/_packs/`, `BUILD/`.

## Fixtures

- `fixtures/basic/` - Verifies the check passes on a clean repo.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/commit/commit-queue/SKILL.md` (1,715 bytes)

```
<!-- CONTENT_HASH: 2acfc1d9ccc3d523edf7118e48beccae7b879b278e946f016b310644793d5539 -->

**required_canon_version:** >=3.0.0


# Skill: commit-queue

**Version:** 0.1.0

**Status:** Active



## Trigger

Use when managing a queued commit workflow (enqueue, list, process) that coordinates multiple local agents and produces deterministic queue artifacts.

## Overview

Provide a deterministic commit queue stored under `CONTRACTS/_runs/commit_queue/` and a process step that stages files for the next queued entry without performing `git commit`.

## Workflow

1) Enqueue a commit request with `action: "enqueue"` and required metadata.
2) List the queue with `action: "list"`.
3) Process the next entry with `action: "process"` to stage files and emit a status payload.
4) If staging succeeds, follow the normal commit ceremony manually.

## Input schema (run.py)

- `action`: "enqueue" | "list" | "process"
- `queue_id`: optional string (default: "default")
- `entry`: object for enqueue:
  - `message`: commit message
  - `files`: array of repo-relative paths
  - `author`: optional string
  - `notes`: optional string
  - `created_at`: required string timestamp
- `max_items`: integer for list

## Output schema

- `ok`: boolean
- `queue_id`: string
- `action`: string
- `entries`: array (for list)
- `staged`: array (for process)
- `status`: string ("pending" | "staged" | "error")
- `error`: string (if any)

## Constraints

- Append-only queue at `CONTRACTS/_runs/commit_queue/<queue_id>.jsonl`.
- No automatic `git commit` inside the skill; commits remain manual and ceremony-gated.
- Repo-relative paths only.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/commit/commit-summary-log/SKILL.md` (3,316 bytes)

```
<!-- CONTENT_HASH: 9b6f208bd4bca482a927ba797787ae4d18e6a16ac16f3a2e1ca7bd429fd19f80 -->

**required_canon_version:** >=3.0.0


# Skill: commit-summary-log

**Version:** 0.2.0

**Status:** Active



## Purpose

1) Write a deterministic, per-commit summary entry to a JSONL log under `CONTRACTS/_runs/commit_logs/`.

2) Generate a single-line, governance-friendly Git commit message template for the current commit.

This is intended to be run during/after the commit ceremony so you have a durable, machine-readable record of what each commit contained.

## Trigger

Use when you want to:
- Record a structured summary of a commit (hash, subject, files, dates).
- Maintain an append-only commit log under `CONTRACTS/_runs/` without modifying CANON.
- Generate a compliant commit message line (no body).

## Inputs

`input.json` fields:

- `action` (string): `"log"` or `"template"` (default: `"log"`).

For `action:"log"`:
- `mode` (string): `"git"` or `"manual"` (default: `"git"`).
- `commit` (string, required for `mode:"git"`): Commit hash or ref to summarize (example: `"HEAD"`).
- `note` (string, optional): Additional short note to attach to the log entry.
- `include_body` (boolean, optional): Include commit body in entry (default: `false`).
- `append` (boolean, optional): Append to the log file (default: `true`).
- `log_path` (string, optional): Log file path (default: `CONTRACTS/_runs/commit_logs/commit_summaries.jsonl`).

For `mode:"manual"`:
- `entry` (object, required): A complete entry payload to use as-is.

For `action:"template"`:
- `type` (string, required): Conventional commit-ish type (`feat`, `fix`, `docs`, `chore`, `refactor`, `test`).
- `scope` (string, required): Short scope (examples: `canon`, `llm-packer`, `skills`).
- `subject` (string, required): Imperative, present tense; no capitalization; no trailing period; max 50 chars.
- `normalize` (boolean, optional): If true, lowercases and strips a trailing period (default: `true`).
- `warn_if_changelog_missing` (boolean, optional): If true, warn when there are staged changes but no staged `CANON/CHANGELOG.md` (default: `true`).

## Outputs

For `action:"log"`:
- Writes `output.json` containing:
  - `ok` (boolean)
  - `append` (boolean)
  - `log_path` (string)
  - `entry` (object)
- If `append:true`, also appends `entry` as one JSON line to `log_path`.

For `action:"template"`:
- Writes `output.json` containing:
  - `ok` (boolean)
  - `message` (string)
  - `warnings` (array of strings)

## Constraints

- Must be deterministic (no wall-clock timestamps). Dates must come from git metadata or explicit input.
- Must only write logs under `CONTRACTS/_runs/`.
- Must not modify CANON or CONTEXT.

## Commit Message Template Prompt

Create a structured Git commit message with the following format:

Format:
`<type>(<scope>): <subject>`

Rules:
- Check to see what changed in the Changelog and Git history
- Update the changelog if necessary
- Only read other documents if necessary
- One logical change per commit
- Use imperative, present tense
- No capitalization or trailing period
- Max 50 chars
- Details belong in the changelog, not the commit body

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/cortex/cas-integrity-check/SKILL.md` (1,026 bytes)

```
<!-- CONTENT_HASH: d3375ef099b88e5ef47ebae81e81bfe116399e6724bb4938397d56a361642aec -->

**required_canon_version:** >=3.0.0


# Skill: cas-integrity-check

**Version:** 1.0.0

**Status:** Active



## Purpose

Verify the integrity of a content-addressed storage (CAS) directory by checking
that each blob's SHA-256 hash matches its filename.

## Trigger

Use when you want to verify that a CAS directory is not corrupted.

## Inputs

`input.json` fields:

- `cas_root` (string, required): Path to the CAS root directory (repo-relative recommended).

## Outputs

Writes `output.json` containing:

- `status` (string): `success` or `failure`
- `total_blobs` (int)
- `corrupt_blobs` (array): objects with `path` and `reason` (+ optional `expected`, `actual`)
- `cas_root` (string): resolved path checked

## Constraints

- Deterministic (no wall-clock usage).
- Read-only: must not modify repo files.

## Fixtures

- `fixtures/missing_root/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/cortex/cortex-build/SKILL.md` (923 bytes)

```
**required_canon_version:** >=3.0.0

# Cortex Build Skill

**Version:** 0.1.0

**Status:** Active

Rebuild the Cortex index and SECTION_INDEX, then verify expected paths appear in SECTION_INDEX.

## Usage

```bash
python run.py input.json output.json
```

## Inputs (input.json)

- expected_paths: list of repo-relative paths to verify in SECTION_INDEX
- timeout_sec: int (default 120)
- build_script: optional repo-relative path to cortex.build.py
- section_index_path: optional repo-relative path to SECTION_INDEX.json

## Outputs (output.json)

- ok: true|false
- returncode: int
- section_index_path: repo-relative path
- missing_paths: list of expected paths missing from SECTION_INDEX
- errors: list of error strings (empty when ok)

## Constraints

- Writes only to allowed output roots via the underlying builder.
- Deterministic env: sets PYTHONHASHSEED and CORTEX_BUILD_TIMESTAMP (git head).
- No network access.
```

## `CAPABILITY/SKILLS/cortex/cortex-summaries/SKILL.md` (1,461 bytes)

```
<!-- CONTENT_HASH: 459a7259d4910561c1b3125e514658c2923ae543f50563fe810345c0a0bcf328 -->

**required_canon_version:** >=3.0.0


# Skill: cortex-summaries

**Version:** 0.1.0

**Status:** Active



## Trigger

Use when adding or validating deterministic, advisory section summaries (System-1 surface) derived from `CORTEX/_generated/SECTION_INDEX.json`.

## Inputs

- `input.json` with:
  - `record` (object): SECTION_INDEX-style record (`section_id`, `heading`, `start_line`, `end_line`, `hash`, `path` optional).
  - `slice_text` (string): exact section slice text (heading line through end_line inclusive).

## Outputs

- Writes `actual.json` with:
  - `safe_filename` (string)
  - `summary_md` (string)
  - `summary_sha256` (string)

## Workflow

1. Confirm summaries are derived artifacts only (never authoritative).
2. Ensure build emits:
   - `CORTEX/_generated/summaries/<safe_section_id>.md`
   - `CORTEX/_generated/SUMMARY_INDEX.json`
3. Ensure CLI supports `python TOOLS/cortex.py summary <section_id>` and `--list`.
4. Ensure determinism (stable ordering, stable hashing, no timestamps).
5. Run `python3 TOOLS/critic.py` and `python3 CONTRACTS/runner.py`.

## Constraints

- No LLM calls.
- No DB storage for summaries.
- Generated artifacts only under `CORTEX/_generated/`.
- Provenance events only under `CONTRACTS/_runs/`.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/cortex/llm-packer-smoke/SKILL.md` (1,538 bytes)

```
<!-- CONTENT_HASH: d833438867b3cbbf8ae15f98c1fe9e9caf7ee49eda2ca3fb1332f76479aaf02f -->

**required_canon_version:** >=3.0.0


# Skill: llm-packer-smoke

**Version:** 0.1.0

**Status:** Reference



## Trigger

Use to verify that `MEMORY/LLM_PACKER/Engine/packer.py` runs and produces a minimal pack skeleton under `MEMORY/LLM_PACKER/_packs/` (fixture outputs should go under `_packs/_system/`).

## Inputs

- `input.json`:
  - `scope` (string): `ags` (default) or `lab` (THOUGHT/LAB only).
  - `out_dir` (string): output directory for the pack, relative to the repo root and under `MEMORY/LLM_PACKER/_packs/`.
  - `mode` (string): `full` or `delta`.
  - `profile` (string): `full` or `lite`.
  - `combined` (bool): whether to generate `FULL/` outputs.
  - `stamp` (string): stamp for timestamped `FULL/` outputs.
  - `split_lite` (bool): whether to generate `LITE/` outputs.
  - `zip` (bool): whether to generate a zip archive.
  - `emit_pruned` (bool): whether to generate `PRUNED/` output (reduced planning context).

## Outputs

- Writes `actual.json` containing the verified pack directory and a list of required files that were found.

## Constraints

- Must only write generated artifacts under `MEMORY/LLM_PACKER/_packs/` (and must not write system artifacts to `BUILD/`).
- Deterministic and self-contained.
- When `emit_pruned` is OFF: PRUNED/ must not exist in the pack.
- When `emit_pruned` is ON: PRUNED/ must exist with valid manifest and rules files.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/cortex/system1-verify/SKILL.md` (868 bytes)

```
<!-- CONTENT_HASH: 714f1a1f568ac3e93fcb1c1ed6134733148c65799e1aadbe6b7a11f76e36c7fd -->

**required_canon_version:** >=3.0.0


# System 1 Verify Skill

**Version:** 1.0.0

**Status:** Experimental



**Date:** 2025-12-28
**Confidence:** Medium
**Impact:** Low
**Tags:** [verification, cortex, system1]

## Purpose
Ensures system1.db is in sync with repository state and verifies system1 indexer is working correctly.

## Description
This skill runs verification checks against the System 1 database to detect:
1. Missing indexed files
2. Stale (orphaned) database entries
3. Hash mismatches between indexed files and actual CANON content

## Usage
Run from repository root:
```bash
ags run --skill system1-verify
```

## Dependencies
- system1.db (CORTEX/system1.db)
- CANON directory files

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/governance/admission-control/SKILL.md` (917 bytes)

```
<!-- CONTENT_HASH: 163bb0800b06a8adabb867a11a091bef3d9c250e22335393f5a4ae6411c65e5f -->

**required_canon_version:** >=3.0.0


# Skill: admission-control

**Version:** 0.1.0

**Status:** Active



## Purpose

Validate the `ags admit` admission control gate using deterministic fixtures.

## Trigger

Use when you need to verify admission control policy behavior via fixtures.

## Inputs

- `input.json`: admission intent JSON.

## Outputs

- Writes `actual.json` containing:
  - `rc` (int): exit code from `ags admit`.
  - `result` (object|null): parsed JSON output from `ags admit`.

## Constraints

- Must be deterministic.
- Must not modify repo files (reads only).

## Fixtures

- `fixtures/read_only_write_block/`
- `fixtures/artifact_only_outside_block/`
- `fixtures/repo_write_flag_required/`
- `fixtures/artifact_only_allow/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/governance/canon-governance-check/SKILL.md` (2,277 bytes)

```
---
name: canon-governance-check
version: "0.1.0"
description: Enforces changelog updates for significant changes to CANON/, TOOLS/, schemas, and ADRs
compatibility: all
---

<!-- CONTENT_HASH: 6ccf92d5a58730e071eab8db36222e2c03e3779f43e2056dcceac11528ab4ba1 -->

**required_canon_version:** >=3.0.0




# Canon Governance Check Skill

**Version:** 0.1.0

**Status:** Active

**Required Canon Version:** >=2.6.0 <3.0.0

## Purpose
Enforces documentation hygiene by requiring changelog updates when significant system changes are made.

## What it checks

### Behavior Changes (requires CANON/CHANGELOG.md)
- `TOOLS/` - Runtime behavior
- `CATALYTIC-DPT/PRIMITIVES/` and `CATALYTIC-DPT/PIPELINES/` - Core runtime
- `SKILLS/` - Agent capabilities
- `.github/workflows/` - CI enforcement

### Rule Changes (requires CANON/CHANGELOG.md)
- `CANON/*.md` - Canon specifications
- `CATALYTIC-DPT/SPECTRUM/*.md` - Frozen law
- `SCHEMAS/*.json` - Contract definitions

### Decision Changes (requires CANON/CHANGELOG.md)
- `CONTEXT/decisions/*.md` - Architecture Decision Records

### Warnings (not errors)
- CAT-DPT changes without `CATALYTIC-DPT/CHANGELOG.md` update
- Canon changes without `AGENTS.md` sync

## Usage

### CLI
```bash
# Normal check
node TOOLS/check-canon-governance.js

# Verbose mode (show all changed files)
node TOOLS/check-canon-governance.js --verbose
```

### As a Skill
```bash
python SKILLS/canon-governance-check/run.py
```

### In CI
Automatically runs in `.github/workflows/contracts.yml` on every push/PR.

### Pre-commit Hook
```bash
# Install pre-commit hook
cp SKILLS/canon-governance-check/scripts/pre-commit .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

## Exit Codes
- `0` - Pass (no significant changes or changelog updated)
- `1` - Fail (significant changes without changelog)

## Cortex Integration
When run with `CORTEX_RUN_ID` set, logs governance check events to the Cortex provenance ledger.

## Implementation
- **Core script**: `TOOLS/check-canon-governance.js` (Node.js)
- **Skill wrapper**: `SKILLS/canon-governance-check/run.py`
- **Pre-commit hook**: `SKILLS/canon-governance-check/scripts/pre-commit`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/governance/canon-migration/SKILL.md` (1,740 bytes)

```
<!-- CONTENT_HASH: a78620c93498aa25b0b5ed02b3264e51d565f2ea82f334f57bac9415b4bdaca9 -->

**required_canon_version:** >=3.0.0


# Skill: canon-migration

**Version:** 0.1.0

**Status:** Active



## Purpose

This skill handles migrations when breaking changes occur to the canon or system structure.

## Trigger

Run this skill when:
- Canon version has a major bump (e.g., 0.x.x → 1.x.x)
- Invariants are changed (requires exceptional process per INV-* rules)
- File structure changes (per INV-001)

## Inputs

- `source_version`: The canon version the pack was created under
- `target_version`: The canon version to migrate to
- `pack_path`: Path to the pack directory to migrate

## Outputs

- `migrated_files`: List of files that were transformed
- `migration_log`: Detailed log of changes made
- `warnings`: Any compatibility warnings

## Migration Process

1. **Version Detection**: Read `meta/PACK_INFO.json` for source version
2. **Migration Chain**: Apply migrations in sequence (0.1 → 0.2 → 0.3 → ...)
3. **Validation**: Run fixtures to verify migrated pack
4. **Manifest Update**: Regenerate manifests with new hashes

## Example Migrations

### 0.1.x → 0.2.x
- No structural changes required
- Update manifest version field

### Future: 0.x → 1.0
- Evaluate invariant changes
- Apply file structure transformations
- Update token grammar if deprecated

## Constraints

- Must not lose data during migration
- Must maintain referential integrity
- Must log all transformations

## Fixtures

- `fixtures/basic/` - Test migration from previous version
- `fixtures/roundtrip/` - Verify data survives migration cycle

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/governance/canonical-doc-enforcer/SKILL.md` (4,324 bytes)

```
# Canonical Document Enforcer Skill

**Purpose:** Enforce canonical filename and metadata standards for ALL markdown documentation across the repository.

## Scope

This skill validates and fixes:
- **All `.md` files** in the repository (except exempted paths)
- Filename format: `MM-DD-YYYY-HH-MM_DESCRIPTIVE_TITLE.md`
- YAML frontmatter with required fields
- Content hash placement and validity
- Timestamp consistency

## Exemptions

The following paths are **EXEMPT** from canonical enforcement:
- `LAW/CANON/*.md` - Canon files (different governance)
- `CAPABILITY/SKILLS/*/SKILL.md` - Skill manifests
- `CAPABILITY/TESTBENCH/**/*.md` - Test fixtures
- `LAW/CONTRACTS/fixtures/**/*.md` - Test data
- `README.md`, `AGENTS.md`, `CHANGELOG.md` - Root documentation
- `.github/**/*.md` - GitHub metadata
- `BUILD/**/*.md` - User workspace

## Operations

### 1. Validate
Scans repository for non-canonical documents and reports violations.

**Usage:**
```bash
python run.py --mode validate
```

**Output:**
- List of files with violations
- Specific violation types per file
- Suggested fixes

### 2. Fix
Automatically renames and updates files to canonical format.

**Usage:**
```bash
python run.py --mode fix [--dry-run]
```

**Actions:**
- Renames files to `MM-DD-YYYY-HH-MM_TITLE.md`
- Adds/updates YAML frontmatter
- Computes and inserts content hash
- Preserves file content

### 3. Report
Generates compliance report for the repository.

**Usage:**
```bash
python run.py --mode report --output INBOX/reports/
```

## Required Fields

All canonical documents MUST have:

```yaml
---
uuid: "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
title: "Human Readable Title"
section: report|research|roadmap|guide|archive
bucket: "category/subcategory"
author: "System|Antigravity|Human Name"
priority: High|Medium|Low
created: "YYYY-MM-DD HH:MM"
modified: "YYYY-MM-DD HH:MM"
status: "Draft|Active|Complete|Archived"
summary: "One-line summary"
tags: [tag1, tag2, tag3]
hashtags: ["#category", "#topic"]
---
<!-- CONTENT_HASH: <sha256> -->
```

## Validation Rules

1. **Filename Pattern:** `^\d{2}-\d{2}-\d{4}-\d{2}-\d{2}_.+\.md$`
2. **Title Format:** ALL_CAPS_WITH_UNDERSCORES
3. **YAML Presence:** Lines 1-N start with `---`
4. **Hash Placement:** Immediately after closing `---`
5. **Hash Validity:** SHA256 matches content (excluding YAML and hash line)
6. **Timestamp Match:** Filename timestamp == YAML `created` field
7. **UUID Format:** RFC 4122 UUID v4

## Exit Codes

- `0` - All documents canonical
- `1` - Violations found (validate mode)
- `2` - Fix operation failed
- `3` - Invalid arguments

## Integration

### Pre-commit Hook
```bash
# In .githooks/pre-commit
python CAPABILITY/SKILLS/governance/canonical-doc-enforcer/run.py --mode validate --staged-only
```

### CI/CD
```bash
# In .github/workflows/governance.yml
- name: Validate Canonical Docs
  run: python CAPABILITY/SKILLS/governance/canonical-doc-enforcer/run.py --mode validate
```

## Examples

### Validate Repository
```bash
python run.py --mode validate
# Output:
# [VIOLATION] MEMORY/ARCHIVE/roadmaps/AGS_ROADMAP_3.3.18.md
#   - Invalid filename (missing timestamp prefix)
#   - Missing YAML frontmatter
#   - Missing content hash
```

### Fix Non-Canonical File
```bash
python run.py --mode fix --file "MEMORY/ARCHIVE/roadmaps/AGS_ROADMAP_3.3.18.md"
# Output:
# [RENAMED] AGS_ROADMAP_3.3.18.md -> 01-05-2026-12-45_AGS_ROADMAP_3_3_18.md
# [UPDATED] Added YAML frontmatter
# [UPDATED] Added content hash
```

### Dry Run
```bash
python run.py --mode fix --dry-run
# Output:
# [DRY-RUN] Would rename: AGS_ROADMAP_3.3.18.md -> 01-05-2026-12-45_AGS_ROADMAP_3_3_18.md
# [DRY-RUN] Would add YAML frontmatter
# [DRY-RUN] Would add content hash
```

## Receipts

All operations emit receipts to `LAW/CONTRACTS/_runs/canonical-doc-enforcer/`:
- `validate_receipt.json` - Validation results
- `fix_receipt.json` - Fix operation results
- `report_receipt.json` - Compliance report data

## Related

- `LAW/CANON/DOCUMENT_POLICY.md` - Canonical document policy
- `CAPABILITY/TOOLS/utilities/rename_canon.py` - Legacy renaming tool
- `CAPABILITY/SKILLS/inbox/inbox-report-writer/` - INBOX-specific tooling
```

## `CAPABILITY/SKILLS/governance/ci-trigger-policy/SKILL.md` (359 bytes)

```
<!-- CONTENT_HASH: 0000000000000000000000000000000000000000000000000000000000000000 -->

**required_canon_version:** >=3.0.0

# Skill: ci-trigger-policy

**Version:** 1.0.0
**Status:** Active

## Trigger
Run when a policy check is required for CI triggers.

## Inputs
- input.json

## Outputs
- output.json

## Constraints
- Deterministic
```

## `CAPABILITY/SKILLS/governance/intent-guard/SKILL.md` (837 bytes)

```
---
skill: intent-guard
name: intent-guard
version: "0.1.0"
status: Active
description: |
  Ensures deterministic intent artifacts are generated for governed pipeline runs and admission gate responses are recorded.
compatibility: all
required_canon_version: ">=2.11.12 <3.0.0"
---

<!-- CONTENT_HASH: 275339bf912000b015db985135ef0b87a04e31e9740f6b4c970f8f7955db4dd7 -->

**required_canon_version:** >=3.0.0




# Intent Guard Skill

**Skill:** intent-guard
**Version:** 0.1.0
**Status:** Active
**Required Canon Version:** >=2.11.12 <3.0.0

This skill exercises `TOOLS/intent.py` and `TOOLS/admission.py` to confirm that deterministic `intent.json` artifacts are produced and admission responses behave as expected when the run claims artifact-only vs repo-write modes.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/governance/invariant-freeze/SKILL.md` (955 bytes)

```
<!-- CONTENT_HASH: e37d6aefb24a29bd64525f913dd0fef7d8d5b235612ac395a6ae8a0a8d625207 -->

**required_canon_version:** >=3.0.0


# Skill: Invariant Freeze

**Version:** 0.1.0
**Status:** Active


## Purpose

Verifies that all core invariants (INV-001 through INV-008) exist in `CANON/INVARIANTS.md`. This ensures that invariants are not removed without a major version bump, maintaining the v1.0 stability guarantee.

## Triggers

- Manual verification of governance stability.
- CI check before releases.

## Inputs

- `CANON/INVARIANTS.md` (source of truth)
- `input.json` with `expected_invariants` list.

## Outputs

- `actual.json` with:
  - `found_invariants`: list of matches.
  - `missing`: list of missing expected invariants.
  - `valid`: boolean status.

## Constraints

- Must search for exact `[INV-XXX]` tags.
- Must not allow gaps or removals from the frozen list.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/governance/master-override/SKILL.md` (1,150 bytes)

```
<!-- CONTENT_HASH: 53873221b9c1bef59f0127203848959b23baebe62b5639efe005e3867bdf9c8b -->

**required_canon_version:** >=3.0.0


# Skill: master-override

**Version:** 0.1.0

**Status:** Active



## Purpose

Audit logging and gated access for `MASTER_OVERRIDE` usage.

## Trigger

Use when a user prompt contains `MASTER_OVERRIDE` (before executing any overridden action), or when the Sovereign explicitly asks to view override logs with `MASTER_OVERRIDE`.

## Inputs

- `action`: `"log"` or `"read"`
- `token`: must equal `MASTER_OVERRIDE`
- `note` (optional): short reason/context for the override
- `limit` (optional, `read` only): number of most recent entries to return (default: 20)

## Outputs

- For `log`: `{ ok, action, log_path }`
- For `read`: `{ ok, action, log_path, entries }` (only when authorized)

## Constraints

- Logs must be written under `CONTRACTS/_runs/override_logs/`.
- Must not read, quote, or summarize override logs unless authorized.
- Must not modify CANON or CONTEXT.

## Fixtures

- `fixtures/basic/`
- `fixtures/unauthorized-read/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/governance/repo-contract-alignment/SKILL.md` (2,275 bytes)

```
<!-- CONTENT_HASH: dc5da4881546efe848cbadf457ccc141e4512024375fae7f5649fa98839fc310 -->

**required_canon_version:** >=3.0.0


# Skill: repo-contract-alignment

**Version:** 0.1.0
**Status:** Active


## Purpose

Align the repository with its stated governance by scanning contract docs, extracting explicit rules, running checks, and implementing the smallest compliant fixes with enforcement.

## Trigger

Use when asked to align repo behavior with canon/contract docs, audit governance compliance, or implement minimal fixes plus enforcement for regressions.

## Workflow

1. Confirm intent gate
   - If the user is asking for analysis or strategy only, stop after Findings/Plan and ask for explicit implementation approval.
   - Do not touch CANON or edit existing CONTEXT unless the task is explicitly about rules/governance/memory updates.

2. Ensure cortex is available
   - If `CORTEX/_generated/cortex.db` is missing, run `python CORTEX/cortex.build.py`.
   - Use `python CORTEX/query.py --json` or `--find` for file discovery; avoid raw filesystem scans.

3. Identify contract docs
   - From the cortex index, collect docs matching: `README.md`, `AGENTS.md`, `CANON/`, `CONTEXT/decisions/` (ADRs), `ROADMAP`, `CONTRIBUTING`, `SECURITY`, `CONTEXT/maps/*`, and any explicit “contract” docs.

4. Extract explicit rules
   - Read only those contract docs and list their rules.
   - Resolve conflicts using the authority gradient; note any conflicts.

5. Run existing checks/tests/build scripts
   - Always run `python TOOLS/critic.py` and `python CONTRACTS/runner.py`.
   - Run any additional scripts referenced by contract docs.

6. Report issues and minimal fixes
   - Produce a prioritized issue list (P0 violations, P1 missing enforcement, P2 hygiene).
   - Propose the smallest fixes and enforcement to prevent regressions.

7. Implement and re-check
   - Apply the smallest correct changes, add/adjust fixtures if behavior changes, then re-run checks until passing.
   - Write artifacts only to allowed roots (`CONTRACTS/_runs/`, `CORTEX/_generated/`, `MEMORY/LLM_PACKER/_packs/`).

## Output format

Always respond with: Findings, Plan, Changes, Commands run, Next.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/inbox/inbox-report-writer/SKILL.md` (943 bytes)

```
**required_canon_version:** >=3.0.0

# Skill: inbox-report-writer

**Version:** 0.1.0

**Status:** Active

## Trigger

Use when generating INBOX ledgers, updating INBOX.md indexes, or validating INBOX content hashes.

## Inputs

- `input.json` with:
  - `operation`: generate_ledger | update_index | verify_hash
  - `inbox_path`: repo-relative path (default: INBOX)
  - `ledger_path`: output path under LAW/CONTRACTS/_runs (required for generate_ledger)
  - `file_path`: repo-relative path (required for verify_hash)
  - `allow_inbox_write`: true to permit update_index

## Outputs

- `output.json` summary with status, operation, and any output paths.
- Optional ledger file written under `LAW/CONTRACTS/_runs/`.

## Constraints

- Output JSON is deterministic.
- Ledger outputs must stay under `LAW/CONTRACTS/_runs/`.
- INBOX writes require explicit `allow_inbox_write`.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/mcp/mcp-access-validator/SKILL.md` (4,432 bytes)

```
<!-- CONTENT_HASH: 52686a4a44816ad79480c76cc0d51ba113ac0350b2eb871b42e9310030b43394 -->

**required_canon_version:** >=3.0.0


# MCP Access Validator

**Skill ID:** `mcp-access-validator`
**Version:** 1.0.0
**Status:** Active
**Tags:** mcp, governance, validation, token-efficiency

## Purpose

Prevents token waste by validating that agents use the MCP server's existing tools instead of writing custom database queries or manual file inspection. This skill enforces the "MCP-first" principle for all cortex access.

## Problem Statement

Agents waste tokens by:
1. Writing Python SQLite snippets to inspect databases directly
2. Running manual file system operations instead of using `cortex_query`
3. Creating custom scripts for tasks already covered by MCP tools
4. Analyzing database schemas instead of using semantic search tools

This violates the catalytic computing principle of token efficiency and bypasses the governance layer.

## Solution

The MCP Access Validator skill:
1. **Detects** when an agent is performing manual database/file operations
2. **Recommends** the appropriate MCP tool for the task
3. **Provides** a token efficiency score for the agent's approach
4. **Generates** audit logs of token waste incidents

## Input Schema

```json
{
  "agent_action": "string describing what the agent is trying to do",
  "agent_code_snippet": "optional code the agent wrote",
  "files_accessed": ["list of files the agent accessed manually"],
  "databases_queried": ["list of databases the agent queried directly"]
}
```

## Output Schema

```json
{
  "validation_passed": "boolean",
  "token_waste_detected": "boolean",
  "recommended_mcp_tool": "string",
  "tool_usage_example": "object",
  "estimated_token_savings": "number",
  "audit_entry": "object"
}
```

## Usage Examples

### Example 1: Manual Database Query
**Agent Action:** "I need to check what's in the system1.db database"
**Agent Code:** `import sqlite3; conn = sqlite3.connect('CORTEX/_generated/system1.db'); cursor = conn.execute('SELECT * FROM symbols')`
**Validation Result:** 
- `token_waste_detected`: true
- `recommended_mcp_tool`: `cortex_query`
- `tool_usage_example`: `cortex_query({"query": "symbols"})`
- `estimated_token_savings`: 95%

### Example 2: Manual File Reading
**Agent Action:** "I want to read the CONTRACT.md file"
**Agent Code:** `open('LAW/CANON/CONTRACT.md').read()`
**Validation Result:**
- `token_waste_detected`: true  
- `recommended_mcp_tool`: `canon_read`
- `tool_usage_example`: `canon_read({"file": "CONTRACT"})`
- `estimated_token_savings`: 90%

## Implementation

The skill works by:
1. Parsing the agent's action description and code
2. Matching patterns against known MCP tool capabilities
3. Calculating token efficiency based on:
   - MCP tool response size vs manual code size
   - Governance compliance overhead
   - Audit logging completeness
4. Generating actionable recommendations

## Governance Impact

This skill directly supports:
- **ADR-021**: Mandatory Agent Identity (uses session_id for audit)
- **ADR-004**: MCP Integration (enforces tool usage)
- **Catalytic Computing**: Token efficiency principles
- **AGENTS.md Section 0**: Cortex connection requirements

## Dependencies

- MCP server running with available tools
- Audit log directory (`LAW/CONTRACTS/_runs/mcp_logs/`)
- Session ID for agent identification

## Error Handling

If the MCP server is not accessible, the skill will:
1. Return a validation failure
2. Provide connection instructions
3. Log the incident for governance review

## Performance

- Validation time: < 100ms
- Memory usage: < 10MB
- No external network calls (uses local MCP server)

## Security

- Read-only validation
- No file system modifications
- All audit logs are append-only
- Session ID verification for ADR-021 compliance

## Testing

See `fixtures/` directory for test cases covering:
1. Valid MCP tool usage
2. Manual database query detection
3. File system access detection
4. Mixed usage scenarios
5. Edge cases and error conditions

## Maintenance

This skill should be updated when:
1. New MCP tools are added
2. Token efficiency metrics change
3. Governance requirements evolve
4. Agent behavior patterns shift

## Related Skills

- `session-info-validator`: Validates ADR-021 compliance
- `cortex-query-optimizer`: Optimizes MCP tool usage
- `token-efficiency-auditor`: Comprehensive token usage analysis

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/mcp/mcp-adapter/SKILL.md` (724 bytes)

```
<!-- CONTENT_HASH: 947418164cb9f5cb7e42a3efd5aae779db7b4468b365669741b5182e0a40cf31 -->

**required_canon_version:** >=3.0.0


# Skill: mcp-adapter
**Version:** 0.1.0
**Status:** Active

**canon_version:** "3.0.0"

# MCP Adapter

This skill wraps an MCP server execution in a governance envelope.

## Usage

This skill is primarily used by the `ags` runtime to execute MCP servers safely.

### Wrapper Script
`scripts/wrapper.py` takes a JSON configuration file and produces a deterministic JSON output artifact.

```bash
python scripts/wrapper.py config.json output.json
```

### Configuration Schema
See `CATALYTIC-DPT/SCHEMAS/mcp_adapter.schema.json`.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/mcp/mcp-builder/SKILL.md` (9,232 bytes)

```
<!-- CONTENT_HASH: fd1b69daf795f227c42b49714692e6fac2530cd61da1110ac9ee8c20118d0782 -->

**required_canon_version:** >=3.0.0


# Skill: mcp-builder
**Version:** 0.1.0
**Status:** Active

**canon_version:** "3.0.0"

# MCP Server Development Guide

## Overview

Create MCP (Model Context Protocol) servers that enable LLMs to interact with external services through well-designed tools. The quality of an MCP server is measured by how well it enables LLMs to accomplish real-world tasks.

---

# Process

## 🚀 High-Level Workflow

Creating a high-quality MCP server involves four main phases:

### Phase 1: Deep Research and Planning

#### 1.1 Understand Modern MCP Design

**API Coverage vs. Workflow Tools:**
Balance comprehensive API endpoint coverage with specialized workflow tools. Workflow tools can be more convenient for specific tasks, while comprehensive coverage gives agents flexibility to compose operations. Performance varies by client—some clients benefit from code execution that combines basic tools, while others work better with higher-level workflows. When uncertain, prioritize comprehensive API coverage.

**Tool Naming and Discoverability:**
Clear, descriptive tool names help agents find the right tools quickly. Use consistent prefixes (e.g., `github_create_issue`, `github_list_repos`) and action-oriented naming.

**Context Management:**
Agents benefit from concise tool descriptions and the ability to filter/paginate results. Design tools that return focused, relevant data. Some clients support code execution which can help agents filter and process data efficiently.

**Actionable Error Messages:**
Error messages should guide agents toward solutions with specific suggestions and next steps.

#### 1.2 Study MCP Protocol Documentation

**Navigate the MCP specification:**

Start with the sitemap to find relevant pages: `https://modelcontextprotocol.io/sitemap.xml`

Then fetch specific pages with `.md` suffix for markdown format (e.g., `https://modelcontextprotocol.io/specification/draft.md`).

Key pages to review:
- Specification overview and architecture
- Transport mechanisms (streamable HTTP, stdio)
- Tool, resource, and prompt definitions

#### 1.3 Study Framework Documentation

**Recommended stack:**
- **Language**: TypeScript (high-quality SDK support and good compatibility in many execution environments e.g. MCPB. Plus AI models are good at generating TypeScript code, benefiting from its broad usage, static typing and good linting tools)
- **Transport**: Streamable HTTP for remote servers, using stateless JSON (simpler to scale and maintain, as opposed to stateful sessions and streaming responses). stdio for local servers.

**Load framework documentation:**

- **MCP Best Practices**: [📋 View Best Practices](./reference/mcp_best_practices.md) - Core guidelines

**For TypeScript (recommended):**
- **TypeScript SDK**: Use WebFetch to load `https://raw.githubusercontent.com/modelcontextprotocol/typescript-sdk/main/README.md`
- [⚡ TypeScript Guide](./reference/node_mcp_server.md) - TypeScript patterns and examples

**For Python:**
- **Python SDK**: Use WebFetch to load `https://raw.githubusercontent.com/modelcontextprotocol/python-sdk/main/README.md`
- [🐍 Python Guide](./reference/python_mcp_server.md) - Python patterns and examples

#### 1.4 Plan Your Implementation

**Understand the API:**
Review the service's API documentation to identify key endpoints, authentication requirements, and data models. Use web search and WebFetch as needed.

**Tool Selection:**
Prioritize comprehensive API coverage. List endpoints to implement, starting with the most common operations.

---

### Phase 2: Implementation

#### 2.1 Set Up Project Structure

See language-specific guides for project setup:
- [⚡ TypeScript Guide](./reference/node_mcp_server.md) - Project structure, package.json, tsconfig.json
- [🐍 Python Guide](./reference/python_mcp_server.md) - Module organization, dependencies

#### 2.2 Implement Core Infrastructure

Create shared utilities:
- API client with authentication
- Error handling helpers
- Response formatting (JSON/Markdown)
- Pagination support

#### 2.3 Implement Tools

For each tool:

**Input Schema:**
- Use Zod (TypeScript) or Pydantic (Python)
- Include constraints and clear descriptions
- Add examples in field descriptions

**Output Schema:**
- Define `outputSchema` where possible for structured data
- Use `structuredContent` in tool responses (TypeScript SDK feature)
- Helps clients understand and process tool outputs

**Tool Description:**
- Concise summary of functionality
- Parameter descriptions
- Return type schema

**Implementation:**
- Async/await for I/O operations
- Proper error handling with actionable messages
- Support pagination where applicable
- Return both text content and structured data when using modern SDKs

**Annotations:**
- `readOnlyHint`: true/false
- `destructiveHint`: true/false
- `idempotentHint`: true/false
- `openWorldHint`: true/false

---

### Phase 3: Review and Test

#### 3.1 Code Quality

Review for:
- No duplicated code (DRY principle)
- Consistent error handling
- Full type coverage
- Clear tool descriptions

#### 3.2 Build and Test

**TypeScript:**
- Run `npm run build` to verify compilation
- Test with MCP Inspector: `npx @modelcontextprotocol/inspector`

**Python:**
- Verify syntax: `python -m py_compile your_server.py`
- Test with MCP Inspector

See language-specific guides for detailed testing approaches and quality checklists.

---

### Phase 4: Create Evaluations

After implementing your MCP server, create comprehensive evaluations to test its effectiveness.

**Load [✅ Evaluation Guide](./reference/evaluation.md) for complete evaluation guidelines.**

#### 4.1 Understand Evaluation Purpose

Use evaluations to test whether LLMs can effectively use your MCP server to answer realistic, complex questions.

#### 4.2 Create 10 Evaluation Questions

To create effective evaluations, follow the process outlined in the evaluation guide:

1. **Tool Inspection**: List available tools and understand their capabilities
2. **Content Exploration**: Use READ-ONLY operations to explore available data
3. **Question Generation**: Create 10 complex, realistic questions
4. **Answer Verification**: Solve each question yourself to verify answers

#### 4.3 Evaluation Requirements

Ensure each question is:
- **Independent**: Not dependent on other questions
- **Read-only**: Only non-destructive operations required
- **Complex**: Requiring multiple tool calls and deep exploration
- **Realistic**: Based on real use cases humans would care about
- **Verifiable**: Single, clear answer that can be verified by string comparison
- **Stable**: Answer won't change over time

#### 4.4 Output Format

Create an XML file with this structure:

```xml
<evaluation>
  <qa_pair>
    <question>Find discussions about AI model launches with animal codenames. One model needed a specific safety designation that uses the format ASL-X. What number X was being determined for the model named after a spotted wild cat?</question>
    <answer>3</answer>
  </qa_pair>
<!-- More qa_pairs... -->
</evaluation>
```

---

# Reference Files

## 📚 Documentation Library

Load these resources as needed during development:

### Core MCP Documentation (Load First)
- **MCP Protocol**: Start with sitemap at `https://modelcontextprotocol.io/sitemap.xml`, then fetch specific pages with `.md` suffix
- [📋 MCP Best Practices](./reference/mcp_best_practices.md) - Universal MCP guidelines including:
  - Server and tool naming conventions
  - Response format guidelines (JSON vs Markdown)
  - Pagination best practices
  - Transport selection (streamable HTTP vs stdio)
  - Security and error handling standards

### SDK Documentation (Load During Phase 1/2)
- **Python SDK**: Fetch from `https://raw.githubusercontent.com/modelcontextprotocol/python-sdk/main/README.md`
- **TypeScript SDK**: Fetch from `https://raw.githubusercontent.com/modelcontextprotocol/typescript-sdk/main/README.md`

### Language-Specific Implementation Guides (Load During Phase 2)
- [🐍 Python Implementation Guide](./reference/python_mcp_server.md) - Complete Python/FastMCP guide with:
  - Server initialization patterns
  - Pydantic model examples
  - Tool registration with `@mcp.tool`
  - Complete working examples
  - Quality checklist

- [⚡ TypeScript Implementation Guide](./reference/node_mcp_server.md) - Complete TypeScript guide with:
  - Project structure
  - Zod schema patterns
  - Tool registration with `server.registerTool`
  - Complete working examples
  - Quality checklist

### Evaluation Guide (Load During Phase 4)
- [✅ Evaluation Guide](./reference/evaluation.md) - Complete evaluation creation guide with:
  - Question creation guidelines
  - Answer verification strategies
  - XML format specifications
  - Example questions and answers
  - Running an evaluation with the provided scripts

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/mcp/mcp-extension-verify/SKILL.md` (1,129 bytes)

```
<!-- CONTENT_HASH: 94a604067049421f647271e3d6d14a0dc88c16412de0e761e261d40b7a1ffb68 -->

**required_canon_version:** >=3.0.0


# Skill: mcp-extension-verify

**Version:** 0.1.0

**Status:** Active



## Trigger

Use when asked to verify the AGS MCP server inside any IDE extension or MCP-compatible client.

## Inputs

- `input.json` with:
  - `client` (string, optional): `"vscode"`, `"claude"`, or `"generic"` (default).
  - `entrypoint_substring` (string, optional): Relative path to the MCP entrypoint.
  - `args` (array, optional): Arguments to pass to the entrypoint (default: `["--test"]`).

## Outputs

- Writes `actual.json` with:
  - `ok` (boolean)
  - `returncode` (number)
  - `entrypoint` (string, relative path)
  - `args` (array)
  - `client` (string)
  - `instructions` (array of strings)

## Constraints

- Must use `CORTEX/query.py` for file discovery checks.
- Must not scan the filesystem directly.
- Must not modify canon or context.
- Any runtime artifacts must stay under allowed roots.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/mcp/mcp-message-board/SKILL.md` (1,654 bytes)

```
<!-- CONTENT_HASH: 7e9a19ab3465161e49b31bc2a5ea38ad9591d82fc6cf02410938122840ea77e9 -->

**required_canon_version:** >=3.0.0


# Skill: mcp-message-board

**Version:** 0.1.0

**Status:** Active



## Trigger

Use when adding or modifying the MCP message board toolset (schema, server handlers, storage, roles, fixtures, ADR, changelog/version).

## Overview

Implement the MCP message board tools and their governance artifacts without changing unrelated MCP logic.

## Workflow

1) Add/confirm tool schema definitions in `MCP/schemas/tools.json`.
2) Implement tool handlers in `MCP/server.py`:
   - Read: `message_board_list`
   - Write: `message_board_write` (post/pin/unpin/delete/purge)
3) Store events under `CONTRACTS/_runs/message_board/<board>.jsonl` with append-only records.
4) Enforce roles:
   - Default role: `poster` (post + list)
   - `moderator` (post + list + pin/unpin + delete)
   - `admin` (all + purge)
   - Role allowlist file at `CAPABILITY/MCP/board_roles.json` keyed by `session_id`.
5) Add fixtures for the skill and any new governance expectations.
6) Add ADR under `CONTEXT/decisions/` and update `CANON/CHANGELOG.md` + `CANON/VERSIONING.md`.

## Output format (events)

Each event record is a JSON object with:
- `id` (uuid or hash)
- `board`
- `author_session_id`
- `role`
- `type` (`post|pin|unpin|delete|purge`)
- `message` (for posts)
- `ref_id` (for pin/delete)
- `created_at` (ISO timestamp)

## Constraints

- Use only standard library.
- Keep logic deterministic where possible.
- Write artifacts only under allowed roots.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/mcp/mcp-precommit-check/SKILL.md` (1,796 bytes)

```
<!-- CONTENT_HASH: 49074ec22830377e0417793f0c711f975a598826378c3ad82c421e3e099e94a0 -->

**required_canon_version:** >=3.0.0


# Skill: mcp-precommit-check

**Version:** 0.1.0

**Status:** Active



## Trigger

Use when asked to verify MCP is healthy before commit, including entrypoint tests,
server running, and Windows autostart status.

## Inputs

- `input.json` with:
  - `entrypoint` (string, optional): Relative path to MCP entrypoint (default: `LAW/CONTRACTS/ags_mcp_entrypoint.py`).
  - `auto_entrypoint` (string, optional): Relative path to auto entrypoint (default: `LAW/CONTRACTS/_runs/ags_mcp_auto.py`).
  - `args` (array, optional): Args for entrypoint (default: `["--test"]`).
  - `auto_args` (array, optional): Args for auto entrypoint (default: `["--test"]`).
  - `require_running` (boolean, optional): Require a running server PID (default: `true`).
  - `require_autostart` (boolean, optional): Require autostart enabled on Windows (default: `true`).
  - `dry_run` (boolean, optional): If true, skip execution and report success (default: `false`).
  - `bridge_config` (string, optional): Path to PowerShell bridge config for non-Windows checks.
  - `bridge_timeout_seconds` (integer, optional): Bridge request timeout (default: 30).

## Outputs

- Writes `actual.json` with:
  - `ok` (boolean)
  - `checks` (object):
    - `entrypoint` (object)
    - `auto_entrypoint` (object)
    - `running` (object)
    - `autostart` (object)

## Constraints

- Must not modify canon or context.
- Must not write artifacts outside allowed roots.
- On non-Windows, running/autostart checks use `powershell.exe` when available and fall back to the PowerShell bridge.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/mcp/mcp-smoke/SKILL.md` (1,500 bytes)

```
<!-- CONTENT_HASH: 3500ba9ad1d99cf179c71ea71d756c5d30401724592a3accda58abb61a45d26f -->

**required_canon_version:** >=3.0.0


# Skill: mcp-smoke

**Version:** 0.1.0

**Status:** Active



## Trigger

Use when asked to verify that the AGS MCP server is runnable (stdio mode) and to perform a quick smoke test.

## Inputs

- `input.json` with:
  - `entrypoint_substring` (string, optional): Relative path to the MCP entrypoint.
  - `args` (array, optional): Arguments to pass to the entrypoint (default: `["--test"]`).
  - `bridge_smoke` (object, optional):
    - `enabled` (boolean): If true, call the local terminal bridge after the server check.
    - `command` (string, optional): Command to execute via the bridge.
    - `cwd` (string, optional): Working directory for the bridge command.
    - `timeout_seconds` (integer, optional): Bridge request timeout (default: 30).

## Outputs

- Writes `actual.json` with:
  - `ok` (boolean)
  - `returncode` (number)
  - `entrypoint` (string, relative path)
  - `args` (array)
  - `bridge_smoke` (object):
    - `enabled` (boolean)
    - `ok` (boolean)
    - `exit_code` (number, optional)
    - `error` (string, optional)

## Constraints

- Must use `CORTEX/query.py` for file discovery checks.
- Must not scan the filesystem directly.
- Must not modify canon or context.
- Any runtime artifacts must stay under allowed roots.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/pipeline/pipeline-dag-receipts/SKILL.md` (972 bytes)

```
<!-- CONTENT_HASH: 34e78399fa67a452129b5d956d27c8765382dd89943630e6221db8456c9ba80b -->

**required_canon_version:** >=3.0.0


# Skill: pipeline-dag-receipts

**Version:** 0.1.0

**Status:** Draft



## Trigger

When the agent is asked to implement distributed execution receipts for pipeline DAG nodes (Phase 7.1).

## Inputs

JSON object:
- `dag_spec_path` (string, required): Repo-relative path to a DAG spec JSON file.
- `runs_root` (string, optional): Runs root directory; default `"CONTRACTS/_runs"`.

## Outputs

JSON object:
- `ok` (boolean)
- `code` (string)
- `details` (object)

## Constraints

- Must be deterministic and idempotent.
- Must not modify CANON or CONTEXT directly.
- Must not import from `CATALYTIC-DPT/LAB/`.

## Fixtures

- `fixtures/basic_ok`: placeholder runner output (governance-only).
- `fixtures/tamper_reject`: placeholder runner output (governance-only).

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/pipeline/pipeline-dag-restore/SKILL.md` (1,068 bytes)

```
<!-- CONTENT_HASH: 419edd6bb0ec051bbe08e2de9bd01ec57bcba07908dbe2ace02201659ae10fd0 -->

**required_canon_version:** >=3.0.0


# Skill: pipeline-dag-restore

**Version:** 0.1.0

**Status:** Draft



## Trigger

Use when implementing or modifying the pipeline DAG restore runner, including receipt-gated recovery, CLI wiring, tests, and roadmap/changelog updates.

## Inputs

- DAG runtime files under `CATALYTIC-DPT/PIPELINES/`
- CLI surface in `TOOLS/catalytic.py`
- Tests in `CATALYTIC-DPT/TESTBENCH/`
- Governance docs (`CATALYTIC-DPT/ROADMAP_V2.3.md`, `CATALYTIC-DPT/CHANGELOG.md`)

## Outputs

- Deterministic restore behavior (receipt-gated, idempotent)
- Fail-closed verification checks
- Updated tests and governance docs

## Constraints

- Determinism only; no timestamps or random IDs.
- Fail closed with stable error codes.
- Artifact-only dependencies; no implicit data flow.
- Do not touch out-of-scope files.

## Fixtures

- `fixtures/basic_ok`
- `fixtures/tamper_reject`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/pipeline/pipeline-dag-scheduler/SKILL.md` (1,391 bytes)

```
<!-- CONTENT_HASH: 8fc47145aff0ac6bdeeacfc09d9f8c7cfd383263c054668c48152704a6e646de -->

**required_canon_version:** >=3.0.0


# Skill: pipeline-dag-scheduler

**Version:** 0.1.0

**Status:** Draft



## Trigger

When the agent is asked to implement deterministic pipeline DAG scheduling (Phase 7.0) that composes multiple existing pipelines into a DAG with artifact-only dependencies, resume safety, and fail-closed verification.

## Inputs

JSON object:
- `dag_spec_path` (string, required): Repo-relative path to a DAG spec JSON file.
- `runs_root` (string, optional): Runs root directory; default `"CONTRACTS/_runs"`.
- `project_root` (string, optional): Repo root path; default inferred.

## Outputs

JSON object:
- `ok` (boolean)
- `code` (string)
- `details` (object)

Side effects:
- Creates or updates deterministic DAG artifacts under `<runs_root>/_pipelines/_dags/<dag_id>/` only.
- Does not write artifacts outside allowed roots.

## Constraints

- Must be deterministic and idempotent.
- Must not modify CANON or CONTEXT.
- Must not import from `CATALYTIC-DPT/LAB/`.
- Must fail closed on any schema/validation ambiguity.

## Fixtures

- `fixtures/basic_ok`: a 2-node DAG executes deterministically and is verifiable.
- `fixtures/cycle_reject`: a cycle is rejected with a stable error code.

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/utilities/doc-merge-batch-skill/SKILL.md` (930 bytes)

```
---
name: doc-merge-batch-skill
version: "1.0.0"
description: Deterministic document merge utility (verify/apply) with JSON-in/JSON-out skill wrapper
compatibility: all
---

<!-- CONTENT_HASH: GENERATED -->

**required_canon_version:** >=3.0.0

# Skill: doc-merge-batch-skill

**Version:** 1.0.0
**Status:** Active

## Purpose
Wraps the `doc_merge_batch` module as an AGS skill with deterministic JSON I/O.

## Inputs
`input.json`:
- `mode`: `"verify"` (recommended) or `"apply"`
- `pairs`: list of `{ "a": "...", "b": "..." }` relative file paths
- `out_dir`: output directory (relative path)

## Outputs
Writes a JSON report to the provided `output.json` path:
- `ok`: boolean
- `mode`, `out_dir`, `pairs`
- `report_path`: path to the underlying tool's `report.json` if present

## Constraints
- Writes outputs only under the provided `out_dir`.
*** End Patch"}]}commentary to=functions.apply_patch  玩彩神争霸Exit code: 0
```

## `CAPABILITY/SKILLS/utilities/doc-update/SKILL.md` (2,311 bytes)

```
<!-- CONTENT_HASH: e55e25737af57b512b8918844cdd78f9ea09269c268c7be7975a15f31ba09547 -->

**required_canon_version:** >=3.0.0


# Skill: doc-update

**Version:** 0.1.0

**Status:** Active



## Trigger

Use when asked to update repository documentation, ADRs, or onboarding guidance.

## Doc system overview (authoritative structure)

- **CANON/**: binding rules (CONTRACT, INVARIANTS, VERSIONING). Only edit when explicitly asked.
- **CONTEXT/**: ADRs, preferences, rejections, and research. ADRs explain why decisions exist.
- **CONTEXT/maps/**: entrypoints and system maps that tell agents where to change things.
- **README.md**: top-level overview and required session bootstrap.
- **MCP/**: protocol integration docs and server entrypoints.
- **SKILLS/**: procedural workflows + fixtures for non-trivial work.
- **CONTRACTS/**: fixtures and schemas that enforce behavior.
- **TOOLS/**: critics, linters, and migration helpers.

## Inputs

- `input.json` with:
  - `topic` (string): e.g. "mcp", "skills", "governance".
  - `extra_targets` (array, optional): Additional paths to include in the update set.

## Outputs

- Writes `actual.json` with:
  - `topic` (string)
  - `doc_system` (array of strings)
  - `recommended_targets` (array of strings)
  - `notes` (array of strings)

## Workflow

1. Confirm intent gate (do not edit CANON or existing CONTEXT unless explicitly requested).
2. Use `CORTEX/query.py` to locate entrypoints; avoid raw filesystem discovery.
3. Update the smallest set of docs that inform all agents (README, CONTEXT/maps/ENTRYPOINTS, MCP docs, relevant ADRs).
4. For MCP updates, include:
   - The recommended entrypoint (`LAW/CONTRACTS/ags_mcp_entrypoint.py`).
   - The log location (`LAW/CONTRACTS/_runs/mcp_logs/`).
   - The verification skills (`mcp-smoke`, `mcp-extension-verify`).
   - Client config examples for Windows and WSL where relevant.
5. Run `python3 TOOLS/critic.py` and `python3 CONTRACTS/runner.py` after changes.

## Constraints

- Must not scan the filesystem directly (use `CORTEX/query.py` for discovery).
- Must not modify canon or context unless explicitly authorized.
- Must not write artifacts outside allowed roots.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/utilities/example-echo/SKILL.md` (714 bytes)

```
<!-- CONTENT_HASH: bd4db62bbe253d888eafe3dddb4f5851b18a79f00cf3b90c0f5db7af6a850164 -->

**required_canon_version:** >=3.0.0


# Skill: example-echo

**Version:** 0.1.0

**Status:** Reference



## Trigger

Use when a minimal, deterministic example skill is needed to verify the contract runner.

## Inputs

- `input.json` with any JSON value.

## Outputs

- Writes `actual.json` containing the same JSON value as the input.

## Constraints

- Deterministic and side-effect free outside the provided output path (runner writes fixture outputs under `CONTRACTS/_runs/`).
- Must not modify canon or context.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/utilities/file-analyzer/SKILL.md` (858 bytes)

```
<!-- CONTENT_HASH: 373d9bb6438898b8652edb9871c3572fc594135267e9af172fcbd5796ac4af67 -->

**required_canon_version:** >=3.0.0


# Skill: file-analyzer
**Version:** 0.1.0
**Status:** Active

**canon_version:** "3.0.0"

# File Analyzer

Analyzes repo structure and identifies critical files.

## Usage

```bash
python scripts/run.py input.json output.json
```

## Input Schema

```json
{
  "repo_path": "D:/path/to/repo",
  "task_type": "analyze_swarm",
  "focus_areas": ["SKILLS/", "MCP/"],
  "output_format": "json"
}
```

## Task Types

| Type | Purpose |
|------|---------|
| `analyze_swarm` | Understand swarm architecture |
| `find_config` | Locate configuration files |
| `identify_dependencies` | Find skill dependencies |
| `list_critical_files` | List essential files |

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/utilities/pack-validate/SKILL.md` (1,520 bytes)

```
<!-- CONTENT_HASH: 88b9e58c965d51414dc6f300f7cf84ef02b0f91c341acb159dea97c4da4f05af -->

**required_canon_version:** >=3.0.0


# Skill: pack-validate

**Version:** 0.1.0

**Status:** Active



## Purpose

Validates that a pack is complete, correctly structured, and navigable.

## Checks Performed

1. **Structure Validation**
   - `meta/` directory exists
   - `repo/` directory exists
   - Required meta files present (PACK_INFO.json, REPO_STATE.json, FILE_INDEX.json)

2. **Manifest Integrity**
   - All files in manifest exist in pack
   - File hashes match manifest

3. **Navigation Validation**
   - START_HERE.md or ENTRYPOINTS.md accessible
   - Split files have correct naming (AGS-00_INDEX.md, etc.)

4. **Token Validation**
   - CONTEXT.txt exists
   - Token warnings noted

5. **PRUNED Validation** (if PRUNED/ exists)
   - PRUNED/PACK_MANIFEST_PRUNED.json exists and has valid schema
   - PRUNED/meta/PRUNED_RULES.json exists
   - Manifest entries include path, hash, and size
   - Hashes and sizes match actual files
   - Manifest entries are in canonical (lexicographic) order
   - No staging directories (.pruned_staging_*) or backup directories (PRUNED._old) present

## Inputs

- `pack_path`: Path to the pack directory to validate

## Outputs

- `valid`: Boolean - whether pack passes all checks
- `errors`: List of validation errors
- `warnings`: List of warnings (non-fatal)
- `stats`: Pack statistics (file count, bytes, tokens)

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/utilities/powershell-bridge/SKILL.md` (801 bytes)

```
<!-- CONTENT_HASH: fae1d6a08e7c5deaa0171dd9199751aa4c806741dda235d1172b845a784faa00 -->

**required_canon_version:** >=3.0.0


# Skill: powershell-bridge

**Version:** 0.1.0

**Status:** Active



## Trigger

Use when asked to set up a local PowerShell bridge for controlled command execution on Windows.

## Inputs

- `input.json` with:
  - `repo_root` (string, optional): Repository root path override.

## Outputs

- Writes `output.json` with:
  - `ok` (boolean)
  - `paths` (object): Relevant file locations.
  - `instructions` (array of strings): Setup and usage steps.

## Constraints

- Must not execute PowerShell or external commands.
- Must only emit deterministic instructions.

## Fixtures

- `fixtures/basic/`

**required_canon_version:** >=3.0.0
```

## `CAPABILITY/SKILLS/utilities/prompt-runner/SKILL.md` (2,383 bytes)

```
---
name: prompt-runner
description: Run NAVIGATION/PROMPTS tasks by parsing headers, enforcing prompt canon gates (lint, FILL_ME__, hash checks, allowlists, dependencies), executing declared commands, and emitting deterministic receipts/reports. Use when asked to execute a prompt file or run a phase prompt.
---

**required_canon_version:** >=3.0.0

# Prompt Runner

**Version:** 0.1.0

**Status:** Active

Execute prompt files with a deterministic, receipt-first workflow. This skill enforces the prompt canon and fails closed.

## Usage

```bash
python run.py input.json output.json
```

## Input (input.json)

Required fields:
- task_id: string
- prompt_path: repo-relative path to a prompt markdown file
- output_dir: repo-relative path for runner artifacts (must be under LAW/CONTRACTS/_runs)

Optional fields:
- emit_data: true|false (default false)
- data_path: repo-relative path for DATA.json (defaults to output_dir/DATA.json)
- commands: list of objects { command: string, timeout_sec: int, allow_failure: bool }
- manifest_path: repo-relative path to PROMPT_PACK_MANIFEST.json (required when depends_on is non-empty)
- plan_ref: string plan identifier or artifact path (required for non-planner models)
- max_output_bytes: int (default 100000)

## Behavior

- Verifies prompt path exists in cortex SECTION_INDEX.
- Parses YAML frontmatter and enforces required header fields.
- Enforces required sections and SCOPE allowlists.
- Stops if any FILL_ME__ tokens remain (BLOCKED_UNKNOWN).
- Validates policy_canon_sha256 and guide_canon_sha256 against current canon.
- Runs canonical lint command and blocks on exit code 1.
- Checks dependencies via manifest and requires receipt result OK.
- Writes receipt.json and REPORT.md (and optional DATA.json) under LAW/CONTRACTS/_runs.

## Output (output.json)

- status: success|error
- result: OK|VERIFICATION_FAILED|BLOCKED_UNKNOWN|INTERNAL_ERROR|POLICY_BREACH
- prompt_sha256: hex digest of prompt contents
- frontmatter: parsed key-value pairs
- headings: list of section headings
- fill_me_tokens: list of unresolved tokens found
- lint: { command, exit_code, result, stdout, stderr }
- commands_run: list with exit codes and outputs
- artifacts: resolved artifact paths
- errors: list of error strings

## Notes

- Do not use this skill for unrelated repo changes.
- Lint failures or missing required facts stop execution.
```

## `CAPABILITY/SKILLS/utilities/skill-creator/SKILL.md` (18,148 bytes)

```
<!-- CONTENT_HASH: 557d712831d40cc332e58fbc007ee4bd2eb8a6d0e9e502a1091f3f37ecbff3d4 -->

**required_canon_version:** >=3.0.0


# Skill: skill-creator
**Version:** 0.1.0
**Status:** Active

**canon_version:** "3.0.0"

# Skill Creator

This skill provides guidance for creating effective skills.

## About Skills

Skills are modular, self-contained packages that extend Claude's capabilities by providing
specialized knowledge, workflows, and tools. Think of them as "onboarding guides" for specific
domains or tasks—they transform Claude from a general-purpose agent into a specialized agent
equipped with procedural knowledge that no model can fully possess.

### What Skills Provide

1. Specialized workflows - Multi-step procedures for specific domains
2. Tool integrations - Instructions for working with specific file formats or APIs
3. Domain expertise - Company-specific knowledge, schemas, business logic
4. Bundled resources - Scripts, references, and assets for complex and repetitive tasks

## Core Principles

### Concise is Key

The context window is a public good. Skills share the context window with everything else Claude needs: system prompt, conversation history, other Skills' metadata, and the actual user request.

**Default assumption: Claude is already very smart.** Only add context Claude doesn't already have. Challenge each piece of information: "Does Claude really need this explanation?" and "Does this paragraph justify its token cost?"

Prefer concise examples over verbose explanations.

### Set Appropriate Degrees of Freedom

Match the level of specificity to the task's fragility and variability:

**High freedom (text-based instructions)**: Use when multiple approaches are valid, decisions depend on context, or heuristics guide the approach.

**Medium freedom (pseudocode or scripts with parameters)**: Use when a preferred pattern exists, some variation is acceptable, or configuration affects behavior.

**Low freedom (specific scripts, few parameters)**: Use when operations are fragile and error-prone, consistency is critical, or a specific sequence must be followed.

Think of Claude as exploring a path: a narrow bridge with cliffs needs specific guardrails (low freedom), while an open field allows many routes (high freedom).

### Anatomy of a Skill

Every skill consists of a required SKILL.md file and optional bundled resources:

```
skill-name/
├── SKILL.md (required)
│   ├── YAML frontmatter metadata (required)
│   │   ├── name: (required)
│   │   └── description: (required)
│   └── Markdown instructions (required)
└── Bundled Resources (optional)
    ├── scripts/          - Executable code (Python/Bash/etc.)
    ├── references/       - Documentation intended to be loaded into context as needed
    └── assets/           - Files used in output (templates, icons, fonts, etc.)
```

#### SKILL.md (required)

Every SKILL.md consists of:

- **Frontmatter** (YAML): Contains `name` and `description` fields. These are the only fields that Claude reads to determine when the skill gets used, thus it is very important to be clear and comprehensive in describing what the skill is, and when it should be used.
- **Body** (Markdown): Instructions and guidance for using the skill. Only loaded AFTER the skill triggers (if at all).

#### Bundled Resources (optional)

##### Scripts (`scripts/`)

Executable code (Python/Bash/etc.) for tasks that require deterministic reliability or are repeatedly rewritten.

- **When to include**: When the same code is being rewritten repeatedly or deterministic reliability is needed
- **Example**: `scripts/rotate_pdf.py` for PDF rotation tasks
- **Benefits**: Token efficient, deterministic, may be executed without loading into context
- **Note**: Scripts may still need to be read by Claude for patching or environment-specific adjustments

##### References (`references/`)

Documentation and reference material intended to be loaded as needed into context to inform Claude's process and thinking.

- **When to include**: For documentation that Claude should reference while working
- **Examples**: `references/finance.md` for financial schemas, `references/mnda.md` for company NDA template, `references/policies.md` for company policies, `references/api_docs.md` for API specifications
- **Use cases**: Database schemas, API documentation, domain knowledge, company policies, detailed workflow guides
- **Benefits**: Keeps SKILL.md lean, loaded only when Claude determines it's needed
- **Best practice**: If files are large (>10k words), include grep search patterns in SKILL.md
- **Avoid duplication**: Information should live in either SKILL.md or references files, not both. Prefer references files for detailed information unless it's truly core to the skill—this keeps SKILL.md lean while making information discoverable without hogging the context window. Keep only essential procedural instructions and workflow guidance in SKILL.md; move detailed reference material, schemas, and examples to references files.

##### Assets (`assets/`)

Files not intended to be loaded into context, but rather used within the output Claude produces.

- **When to include**: When the skill needs files that will be used in the final output
- **Examples**: `assets/logo.png` for brand assets, `assets/slides.pptx` for PowerPoint templates, `assets/frontend-template/` for HTML/React boilerplate, `assets/font.ttf` for typography
- **Use cases**: Templates, images, icons, boilerplate code, fonts, sample documents that get copied or modified
- **Benefits**: Separates output resources from documentation, enables Claude to use files without loading them into context

#### What to Not Include in a Skill

A skill should only contain essential files that directly support its functionality. Do NOT create extraneous documentation or auxiliary files, including:

- README.md
- INSTALLATION_GUIDE.md
- QUICK_REFERENCE.md
- CHANGELOG.md
- etc.

The skill should only contain the information needed for an AI agent to do the job at hand. It should not contain auxilary context about the process that went into creating it, setup and testing procedures, user-facing documentation, etc. Creating additional documentation files just adds clutter and confusion.

### Progressive Disclosure Design Principle

Skills use a three-level loading system to manage context efficiently:

1. **Metadata (name + description)** - Always in context (~100 words)
2. **SKILL.md body** - When skill triggers (<5k words)
3. **Bundled resources** - As needed by Claude (Unlimited because scripts can be executed without reading into context window)

#### Progressive Disclosure Patterns

Keep SKILL.md body to the essentials and under 500 lines to minimize context bloat. Split content into separate files when approaching this limit. When splitting out content into other files, it is very important to reference them from SKILL.md and describe clearly when to read them, to ensure the reader of the skill knows they exist and when to use them.

**Key principle:** When a skill supports multiple variations, frameworks, or options, keep only the core workflow and selection guidance in SKILL.md. Move variant-specific details (patterns, examples, configuration) into separate reference files.

**Pattern 1: High-level guide with references**

```markdown
# PDF Processing

## Quick start

Extract text with pdfplumber:
[code example]

## Advanced features

- **Form filling**: See [FORMS.md](FORMS.md) for complete guide
- **API reference**: See [REFERENCE.md](REFERENCE.md) for all methods
- **Examples**: See [EXAMPLES.md](EXAMPLES.md) for common patterns
```

Claude loads FORMS.md, REFERENCE.md, or EXAMPLES.md only when needed.

**Pattern 2: Domain-specific organization**

For Skills with multiple domains, organize content by domain to avoid loading irrelevant context:

```
bigquery-skill/
├── SKILL.md (overview and navigation)
└── reference/
    ├── finance.md (revenue, billing metrics)
    ├── sales.md (opportunities, pipeline)
    ├── product.md (API usage, features)
    └── marketing.md (campaigns, attribution)
```

When a user asks about sales metrics, Claude only reads sales.md.

Similarly, for skills supporting multiple frameworks or variants, organize by variant:

```
cloud-deploy/
├── SKILL.md (workflow + provider selection)
└── references/
    ├── aws.md (AWS deployment patterns)
    ├── gcp.md (GCP deployment patterns)
    └── azure.md (Azure deployment patterns)
```

When the user chooses AWS, Claude only reads aws.md.

**Pattern 3: Conditional details**

Show basic content, link to advanced content:

```markdown
# DOCX Processing

## Creating documents

Use docx-js for new documents. See [DOCX-JS.md](DOCX-JS.md).

## Editing documents

For simple edits, modify the XML directly.

**For tracked changes**: See [REDLINING.md](REDLINING.md)
**For OOXML details**: See [OOXML.md](OOXML.md)
```

Claude reads REDLINING.md or OOXML.md only when the user needs those features.

**Important guidelines:**

- **Avoid deeply nested references** - Keep references one level deep from SKILL.md. All reference files should link directly from SKILL.md.
- **Structure longer reference files** - For files longer than 100 lines, include a table of contents at the top so Claude can see the full scope when previewing.

## Skill Creation Process

Skill creation involves these steps:

1. Understand the skill with concrete examples
2. Plan reusable skill contents (scripts, references, assets)
3. Initialize the skill (run init_skill.py)
4. Edit the skill (implement resources and write SKILL.md)
5. Package the skill (run package_skill.py)
6. Iterate based on real usage

Follow these steps in order, skipping only if there is a clear reason why they are not applicable.

### Step 1: Understanding the Skill with Concrete Examples

Skip this step only when the skill's usage patterns are already clearly understood. It remains valuable even when working with an existing skill.

To create an effective skill, clearly understand concrete examples of how the skill will be used. This understanding can come from either direct user examples or generated examples that are validated with user feedback.

For example, when building an image-editor skill, relevant questions include:

- "What functionality should the image-editor skill support? Editing, rotating, anything else?"
- "Can you give some examples of how this skill would be used?"
- "I can imagine users asking for things like 'Remove the red-eye from this image' or 'Rotate this image'. Are there other ways you imagine this skill being used?"
- "What would a user say that should trigger this skill?"

To avoid overwhelming users, avoid asking too many questions in a single message. Start with the most important questions and follow up as needed for better effectiveness.

Conclude this step when there is a clear sense of the functionality the skill should support.

### Step 2: Planning the Reusable Skill Contents

To turn concrete examples into an effective skill, analyze each example by:

1. Considering how to execute on the example from scratch
2. Identifying what scripts, references, and assets would be helpful when executing these workflows repeatedly

Example: When building a `pdf-editor` skill to handle queries like "Help me rotate this PDF," the analysis shows:

1. Rotating a PDF requires re-writing the same code each time
2. A `scripts/rotate_pdf.py` script would be helpful to store in the skill

Example: When designing a `frontend-webapp-builder` skill for queries like "Build me a todo app" or "Build me a dashboard to track my steps," the analysis shows:

1. Writing a frontend webapp requires the same boilerplate HTML/React each time
2. An `assets/hello-world/` template containing the boilerplate HTML/React project files would be helpful to store in the skill

Example: When building a `big-query` skill to handle queries like "How many users have logged in today?" the analysis shows:

1. Querying BigQuery requires re-discovering the table schemas and relationships each time
2. A `references/schema.md` file documenting the table schemas would be helpful to store in the skill

To establish the skill's contents, analyze each concrete example to create a list of the reusable resources to include: scripts, references, and assets.

### Step 3: Initializing the Skill

At this point, it is time to actually create the skill.

Skip this step only if the skill being developed already exists, and iteration or packaging is needed. In this case, continue to the next step.

When creating a new skill from scratch, always run the `init_skill.py` script. The script conveniently generates a new template skill directory that automatically includes everything a skill requires, making the skill creation process much more efficient and reliable.

Usage:

```bash
scripts/init_skill.py <skill-name> --path <output-directory>
```

The script:

- Creates the skill directory at the specified path
- Generates a SKILL.md template with proper frontmatter and TODO placeholders
- Creates example resource directories: `scripts/`, `references/`, and `assets/`
- Adds example files in each directory that can be customized or deleted

After initialization, customize or remove the generated SKILL.md and example files as needed.

### Step 4: Edit the Skill

When editing the (newly-generated or existing) skill, remember that the skill is being created for another instance of Claude to use. Include information that would be beneficial and non-obvious to Claude. Consider what procedural knowledge, domain-specific details, or reusable assets would help another Claude instance execute these tasks more effectively.

#### Learn Proven Design Patterns

Consult these helpful guides based on your skill's needs:

- **Multi-step processes**: See references/workflows.md for sequential workflows and conditional logic
- **Specific output formats or quality standards**: See references/output-patterns.md for template and example patterns

These files contain established best practices for effective skill design.

#### Start with Reusable Skill Contents

To begin implementation, start with the reusable resources identified above: `scripts/`, `references/`, and `assets/` files. Note that this step may require user input. For example, when implementing a `brand-guidelines` skill, the user may need to provide brand assets or templates to store in `assets/`, or documentation to store in `references/`.

Added scripts must be tested by actually running them to ensure there are no bugs and that the output matches what is expected. If there are many similar scripts, only a representative sample needs to be tested to ensure confidence that they all work while balancing time to completion.

Any example files and directories not needed for the skill should be deleted. The initialization script creates example files in `scripts/`, `references/`, and `assets/` to demonstrate structure, but most skills won't need all of them.

#### Update SKILL.md

**Writing Guidelines:** Always use imperative/infinitive form.

##### Frontmatter

Write the YAML frontmatter with `name` and `description`:

- `name`: The skill name
- `description`: This is the primary triggering mechanism for your skill, and helps Claude understand when to use the skill.
  - Include both what the Skill does and specific triggers/contexts for when to use it.
  - Include all "when to use" information here - Not in the body. The body is only loaded after triggering, so "When to Use This Skill" sections in the body are not helpful to Claude.
  - Example description for a `docx` skill: "Comprehensive document creation, editing, and analysis with support for tracked changes, comments, formatting preservation, and text extraction. Use when Claude needs to work with professional documents (.docx files) for: (1) Creating new documents, (2) Modifying or editing content, (3) Working with tracked changes, (4) Adding comments, or any other document tasks"

Do not include any other fields in YAML frontmatter.

##### Body

Write instructions for using the skill and its bundled resources.

### Step 5: Packaging a Skill

Once development of the skill is complete, it must be packaged into a distributable .skill file that gets shared with the user. The packaging process automatically validates the skill first to ensure it meets all requirements:

```bash
scripts/package_skill.py <path/to/skill-folder>
```

Optional output directory specification:

```bash
scripts/package_skill.py <path/to/skill-folder> ./dist
```

The packaging script will:

1. **Validate** the skill automatically, checking:

   - YAML frontmatter format and required fields
   - Skill naming conventions and directory structure
   - Description completeness and quality
   - File organization and resource references

2. **Package** the skill if validation passes, creating a .skill file named after the skill (e.g., `my-skill.skill`) that includes all files and maintains the proper directory structure for distribution. The .skill file is a zip file with a .skill extension.

If validation fails, the script will report the errors and exit without creating a package. Fix any validation errors and run the packaging command again.

### Step 6: Iterate

After testing the skill, users may request improvements. Often this happens right after using the skill, with fresh context of how the skill performed.

**Iteration workflow:**

1. Use the skill on real tasks
2. Notice struggles or inefficiencies
3. Identify how SKILL.md or bundled resources should be updated
4. Implement changes and test again

**required_canon_version:** >=3.0.0
```
