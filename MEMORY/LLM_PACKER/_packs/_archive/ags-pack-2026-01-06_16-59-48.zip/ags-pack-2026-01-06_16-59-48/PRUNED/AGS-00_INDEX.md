# AGS Pack Index (PRUNED)

This directory contains a reduced planning context for LLM navigation.

## What is PRUNED?

PRUNED is a minimal subset of full AGS repository, optimized for:
- Understanding governance rules and decisions
- Navigating roadmaps and operational procedures
- Finding skill manifests and tool documentation

## Contents

- `AGS-01_NAVIGATION.md` - Roadmaps and OPS
- `AGS-02_LAW_CANON.md` - Core governance rules
- `AGS-03_LAW_CONTEXT.md` - ADRs and decision records
- `AGS-04_CONTRACTS_SCHEMAS.md` - JSON schemas
- `AGS-05_SKILL_MANIFESTS.md` - Skill SKILL.md files
- `AGS-06_TOOL_DOCS.md` - Tool documentation

## Notes

- PRUNED does NOT include full source code trees.
- Use FULL/ or SPLIT/ for complete repository access.
- PRUNED is deterministic and additive (does not affect other outputs).
