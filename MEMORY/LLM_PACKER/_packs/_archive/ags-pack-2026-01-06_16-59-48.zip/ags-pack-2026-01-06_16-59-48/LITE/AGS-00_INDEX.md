# AGS Pack Index (LITE)

This directory contains a compressed, discussion-first map of the pack.

## Read order
1) `repo/AGENTS.md`
2) `repo/README.md`
3) `repo/LAW/CANON/CONTRACT.md` and `repo/LAW/CANON/INVARIANTS.md` and `repo/LAW/CANON/VERSIONING.md`
4) `repo/LAW/CONTRACTS/runner.py`
5) `repo/NAVIGATION/MAPS/ENTRYPOINTS.md`
6) `repo/CAPABILITY/TOOLS/critic.py` and `repo/CAPABILITY/SKILLS/*/SKILL.md`
7) `repo/DIRECTION/` (roadmaps, if used)
8) `repo/MEMORY/LLM_PACKER/README.md`
9) `meta/PACK_INFO.json`
10) `meta/FILE_TREE.txt` and `meta/FILE_INDEX.json`
