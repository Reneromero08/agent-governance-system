import torch
import time
import os
import sys
from transformers import AutoTokenizer, AutoModelForCausalLM, DynamicCache

# Add directory to sys.path to import our custom cache
DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, DIR)

from huggingface_catalytic_cache import HuggingFaceCatalyticCache

def get_cache_size_bytes(cache) -> int:
    """Helper to calculate total byte size of cached tensors."""
    total_bytes = 0
    # For our custom HuggingFaceCatalyticCache
    if hasattr(cache, "key_cache"):
        for k in cache.key_cache:
            if k is not None:
                total_bytes += k.numel() * k.element_size()
        for v in cache.value_cache:
            if v is not None:
                total_bytes += v.numel() * v.element_size()
    # For standard DynamicCache
    elif hasattr(cache, "layers"):
        for layer in cache.layers:
            if hasattr(layer, "keys") and isinstance(layer.keys, torch.Tensor) and layer.keys.numel() > 0:
                total_bytes += layer.keys.numel() * layer.keys.element_size()
            if hasattr(layer, "values") and isinstance(layer.values, torch.Tensor) and layer.values.numel() > 0:
                total_bytes += layer.values.numel() * layer.values.element_size()
    return total_bytes

def run_scenario(name: str, model, tokenizer, prompt: str, cache_obj, num_steps: int = 150):
    print(f"\nRunning scenario: {name}...")
    device = next(model.parameters()).device
    input_ids = tokenizer.encode(prompt, return_tensors="pt").to(device)
    
    # Track statistics
    step_sizes = []
    step_times = []
    generated_tokens = []
    
    current_input_ids = input_ids.clone()
    
    # Warmup step to initialize cache / calibrate projectors
    t_start = time.perf_counter()
    with torch.no_grad():
        outputs = model(current_input_ids, past_key_values=cache_obj, use_cache=True)
    next_token_logits = outputs.logits[:, -1, :]
    next_token = torch.argmax(next_token_logits, dim=-1, keepdim=True)
    current_input_ids = torch.cat([current_input_ids, next_token], dim=-1)
    
    step_times.append(time.perf_counter() - t_start)
    step_sizes.append(get_cache_size_bytes(cache_obj))
    generated_tokens.append(next_token.item())
    
    # Autoregressive generation loop
    for i in range(num_steps - 1):
        t_start = time.perf_counter()
        with torch.no_grad():
            outputs = model(current_input_ids[:, -1:], past_key_values=cache_obj, use_cache=True)
        next_token_logits = outputs.logits[:, -1, :]
        next_token = torch.argmax(next_token_logits, dim=-1, keepdim=True)
        current_input_ids = torch.cat([current_input_ids, next_token], dim=-1)
        
        step_times.append(time.perf_counter() - t_start)
        step_sizes.append(get_cache_size_bytes(cache_obj))
        generated_tokens.append(next_token.item())

    total_time = sum(step_times)
    tokens_per_sec = len(step_times) / total_time
    output_text = tokenizer.decode(current_input_ids[0])
    
    print(f"[{name}] Finished in {total_time:.2f}s ({tokens_per_sec:.2f} tok/sec)")
    print(f"[{name}] Final cache size: {step_sizes[-1] / 1024:.2f} KB")
    
    return {
        "text": output_text,
        "tokens": generated_tokens,
        "sizes": step_sizes,
        "times": step_times,
        "tok_per_sec": tokens_per_sec
    }

def main():
    print("=" * 80)
    print("GEMMA-4 REAL-MODEL CATALYTIC KV CACHE EXPERIMENT")
    print("=" * 80)
    
    model_id = "google/gemma-4-E2B-it"
    print(f"Loading local model {model_id}...")
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.bfloat16 if device == "cuda" else torch.float32
    print(f"Using device: {device}, dtype: {dtype}")
    
    # We load tokenizer and model locally
    tokenizer = AutoTokenizer.from_pretrained(model_id, local_files_only=True, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        local_files_only=True,
        trust_remote_code=True,
        torch_dtype=dtype,
        device_map=device
    )
    model.eval()
    print("Model loaded successfully.")
    
    # Define a long, descriptive prompt to fill up history
    raw_prompt = (
        "The following is a detailed report on quantum computing: Quantum computing is a rapidly-emerging technology "
        "that harnesses the laws of quantum mechanics to solve problems too complex for classical computers. "
        "Today, IBM, Google, and other leaders are building increasingly powerful quantum processors that use qubits "
        "instead of classical bits. This report details the architectural nuances of topological quantum error correction, "
        "specifically looking at surface codes and color codes, and compares their performance under various noise models. "
        "Furthermore, we analyze the scaling limits of dilution refrigerators and the integration of superconducting "
        "coaxial lines to transmit control microwave pulses to the quantum chip. Please summarize the main challenges "
        "and technical milestones for quantum scalability."
    )
    chat = [{"role": "user", "content": raw_prompt}]
    prompt = tokenizer.apply_chat_template(chat, tokenize=False, add_generation_prompt=True)
    
    # Configuration parameters
    k_dim = 64            # Compress head_dim (256) to 64
    max_history = 128     # Bounded temporal history limit
    active_window = 64    # Keep last 64 tokens in high-fidelity
    sink_tokens = 4       # Keep first 4 tokens to avoid attention sinks
    num_steps = 100       # Number of generated tokens (fast on GPU)
    
    # 1. Baseline DynamicCache
    baseline_cache = DynamicCache()
    res_base = run_scenario("Baseline (DynamicCache)", model, tokenizer, prompt, baseline_cache, num_steps)
    
    # 2. Spatial-Only Catalytic Cache (max_history set very high so no temporal pruning occurs)
    spatial_cache = HuggingFaceCatalyticCache(k_dim=k_dim, max_history=10000, active_window=active_window, sink_tokens=sink_tokens)
    res_spatial = run_scenario("Spatial-Only Compression", model, tokenizer, prompt, spatial_cache, num_steps)
    
    # 3. Full Catalytic Cache (Spatial compression + Temporal Heavy Hitter pruning)
    catalytic_cache = HuggingFaceCatalyticCache(k_dim=k_dim, max_history=max_history, active_window=active_window, sink_tokens=sink_tokens)
    res_cat = run_scenario("Full Catalytic Cache", model, tokenizer, prompt, catalytic_cache, num_steps)
    
    # Print analysis table
    print("\n" + "=" * 80)
    print("EXPERIMENTAL ANALYSIS")
    print("=" * 80)
    print(f"{'Metric':<25} | {'Baseline':<15} | {'Spatial-Only':<15} | {'Full Catalytic':<15}")
    print("-" * 80)
    print(f"{'Init Cache (KB)':<25} | {res_base['sizes'][0]/1024:<15.2f} | {res_spatial['sizes'][0]/1024:<15.2f} | {res_cat['sizes'][0]/1024:<15.2f}")
    print(f"{'Final Cache (KB)':<25} | {res_base['sizes'][-1]/1024:<15.2f} | {res_spatial['sizes'][-1]/1024:<15.2f} | {res_cat['sizes'][-1]/1024:<15.2f}")
    
    # Calculate compression ratio
    comp_ratio = res_base['sizes'][-1] / res_cat['sizes'][-1]
    print(f"{'Compression Ratio':<25} | {'1.00x':<15} | {res_base['sizes'][-1]/res_spatial['sizes'][-1]:<15.2f}x | {comp_ratio:<15.2f}x")
    print(f"{'Speed (tok/sec)':<25} | {res_base['tok_per_sec']:<15.2f} | {res_spatial['tok_per_sec']:<15.2f} | {res_cat['tok_per_sec']:<15.2f}")
    
    # Check text similarity / overlap of generated tokens
    match_spatial = sum(1 for a, b in zip(res_base['tokens'], res_spatial['tokens']) if a == b) / len(res_base['tokens']) * 100
    match_cat = sum(1 for a, b in zip(res_base['tokens'], res_cat['tokens']) if a == b) / len(res_base['tokens']) * 100
    print(f"{'Token Match Rate (%)':<25} | {'100.00%':<15} | {match_spatial:<15.2f}% | {match_cat:<15.2f}%")
    print("=" * 80)
    
    print("\n--- SAMPLE GENERATION (Baseline) ---")
    print(res_base['text'][-300:])
    print("\n--- SAMPLE GENERATION (Full Catalytic) ---")
    print(res_cat['text'][-300:])

if __name__ == "__main__":
    main()
