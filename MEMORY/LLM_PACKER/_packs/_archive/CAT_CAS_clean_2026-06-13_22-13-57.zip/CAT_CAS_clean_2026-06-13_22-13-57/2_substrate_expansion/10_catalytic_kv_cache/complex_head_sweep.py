"""
Complex Projective Attention: Scaling Sweep over Head Counts
Sweeps head count H in [4, 8, 16, 32] with d_model=64.
Compares training loss, validation accuracy, and KV cache size.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math
import time

# Set seeds for reproducibility
torch.manual_seed(42)
np.random.seed(42)

class ComplexProjectiveAttention(nn.Module):
    def __init__(self, d_model, num_heads):
        super().__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads
        
        # Projections
        self.q_proj_r = nn.Linear(d_model, d_model, bias=False)
        self.q_proj_i = nn.Linear(d_model, d_model, bias=False)
        
        self.k_proj_r = nn.Linear(d_model, d_model, bias=False)
        self.k_proj_i = nn.Linear(d_model, d_model, bias=False)
        
        self.v_proj_r = nn.Linear(d_model, d_model, bias=False)
        self.v_proj_i = nn.Linear(d_model, d_model, bias=False)
        
        self.out_proj = nn.Linear(d_model, d_model, bias=False)
        
        # Orthogonal phases per head
        angles = torch.linspace(0, 2 * math.pi, num_heads + 1)[:num_heads]
        self.phases = nn.ParameterList([
            nn.Parameter(angle.unsqueeze(0)) for angle in angles
        ])
        
    def forward(self, x, cache=None):
        B, S, D = x.shape
        H = self.num_heads
        d_k = self.head_dim
        
        qr = self.q_proj_r(x).view(B, S, H, d_k).transpose(1, 2)
        qi = self.q_proj_i(x).view(B, S, H, d_k).transpose(1, 2)
        
        kr = self.k_proj_r(x).view(B, S, H, d_k).transpose(1, 2)
        ki = self.k_proj_i(x).view(B, S, H, d_k).transpose(1, 2)
        
        vr = self.v_proj_r(x).view(B, S, H, d_k).transpose(1, 2)
        vi = self.v_proj_i(x).view(B, S, H, d_k).transpose(1, 2)
        
        if cache is not None:
            # Compress
            k_complex = torch.complex(kr, ki)
            v_complex = torch.complex(vr, vi)
            
            k_comp_list = []
            v_comp_list = []
            for h in range(H):
                c, s = torch.cos(self.phases[h]), torch.sin(self.phases[h])
                phase = torch.complex(c, s).to(x.device)
                k_comp_list.append(k_complex[:, h] * phase)
                v_comp_list.append(v_complex[:, h] * phase)
                
            k_comp = torch.stack(k_comp_list, dim=1).sum(dim=1, keepdim=True)
            v_comp = torch.stack(v_comp_list, dim=1).sum(dim=1, keepdim=True)
            
            cache['k'] = k_comp
            cache['v'] = v_comp
            
            # Retrieve
            head_outputs = []
            scale = 1.0 / math.sqrt(d_k)
            for h in range(H):
                q_h = torch.complex(qr[:, h], qi[:, h])
                c, s = torch.cos(self.phases[h]), torch.sin(self.phases[h])
                phase_conj = torch.complex(c, -s).to(x.device)
                k_aligned = cache['k'].squeeze(1) * phase_conj
                v_aligned = cache['v'].squeeze(1) * phase_conj
                
                score_complex = torch.matmul(q_h, k_aligned.transpose(-2, -1)) * scale
                score_h = score_complex.real
                
                attn_probs = F.softmax(score_h, dim=-1)
                attn_probs_complex = torch.complex(attn_probs, torch.zeros_like(attn_probs))
                out_complex = torch.matmul(attn_probs_complex, v_aligned)
                head_outputs.append(out_complex.real)
                
            outputs = torch.cat(head_outputs, dim=-1)
        else:
            # Eager Direct Projective Attention
            head_outputs = []
            scale = 1.0 / math.sqrt(d_k)
            for h in range(H):
                q_h = torch.complex(qr[:, h], qi[:, h])
                k_h = torch.complex(kr[:, h], ki[:, h])
                v_h = torch.complex(vr[:, h], vi[:, h])
                
                score_h = torch.matmul(q_h, k_h.transpose(-2, -1)) * scale
                attn_probs = F.softmax(score_h.real, dim=-1)
                attn_probs_complex = torch.complex(attn_probs, torch.zeros_like(attn_probs))
                out_h = torch.matmul(attn_probs_complex, v_h).real
                head_outputs.append(out_h)
            outputs = torch.cat(head_outputs, dim=-1)
            
        return self.out_proj(outputs)

class StandardMHA(nn.Module):
    def __init__(self, d_model, num_heads):
        super().__init__()
        self.mha = nn.MultiheadAttention(d_model, num_heads, batch_first=True)
        
    def forward(self, x, cache=None):
        if cache is not None:
            out, _ = self.mha(x, x, x)
            cache['k'] = torch.randn(x.shape[0], self.mha.num_heads, x.shape[1], self.mha.embed_dim // self.mha.num_heads)
            cache['v'] = torch.randn(x.shape[0], self.mha.num_heads, x.shape[1], self.mha.embed_dim // self.mha.num_heads)
            return out
        out, _ = self.mha(x, x, x)
        return out

def generate_sorting_data(num_samples, seq_len, vocab_size):
    X = torch.randint(1, vocab_size, (num_samples, seq_len))
    Y, _ = torch.sort(X, dim=-1)
    return X, Y

class SortingModel(nn.Module):
    def __init__(self, vocab_size, d_model, num_heads, use_complex=True):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, d_model)
        if use_complex:
            self.attn = ComplexProjectiveAttention(d_model, num_heads)
        else:
            self.attn = StandardMHA(d_model, num_heads)
        self.fc = nn.Linear(d_model, vocab_size)
        
    def forward(self, x, cache=None):
        h = self.embedding(x)
        h = self.attn(h, cache)
        return self.fc(h)

def run_sweep():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Running sweep on device: {device}\n")
    
    # Constants
    vocab_size = 30
    seq_len = 16
    d_model = 64
    num_samples = 1500
    epochs = 10
    batch_size = 32
    
    # Generate data
    X, Y = generate_sorting_data(num_samples, seq_len, vocab_size)
    dataset = torch.utils.data.TensorDataset(X, Y)
    train_size = int(0.8 * num_samples)
    val_size = num_samples - train_size
    train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_size, val_size])
    
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    
    # Sweep configurations
    head_counts = [4, 8, 16, 32]
    results = []
    
    for h in head_counts:
        print(f"\n==================== Head Count H = {h} ====================")
        
        # 1. Train Standard Model
        model_std = SortingModel(vocab_size, d_model, h, use_complex=False).to(device)
        opt_std = torch.optim.Adam(model_std.parameters(), lr=0.003)
        criterion = nn.CrossEntropyLoss()
        
        model_std.train()
        for epoch in range(epochs):
            for x, y in train_loader:
                x, y = x.to(device), y.to(device)
                opt_std.zero_grad()
                logits = model_std(x)
                loss = criterion(logits.view(-1, vocab_size), y.view(-1))
                loss.backward()
                opt_std.step()
                
        # 2. Train Complex Model
        model_comp = SortingModel(vocab_size, d_model, h, use_complex=True).to(device)
        opt_comp = torch.optim.Adam(model_comp.parameters(), lr=0.003)
        
        model_comp.train()
        for epoch in range(epochs):
            for x, y in train_loader:
                x, y = x.to(device), y.to(device)
                opt_comp.zero_grad()
                logits = model_comp(x)
                loss = criterion(logits.view(-1, vocab_size), y.view(-1))
                loss.backward()
                opt_comp.step()
                
        # 3. Evaluate and measure sizes
        model_std.eval()
        model_comp.eval()
        
        cache_std = {}
        cache_comp = {}
        
        val_x, _ = next(iter(val_loader))
        val_x = val_x.to(device)
        
        with torch.no_grad():
            _ = model_std(val_x, cache=cache_std)
            _ = model_comp(val_x, cache=cache_comp)
            
        std_bytes = (cache_std['k'].numel() + cache_std['v'].numel()) * 4
        comp_bytes = (cache_comp['k'].numel() + cache_comp['v'].numel()) * 8
        savings_pct = (1.0 - comp_bytes / std_bytes) * 100
        
        # Calculate Validation Accuracy
        def get_acc(model):
            correct = 0
            total = 0
            with torch.no_grad():
                for x, y in val_loader:
                    x, y = x.to(device), y.to(device)
                    logits = model(x)
                    preds = torch.argmax(logits, dim=-1)
                    correct += (preds == y).sum().item()
                    total += y.numel()
            return correct / total
            
        acc_std = get_acc(model_std)
        acc_comp = get_acc(model_comp)
        
        results.append({
            'H': h,
            'std_acc': acc_std,
            'comp_acc': acc_comp,
            'std_size': std_bytes,
            'comp_size': comp_bytes,
            'savings': savings_pct
        })
        
        print(f"H={h} | Standard Acc: {acc_std:.2%} | Complex Acc: {acc_comp:.2%} | Savings: {savings_pct:.1f}%")
        
    # Print Markdown Table of Sweep Results
    print("\n\n" + "=" * 70)
    print("FINAL SWEEP RESULTS TABLE")
    print("=" * 70)
    print("| Head Count (H) | Std MHA Acc | Complex Acc | Std Cache Size | Complex Cache Size | VRAM Savings |")
    print("|----------------|-------------|-------------|----------------|--------------------|--------------|")
    for r in results:
        print(f"| {r['H']:<14} | {r['std_acc']:<11.2%} | {r['comp_acc']:<11.2%} | {r['std_size']:<14} | {r['comp_size']:<18} | {r['savings']:<11.1f}% |")

if __name__ == "__main__":
    run_sweep()
