import torch
import math
from typing import Dict, Tuple, Optional, List, Any
from transformers.cache_utils import Cache

class HuggingFaceCatalyticCache(Cache):
    """
    HuggingFace-compatible Cache subclass that implements:
    1. Spatial compression: SVD projection to lower dimension k_dim.
    2. Temporal pruning: Keeps attention sinks (first S tokens), active window (last W tokens),
       and prunes the rest to heavy hitters based on key L2-norm.
    """
    def __init__(
        self,
        k_dim: int = 64,
        max_history: int = 128,
        active_window: int = 64,
        sink_tokens: int = 4
    ):
        super().__init__(layers=[])
        self.k_dim = k_dim
        self.max_history = max_history
        self.active_window = active_window
        self.sink_tokens = sink_tokens

        # Caches to store the COMPRESSED keys and values
        # Store layout per layer:
        # key_cache[layer_idx] -> tensor of shape [batch, heads, seq_len, k_dim] or [batch, heads, seq_len, head_dim]
        self.key_cache: List[Optional[torch.Tensor]] = []
        self.value_cache: List[Optional[torch.Tensor]] = []

        # We keep projectors per layer
        # Each projector maps [head_dim] <-> [k_dim]
        self.k_projs: Dict[int, torch.Tensor] = {} # layer_idx -> projection matrix
        self.k_means: Dict[int, torch.Tensor] = {}
        self.v_projs: Dict[int, torch.Tensor] = {}
        self.v_means: Dict[int, torch.Tensor] = {}

    def get_seq_length(self, layer_idx: int = 0) -> int:
        """Returns the sequence length of the cache for the given layer."""
        if layer_idx >= len(self.key_cache) or self.key_cache[layer_idx] is None:
            return 0
        return self.key_cache[layer_idx].shape[-2]

    def _calibrate_projector(self, layer_idx: int, key_data: torch.Tensor, value_data: torch.Tensor):
        """
        Calibrates SVD/PCA projectors on the initial pre-fill activations.
        key_data, value_data shapes: [batch, heads, seq_len, head_dim]
        """
        # We flatten across batch, heads, and seq_len to get a 2D matrix of shape [N, head_dim]
        _, _, _, head_dim = key_data.shape
        
        # Fit Key Projector
        k_flat = key_data.detach().reshape(-1, head_dim).float()
        k_mean = k_flat.mean(dim=0)
        k_centered = k_flat - k_mean
        try:
            _, _, Vt_k = torch.linalg.svd(k_centered, full_matrices=False)
            self.k_projs[layer_idx] = Vt_k[:self.k_dim].to(key_data.dtype)
        except Exception:
            # Fallback to random projection if SVD fails/converges slowly
            self.k_projs[layer_idx] = (torch.randn(self.k_dim, head_dim, device=key_data.device) / math.sqrt(head_dim)).to(key_data.dtype)
        self.k_means[layer_idx] = k_mean.to(key_data.dtype)

        # Fit Value Projector
        v_flat = value_data.detach().reshape(-1, head_dim).float()
        v_mean = v_flat.mean(dim=0)
        v_centered = v_flat - v_mean
        try:
            _, _, Vt_v = torch.linalg.svd(v_centered, full_matrices=False)
            self.v_projs[layer_idx] = Vt_v[:self.k_dim].to(value_data.dtype)
        except Exception:
            self.v_projs[layer_idx] = (torch.randn(self.k_dim, head_dim, device=value_data.device) / math.sqrt(head_dim)).to(value_data.dtype)
        self.v_means[layer_idx] = v_mean.to(value_data.dtype)

    def _compress(self, layer_idx: int, keys: torch.Tensor, values: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compress keys/values: [B, H, T, head_dim] -> [B, H, T, k_dim]"""
        if layer_idx not in self.k_projs:
            return keys, values
        
        k_mean = self.k_means[layer_idx]
        k_proj = self.k_projs[layer_idx]
        v_mean = self.v_means[layer_idx]
        v_proj = self.v_projs[layer_idx]

        k_comp = torch.matmul(keys - k_mean, k_proj.T)
        v_comp = torch.matmul(values - v_mean, v_proj.T)
        return k_comp, v_comp

    def _decompress(self, layer_idx: int, keys_comp: torch.Tensor, values_comp: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Decompress keys/values: [B, H, T, k_dim] -> [B, H, T, head_dim]"""
        if layer_idx not in self.k_projs:
            return keys_comp, values_comp
        
        k_mean = self.k_means[layer_idx]
        k_proj = self.k_projs[layer_idx]
        v_mean = self.v_means[layer_idx]
        v_proj = self.v_projs[layer_idx]

        keys_dec = torch.matmul(keys_comp, k_proj) + k_mean
        values_dec = torch.matmul(values_comp, v_proj) + v_mean
        return keys_dec, values_dec

    def update(
        self,
        key_states: torch.Tensor,
        value_states: torch.Tensor,
        layer_idx: int,
        cache_kwargs: Optional[Dict[str, Any]] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Updates the cache with the new key/value states, applying SVD spatial compression
        and temporal heavy-hitter pruning.
        """
        batch_size, num_heads, new_len, head_dim = key_states.shape

        while len(self.key_cache) <= layer_idx:
            self.key_cache.append(None)
            self.value_cache.append(None)

        # 1. Pre-fill Calibration / Initialization
        if self.key_cache[layer_idx] is None:
            # Calibrate on the prompt activations
            self._calibrate_projector(layer_idx, key_states, value_states)
            
            # Compress and store initial states
            k_comp, v_comp = self._compress(layer_idx, key_states, value_states)
            self.key_cache[layer_idx] = k_comp
            self.value_cache[layer_idx] = v_comp
            
            # Return full decompressed states
            return key_states, value_states

        # 2. Appending new step
        k_comp_new, v_comp_new = self._compress(layer_idx, key_states, value_states)
        
        # Concat compressed cache
        k_cached = torch.cat([self.key_cache[layer_idx], k_comp_new], dim=-2)
        v_cached = torch.cat([self.value_cache[layer_idx], v_comp_new], dim=-2)
        
        total_len = k_cached.shape[-2]

        # 3. Temporal Pruning (if sequence exceeds max_history)
        if total_len > self.max_history:
            # Estimate token importance using Key L2 norm
            # shape: [total_len]
            # More central and high-magnitude keys tend to dominate attention
            scores = k_cached.norm(dim=-1).mean(dim=(0, 1))
            
            # Divide sequence into regions:
            # Sinks, Middle (History), and Active Local Window
            sink_idx = torch.arange(0, self.sink_tokens, device=key_states.device)
            active_idx = torch.arange(total_len - self.active_window, total_len, device=key_states.device)
            
            # Candidates for pruning are the middle tokens
            middle_start = self.sink_tokens
            middle_end = total_len - self.active_window
            
            if middle_end > middle_start:
                middle_scores = scores[middle_start:middle_end]
                k_keep = self.max_history - self.sink_tokens - self.active_window
                
                # Pick top k highest-norm keys as heavy hitters
                if k_keep > 0:
                    _, top_mid_idx = torch.topk(middle_scores, k=min(k_keep, len(middle_scores)), sorted=False)
                    top_mid_idx = top_mid_idx + middle_start
                else:
                    top_mid_idx = torch.tensor([], dtype=torch.long, device=key_states.device)
                
                # Combine all retained indices in chronological order
                keep_idx = torch.cat([sink_idx, top_mid_idx, active_idx])
                keep_idx, _ = torch.sort(keep_idx)
                
                # Prune cache tensors
                k_cached = k_cached[:, :, keep_idx, :]
                v_cached = v_cached[:, :, keep_idx, :]

        # Save updated compressed cache
        self.key_cache[layer_idx] = k_cached
        self.value_cache[layer_idx] = v_cached

        # 4. Return decompressed representation for the forward pass
        return self._decompress(layer_idx, k_cached, v_cached)
