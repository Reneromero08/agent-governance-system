"""
Complex-Phase KV Cache Compression Demo (Application 1)
Implements and benchmarks complex-phase orthogonal multiplexing for KV cache compression in PyTorch.
Compares standard multi-head attention cache size and attention maps against the compressed phase cache.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import time

class ComplexPhaseKVCache:
    def __init__(self, num_heads, head_dim, device="cpu"):
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.device = device
        
        # 1. Biological spiral phase angles for maximum spacing (Q56 Discovery)
        # Using a 2pi / 13 spiral spacing to pack phase states optimally
        angles = np.arange(num_heads) * (2 * np.pi / 13.0)
        self.phases = torch.tensor(
            np.exp(1j * angles),
            dtype=torch.complex64,
            device=device
        ).view(num_heads, 1, 1)  # [H, 1, 1] for broadcasting to [H, SeqLen, HeadDim]

    def compress(self, k, v):
        """
        Compresses Key and Value tensors by rotating them with orthogonal phases
        and summing them across the head dimension.
        
        Inputs:
          k: [Batch, H, SeqLen, HeadDim] (Real float32)
          v: [Batch, H, SeqLen, HeadDim] (Real float32)
        Outputs:
          k_comp: [Batch, 1, SeqLen, HeadDim] (Complex complex64)
          v_comp: [Batch, 1, SeqLen, HeadDim] (Complex complex64)
          
        Memory reduction: 
          Original storage: 2 * H * SeqLen * HeadDim * 4 bytes (float32)
          Compressed storage: 2 * 1 * SeqLen * HeadDim * 8 bytes (complex64)
          Memory savings ratio = H / 2.
          For H=8 heads, this is a 4x reduction in VRAM!
        """
        batch, H, SeqLen, HeadDim = k.shape
        assert H == self.num_heads
        
        # Lift to complex plane
        k_complex = torch.complex(k, torch.zeros_like(k))
        v_complex = torch.complex(v, torch.zeros_like(v))
        
        # Apply head-specific phase rotation
        k_rotated = k_complex * self.phases
        v_rotated = v_complex * self.phases
        
        # Superimpose across heads (sum)
        k_comp = k_rotated.sum(dim=1, keepdim=True)
        v_comp = v_rotated.sum(dim=1, keepdim=True)
        
        return k_comp, v_comp

    def retrieve(self, k_comp, v_comp, head_idx):
        """
        Retrieves Key and Value for a specific head index using the Born Rule
        Projective Measurement.
        
        Inputs:
          k_comp: [Batch, 1, SeqLen, HeadDim] (Complex complex64)
          v_comp: [Batch, 1, SeqLen, HeadDim] (Complex complex64)
          head_idx: Int (index of head to retrieve)
        Outputs:
          k_ret: [Batch, SeqLen, HeadDim] (Real float32)
          v_ret: [Batch, SeqLen, HeadDim] (Real float32)
        """
        # Get target phase and its complex conjugate
        target_phase = self.phases[head_idx].conj()
        
        # Align phases for target head: aligned = target * exp(-i*theta)
        k_aligned = k_comp.squeeze(1) * target_phase
        v_aligned = v_comp.squeeze(1) * target_phase
        
        # Born Rule projection: take real part
        # Orthogonal heads (which have different phases) cancel out or average to 0 (destructive interference)
        k_ret = k_aligned.real
        v_ret = aligned_projective_scale(v_aligned.real, self.num_heads)
        
        return k_ret, v_aligned.real

def aligned_projective_scale(x, num_heads):
    # Due to summation, the aligned head is scaled by 1.0, while others add noise
    # We don't need additional scaling since the target head amplitude is preserved
    return x

def run_demo():
    print("=" * 70)
    print("COMPLEX-PHASE KV CACHE COMPRESSION (APPLICATION 1)")
    print("=" * 70)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Running on: {device}\n")
    
    # Configuration
    batch_size = 1
    num_heads = 8
    seq_len = 64
    head_dim = 64
    
    # Generate realistic query, key, value tensors
    # We add some low-rank structure to keys/values to mimic real LLM behavior
    torch.manual_seed(42)
    q = torch.randn(batch_size, num_heads, seq_len, head_dim, device=device)
    k_raw = torch.randn(batch_size, num_heads, seq_len, head_dim, device=device)
    v_raw = torch.randn(batch_size, num_heads, seq_len, head_dim, device=device)
    
    # Project keys and values to a slightly smoother manifold to represent tokens
    k = F.normalize(k_raw, dim=-1)
    v = F.normalize(v_raw, dim=-1)
    
    # --- 1. Classical Multi-Head Attention Run ---
    print("[Baseline] Computing Classical Attention...")
    # Attention score: Q * K^T / sqrt(d)
    scale = 1.0 / np.sqrt(head_dim)
    scores_classic = torch.matmul(q, k.transpose(-2, -1)) * scale
    attn_classic = F.softmax(scores_classic, dim=-1)
    out_classic = torch.matmul(attn_classic, v)
    
    # Compute size in bytes
    # Key size + Value size = 2 * (B * H * S * D) * 4 bytes
    classic_size_bytes = 2 * (batch_size * num_heads * seq_len * head_dim) * 4
    print(f"  - KV Cache Size: {classic_size_bytes} bytes ({classic_size_bytes / 1024:.2f} KB)")
    
    # --- 2. Compressed Complex-Phase Attention Run ---
    print("\n[Compressed] Initializing Complex Phase Cache...")
    cache = ComplexPhaseKVCache(num_heads, head_dim, device=device)
    
    # Compress Key and Value
    k_comp, v_comp = cache.compress(k, v)
    
    # Memory size:
    # 2 * (B * 1 * S * D) * 8 bytes (since complex64 has 8 bytes per element)
    comp_size_bytes = 2 * (batch_size * 1 * seq_len * head_dim) * 8
    savings_percent = (1 - comp_size_bytes / classic_size_bytes) * 100
    print(f"  - Compressed KV Cache Size: {comp_size_bytes} bytes ({comp_size_bytes / 1024:.2f} KB)")
    print(f"  - VRAM Savings: {savings_percent:.1f}% (Expected: {(1 - 2/num_heads)*100:.1f}%)")
    
    # Retrieve and compute attention for each head
    retrieved_keys = []
    retrieved_values = []
    
    print("\n[Compressed] Retrieving and reconstructing per-head attention maps...")
    for h in range(num_heads):
        kh_ret, vh_ret = cache.retrieve(k_comp, v_comp, h)
        retrieved_keys.append(kh_ret.unsqueeze(1))
        retrieved_values.append(vh_ret.unsqueeze(1))
        
    k_restored = torch.cat(retrieved_keys, dim=1) # [B, H, S, D]
    v_restored = torch.cat(retrieved_values, dim=1) # [B, H, S, D]
    
    # Compute attention scores using restored keys and values
    scores_comp = torch.matmul(q, k_restored.transpose(-2, -1)) * scale
    attn_comp = F.softmax(scores_comp, dim=-1)
    out_comp = torch.matmul(attn_comp, v_restored)
    
    # --- 3. Verification & Metrics ---
    print("\n" + "=" * 70)
    print("VERIFICATION & ACCURACY METRICS")
    print("=" * 70)
    
    # Cosine similarities
    k_sim = F.cosine_similarity(k, k_restored, dim=-1).mean().item()
    v_sim = F.cosine_similarity(v, v_restored, dim=-1).mean().item()
    
    # Attention map correlation
    attn_flat_classic = attn_classic.view(-1)
    attn_flat_comp = attn_comp.view(-1)
    attn_corr = torch.corrcoef(torch.stack([attn_flat_classic, attn_flat_comp]))[0, 1].item()
    
    # Final output correlation
    out_flat_classic = out_classic.view(-1)
    out_flat_comp = out_comp.view(-1)
    out_corr = torch.corrcoef(torch.stack([out_flat_classic, out_flat_comp]))[0, 1].item()
    
    print(f"Key Reconstruction Cosine Similarity:       {k_sim:.4f}")
    print(f"Value Reconstruction Cosine Similarity:     {v_sim:.4f}")
    print(f"Attention Map Correlation (classic vs comp): {attn_corr:.4f}")
    print(f"Final Attention Output Correlation:         {out_corr:.4f}")
    
    # Verdict
    success = (attn_corr > 0.85) and (out_corr > 0.85)
    if success:
        print("\n[VERDICT: SUCCESS]")
        print("  Complex-Phase KV cache compression yields high alignment with minimal cross-talk!")
    else:
        print("\n[VERDICT: FAILURE]")
        print("  Reconstruction noise exceeds acceptable thresholds.")

if __name__ == "__main__":
    run_demo()
