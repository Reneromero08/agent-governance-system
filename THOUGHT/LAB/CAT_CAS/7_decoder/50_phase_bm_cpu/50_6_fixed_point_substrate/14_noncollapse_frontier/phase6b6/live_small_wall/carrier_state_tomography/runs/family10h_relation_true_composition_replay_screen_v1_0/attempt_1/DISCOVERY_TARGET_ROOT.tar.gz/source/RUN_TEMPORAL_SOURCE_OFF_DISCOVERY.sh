#!/usr/bin/env bash
set -u
SOURCE_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$SOURCE_ROOT"
mkdir -p discovery_logs discovery_outputs
printf '%s\n' "$(date -u +%FT%TZ)" > DISCOVERY_TARGET_STARTED_UTC.txt
prepare_cpufreq() {
python3 - <<'PY'
import json, pathlib, sys, time
receipt = {"schema": "FAMILY10H_RELATION_COMPOSITION_REPLAY_EXCLUSION_CPUFREQ_PREPARE_V1", "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "cpus": {}, "failures": []}
for cpu in [4, 5]:
    root = pathlib.Path(f"/sys/devices/system/cpu/cpu{cpu}/cpufreq")
    gov = root / "scaling_governor"
    avail = root / "scaling_available_governors"
    try:
        before = gov.read_text().strip()
        available = avail.read_text().strip().split()
        if "performance" in available:
            gov.write_text("performance\n")
        after = gov.read_text().strip()
        receipt["cpus"][str(cpu)] = {"governor_path": str(gov), "available_governors": available, "before_governor": before, "prepared_governor": after, "prepared": after == "performance"}
        if after != "performance":
            receipt["failures"].append(f"cpu{cpu} performance governor unavailable: {after}")
    except Exception as exc:
        receipt["failures"].append(f"cpu{cpu} governor prepare failed: {exc}")
receipt["passed"] = not receipt["failures"] and all(item.get("prepared") for item in receipt["cpus"].values())
pathlib.Path("discovery_logs/cpufreq_prepare.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
sys.exit(0 if receipt["passed"] else 1)
PY
}
restore_cpufreq() {
python3 - <<'PY'
import json, pathlib, sys, time
prep_path = pathlib.Path("discovery_logs/cpufreq_prepare.json")
receipt = {"schema": "FAMILY10H_RELATION_COMPOSITION_REPLAY_EXCLUSION_CPUFREQ_RESTORE_V1", "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "cpus": {}, "failures": []}
try:
    prep = json.loads(prep_path.read_text())
except Exception as exc:
    prep = {"cpus": {}}
    receipt["failures"].append(f"prepare receipt unavailable: {exc}")
for cpu, item in prep.get("cpus", {}).items():
    path = pathlib.Path(item["governor_path"])
    target = item["before_governor"]
    try:
        current = path.read_text().strip()
        path.write_text(target + "\n")
        after = path.read_text().strip()
        receipt["cpus"][cpu] = {"governor_before_restore": current, "restore_target_governor": target, "governor_after_restore": after, "restored": after == target}
        if after != target:
            receipt["failures"].append(f"cpu{cpu} restore mismatch: {after} != {target}")
    except Exception as exc:
        receipt["failures"].append(f"cpu{cpu} restore failed: {exc}")
receipt["passed"] = not receipt["failures"] and all(item.get("restored") for item in receipt["cpus"].values())
pathlib.Path("discovery_logs/cpufreq_restore.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
sys.exit(0 if receipt["passed"] else 1)
PY
}
preflight() {
python3 - <<'PY'
import json, pathlib, subprocess, sys
failures = []
cpuinfo = pathlib.Path("/proc/cpuinfo").read_text(errors="replace")
if "vendor_id\t: AuthenticAMD" not in cpuinfo:
    failures.append("vendor mismatch")
if "cpu family\t: 16" not in cpuinfo:
    failures.append("family mismatch")
if "model\t\t: 10" not in cpuinfo:
    failures.append("model mismatch")
for cpu in [4, 5]:
    if subprocess.run(["taskset", "-c", str(cpu), "true"], capture_output=True).returncode != 0:
        failures.append(f"cpu{cpu} pinning failed")
sensor = pathlib.Path("/sys/class/hwmon/hwmon0/temp1_input")
name = pathlib.Path("/sys/class/hwmon/hwmon0/name")
temp = None
if not sensor.exists() or not name.exists() or name.read_text().strip() != "k10temp":
    failures.append("approved k10temp sensor missing")
else:
    temp = int(sensor.read_text().strip())
    if temp >= 68000:
        failures.append(f"temperature veto {temp}")
pmu = subprocess.run(["./relation_spatial_pmu_preflight", "--disabled-group-preflight", "4"], text=True, capture_output=True)
receipt = {"schema": "FAMILY10H_RELATION_COMPOSITION_REPLAY_EXCLUSION_PREFLIGHT_V1", "passed": not failures and pmu.returncode == 0, "failures": failures, "target_identity": "AuthenticAMD family16 model10 cpus4-5", "sensor": {"hwmon": "hwmon0", "name": name.read_text().strip() if name.exists() else None, "temp1_input": temp}, "pmu_preflight": {"returncode": pmu.returncode, "stdout": pmu.stdout, "stderr": pmu.stderr}, "small_wall_crossed": False}
pathlib.Path("discovery_logs/preflight.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
sys.exit(0 if receipt["passed"] else 1)
PY
}
prepare_cpufreq
prep_rc=$?
printf '%s\n' "$prep_rc" > discovery_logs/cpufreq_prepare.rc
trap 'restore_cpufreq; printf "%s\n" "$?" > discovery_logs/cpufreq_restore.rc' EXIT
if [ "$prep_rc" -ne 0 ]; then
  exit 22
fi
preflight
preflight_rc=$?
printf '%s\n' "$preflight_rc" > discovery_logs/preflight.rc
if [ "$preflight_rc" -ne 0 ]; then
  exit 23
fi
printf '%s\n' "$(date -u +%FT%TZ)" > ATTEMPT_CONSUMED
overall=0
for variant in adjacent_r0r1_primary adjacent_r0r1_sham adjacent_r1r0_primary adjacent_r1r0_sham dead_adjacent_r0r1_primary dead_adjacent_r0r1_sham dead_adjacent_r1r0_primary dead_adjacent_r1r0_sham source_off_adjacent_r0r1_primary source_off_adjacent_r0r1_sham source_off_adjacent_r1r0_primary source_off_adjacent_r1r0_sham gapped_r0r1_primary gapped_r0r1_sham gapped_r1r0_primary gapped_r1r0_sham balanced_alt_a_primary balanced_alt_a_sham balanced_alt_b_primary balanced_alt_b_sham; do
  out="$SOURCE_ROOT/discovery_outputs/$variant"
  schedule="$SOURCE_ROOT/COMPOSITION_REPLAY_EXCLUSION_SCHEDULES/$variant.tsv"
  if [ -e "$out" ]; then
    echo 97 > "discovery_logs/$variant.rc"
    overall=97
    continue
  fi
  FAMILY10H_RELATION_SPATIAL_RUNTIME_AUTHORITY="family10h_relation_spatial_pair_readout_v1_0" \
    chrt -f 80 "$SOURCE_ROOT/relation_spatial_runtime" --execute-schedule "$schedule" "$out" \
    > "discovery_logs/$variant.stdout" 2> "discovery_logs/$variant.stderr"
  rc=$?
  echo "$rc" > "discovery_logs/$variant.rc"
  {
    echo "raw_records=$(test -f "$out/raw_records.jsonl" && wc -l < "$out/raw_records.jsonl" || echo 0)"
    echo "pair_observations=$(test -f "$out/pair_observations.jsonl" && wc -l < "$out/pair_observations.jsonl" || echo 0)"
    echo "source_death_receipts=$(test -f "$out/source_death_receipts.jsonl" && wc -l < "$out/source_death_receipts.jsonl" || echo 0)"
  } > "discovery_logs/$variant.counts"
  if [ "$rc" -ne 0 ]; then
    overall=$rc
  fi
done
python3 - <<'PY'
import hashlib, json, pathlib
root = pathlib.Path(".")
variants = ["adjacent_r0r1_primary", "adjacent_r0r1_sham", "adjacent_r1r0_primary", "adjacent_r1r0_sham", "dead_adjacent_r0r1_primary", "dead_adjacent_r0r1_sham", "dead_adjacent_r1r0_primary", "dead_adjacent_r1r0_sham", "source_off_adjacent_r0r1_primary", "source_off_adjacent_r0r1_sham", "source_off_adjacent_r1r0_primary", "source_off_adjacent_r1r0_sham", "gapped_r0r1_primary", "gapped_r0r1_sham", "gapped_r1r0_primary", "gapped_r1r0_sham", "balanced_alt_a_primary", "balanced_alt_a_sham", "balanced_alt_b_primary", "balanced_alt_b_sham"]
def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
def lines(path):
    if not path.exists():
        return 0
    with path.open("rb") as handle:
        return sum(1 for line in handle if line.rstrip(b"\r\n"))
summary = {"schema": "FAMILY10H_RELATION_COMPOSITION_REPLAY_EXCLUSION_TARGET_SUMMARY_V1", "run_id": "family10h_relation_true_composition_replay_screen_v1_0", "attempt_consumed": (root / "ATTEMPT_CONSUMED").exists(), "variants": {}, "small_wall_crossed": False}
for variant in variants:
    out = root / "discovery_outputs" / variant
    rc_path = root / "discovery_logs" / f"{variant}.rc"
    summary["variants"][variant] = {"rc": int(rc_path.read_text().strip()) if rc_path.exists() else None, "raw_record_count": lines(out / "raw_records.jsonl"), "pair_observation_count": lines(out / "pair_observations.jsonl"), "source_death_receipt_count": lines(out / "source_death_receipts.jsonl"), "raw_sha256": sha(out / "raw_records.jsonl") if (out / "raw_records.jsonl").exists() else None, "pair_sha256": sha(out / "pair_observations.jsonl") if (out / "pair_observations.jsonl").exists() else None, "death_sha256": sha(out / "source_death_receipts.jsonl") if (out / "source_death_receipts.jsonl").exists() else None}
summary["raw_record_count_total"] = sum(v["raw_record_count"] for v in summary["variants"].values())
summary["pair_observation_count_total"] = sum(v["pair_observation_count"] for v in summary["variants"].values())
summary["source_death_receipt_count_total"] = sum(v["source_death_receipt_count"] for v in summary["variants"].values())
summary["passed"] = summary["attempt_consumed"] and all(v["rc"] == 0 for v in summary["variants"].values())
summary["summary_sha256"] = hashlib.sha256(json.dumps(summary, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
(root / "RELATION_COMPOSITION_REPLAY_EXCLUSION_TARGET_SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
PY
printf '%s\n' "$(date -u +%FT%TZ)" > DISCOVERY_TARGET_ENDED_UTC.txt
exit "$overall"
