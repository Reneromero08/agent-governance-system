#!/bin/sh
set -u
TX="/root/catcas_live_small_wall/family10h_relation_only_matched_permutation_v1_0/91a5b5709c382ed4"
SRC="$TX/source"
OUT="$SRC/_relation_only_owned_outputs/attempt_1"
ARCHIVE="$TX/../ATTEMPT_1_REMOTE_ROOT.tar.gz"
cd "$SRC"
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$TX/controller_start_utc.txt"
export FAMILY10H_RELATION_ONLY_LIVE_AUTHORITY='family10h_relation_only_matched_permutation_v1_0'
export FAMILY10H_RELATION_ONLY_SOURCE_AUTHORITY_COMMIT='6d51288bba6d2b596c6b8eaad1552ff33e848f9a'
export FAMILY10H_RELATION_ONLY_FREEZE_COMMIT='91a5b5709c382ed402ca7e4f805b7ebe5a139700'
export FAMILY10H_RELATION_ONLY_MANIFEST_SHA256='7c1ff5656703b45ad373a593d50351ef15e95baabac0880d8ad40cb8a1e49788'
export FAMILY10H_RELATION_ONLY_DEPLOYMENT_CUSTODY="$SRC/RELATION_ONLY_DEPLOYMENT_CUSTODY.json"
unset FAMILY10H_RELATION_ONLY_PREFLIGHT_FIXTURE
unset FAMILY10H_RELATION_ONLY_PREFLIGHT_SYSTEM_MOCK
unset FAMILY10H_RELATION_ONLY_EXECUTION_MODE
unset FAMILY10H_RELATION_ONLY_RUNTIME_AUTHORITY
set +e
python3 relation_only_target.py --execute-authorized --source-root "$SRC" --output-root "$OUT" > "$TX/target_wrapper_execution.json" 2> "$TX/target_wrapper_execution.stderr"
rc=$?
set -e
printf '%s\n' "$rc" > "$TX/target_wrapper_execution.rc"
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$TX/controller_end_utc.txt"
python3 - "$TX" <<'PY'
import json, pathlib, sys, time
root = pathlib.Path(sys.argv[1])
out = root / 'source' / '_relation_only_owned_outputs' / 'attempt_1'
wrapper_path = root / 'target_wrapper_execution.json'
summary = {
    'schema': 'FAMILY10H_RELATION_ONLY_CONTROLLER_PRESERVATION_RECEIPT_V1',
    'utc_unix': int(time.time()),
    'wrapper_json_present': wrapper_path.exists(),
    'wrapper_json_valid': False,
    'physical_preflight_receipt_path': None,
    'pmu_preflight_receipt_path': None,
    'raw_record_count': 0,
    'source_death_receipt_count': 0,
}
try:
    wrapper = json.loads(wrapper_path.read_text(encoding='utf-8'))
    summary['wrapper_json_valid'] = True
except Exception as exc:
    wrapper = {}
    summary['wrapper_parse_error'] = str(exc)
if isinstance(wrapper, dict):
    preflight = wrapper.get('preflight')
    if isinstance(preflight, dict):
        dest_parent = out if out.exists() else root
        dest_parent.mkdir(parents=True, exist_ok=True)
        preflight_path = dest_parent / 'physical_preflight_receipt.json'
        preflight_path.write_text(json.dumps(preflight, indent=2, sort_keys=True, allow_nan=False) + '\n', encoding='utf-8')
        summary['physical_preflight_receipt_path'] = str(preflight_path)
        pmu = preflight.get('physical_observation', {}).get('pmu')
        if isinstance(pmu, dict):
            pmu_path = dest_parent / 'pmu_preflight_receipt.json'
            pmu_path.write_text(json.dumps(pmu, indent=2, sort_keys=True, allow_nan=False) + '\n', encoding='utf-8')
            summary['pmu_preflight_receipt_path'] = str(pmu_path)
    summary['raw_record_count'] = wrapper.get('raw_record_count', 0)
    summary['source_death_receipt_count'] = wrapper.get('source_death_receipt_count', 0)
summary_path = root / 'controller_preservation_receipt.json'
summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True, allow_nan=False) + '\n', encoding='utf-8')
PY
tar -C "$TX" -czf "$ARCHIVE" .
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
stat -c '%s' "$ARCHIVE" > "$ARCHIVE.size"
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$TX/archive_end_utc.txt"
exit 0