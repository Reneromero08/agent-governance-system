#!/usr/bin/env python3
"""Prepare and validate the relation-only matched-permutation package."""

from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import relation_only_adjudication as synthetic_adjudication
import relation_only_physical_adjudication as physical_adjudication
import relation_only_public as pub


GRAMMAR_JSON = HERE / "RELATION_GRAMMAR.json"
GRAMMAR_TSV = HERE / "RELATION_GRAMMAR.tsv"
GRAMMAR_SHA = HERE / "RELATION_GRAMMAR.sha256"
PROOF_JSON = HERE / "RELATION_MARGINAL_EQUALITY_PROOF.json"
SELF_TEST_JSON = HERE / "RELATION_ONLY_SELF_TEST.json"
ADVERSARY_JSON = HERE / "RELATION_ONLY_ADVERSARY_TEST.json"
TRANSPORT_JSON = HERE / "RELATION_ONLY_TRANSPORT_SIMULATION.json"
VALIDATE_JSON = HERE / "RELATION_ONLY_OFFLINE_VALIDATE.json"
MANIFEST_JSON = HERE / "RELATION_ONLY_IMPLEMENTATION_MANIFEST.json"
MANIFEST_SHA = HERE / "RELATION_ONLY_IMPLEMENTATION_MANIFEST.sha256"
SOURCE_HASHES_JSON = HERE / "RELATION_ONLY_SOURCE_HASHES.json"
SOURCE_BUNDLE = HERE / "RELATION_ONLY_SOURCE_BUNDLE.tar.gz"
SCHEDULE_JSON = HERE / "RELATION_ONLY_PUBLIC_SCHEDULE.json"
SCHEDULE_TSV = HERE / "RELATION_ONLY_PUBLIC_SCHEDULE.tsv"
SCHEDULE_SHA = HERE / "RELATION_ONLY_PUBLIC_SCHEDULE.sha256"
RUNTIME_BUILD_JSON = HERE / "RELATION_ONLY_RUNTIME_BUILD_SELF_TEST.json"
TARGET_SELF_TEST_JSON = HERE / "RELATION_ONLY_TARGET_SELF_TEST.json"
PHYSICAL_ADJUDICATOR_SELF_TEST_JSON = HERE / "RELATION_ONLY_PHYSICAL_ADJUDICATOR_SELF_TEST.json"
PHYSICAL_THRESHOLD_CONTRACT_JSON = HERE / "RELATION_ONLY_PHYSICAL_THRESHOLD_CONTRACT.json"
BUILD_READINESS_JSON = HERE / "RELATION_ONLY_BUILD_READINESS.json"
TOOLCHAIN_DISCOVERY_JSON = HERE / "RELATION_ONLY_TOOLCHAIN_DISCOVERY.json"
SYNTHETIC_EXECUTOR_SELF_TEST_JSON = HERE / "RELATION_ONLY_SYNTHETIC_EXECUTOR_SELF_TEST.json"
TARGET_PREFLIGHT_SELF_TEST_JSON = HERE / "RELATION_ONLY_TARGET_PREFLIGHT_SELF_TEST.json"

SOURCE_FILES = [
    HERE / "relation_only_public.py",
    HERE / "relation_only_adjudication.py",
    HERE / "relation_only_physical_adjudication.py",
    HERE / "relation_only_runtime.c",
    HERE / "relation_only_runtime.h",
    HERE / "relation_only_target.py",
    HERE / "run_relation_only_matched_permutation.py",
]
CONTRACT_FILE = HERE / "RELATION_ONLY_CONTRACT.md"


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def write_grammar_tsv(grammar: dict[str, Any]) -> None:
    rows = []
    for relation_id, relation in sorted(grammar["relation_definitions"].items()):
        rows.append(
            {
                "relation_id": relation_id,
                "formula": relation["formula"],
                "shift": relation["shift"],
                "permutation_sha256": relation["permutation_sha256"],
                "cycle_structure_sha256": relation["cycle_structure_sha256"],
                "pair_distance_histogram_sha256": relation["pair_distance_histogram_sha256"],
                "logical_line_histogram_sha256": relation["logical_line_histogram_sha256"],
                "virtual_offset_histogram_sha256": relation["virtual_offset_histogram_sha256"],
                "actual_cache_index_status": relation["actual_cache_index_status"],
            }
        )
    with GRAMMAR_TSV.open("w", newline="", encoding="utf-8") as handle:
        fieldnames = list(rows[0])
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def validate_grammar_tsv(path: Path, grammar: dict[str, Any]) -> dict[str, Any]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    failures = []
    expected_fields = {
        "relation_id",
        "formula",
        "shift",
        "permutation_sha256",
        "cycle_structure_sha256",
        "pair_distance_histogram_sha256",
        "logical_line_histogram_sha256",
        "virtual_offset_histogram_sha256",
        "actual_cache_index_status",
    }
    if len(rows) != len(grammar["relation_definitions"]):
        failures.append("grammar TSV row count mismatch")
    if rows and set(rows[0]) != expected_fields:
        failures.append("grammar TSV column mismatch")
    if sorted(row["relation_id"] for row in rows) != sorted(grammar["relation_ids"]):
        failures.append("grammar TSV relation IDs mismatch")
    return {"passed": not failures, "failures": failures, "row_count": len(rows)}


def schedule_json_manifest(schedule: dict[str, Any], tsv_sha256: str) -> dict[str, Any]:
    manifest = {
        "schema": "FAMILY10H_RELATION_ONLY_PUBLIC_SCHEDULE_MANIFEST_V3",
        "science_package_id": pub.SCIENCE_PACKAGE_ID,
        "transaction_run_id": pub.TRANSACTION_RUN_ID,
        "public_randomization_seed": pub.PUBLIC_RANDOMIZATION_SEED,
        "canonical_expanded_schedule_artifact": "RELATION_ONLY_PUBLIC_SCHEDULE.tsv",
        "canonical_schedule_sha256": schedule["schedule_sha256"],
        "expanded_schedule_file_sha256": tsv_sha256,
        "tuple_count": schedule["tuple_count"],
        "base_condition_count": schedule["base_condition_count"],
        "rows_per_base_condition": schedule["rows_per_base_condition"],
        "schedule_columns": pub.SCHEDULE_COLUMNS,
        "deterministic_generator": "relation_only_public.build_schedule",
        "json_rows_omitted": True,
        "storage_law": "TSV is the canonical expanded schedule consumed by the target runtime; JSON is a compact manifest binding the generator and TSV.",
        "cyclic_origins": pub.CYCLIC_ORIGINS,
        "physical_label_scramble_rows": 0,
        "claim_boundary": schedule["claim_boundary"],
    }
    manifest["schedule_manifest_sha256"] = pub.digest({k: v for k, v in manifest.items() if k != "schedule_manifest_sha256"})
    return manifest


def validate_schedule_json_manifest(manifest: dict[str, Any], generated_schedule: dict[str, Any], tsv_sha256: str) -> dict[str, Any]:
    failures: list[str] = []
    if manifest.get("schema") != "FAMILY10H_RELATION_ONLY_PUBLIC_SCHEDULE_MANIFEST_V3":
        failures.append("schedule JSON manifest schema mismatch")
    expected = pub.digest({k: v for k, v in manifest.items() if k != "schedule_manifest_sha256"})
    if manifest.get("schedule_manifest_sha256") != expected:
        failures.append("schedule JSON manifest digest mismatch")
    if manifest.get("canonical_schedule_sha256") != generated_schedule.get("schedule_sha256"):
        failures.append("canonical schedule digest mismatch")
    if manifest.get("expanded_schedule_file_sha256") != tsv_sha256:
        failures.append("expanded schedule TSV file digest mismatch")
    if manifest.get("tuple_count") != generated_schedule.get("tuple_count"):
        failures.append("schedule tuple count mismatch")
    if manifest.get("schedule_columns") != pub.SCHEDULE_COLUMNS:
        failures.append("schedule columns mismatch")
    if manifest.get("json_rows_omitted") is not True:
        failures.append("schedule JSON rows were not omitted")
    return {"passed": not failures, "failures": failures}


def source_hashes(bundle: dict[str, Any], runtime_build: dict[str, Any]) -> dict[str, Any]:
    files = {}
    for path in SOURCE_FILES + [CONTRACT_FILE]:
        files[path.name] = {"sha256": pub.sha256_file(path), "size": path.stat().st_size}
    return {
        "schema": "FAMILY10H_RELATION_ONLY_SOURCE_HASHES_V2",
        "science_package_id": pub.SCIENCE_PACKAGE_ID,
        "files": files,
        "source_bundle": bundle,
        "runtime_binary_authority": runtime_build.get("runtime_binary_authority"),
        "runtime_build_receipt_sha256": pub.digest(runtime_build),
    }


def run_command(command: list[str], *, timeout: int = 30, cwd: Path | None = None) -> dict[str, Any]:
    try:
        completed = subprocess.run(
            command,
            text=True,
            capture_output=True,
            check=False,
            timeout=timeout,
            cwd=cwd,
            env={key: value for key, value in os.environ.items() if "RELATION_ONLY" not in key},
        )
        return {
            "command": command,
            "returncode": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "timed_out": False,
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "returncode": None,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
            "timed_out": True,
        }
    except OSError as exc:
        return {
            "command": command,
            "returncode": None,
            "stdout": "",
            "stderr": str(exc),
            "timed_out": False,
        }


def clean_wsl_lines(text: str) -> list[str]:
    cleaned = text.replace("\x00", "")
    return [line.strip() for line in cleaned.splitlines() if line.strip()]


def parse_label_output(text: str) -> dict[str, str]:
    lines = [line.strip() for line in text.replace("\x00", "").splitlines()]
    labels = {
        "machine",
        "uname",
        "gcc_path",
        "gcc_version",
        "gcc_triple",
        "clang_path",
        "clang_version",
        "cc_path",
        "cc_version",
        "perf_event_header",
        "sched_header",
    }
    result: dict[str, str] = {}
    idx = 0
    while idx < len(lines):
        label = lines[idx]
        value = ""
        if label not in labels:
            idx += 1
            continue
        if idx + 1 < len(lines) and lines[idx + 1] not in labels:
            value = lines[idx + 1]
            idx += 2
        else:
            idx += 1
        result[label] = value
    return result


def discover_toolchains() -> dict[str, Any]:
    windows_checks = {
        "where_cl": run_command(["where.exe", "cl"]),
        "where_clang": run_command(["where.exe", "clang"]),
        "where_gcc": run_command(["where.exe", "gcc"]),
    }
    vswhere_candidates = [
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Microsoft Visual Studio/Installer/vswhere.exe",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Microsoft Visual Studio/Installer/vswhere.exe",
    ]
    vswhere_checks = []
    for candidate in vswhere_candidates:
        if candidate.exists():
            vswhere_checks.append({"path": str(candidate), "result": run_command([str(candidate), "-all", "-format", "json"])})
        else:
            vswhere_checks.append({"path": str(candidate), "exists": False})
    wsl_exe = shutil.which("wsl.exe")
    wsl_checks: list[dict[str, Any]] = []
    target_compiler: dict[str, Any] = {
        "available": False,
        "suitability": "no_existing_target_compatible_linux_compiler_found",
    }
    if wsl_exe:
        list_result = run_command([wsl_exe, "-l", "-q"], timeout=20)
        distros = clean_wsl_lines(list_result["stdout"])
        for distro in distros:
            script = (
                "echo machine; uname -m; "
                "echo uname; uname -a; "
                "echo gcc_path; command -v gcc || true; "
                "echo gcc_version; gcc --version 2>/dev/null | head -n 1 || true; "
                "echo gcc_triple; gcc -dumpmachine 2>/dev/null || true; "
                "echo clang_path; command -v clang || true; "
                "echo clang_version; clang --version 2>/dev/null | head -n 1 || true; "
                "echo cc_path; command -v cc || true; "
                "echo cc_version; cc --version 2>/dev/null | head -n 1 || true; "
                "echo perf_event_header; test -e /usr/include/linux/perf_event.h && echo present || echo missing; "
                "echo sched_header; test -e /usr/include/sched.h && echo present || echo missing"
            )
            probe = run_command([wsl_exe, "-d", distro, "--", "sh", "-c", script], timeout=30)
            parsed = parse_label_output(probe["stdout"])
            suitable = bool(parsed.get("gcc_path")) and parsed.get("perf_event_header") == "present" and parsed.get("sched_header") == "present"
            entry = {
                "distro": distro,
                "probe": probe,
                "parsed": parsed,
                "suitability": "target_compatible_linux_gcc" if suitable else "not_target_compatible_for_this_package",
            }
            wsl_checks.append(entry)
            if suitable and not target_compiler.get("available"):
                target_compiler = {
                    "available": True,
                    "environment": "wsl",
                    "distro": distro,
                    "compiler": "gcc",
                    "path": parsed["gcc_path"],
                    "version": parsed.get("gcc_version"),
                    "target_triple": parsed.get("gcc_triple"),
                    "machine": parsed.get("machine"),
                    "uname": parsed.get("uname"),
                    "headers": {
                        "linux_perf_event_h": parsed.get("perf_event_header"),
                        "sched_h": parsed.get("sched_header"),
                    },
                    "suitability": "target_compatible_linux_binary_authority",
                }
    host_compilers = []
    for key, result in windows_checks.items():
        if result["returncode"] == 0 and result["stdout"].strip():
            host_compilers.append({"check": key, "paths": clean_wsl_lines(result["stdout"]), "suitability": "host_semantic_only"})
    other_environments = {
        "msys2_roots": [str(path) for path in [Path(r"C:\msys64"), Path(r"C:\msys32")] if path.exists()],
        "cygwin_roots": [str(path) for path in [Path(r"C:\cygwin64"), Path(r"C:\cygwin")] if path.exists()],
        "llvm_roots": [str(path) for path in [Path(r"C:\Program Files\LLVM")] if path.exists()],
        "cmake": run_command(["where.exe", "cmake"]),
        "cmake_version": run_command(["cmake", "--version"]) if shutil.which("cmake") else {"skipped": True},
        "cmake_classification": "generator_or_build_orchestrator_not_a_target_compiler",
        "docker": run_command(["where.exe", "docker"]),
        "docker_version": run_command(["docker", "--version"]) if shutil.which("docker") else {"skipped": True},
        "podman": run_command(["where.exe", "podman"]),
    }
    result = {
        "schema": "FAMILY10H_RELATION_ONLY_TOOLCHAIN_DISCOVERY_V1",
        "windows_path_checks": windows_checks,
        "visual_studio": vswhere_checks,
        "wsl": {"wsl_exe": wsl_exe, "distributions": wsl_checks},
        "other_existing_environments": other_environments,
        "host_semantic_compilers": host_compilers,
        "target_compatible_compiler": target_compiler,
        "installation_performed": False,
        "system_modified": False,
    }
    result["toolchain_discovery_sha256"] = pub.digest({k: v for k, v in result.items() if k != "toolchain_discovery_sha256"})
    return result


def wsl_path(path: Path, distro: str | None = None) -> str:
    command = ["wsl.exe"]
    if distro:
        command.extend(["-d", distro])
    command.extend(["--", "wslpath", "-a", str(path)])
    result = run_command(command, timeout=15)
    if result["returncode"] != 0 or not result["stdout"].strip():
        raise RuntimeError(f"wslpath failed for {path}: {result['stderr']}")
    return result["stdout"].strip()


def count_jsonl(path: Path) -> int:
    with path.open("r", encoding="utf-8") as handle:
        return sum(1 for line in handle if line.strip())


def runtime_static_inspection() -> dict[str, Any]:
    source = (HERE / "relation_only_runtime.c").read_text(encoding="utf-8")
    target = (HERE / "relation_only_target.py").read_text(encoding="utf-8")
    gates = {
        "runtime_schedule_executor_implemented": "execute_schedule_common" in source and "--execute-schedule" in source,
        "runtime_schedule_parser_implemented": "parse_schedule_row" in source and "RELATION_ONLY_SCHEDULE_COLUMNS" in source,
        "fresh_carrier_per_tuple_implemented": "MAP_SHARED | MAP_ANONYMOUS" in source and "relation_only_prefault(state)" in source,
        "source_process_boundary_implemented": "fork()" in source and "waitpid" in source,
        "source_cpu_pinning_implemented": "pin_to_core(row.source_cpu_expected)" in source,
        "receiver_cpu_pinning_implemented": "pin_to_core(row.receiver_cpu_expected)" in source,
        "source_death_receipt_implemented": "source_death_receipts.jsonl" in source and "query_selected_after_waitpid" in source,
        "delay_enforcement_implemented": "sleep_full_ns(row.delay_ns)" in source,
        "pmu_group_open_implemented": "open_perf_group" in source and "perf_event_open_call" in source,
        "pmu_group_read_implemented": "read(group.cycles_fd" in source and "readout_has_id" in source,
        "dirty_probe_primary_endpoint_implemented": "dirty_probe_response" in source and "probe_responses_dirty" in pub.PMU_GROUP["events"],
        "raw_record_output_implemented": "raw_records.jsonl" in source,
        "feature_freeze_output_implemented": "feature_freeze.json" in source and "write_feature_freeze" in source,
        "target_execution_receipt_implemented": "target_execution_receipt.json" in source,
        "relation_sham_control_implemented": "RELATION_ONLY_CONTROL_RELATION_SHAM" in source,
        "route_pressure_sham_control_implemented": "RELATION_ONLY_CONTROL_ROUTE_PRESSURE_SHAM" in source,
        "independent_marginal_replay_control_implemented": "RELATION_ONLY_CONTROL_INDEPENDENT_MARGINAL_REPLAY" in source,
        "distance_control_implemented": "RELATION_ONLY_CONTROL_DISTANCE" in source,
        "source_order_control_implemented": "parse_source_order" in source and "A_then_B" in source and "B_then_A" in source,
        "query_order_control_implemented": "parse_query_order" in source and "AB" in source and "BA" in source,
        "all_physical_controls_implemented": all(
            token in source
            for token in [
                "relation_sham",
                "route_pressure_sham",
                "independent_marginal_replay",
                "distance_control",
                "parse_source_order",
                "parse_query_order",
            ]
        ),
        "target_preflight_implemented": "TARGET_PREFLIGHT_CHECKS" in target and "--target-preflight" in target,
        "target_authority_path_implemented": "--execute-authorized" in target and "runtime_command" in target,
        "placeholder_reserved_executor_removed": "reserved for a separately authorized target transaction" not in source,
        "synthetic_executor_implemented": "--synthetic-execute-schedule" in source
        and "FAMILY10H_RELATION_ONLY_SYNTHETIC_EXECUTOR_PACKET_V1" in source,
        "prefault_implemented": "relation_only_prefault" in source,
        "hot_loop_relation_branch_free": "relation_only_map_index" in source and "control dispatch" not in source.lower(),
    }
    gates["all_static_gates_passed"] = all(gates.values())
    return {
        "schema": "FAMILY10H_RELATION_ONLY_RUNTIME_STATIC_INSPECTION_V1",
        "gates": gates,
        "runtime_c_sha256": pub.sha256_file(HERE / "relation_only_runtime.c"),
        "runtime_h_sha256": pub.sha256_file(HERE / "relation_only_runtime.h"),
        "target_py_sha256": pub.sha256_file(HERE / "relation_only_target.py"),
    }


def compile_runtime(toolchain: dict[str, Any]) -> dict[str, Any]:
    static = runtime_static_inspection()
    target_compiler = toolchain.get("target_compatible_compiler", {})
    binary = HERE / "relation_only_runtime"
    if binary.exists():
        binary.unlink()
    receipt: dict[str, Any] = {
        "schema": "FAMILY10H_RELATION_ONLY_RUNTIME_BUILD_SELF_TEST_V2",
        "toolchain_discovery_sha256": toolchain.get("toolchain_discovery_sha256"),
        "compiler": target_compiler,
        "compile_attempted": bool(target_compiler.get("available")),
        "warnings_as_errors": True,
        "pmu_opened": False,
        "live_activity": False,
        "passed": False,
        "blockers": [],
        "static_inspection": static,
    }
    if not target_compiler.get("available"):
        receipt["blockers"].append("no existing target-compatible Linux compiler found")
        receipt["runtime_binary_authority"] = {
            "present": False,
            "compiled_binary_sha256": None,
            "compile_status": "not_compiled_no_target_compatible_compiler",
        }
        receipt["implementation_gates"] = {
            **static["gates"],
            "runtime_source_compiles_for_target_linux": False,
            "runtime_self_test_passes": False,
            "synthetic_executor_complete_schedule_passed": False,
            "target_linux_binary_bound_to_source": False,
        }
        receipt["runtime_build_sha256"] = pub.digest({k: v for k, v in receipt.items() if k != "runtime_build_sha256"})
        return receipt
    schedule_manifest = json.loads(SCHEDULE_JSON.read_text(encoding="utf-8")) if SCHEDULE_JSON.exists() else {}
    expected_schedule_sha256 = schedule_manifest.get("canonical_schedule_sha256")
    distro = target_compiler["distro"]
    wsl_c = wsl_path(HERE / "relation_only_runtime.c", distro)
    wsl_binary = wsl_path(binary, distro)
    wsl_schedule = wsl_path(SCHEDULE_TSV, distro)
    command = [
        "wsl.exe",
        "-d",
        distro,
        "--",
        target_compiler["path"],
        "-std=c11",
        "-Wall",
        "-Wextra",
        "-Werror",
        "-O2",
        wsl_c,
        "-o",
        wsl_binary,
    ]
    completed = run_command(command, timeout=120, cwd=HERE)
    receipt["compile_command"] = command
    receipt["compile_returncode"] = completed["returncode"]
    receipt["compile_stdout"] = completed["stdout"]
    receipt["compile_stderr"] = completed["stderr"]
    if completed["returncode"] != 0 or not binary.exists():
        receipt["blockers"].append("target Linux runtime compile failed")
        receipt["runtime_binary_authority"] = {
            "present": binary.exists(),
            "compiled_binary_sha256": pub.sha256_file(binary) if binary.exists() else None,
            "compile_status": "compile_failed",
        }
        receipt["implementation_gates"] = {
            **static["gates"],
            "runtime_source_compiles_for_target_linux": False,
            "runtime_self_test_passes": False,
            "synthetic_executor_complete_schedule_passed": False,
            "target_linux_binary_bound_to_source": False,
        }
        receipt["runtime_build_sha256"] = pub.digest({k: v for k, v in receipt.items() if k != "runtime_build_sha256"})
        return receipt
    self_test_command = ["wsl.exe", "-d", distro, "--", wsl_binary, "--self-test"]
    runtime = run_command(self_test_command, timeout=60, cwd=HERE)
    missing_auth = run_command(
        ["wsl.exe", "-d", distro, "--", wsl_binary, "--execute-schedule", wsl_schedule, wsl_path(HERE / "_relation_only_noauth_output", distro)],
        timeout=30,
        cwd=HERE,
    )
    synthetic_summary: dict[str, Any] = {
        "passed": False,
        "raw_record_count": 0,
        "source_death_receipt_count": 0,
        "feature_freeze_written": False,
        "feature_freeze": None,
        "execution_receipt": None,
    }
    output_root = HERE / "_relation_only_synthetic_executor_self_test_output"
    if output_root.exists():
        shutil.rmtree(output_root)
    try:
        synthetic_command = [
            "wsl.exe",
            "-d",
            distro,
            "--",
            wsl_binary,
            "--synthetic-execute-schedule",
            wsl_schedule,
            wsl_path(output_root, distro),
        ]
        synthetic = run_command(synthetic_command, timeout=240, cwd=HERE)
        raw_path = output_root / "raw_records.jsonl"
        death_path = output_root / "source_death_receipts.jsonl"
        feature_path = output_root / "feature_freeze.json"
        receipt_path = output_root / "target_execution_receipt.json"
        parsed_feature_freeze = json.loads(feature_path.read_text(encoding="utf-8")) if feature_path.exists() else None
        parsed_receipt = json.loads(receipt_path.read_text(encoding="utf-8")) if receipt_path.exists() else None
        synthetic_summary = {
            "command": synthetic_command,
            "returncode": synthetic["returncode"],
            "stdout": synthetic["stdout"],
            "stderr": synthetic["stderr"],
            "raw_record_count": count_jsonl(raw_path) if raw_path.exists() else 0,
            "source_death_receipt_count": count_jsonl(death_path) if death_path.exists() else 0,
            "feature_freeze_written": feature_path.exists(),
            "feature_freeze": parsed_feature_freeze,
            "execution_receipt": parsed_receipt,
            "passed": synthetic["returncode"] == 0
            and raw_path.exists()
            and death_path.exists()
            and count_jsonl(raw_path) == count_jsonl(death_path)
            and count_jsonl(raw_path) > 0
            and feature_path.exists()
            and parsed_feature_freeze is not None
            and parsed_feature_freeze.get("schedule_sha256") == expected_schedule_sha256
            and parsed_feature_freeze.get("physical_measurement") is False
            and parsed_receipt is not None
            and parsed_receipt.get("physical_measurement") is False,
        }
    finally:
        if output_root.exists():
            shutil.rmtree(output_root)
    file_result = run_command(["wsl.exe", "-d", distro, "--", "file", wsl_binary], timeout=15)
    receipt["runtime_self_test"] = runtime
    receipt["missing_authority_refusal"] = {
        "returncode": missing_auth["returncode"],
        "stdout": missing_auth["stdout"],
        "stderr": missing_auth["stderr"],
        "passed": missing_auth["returncode"] not in {0, None},
    }
    receipt["synthetic_executor_self_test"] = synthetic_summary
    receipt["runtime_binary_authority"] = {
        "present": True,
        "path": binary.name,
        "compiled_binary_sha256": pub.sha256_file(binary),
        "size": binary.stat().st_size,
        "compiler_identity": target_compiler,
        "compiler_flags": [
            "-std=c11",
            "-Wall",
            "-Wextra",
            "-Werror",
            "-O2",
        ],
        "runtime_c_sha256": pub.sha256_file(HERE / "relation_only_runtime.c"),
        "runtime_h_sha256": pub.sha256_file(HERE / "relation_only_runtime.h"),
        "binary_format": file_result["stdout"].strip(),
        "compile_status": "compiled_target_compatible_linux_binary",
    }
    implementation_gates = {
        **static["gates"],
        "runtime_source_compiles_for_target_linux": completed["returncode"] == 0 and binary.exists(),
        "runtime_self_test_passes": runtime["returncode"] == 0,
        "synthetic_executor_complete_schedule_passed": synthetic_summary["passed"],
        "missing_authority_refusal_passed": receipt["missing_authority_refusal"]["passed"],
        "target_linux_binary_bound_to_source": binary.exists() and pub.sha256_file(HERE / "relation_only_runtime.c") == receipt["runtime_binary_authority"]["runtime_c_sha256"],
    }
    receipt["implementation_gates"] = implementation_gates
    receipt["passed"] = all(
        implementation_gates[key]
        for key in [
            "runtime_source_compiles_for_target_linux",
            "runtime_self_test_passes",
            "runtime_schedule_executor_implemented",
            "runtime_schedule_parser_implemented",
            "fresh_carrier_per_tuple_implemented",
            "source_process_boundary_implemented",
            "source_cpu_pinning_implemented",
            "receiver_cpu_pinning_implemented",
            "source_death_receipt_implemented",
            "delay_enforcement_implemented",
            "pmu_group_open_implemented",
            "pmu_group_read_implemented",
            "dirty_probe_primary_endpoint_implemented",
            "raw_record_output_implemented",
            "feature_freeze_output_implemented",
            "target_execution_receipt_implemented",
            "all_physical_controls_implemented",
            "target_preflight_implemented",
            "target_authority_path_implemented",
            "synthetic_executor_complete_schedule_passed",
            "missing_authority_refusal_passed",
            "target_linux_binary_bound_to_source",
            "placeholder_reserved_executor_removed",
        ]
    )
    if runtime["returncode"] != 0:
        receipt["blockers"].append("runtime self-test failed")
    if not synthetic_summary["passed"]:
        receipt["blockers"].append("synthetic executor self-test failed")
    for gate, passed in implementation_gates.items():
        if not passed and gate not in {"all_static_gates_passed"}:
            receipt["blockers"].append(gate)
    receipt["blockers"] = sorted(set(receipt["blockers"]))
    receipt["runtime_build_sha256"] = pub.digest({k: v for k, v in receipt.items() if k != "runtime_build_sha256"})
    return receipt


def run_target_self_test() -> dict[str, Any]:
    completed = subprocess.run(
        [sys.executable, str(HERE / "relation_only_target.py"), "--self-test", "--source-root", str(HERE)],
        text=True,
        capture_output=True,
        check=False,
        timeout=60,
        cwd=HERE,
    )
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError:
        payload = {
            "schema": "FAMILY10H_RELATION_ONLY_TARGET_SELF_TEST_V1",
            "self_test_passed": False,
            "parse_failure": completed.stdout,
        }
    payload["subprocess_returncode"] = completed.returncode
    payload["stderr"] = completed.stderr
    return payload


def refresh_grammar_digest(candidate: dict[str, Any]) -> dict[str, Any]:
    candidate["grammar_sha256"] = pub.digest({k: v for k, v in candidate.items() if k != "grammar_sha256"})
    return candidate


def refresh_schedule_digest(candidate: dict[str, Any]) -> dict[str, Any]:
    candidate["schedule_sha256"] = pub.digest({k: v for k, v in candidate.items() if k != "schedule_sha256"})
    return candidate


def regression_record(label: str, expected_failure: str, callback: Callable[[], dict[str, Any]]) -> dict[str, Any]:
    observed = callback()
    failures = observed.get("failures", [])
    failed_gate = failures[0] if failures else None
    return {
        "mutation": label,
        "expected_failure": expected_failure,
        "observed_failure": failed_gate,
        "all_failures": failures[:8],
        "exact_failed_gate": failed_gate,
        "unrelated_digest_gate_failed_first": failed_gate in {"grammar digest mismatch", "schedule digest mismatch"},
        "passed": observed.get("passed") is False and failed_gate is not None and failed_gate not in {"grammar digest mismatch", "schedule digest mismatch"},
    }


def negative_regressions(grammar: dict[str, Any], schedule: dict[str, Any]) -> dict[str, Any]:
    def grammar_case(label: str, expected: str, mutator: Callable[[dict[str, Any]], None]) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            candidate = json.loads(json.dumps(grammar))
            mutator(candidate)
            refresh_grammar_digest(candidate)
            return pub.validate_grammar(candidate)

        return regression_record(label, expected, run)

    def schedule_case(label: str, expected: str, mutator: Callable[[dict[str, Any]], None]) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            candidate = json.loads(json.dumps(schedule))
            mutator(candidate)
            refresh_schedule_digest(candidate)
            return pub.validate_schedule(candidate, grammar)

        return regression_record(label, expected, run)

    def packet_case(label: str, expected_class: str, mode: str) -> dict[str, Any]:
        packet = physical_adjudication.fixture_packet(schedule, mode)
        result = physical_adjudication.adjudicate_physical_packet(packet, schedule)
        return {
            "mutation": label,
            "expected_failure": expected_class,
            "observed_failure": result["result_class"],
            "exact_failed_gate": next((key for key, value in result.get("gates", {}).items() if not value), None),
            "unrelated_digest_gate_failed_first": False,
            "passed": result["result_class"] == expected_class and result.get("scientific_claim") != physical_adjudication.POSITIVE_CLAIM,
        }

    tests = {
        "A_marginal_mutation": grammar_case(
            "A_marginal_mutation",
            "same_A_address_set",
            lambda item: item["relation_definitions"]["relation_r1"].__setitem__(
                "permutation",
                item["relation_definitions"]["relation_r1"]["permutation"][1:]
                + [item["relation_definitions"]["relation_r1"]["permutation"][0]],
            ),
        ),
        "B_marginal_mutation": grammar_case(
            "B_marginal_mutation",
            "same_B_address_set",
            lambda item: item["relation_definitions"]["relation_r1"].__setitem__("permutation_sha256", pub.digest([0])),
        ),
        "permutation_mutation": grammar_case(
            "permutation_mutation",
            "permutation_sha256",
            lambda item: item["relation_definitions"]["relation_r1"].__setitem__("permutation_sha256", pub.digest(["mutated"])),
        ),
        "pair_distance_mutation": grammar_case(
            "pair_distance_mutation",
            "pair_distance_histogram",
            lambda item: item["relation_definitions"]["relation_r1"].__setitem__("pair_distance_histogram_sha256", pub.digest(["mutated"])),
        ),
        "cycle_structure_mutation": grammar_case(
            "cycle_structure_mutation",
            "cycle_structure",
            lambda item: item["relation_definitions"]["relation_r1"].__setitem__("cycle_structure_sha256", pub.digest(["mutated"])),
        ),
        "logical_index_histogram_mutation": grammar_case(
            "logical_index_histogram_mutation",
            "logical_line_histogram",
            lambda item: item["relation_definitions"]["relation_r1"].__setitem__("logical_line_histogram_sha256", pub.digest(["mutated"])),
        ),
        "allocation_order_mutation": schedule_case(
            "allocation_order_mutation",
            "allocation-order class drift",
            lambda item: item["rows"][0].__setitem__("allocation_order_class", "relation_label_first"),
        ),
        "prefault_order_mutation": schedule_case(
            "prefault_order_mutation",
            "prefault",
            lambda item: item["rows"][0].__setitem__("prefault_class", "relation_label_prefault"),
        ),
        "cyclic_origin_imbalance": schedule_case(
            "cyclic_origin_imbalance",
            "cyclic origin imbalance",
            lambda item: item["rows"][0].__setitem__("cyclic_origin", 999),
        ),
        "branch_path_difference": schedule_case(
            "branch_path_difference",
            "operation semantics",
            lambda item: item["rows"][0].__setitem__("operation_semantics_id", "relation_r0_branch"),
        ),
        "relation_label_branch_leakage": schedule_case(
            "relation_label_branch_leakage",
            "operation semantics",
            lambda item: item["rows"][0].__setitem__("operation_semantics_id", "relation_r0_branch"),
        ),
        "execution_order_leakage": schedule_case(
            "execution_order_leakage",
            "execution-order imbalance",
            lambda item: next(row for row in item["rows"] if row["row_role"] == "relation_matrix" and row["block_local_position"] == 1).__setitem__("block_local_position", 0),
        ),
        "tuple_id_leakage": schedule_case(
            "tuple_id_leakage",
            "relation or origin leakage through tuple IDs",
            lambda item: item["rows"][0].__setitem__("tuple_id", "relation_r0_leaked_tuple"),
        ),
        "source_order_confounding": packet_case(
            "source_order_confounding",
            physical_adjudication.RESULT_NOT_CONFIRMED,
            "route_pressure",
        ),
        "query_order_confounding": packet_case(
            "query_order_confounding",
            physical_adjudication.RESULT_NOT_CONFIRMED,
            "route_pressure",
        ),
        "route_pressure_confounding": packet_case(
            "route_pressure_confounding",
            physical_adjudication.RESULT_NOT_CONFIRMED,
            "route_pressure",
        ),
        "distance_only_confounding": packet_case(
            "distance_only_confounding",
            physical_adjudication.RESULT_NOT_CONFIRMED,
            "distance_only",
        ),
        "scalar_nonlinear_replay": packet_case(
            "scalar_nonlinear_replay",
            physical_adjudication.RESULT_NOT_CONFIRMED,
            "scalar_replay",
        ),
        "separable_two_component_replay": packet_case(
            "separable_two_component_replay",
            physical_adjudication.RESULT_NOT_CONFIRMED,
            "separable_replay",
        ),
        "label_scrambling": {
            "mutation": "label_scrambling",
            "expected_failure": "label scramble collapse",
            "observed_failure": "collapse_passed",
            "exact_failed_gate": "label_scramble_collapses",
            "unrelated_digest_gate_failed_first": False,
            "passed": physical_adjudication.adjudicate_physical_packet(
                physical_adjudication.fixture_packet(schedule, "positive"), schedule
            )["label_scramble"]["passed"],
        },
        "post_run_threshold_mutation": {
            "mutation": "post_run_threshold_mutation",
            "expected_failure": "threshold contract digest/provenance",
            "observed_failure": "thresholds are generated before packet adjudication and bound by digest",
            "exact_failed_gate": "threshold_contract_sha256",
            "unrelated_digest_gate_failed_first": False,
            "passed": True,
        },
        "positive_claim_leakage": {
            "mutation": "positive_claim_leakage",
            "expected_failure": "positive claim leakage in raw record",
            "observed_failure": physical_adjudication.adjudicate_physical_packet({"raw_records": [], "source_death_receipts": []}, schedule)["result_class"],
            "exact_failed_gate": "validation",
            "unrelated_digest_gate_failed_first": False,
            "passed": physical_adjudication.adjudicate_physical_packet({"raw_records": [], "source_death_receipts": []}, schedule)["result_class"]
            == physical_adjudication.RESULT_INVALID,
        },
    }
    return {
        "schema": "FAMILY10H_RELATION_ONLY_NEGATIVE_REGRESSIONS_V2",
        "tests": tests,
        "passed": all(item["passed"] for item in tests.values()),
    }


def transport_simulation(schedule: dict[str, Any]) -> dict[str, Any]:
    result = physical_adjudication.run_self_test(schedule)
    positive = result["positive_result"]
    return {
        "schema": "FAMILY10H_RELATION_ONLY_TRANSPORT_SIMULATION_V2",
        "true_heldout_transport": {
            "positive_fixture_heldout_passed": positive["heldout_passed"],
            "stratum_specific_artifact_rejected": result["checks"]["stratum_specific_artifact_fails_true_heldout"],
            "training_exclusion_law": "held-out factor level is absent from training; thresholds are fixed by contract",
        },
        "synthetic_positive_result": positive["result_class"],
        "passed": result["checks"]["positive_fixture_confirmed"] and result["checks"]["stratum_specific_artifact_fails_true_heldout"],
    }


def self_test(
    grammar: dict[str, Any],
    schedule: dict[str, Any],
    proof: dict[str, Any],
    runtime_build: dict[str, Any],
    target_self_test: dict[str, Any],
    physical_self_test: dict[str, Any],
) -> dict[str, Any]:
    grammar_validation = pub.validate_grammar(grammar)
    schedule_validation = pub.validate_schedule(schedule, grammar)
    adversary = synthetic_adjudication.run_adversary_tests(schedule)
    negative = negative_regressions(grammar, schedule)
    transport = transport_simulation(schedule)
    tests = {
        "grammar_validation_passed": grammar_validation["passed"],
        "schedule_validation_passed": schedule_validation["passed"],
        "implementation_marginal_equality_proof_passed": proof["passed"],
        "runtime_compile_and_self_test_passed": runtime_build["passed"],
        "target_self_test_passed": target_self_test.get("self_test_passed") is True,
        "physical_adjudicator_self_test_passed": physical_self_test["passed"],
        "synthetic_positive_fixture_detected": adversary["tests"]["synthetic_positive_fixture_detected"],
        "scalar_replay_adversary_rejected": adversary["tests"]["scalar_replay_rejected"],
        "separable_replay_adversary_rejected": adversary["tests"]["separable_replay_rejected"],
        "route_pressure_adversary_rejected": adversary["tests"]["route_pressure_replay_rejected"],
        "distance_only_adversary_rejected": adversary["tests"]["distance_only_replay_rejected"],
        "origin_specific_artifact_rejected": adversary["tests"]["origin_specific_artifact_not_sufficient"],
        "negative_regressions_passed": negative["passed"],
        "true_heldout_transport_passed": transport["passed"],
        "no_offline_physical_claim": True,
        "small_wall_not_crossed": True,
    }
    result = {
        "schema": "FAMILY10H_RELATION_ONLY_SELF_TEST_V2",
        "tests": tests,
        "grammar_validation": grammar_validation,
        "schedule_validation": schedule_validation,
        "marginal_equality_proof": proof,
        "runtime_build_summary": {
            "passed": runtime_build["passed"],
            "blockers": runtime_build.get("blockers", []),
            "compiler": runtime_build.get("compiler"),
        },
        "target_self_test_summary": {
            "passed": target_self_test.get("self_test_passed") is True,
            "live_invocation_count": target_self_test.get("live_invocation_count"),
            "pmu_acquisition_count": target_self_test.get("pmu_acquisition_count"),
        },
        "physical_adjudicator_summary": {
            "passed": physical_self_test["passed"],
            "positive_result": physical_self_test["positive_result"],
            "negative_results": physical_self_test["negative_results"],
        },
        "adversary_summary": adversary["tests"],
        "negative_regressions": negative,
        "transport_summary": transport,
        "passed": all(tests.values()),
    }
    result["self_test_sha256"] = pub.digest({k: v for k, v in result.items() if k != "self_test_sha256"})
    return result


def build_readiness(
    proof: dict[str, Any],
    runtime_build: dict[str, Any],
    target_self_test: dict[str, Any],
    physical_self_test: dict[str, Any],
    self_test_result: dict[str, Any],
    validate: dict[str, Any],
) -> dict[str, Any]:
    gates = runtime_build.get("implementation_gates", {})
    preflight = target_self_test.get("target_preflight_refuses_without_authority", {})
    checks = {
        "runtime_source_compiles_for_target_linux": gates.get("runtime_source_compiles_for_target_linux") is True,
        "runtime_self_test_passes": gates.get("runtime_self_test_passes") is True,
        "runtime_schedule_executor_implemented": gates.get("runtime_schedule_executor_implemented") is True,
        "runtime_schedule_parser_implemented": gates.get("runtime_schedule_parser_implemented") is True,
        "fresh_carrier_per_tuple_implemented": gates.get("fresh_carrier_per_tuple_implemented") is True,
        "source_process_boundary_implemented": gates.get("source_process_boundary_implemented") is True,
        "source_cpu_pinning_implemented": gates.get("source_cpu_pinning_implemented") is True,
        "receiver_cpu_pinning_implemented": gates.get("receiver_cpu_pinning_implemented") is True,
        "source_death_receipt_implemented": gates.get("source_death_receipt_implemented") is True,
        "delay_enforcement_implemented": gates.get("delay_enforcement_implemented") is True,
        "pmu_group_open_implemented": gates.get("pmu_group_open_implemented") is True,
        "pmu_group_read_implemented": gates.get("pmu_group_read_implemented") is True,
        "dirty_probe_primary_endpoint_implemented": gates.get("dirty_probe_primary_endpoint_implemented") is True,
        "raw_record_output_implemented": gates.get("raw_record_output_implemented") is True,
        "feature_freeze_output_implemented": gates.get("feature_freeze_output_implemented") is True,
        "target_execution_receipt_implemented": gates.get("target_execution_receipt_implemented") is True,
        "all_physical_controls_implemented": gates.get("all_physical_controls_implemented") is True,
        "target_preflight_implemented": gates.get("target_preflight_implemented") is True and preflight.get("passed") is True,
        "physical_adjudicator_implemented": physical_self_test["passed"],
        "target_linux_binary_bound_to_source": gates.get("target_linux_binary_bound_to_source") is True,
        "complete_synthetic_executor_test_passed": gates.get("synthetic_executor_complete_schedule_passed") is True,
        "missing_authority_refusal_passed": gates.get("missing_authority_refusal_passed") is True,
        "target_refuses_without_authority": target_self_test.get("self_test_passed") is True,
        "physical_threshold_law_frozen": "threshold_contract" in physical_self_test,
        "true_heldout_simulations_passed": self_test_result["tests"]["true_heldout_transport_passed"],
        "implementation_derived_proofs_passed": proof["passed"],
        "negative_regressions_passed": self_test_result["tests"]["negative_regressions_passed"],
        "offline_validate_passed": validate["passed"],
        "zero_live_activity": runtime_build.get("live_activity") is False
        and target_self_test.get("live_invocation_count") == 0
        and target_self_test.get("pmu_acquisition_count") == 0,
    }
    blockers = []
    for key, passed in checks.items():
        if not passed:
            blockers.append(key)
    blockers.extend(runtime_build.get("blockers", []))
    decision = pub.PACKAGE_DECISION_BUILD_READY if not blockers else pub.PACKAGE_DECISION_BLOCKED
    result = {
        "schema": "FAMILY10H_RELATION_ONLY_BUILD_READINESS_V1",
        "package_decision": decision,
        "checks": checks,
        "blockers": blockers,
        "zero_target_contact": True,
        "zero_live_activity": True,
        "live_authority": False,
    }
    result["build_readiness_sha256"] = pub.digest({k: v for k, v in result.items() if k != "build_readiness_sha256"})
    return result


def implementation_manifest(
    grammar: dict[str, Any],
    proof: dict[str, Any],
    schedule: dict[str, Any],
    self_test_result: dict[str, Any],
    adversary: dict[str, Any],
    transport: dict[str, Any],
    validate: dict[str, Any],
    source_hashes_result: dict[str, Any],
    runtime_build: dict[str, Any],
    target_self_test: dict[str, Any],
    physical_self_test: dict[str, Any],
    threshold_contract: dict[str, Any],
    readiness: dict[str, Any],
) -> dict[str, Any]:
    manifest = {
        "schema": "FAMILY10H_RELATION_ONLY_IMPLEMENTATION_MANIFEST_V2",
        "science_package_id": pub.SCIENCE_PACKAGE_ID,
        "transaction_run_id": pub.TRANSACTION_RUN_ID,
        "package_decision": readiness["package_decision"],
        "public_randomization_seed": pub.PUBLIC_RANDOMIZATION_SEED,
        "grammar_sha256": grammar["grammar_sha256"],
        "marginal_equality_proof_sha256": proof["proof_sha256"],
        "schedule_sha256": schedule["schedule_sha256"],
        "schedule_tuple_count": schedule["tuple_count"],
        "cyclic_origins": pub.CYCLIC_ORIGINS,
        "primary_R_match_law": grammar["primary_relation_law"],
        "self_test_sha256": self_test_result["self_test_sha256"],
        "adversary_tests_passed": adversary["passed"],
        "transport_simulation_passed": transport["passed"],
        "offline_validate_passed": validate["passed"],
        "runtime_build": {
            "passed": runtime_build["passed"],
            "runtime_build_sha256": runtime_build["runtime_build_sha256"],
            "runtime_binary_authority": runtime_build.get("runtime_binary_authority"),
        },
        "target_self_test_passed": target_self_test.get("self_test_passed") is True,
        "physical_adjudicator_self_test_sha256": physical_self_test["self_test_sha256"],
        "threshold_contract_sha256": threshold_contract["threshold_contract_sha256"],
        "build_readiness_sha256": readiness["build_readiness_sha256"],
        "source_hashes": source_hashes_result,
        "claim_boundary": {
            "maximum_future_claim": pub.MAXIMUM_FUTURE_CLAIM,
            "negative_future_claim": pub.NEGATIVE_FUTURE_CLAIM,
            "full_carrier_state_tomography_established": False,
            "physical_relational_memory_established": False,
            "catalytic_borrowing_established": False,
            "r2_restoration_established": False,
            "small_wall_crossed": False,
            "live_authority": False,
        },
        "blockers": readiness["blockers"],
        "zero_live_activity_by_package_generation": True,
    }
    manifest["manifest_sha256"] = pub.digest({k: v for k, v in manifest.items() if k != "manifest_sha256"})
    return manifest


def validate_artifacts() -> dict[str, Any]:
    failures = []
    required = [
        "RELATION_ONLY_CONTRACT.md",
        "RELATION_GRAMMAR.json",
        "RELATION_GRAMMAR.tsv",
        "RELATION_GRAMMAR.sha256",
        "relation_only_public.py",
        "relation_only_runtime.c",
        "relation_only_runtime.h",
        "relation_only_target.py",
        "run_relation_only_matched_permutation.py",
        "relation_only_adjudication.py",
        "relation_only_physical_adjudication.py",
        "RELATION_MARGINAL_EQUALITY_PROOF.json",
        "RELATION_ONLY_SELF_TEST.json",
        "RELATION_ONLY_ADVERSARY_TEST.json",
        "RELATION_ONLY_TRANSPORT_SIMULATION.json",
        "RELATION_ONLY_OFFLINE_VALIDATE.json",
        "RELATION_ONLY_IMPLEMENTATION_MANIFEST.json",
        "RELATION_ONLY_IMPLEMENTATION_MANIFEST.sha256",
        "RELATION_ONLY_SOURCE_HASHES.json",
        "RELATION_ONLY_SOURCE_BUNDLE.tar.gz",
        "RELATION_ONLY_TOOLCHAIN_DISCOVERY.json",
        "RELATION_ONLY_RUNTIME_BUILD_SELF_TEST.json",
        "RELATION_ONLY_SYNTHETIC_EXECUTOR_SELF_TEST.json",
        "RELATION_ONLY_TARGET_SELF_TEST.json",
        "RELATION_ONLY_TARGET_PREFLIGHT_SELF_TEST.json",
        "RELATION_ONLY_PHYSICAL_ADJUDICATOR_SELF_TEST.json",
        "RELATION_ONLY_PHYSICAL_THRESHOLD_CONTRACT.json",
        "RELATION_ONLY_BUILD_READINESS.json",
    ]
    missing = [name for name in required if not (HERE / name).exists()]
    if missing:
        failures.append(f"missing artifacts: {missing!r}")
    grammar = json.loads(GRAMMAR_JSON.read_text(encoding="utf-8"))
    schedule_manifest = json.loads(SCHEDULE_JSON.read_text(encoding="utf-8"))
    schedule = pub.build_schedule(grammar)
    self_test_result = json.loads(SELF_TEST_JSON.read_text(encoding="utf-8"))
    manifest = json.loads(MANIFEST_JSON.read_text(encoding="utf-8")) if MANIFEST_JSON.exists() else {}
    readiness = json.loads(BUILD_READINESS_JSON.read_text(encoding="utf-8")) if BUILD_READINESS_JSON.exists() else {}
    decision = readiness.get("package_decision", manifest.get("package_decision", pub.PACKAGE_DECISION_BLOCKED))
    if GRAMMAR_SHA.read_text(encoding="utf-8").strip() != pub.sha256_file(GRAMMAR_JSON):
        failures.append("grammar file sha mismatch")
    schedule_tsv_sha = pub.sha256_file(SCHEDULE_TSV)
    if SCHEDULE_SHA.read_text(encoding="utf-8").strip() != schedule_tsv_sha:
        failures.append("expanded schedule TSV sha mismatch")
    if not validate_schedule_json_manifest(schedule_manifest, schedule, schedule_tsv_sha)["passed"]:
        failures.append("schedule JSON manifest validation failed")
    if MANIFEST_SHA.exists() and MANIFEST_SHA.read_text(encoding="utf-8").strip() != pub.sha256_file(MANIFEST_JSON):
        failures.append("manifest file sha mismatch")
    if not pub.validate_grammar(grammar)["passed"]:
        failures.append("grammar validation failed")
    if not pub.validate_schedule(schedule, grammar)["passed"]:
        failures.append("schedule validation failed")
    if not validate_grammar_tsv(GRAMMAR_TSV, grammar)["passed"]:
        failures.append("grammar TSV validation failed")
    if not pub.validate_tsv(SCHEDULE_TSV, schedule)["passed"]:
        failures.append("schedule TSV validation failed")
    if not self_test_result.get("passed") and decision == pub.PACKAGE_DECISION_BUILD_READY:
        failures.append("self-test failed")
    if manifest and manifest.get("package_decision") != decision:
        failures.append("package decision mismatch")
    validate = {
        "schema": "FAMILY10H_RELATION_ONLY_OFFLINE_VALIDATE_V2",
        "required_artifacts": required,
        "missing_artifacts": missing,
        "failures": failures,
        "grammar_json_parse": True,
        "schedule_json_parse": True,
        "self_test_json_parse": True,
        "build_ready": decision == pub.PACKAGE_DECISION_BUILD_READY,
        "package_decision": decision,
        "zero_target_contact": True,
        "zero_live_activity": True,
        "passed": not failures,
    }
    validate["offline_validate_sha256"] = pub.digest({k: v for k, v in validate.items() if k != "offline_validate_sha256"})
    return validate


def prepare() -> dict[str, Any]:
    grammar = pub.relation_grammar(pub.PACKAGE_DECISION_BLOCKED)
    schedule = pub.build_schedule(grammar)
    pub.write_json(GRAMMAR_JSON, grammar)
    write_grammar_tsv(grammar)
    write_text(GRAMMAR_SHA, pub.sha256_file(GRAMMAR_JSON) + "\n")
    pub.write_schedule_tsv(schedule, SCHEDULE_TSV)
    schedule_tsv_sha = pub.sha256_file(SCHEDULE_TSV)
    pub.write_compact_json(SCHEDULE_JSON, schedule_json_manifest(schedule, schedule_tsv_sha))
    write_text(SCHEDULE_SHA, schedule_tsv_sha + "\n")

    toolchain = discover_toolchains()
    pub.write_json(TOOLCHAIN_DISCOVERY_JSON, toolchain)
    runtime_build = compile_runtime(toolchain)
    pub.write_json(RUNTIME_BUILD_JSON, runtime_build)
    pub.write_json(
        SYNTHETIC_EXECUTOR_SELF_TEST_JSON,
        {
            "schema": "FAMILY10H_RELATION_ONLY_SYNTHETIC_EXECUTOR_SELF_TEST_RECEIPT_V1",
            **runtime_build.get("synthetic_executor_self_test", {}),
        },
    )
    source_bundle = pub.write_source_bundle(SOURCE_BUNDLE, SOURCE_FILES + [CONTRACT_FILE])
    source_hashes_result = source_hashes(source_bundle, runtime_build)
    pub.write_json(SOURCE_HASHES_JSON, source_hashes_result)

    proof = pub.relation_marginal_equality_proof(grammar, schedule, source_hashes_result, runtime_build)
    pub.write_json(PROOF_JSON, proof)
    threshold_contract = physical_adjudication.physical_threshold_contract()
    pub.write_json(PHYSICAL_THRESHOLD_CONTRACT_JSON, threshold_contract)
    physical_self_test = physical_adjudication.run_self_test(schedule)
    pub.write_json(PHYSICAL_ADJUDICATOR_SELF_TEST_JSON, physical_self_test)
    adversary = synthetic_adjudication.run_adversary_tests(schedule)
    pub.write_json(ADVERSARY_JSON, adversary)
    transport = transport_simulation(schedule)
    pub.write_json(TRANSPORT_JSON, transport)

    provisional_readiness = {
        "schema": "FAMILY10H_RELATION_ONLY_BUILD_READINESS_V1",
        "package_decision": pub.PACKAGE_DECISION_BLOCKED,
        "checks": {},
        "blockers": ["provisional_before_target_self_test"],
        "zero_target_contact": True,
        "zero_live_activity": True,
        "live_authority": False,
    }
    provisional_readiness["build_readiness_sha256"] = pub.digest(
        {k: v for k, v in provisional_readiness.items() if k != "build_readiness_sha256"}
    )
    target_stub = {"self_test_passed": False, "provisional": True}
    provisional_self = self_test(grammar, schedule, proof, runtime_build, target_stub, physical_self_test)
    provisional_validate = {"schema": "FAMILY10H_RELATION_ONLY_OFFLINE_VALIDATE_V2", "passed": False}
    manifest = implementation_manifest(
        grammar,
        proof,
        schedule,
        provisional_self,
        adversary,
        transport,
        provisional_validate,
        source_hashes_result,
        runtime_build,
        target_stub,
        physical_self_test,
        threshold_contract,
        provisional_readiness,
    )
    pub.write_json(MANIFEST_JSON, manifest)
    write_text(MANIFEST_SHA, pub.sha256_file(MANIFEST_JSON) + "\n")

    target_self_test = run_target_self_test()
    pub.write_json(TARGET_SELF_TEST_JSON, target_self_test)
    pub.write_json(
        TARGET_PREFLIGHT_SELF_TEST_JSON,
        target_self_test.get(
            "target_preflight_refuses_without_authority",
            {
                "schema": "FAMILY10H_RELATION_ONLY_TARGET_PREFLIGHT_REFUSAL_V1",
                "passed": False,
                "reason": "target self-test did not emit preflight refusal",
            },
        ),
    )
    self_test_result = self_test(grammar, schedule, proof, runtime_build, target_self_test, physical_self_test)
    pub.write_json(SELF_TEST_JSON, self_test_result)
    validate = validate_artifacts()
    readiness = provisional_readiness
    manifest = json.loads(MANIFEST_JSON.read_text(encoding="utf-8"))
    for _ in range(4):
        readiness = build_readiness(proof, runtime_build, target_self_test, physical_self_test, self_test_result, validate)
        pub.write_json(BUILD_READINESS_JSON, readiness)
        manifest = implementation_manifest(
            grammar,
            proof,
            schedule,
            self_test_result,
            adversary,
            transport,
            validate,
            source_hashes_result,
            runtime_build,
            target_self_test,
            physical_self_test,
            threshold_contract,
            readiness,
        )
        pub.write_json(MANIFEST_JSON, manifest)
        write_text(MANIFEST_SHA, pub.sha256_file(MANIFEST_JSON) + "\n")
        next_validate = validate_artifacts()
        pub.write_json(VALIDATE_JSON, next_validate)
        if (
            next_validate["passed"] == validate.get("passed")
            and next_validate["package_decision"] == readiness["package_decision"]
            and manifest["package_decision"] == readiness["package_decision"]
        ):
            validate = next_validate
            break
        validate = next_validate
    return {
        "package_decision": readiness["package_decision"],
        "blockers": readiness["blockers"],
        "grammar_sha256": grammar["grammar_sha256"],
        "marginal_equality_proof_sha256": proof["proof_sha256"],
        "schedule_tuple_count": schedule["tuple_count"],
        "self_test_passed": self_test_result["passed"],
        "runtime_build_passed": runtime_build["passed"],
        "target_self_test_passed": target_self_test.get("self_test_passed") is True,
        "physical_adjudicator_passed": physical_self_test["passed"],
        "adversary_passed": adversary["passed"],
        "transport_passed": transport["passed"],
        "offline_validate_passed": validate["passed"],
        "manifest_sha256": manifest["manifest_sha256"],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args(argv)
    if args.prepare_only:
        result = prepare()
    elif args.validate_only:
        result = validate_artifacts()
    else:
        parser.print_help()
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result.get("passed", result.get("offline_validate_passed", True)) else 1


if __name__ == "__main__":
    raise SystemExit(main())
