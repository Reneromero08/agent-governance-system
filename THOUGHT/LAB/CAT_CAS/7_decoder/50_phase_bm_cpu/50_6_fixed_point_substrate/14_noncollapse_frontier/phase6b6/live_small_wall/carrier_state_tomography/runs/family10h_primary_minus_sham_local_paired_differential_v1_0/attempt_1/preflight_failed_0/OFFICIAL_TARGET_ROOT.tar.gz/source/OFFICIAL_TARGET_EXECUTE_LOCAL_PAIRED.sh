#!/usr/bin/env bash
set -u
SOURCE_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$SOURCE_ROOT"
mkdir -p official_logs official_outputs _relation_spatial_owned_outputs
printf '%s\n' "$(date -u +%FT%TZ)" > OFFICIAL_TARGET_STARTED_UTC.txt
RELATION_MANIFEST_SHA="$(sha256sum RELATION_SPATIAL_IMPLEMENTATION_MANIFEST.json | awk '{print $1}')"
FAMILY10H_RELATION_SPATIAL_LIVE_AUTHORITY="family10h_relation_spatial_pair_readout_v1_1_segmented_0" \
FAMILY10H_RELATION_SPATIAL_SOURCE_AUTHORITY_COMMIT="2cdec9704452669d3651a063b6fb5805913647e3" \
FAMILY10H_RELATION_SPATIAL_FREEZE_COMMIT="8720dd543947f26cbd2af18a6a3dd4870c9adf85" \
FAMILY10H_RELATION_SPATIAL_MANIFEST_SHA256="$RELATION_MANIFEST_SHA" \
python3 -B relation_spatial_target.py --target-preflight --source-root "$SOURCE_ROOT" --output-root "$SOURCE_ROOT/_relation_spatial_owned_outputs/preflight_probe" \
  > official_logs/target_preflight.json 2> official_logs/target_preflight.stderr
preflight_rc=$?
printf '%s\n' "$preflight_rc" > official_logs/target_preflight.rc
python3 - "$preflight_rc" <<'PY'
import json, pathlib, sys
rc = int(sys.argv[1])
path = pathlib.Path("official_logs/target_preflight.json")
try:
    data = json.loads(path.read_text())
except Exception as exc:
    data = {"passed": False, "failures": [f"preflight_json_parse_failed: {exc}"], "returncode": rc}
passed = rc == 0 and data.get("passed") is True
pathlib.Path("official_logs/target_preflight_passed.txt").write_text("true\n" if passed else "false\n")
if not passed:
    pathlib.Path("official_logs/target_preflight_failed.txt").write_text(json.dumps(data.get("failures", [])) + "\n")
sys.exit(0 if passed else 1)
PY
preflight_pass=$?
write_summary() {
python3 - <<'PY'
import hashlib, json, pathlib
root = pathlib.Path(".")
variants = ["round0_query_relation_pair", "round0_relation_sham", "round0_scrambled_pair_control", "round0_distance_matched_control", "round0_route_pressure_control", "round1_query_relation_pair", "round1_relation_sham", "round1_scrambled_pair_control", "round1_distance_matched_control", "round1_route_pressure_control"]
def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
def line_count(path):
    if not path.exists():
        return 0
    with path.open("rb") as handle:
        return sum(1 for line in handle if line.rstrip(b"\r\n"))
def info(path, count=False):
    if not path.exists():
        return {"present": False, "size_bytes": 0, "sha256": None, "line_count": 0 if count else None}
    return {"present": True, "size_bytes": path.stat().st_size, "sha256": sha(path), "line_count": line_count(path) if count else None}
preflight = {}
p = root / "official_logs" / "target_preflight.json"
if p.exists():
    try:
        preflight = json.loads(p.read_text())
    except Exception as exc:
        preflight = {"passed": False, "parse_error": str(exc)}
summary = {
    "schema": "FAMILY10H_LOCAL_PAIRED_DIFFERENTIAL_OFFICIAL_TARGET_RUN_SUMMARY_V1",
    "transaction_run_id": "family10h_primary_minus_sham_local_paired_differential_v1_0",
    "segmented_transaction_run_id": "family10h_relation_spatial_pair_readout_v1_1_segmented_0",
    "runtime_authority": "family10h_relation_spatial_pair_readout_v1_0",
    "attempt_consumed": (root / "ATTEMPT_CONSUMED").exists(),
    "target_preflight": preflight,
    "target_preflight_rc": int((root / "official_logs" / "target_preflight.rc").read_text().strip()) if (root / "official_logs" / "target_preflight.rc").exists() else None,
    "variants": {},
    "small_wall_crossed": False,
}
for variant in variants:
    out = root / "official_outputs" / variant
    rc_path = root / "official_logs" / f"{variant}.rc"
    counts_path = root / "official_logs" / f"{variant}.counts"
    summary["variants"][variant] = {
        "rc": int(rc_path.read_text().strip()) if rc_path.exists() else None,
        "counts_text": counts_path.read_text() if counts_path.exists() else "",
        "raw_records.jsonl": info(out / "raw_records.jsonl", True),
        "pair_observations.jsonl": info(out / "pair_observations.jsonl", True),
        "source_death_receipts.jsonl": info(out / "source_death_receipts.jsonl", True),
        "feature_freeze.json": info(out / "feature_freeze.json"),
        "target_execution_receipt.json": info(out / "target_execution_receipt.json"),
    }
summary["all_variant_rc_zero"] = all(v["rc"] == 0 for v in summary["variants"].values()) if summary["variants"] else False
summary["raw_record_count_total"] = sum(v["raw_records.jsonl"]["line_count"] or 0 for v in summary["variants"].values())
summary["pair_observation_count_total"] = sum(v["pair_observations.jsonl"]["line_count"] or 0 for v in summary["variants"].values())
summary["source_death_receipt_count_total"] = sum(v["source_death_receipts.jsonl"]["line_count"] or 0 for v in summary["variants"].values())
summary["passed"] = (
    summary["attempt_consumed"]
    and summary["target_preflight_rc"] == 0
    and summary["all_variant_rc_zero"]
    and summary["raw_record_count_total"] == 20480
    and summary["pair_observation_count_total"] == 5242880
    and summary["source_death_receipt_count_total"] == 20480
)
payload = json.dumps(summary, indent=2, sort_keys=True)
digest = hashlib.sha256(json.dumps(summary, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
summary["summary_sha256"] = digest
(root / "OFFICIAL_TARGET_RUN_SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
PY
}
if [ "$preflight_pass" -ne 0 ]; then
  write_summary
  exit 23
fi
printf '%s\n' "$(date -u +%FT%TZ)" > ATTEMPT_CONSUMED
overall=0
for variant in round0_query_relation_pair round0_relation_sham round0_scrambled_pair_control round0_distance_matched_control round0_route_pressure_control round1_query_relation_pair round1_relation_sham round1_scrambled_pair_control round1_distance_matched_control round1_route_pressure_control; do
  schedule="$SOURCE_ROOT/LOCAL_PAIRED_DIFFERENTIAL_SCHEDULES/$variant.tsv"
  output="$SOURCE_ROOT/official_outputs/$variant"
  stdout_path="$SOURCE_ROOT/official_logs/$variant.stdout"
  stderr_path="$SOURCE_ROOT/official_logs/$variant.stderr"
  rc_path="$SOURCE_ROOT/official_logs/$variant.rc"
  counts_path="$SOURCE_ROOT/official_logs/$variant.counts"
  if [ -e "$output" ]; then
    echo 97 > "$rc_path"
    echo "output_preexisting" > "$stderr_path"
    overall=97
    continue
  fi
  FAMILY10H_RELATION_SPATIAL_RUNTIME_AUTHORITY="family10h_relation_spatial_pair_readout_v1_0" \
    chrt -f 80 "$SOURCE_ROOT/relation_spatial_runtime" --execute-schedule "$schedule" "$output" \
    > "$stdout_path" 2> "$stderr_path"
  rc=$?
  echo "$rc" > "$rc_path"
  {
    echo "raw_records=$(test -f "$output/raw_records.jsonl" && wc -l < "$output/raw_records.jsonl" || echo 0)"
    echo "pair_observations=$(test -f "$output/pair_observations.jsonl" && wc -l < "$output/pair_observations.jsonl" || echo 0)"
    echo "source_death_receipts=$(test -f "$output/source_death_receipts.jsonl" && wc -l < "$output/source_death_receipts.jsonl" || echo 0)"
  } > "$counts_path"
  if [ "$rc" -ne 0 ]; then
    overall="$rc"
  fi
done
write_summary
printf '%s\n' "$(date -u +%FT%TZ)" > OFFICIAL_TARGET_ENDED_UTC.txt
exit "$overall"
