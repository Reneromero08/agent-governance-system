---
title: MINI_HANDOFF_TEMPLATE_CANON
version: 1.0
status: CANONICAL
generated_on: 2026-01-04
scope: Mini handoff template (<=15 lines)
---
<!-- CANON_HASH: e20229f5fb1b911a5ee64af593c1afcdd9547bd0e31d344cc1d8b8275c298079 -->

# MINI_HANDOFF (<=15 lines)

Thread DNA: <quick Q&A | deep build | debug | planning>
Last topic: <1 line>
Decision log: <1 line: X over Y because Z>
Blockers: <none | 1 line>
Open Qs (deferrable): <comma list>
Next actions: <1–3 short steps, no paths>
Notes: <any constraint/pref worth remembering>
